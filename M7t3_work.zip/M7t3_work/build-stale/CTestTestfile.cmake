# CMake generated Testfile for 
# Source directory: C:/Users/zhang/Desktop/M7t3
# Build directory: C:/Users/zhang/Desktop/M7t3/build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test("M7N_DataLayer" "C:/Users/zhang/Desktop/M7t3/build/TestM7N.exe")
set_tests_properties("M7N_DataLayer" PROPERTIES  _BACKTRACE_TRIPLES "C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;178;add_test;C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;0;")
add_test("M7N_Core" "C:/Users/zhang/Desktop/M7t3/build/TestCore.exe")
set_tests_properties("M7N_Core" PROPERTIES  _BACKTRACE_TRIPLES "C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;179;add_test;C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;0;")
add_test("M7N_Engine" "C:/Users/zhang/Desktop/M7t3/build/TestEngine.exe")
set_tests_properties("M7N_Engine" PROPERTIES  _BACKTRACE_TRIPLES "C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;180;add_test;C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;0;")
add_test("M7N_Net" "C:/Users/zhang/Desktop/M7t3/build/TestNet.exe")
set_tests_properties("M7N_Net" PROPERTIES  TIMEOUT "120" _BACKTRACE_TRIPLES "C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;181;add_test;C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;0;")
add_test("M7N_NetDemo" "C:/Users/zhang/Desktop/M7t3/build/NetDemo.exe" "--simulated")
set_tests_properties("M7N_NetDemo" PROPERTIES  TIMEOUT "120" _BACKTRACE_TRIPLES "C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;182;add_test;C:/Users/zhang/Desktop/M7t3/CMakeLists.txt;0;")
subdirs("third_party/glfw")
