/**
 * @file Sandbox2D.cpp
 * @brief M7N 2D 沙盒：像素美术瓦片地图 + 精灵动画 + 相机跟随 + 批渲染统计。
 *
 * 所有美术资源程序化生成（无外部文件）：
 *   - 8x8 图集（128px）：草地/泥土/石板/水面/沙滩/道路 + 树木/石头/花/芦苇/蘑菇
 *   - 4 帧角色行走图（128x32）
 *   - 径向发光与椭圆阴影
 *
 * 功能演示：
 *   - Renderer2D 同纹理批合并 / 视锥剔除 / 图层排序 / Additive 混合
 *   - SpriteAnimatorSystem 帧动画 + 图集 UV
 *   - Camera2D 跟随、缩放、调试绘制
 *   - ImGui 实时统计（draw call / 精灵 / 瓦片 / 剔除）
 *
 * 无头验证：Sandbox2D.exe --screenshot out.bmp
 * 会创建不可见窗口渲染数帧后抓图退出，不抢前台焦点。
 */
#include <M7N/2D/Animation2D.hpp>
#include <M7N/2D/Components.hpp>
#include <M7N/2D/Math2D.hpp>
#include <M7N/2D/Renderer2D.hpp>
#include <M7N/Core/Input.hpp>
#include <M7N/Core/Log.hpp>
#include <M7N/Platform/Application.hpp>
#include <M7N/Scene/Components.hpp>

#include "imgui.h"
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

using namespace M7N;
using namespace M7N::ECS;
using namespace M7N::Scene;
using namespace M7N::Dim2;

// =====================================================================
// 程序化像素画布
// =====================================================================

namespace {

struct Canvas {
    u32 width = 0;
    u32 height = 0;
    std::vector<u8> pixels;   // RGBA8，行 0 = 图像顶部

    Canvas(u32 w, u32 h) : width(w), height(h), pixels(static_cast<size_t>(w) * h * 4, 0) {}

    void Set(i32 x, i32 y, u8 r, u8 g, u8 b, u8 a = 255) {
        if (x < 0 || y < 0 || x >= static_cast<i32>(width) || y >= static_cast<i32>(height)) return;
        const size_t index = (static_cast<size_t>(y) * width + static_cast<size_t>(x)) * 4;
        pixels[index + 0] = r;
        pixels[index + 1] = g;
        pixels[index + 2] = b;
        pixels[index + 3] = a;
    }

    void Rect(i32 x0, i32 y0, i32 x1, i32 y1, u8 r, u8 g, u8 b, u8 a = 255) {
        for (i32 y = y0; y <= y1; ++y)
            for (i32 x = x0; x <= x1; ++x) Set(x, y, r, g, b, a);
    }

    void Circle(i32 cx, i32 cy, i32 radius, u8 r, u8 g, u8 b, u8 a = 255) {
        for (i32 y = cy - radius; y <= cy + radius; ++y) {
            for (i32 x = cx - radius; x <= cx + radius; ++x) {
                const i32 dx = x - cx, dy = y - cy;
                if (dx * dx + dy * dy <= radius * radius) Set(x, y, r, g, b, a);
            }
        }
    }

    void Ellipse(i32 cx, i32 cy, i32 rx, i32 ry, u8 r, u8 g, u8 b, u8 a = 255) {
        for (i32 y = cy - ry; y <= cy + ry; ++y) {
            for (i32 x = cx - rx; x <= cx + rx; ++x) {
                const f32 nx = static_cast<f32>(x - cx) / static_cast<f32>(rx + 1);
                const f32 ny = static_cast<f32>(y - cy) / static_cast<f32>(ry + 1);
                if (nx * nx + ny * ny <= 1.0f) Set(x, y, r, g, b, a);
            }
        }
    }
};

u32 hash2(i32 x, i32 y, u32 seed) {
    u32 h = static_cast<u32>(x) * 374761393u + static_cast<u32>(y) * 668265263u + seed * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}

/// 上传前垂直翻转：GL 纹理 v=0 是底部，而 Canvas 行 0 是顶部。
std::vector<u8> flippedPixels(const Canvas& canvas) {
    std::vector<u8> out(canvas.pixels.size());
    const size_t rowBytes = static_cast<size_t>(canvas.width) * 4;
    for (u32 y = 0; y < canvas.height; ++y) {
        const u8* src = canvas.pixels.data() + static_cast<size_t>(y) * rowBytes;
        u8* dst = out.data() + static_cast<size_t>(canvas.height - 1 - y) * rowBytes;
        std::memcpy(dst, src, rowBytes);
    }
    return out;
}

// ---------------------------------------------------------------------
// 图集
// ---------------------------------------------------------------------

constexpr i32 kTilePx = 16;
constexpr i32 kAtlasCols = 8;
constexpr i32 kAtlasRows = 8;

enum TileId : i32 {
    TileGrass = 0,
    TileGrass2 = 1,
    TileGrassDark = 2,
    TileDirt = 3,
    TileStone = 4,
    TileWater = 5,
    TileSand = 6,
    TilePath = 7,
    TileTallGrass = 8,
    TileTree = 16,
    TileBush = 17,
    TileRock = 18,
    TileFlower = 19,
    TileReed = 20,
    TileMushroom = 21,
};

void drawGroundTile(Canvas& c, i32 tileX, i32 tileY, u8 r, u8 g, u8 b, u32 seed) {
    const i32 ox = tileX * kTilePx;
    const i32 oy = tileY * kTilePx;
    for (i32 y = 0; y < kTilePx; ++y) {
        for (i32 x = 0; x < kTilePx; ++x) {
            const u32 h = hash2(ox + x, oy + y, seed);
            const i32 d = static_cast<i32>(h % 17) - 8;
            c.Set(ox + x, oy + y,
                  static_cast<u8>(std::clamp(static_cast<i32>(r) + d, 0, 255)),
                  static_cast<u8>(std::clamp(static_cast<i32>(g) + d, 0, 255)),
                  static_cast<u8>(std::clamp(static_cast<i32>(b) + d, 0, 255)));
        }
    }
}

void makeTileAtlas(Canvas& c) {
    // --- 地面 ---
    drawGroundTile(c, 0, 0, 78, 126, 62, 11);    // 草地
    drawGroundTile(c, 1, 0, 68, 112, 54, 21);    // 深草
    drawGroundTile(c, 2, 0, 56, 96, 46, 31);     // 暗草
    drawGroundTile(c, 3, 0, 122, 92, 58, 41);    // 泥土
    drawGroundTile(c, 4, 0, 104, 108, 113, 51);  // 石板
    drawGroundTile(c, 5, 0, 52, 104, 168, 61);   // 水面
    drawGroundTile(c, 6, 0, 200, 180, 122, 71);  // 沙滩
    drawGroundTile(c, 7, 0, 152, 118, 76, 81);   // 道路
    drawGroundTile(c, 0, 1, 86, 136, 66, 91);    // 高草底
    drawGroundTile(c, 1, 1, 96, 100, 106, 101);  // 碎石

    // 草地装饰
    for (i32 y = 2; y < kTilePx - 2; ++y) {
        for (i32 x = 2; x < kTilePx - 2; ++x) {
            if (hash2(x, y, 5) % 37 == 0) c.Set(x, y, 104, 158, 82);
            if (hash2(x, y, 9) % 53 == 0) c.Set(x, y, 54, 94, 46);
        }
    }
    // 道路石块
    for (i32 i = 0; i < 7; ++i) {
        const i32 x = static_cast<i32>(hash2(i, 1, 7) % 13) + 2;
        const i32 y = static_cast<i32>(hash2(i, 2, 7) % 13) + 2;
        c.Rect(7 * kTilePx + x, y, 7 * kTilePx + x + 1, y + 1, 172, 140, 96);
    }
    // 石板裂纹
    for (i32 y = 3; y < kTilePx; ++y) {
        c.Set(4 * kTilePx + 5 + (y / 4), y, 74, 78, 84);
        c.Set(4 * kTilePx + 11, y, 78, 82, 88);
    }
    // 水面波纹
    for (i32 y = 2; y < kTilePx; y += 5) {
        for (i32 x = 1; x < kTilePx - 1; ++x) {
            if ((x + y) % 7 < 4) c.Set(5 * kTilePx + x, y, 94, 148, 206);
        }
    }
    // 沙滩点点
    for (i32 i = 0; i < 20; ++i) {
        const i32 x = static_cast<i32>(hash2(i, 3, 13) % kTilePx);
        const i32 y = static_cast<i32>(hash2(i, 4, 13) % kTilePx);
        c.Set(6 * kTilePx + x, y, 224, 206, 152);
    }
    // 高草叶片（图集第 2 行第 1 格 = tile 8）
    for (i32 i = 0; i < 8; ++i) {
        const i32 x = 2 + static_cast<i32>(hash2(i, 5, 17) % 11);
        c.Rect(x, kTilePx + 8, x, kTilePx + 14, 94, 150, 70);
        c.Set(x, kTilePx + 7, 112, 170, 88);
    }
    // 碎石
    for (i32 i = 0; i < 10; ++i) {
        const i32 x = 1 + static_cast<i32>(hash2(i, 6, 19) % 14);
        const i32 y = 1 + static_cast<i32>(hash2(i, 7, 19) % 14);
        c.Circle(1 * kTilePx + x, kTilePx + y, 1, 132, 136, 140);
    }

    // --- 道具（透明底）---
    // 树 16
    {
        const i32 ox = (TileTree % kAtlasCols) * kTilePx;
        const i32 oy = (TileTree / kAtlasCols) * kTilePx;
        c.Rect(ox + 7, oy + 10, ox + 9, oy + 15, 92, 64, 38);
        c.Circle(ox + 8, oy + 7, 6, 32, 72, 42);
        c.Circle(ox + 4, oy + 9, 5, 36, 80, 46);
        c.Circle(ox + 12, oy + 9, 5, 36, 80, 46);
        c.Circle(ox + 8, oy + 6, 4, 58, 112, 60);
        c.Circle(ox + 5, oy + 8, 3, 72, 132, 70);
        c.Circle(ox + 11, oy + 8, 2, 84, 148, 78);
        c.Set(ox + 7, oy + 4, 116, 180, 96);
    }
    // 灌木 17
    {
        const i32 ox = (TileBush % kAtlasCols) * kTilePx;
        const i32 oy = (TileBush / kAtlasCols) * kTilePx;
        c.Circle(ox + 5, oy + 12, 4, 40, 86, 44);
        c.Circle(ox + 10, oy + 12, 4, 44, 94, 48);
        c.Circle(ox + 8, oy + 9, 4, 56, 112, 58);
        c.Circle(ox + 7, oy + 9, 2, 78, 140, 76);
    }
    // 石头 18
    {
        const i32 ox = (TileRock % kAtlasCols) * kTilePx;
        const i32 oy = (TileRock / kAtlasCols) * kTilePx;
        c.Ellipse(ox + 8, oy + 11, 5, 4, 70, 74, 80);
        c.Ellipse(ox + 8, oy + 10, 4, 3, 118, 122, 128);
        c.Rect(ox + 5, oy + 9, ox + 8, oy + 9, 158, 162, 168);
    }
    // 花 19
    {
        const i32 ox = (TileFlower % kAtlasCols) * kTilePx;
        const i32 oy = (TileFlower / kAtlasCols) * kTilePx;
        c.Rect(ox + 8, oy + 8, ox + 8, oy + 14, 64, 126, 58);
        c.Set(ox + 6, oy + 12, 78, 148, 68);
        c.Circle(ox + 7, oy + 6, 1, 244, 226, 140);
        c.Circle(ox + 9, oy + 6, 1, 244, 226, 140);
        c.Circle(ox + 8, oy + 5, 1, 250, 240, 180);
        c.Set(ox + 8, oy + 7, 214, 104, 96);
    }
    // 芦苇 20
    {
        const i32 ox = (TileReed % kAtlasCols) * kTilePx;
        const i32 oy = (TileReed / kAtlasCols) * kTilePx;
        for (i32 i = 0; i < 5; ++i) {
            const i32 x = ox + 3 + i * 2;
            c.Rect(x, oy + 6, x, oy + 14, 66, 120, 62);
            c.Set(x, oy + 5, 92, 150, 76);
        }
        c.Rect(ox + 5, oy + 3, ox + 5, oy + 6, 138, 104, 60);
        c.Rect(ox + 6, oy + 4, ox + 6, oy + 6, 138, 104, 60);
    }
    // 蘑菇 21
    {
        const i32 ox = (TileMushroom % kAtlasCols) * kTilePx;
        const i32 oy = (TileMushroom / kAtlasCols) * kTilePx;
        c.Rect(ox + 7, oy + 10, ox + 9, oy + 14, 224, 208, 170);
        c.Ellipse(ox + 8, oy + 9, 4, 2, 178, 58, 54);
        c.Set(ox + 6, oy + 8, 240, 220, 200);
        c.Set(ox + 10, oy + 9, 240, 220, 200);
    }
}

// ---------------------------------------------------------------------
// 角色 / 光效
// ---------------------------------------------------------------------

void drawPlayerFrame(Canvas& c, i32 frame, i32 ox) {
    const bool stepA = (frame == 1);
    const bool stepB = (frame == 3);
    const i32 bodyY = (stepA || stepB) ? 13 : 14;

    // 腿 + 靴子（左右交替）
    const i32 leftLeg = stepA ? 10 : (stepB ? 12 : 11);
    const i32 rightLeg = stepA ? 19 : (stepB ? 17 : 18);
    c.Rect(ox + leftLeg, 23, ox + leftLeg + 2, 28, 38, 40, 54);
    c.Rect(ox + rightLeg, 23, ox + rightLeg + 2, 28, 38, 40, 54);
    c.Rect(ox + leftLeg - 1, 27, ox + leftLeg + 3, 29, 90, 60, 36);
    c.Rect(ox + rightLeg - 1, 27, ox + rightLeg + 3, 29, 90, 60, 36);

    // 身体描边 + 外套
    c.Rect(ox + 9, bodyY, ox + 22, 23, 28, 30, 40);
    c.Rect(ox + 10, bodyY + 1, ox + 21, 22, 66, 112, 164);
    c.Rect(ox + 10, bodyY + 1, ox + 15, 22, 82, 134, 190);
    c.Rect(ox + 10, 21, ox + 21, 22, 44, 62, 92);   // 腰带
    c.Set(ox + 16, 21, 224, 192, 108);
    c.Rect(ox + 10, 17, ox + 21, 18, 44, 82, 126);

    // 手臂
    const i32 leftArmY = stepA ? 16 : (stepB ? 14 : 15);
    const i32 rightArmY = stepA ? 14 : (stepB ? 16 : 15);
    c.Rect(ox + 6, leftArmY, ox + 9, leftArmY + 6, 28, 30, 40);
    c.Rect(ox + 7, leftArmY + 1, ox + 9, leftArmY + 5, 82, 134, 190);
    c.Rect(ox + 22, rightArmY, ox + 25, rightArmY + 6, 28, 30, 40);
    c.Rect(ox + 22, rightArmY + 1, ox + 24, rightArmY + 5, 82, 134, 190);
    c.Rect(ox + 6, leftArmY + 5, ox + 9, leftArmY + 7, 238, 196, 156);
    c.Rect(ox + 22, rightArmY + 5, ox + 25, rightArmY + 7, 238, 196, 156);

    // 头 + 头发
    c.Rect(ox + 9, 5, ox + 22, 15, 28, 30, 40);
    c.Rect(ox + 10, 6, ox + 21, 14, 240, 198, 158);
    c.Rect(ox + 10, 6, ox + 21, 8, 92, 62, 38);
    c.Rect(ox + 10, 9, ox + 11, 12, 92, 62, 38);
    c.Rect(ox + 20, 9, ox + 21, 12, 92, 62, 38);

    // 帽子
    c.Rect(ox + 7, 4, ox + 24, 6, 30, 26, 30);
    c.Rect(ox + 8, 5, ox + 23, 6, 176, 66, 52);
    c.Rect(ox + 10, 0, ox + 21, 5, 30, 26, 30);
    c.Rect(ox + 11, 1, ox + 20, 4, 200, 78, 60);
    c.Rect(ox + 11, 4, ox + 20, 4, 126, 44, 38);

    // 眼睛 / 腮红
    c.Set(ox + 13, 11, 32, 32, 42);
    c.Set(ox + 18, 11, 32, 32, 42);
    c.Set(ox + 12, 12, 240, 160, 142);
    c.Set(ox + 19, 12, 240, 160, 142);

    // 背包
    c.Rect(ox + 22, 13, ox + 24, 19, 126, 84, 48);
    c.Rect(ox + 22, 14, ox + 23, 18, 156, 108, 62);
}

void makePlayerSheet(Canvas& c) {
    for (i32 frame = 0; frame < 4; ++frame) {
        drawPlayerFrame(c, frame, frame * 32);
    }
}

void makeGlow(Canvas& c) {
    const f32 cx = (c.width - 1) * 0.5f;
    const f32 cy = (c.height - 1) * 0.5f;
    const f32 maxDist = cx;
    for (u32 y = 0; y < c.height; ++y) {
        for (u32 x = 0; x < c.width; ++x) {
            const f32 dx = (x - cx) / maxDist;
            const f32 dy = (y - cy) / maxDist;
            const f32 d = std::sqrt(dx * dx + dy * dy);
            const f32 a = std::clamp(1.0f - d, 0.0f, 1.0f);
            const f32 alpha = a * a * 255.0f;
            c.Set(static_cast<i32>(x), static_cast<i32>(y), 255, 255, 255,
                  static_cast<u8>(alpha));
        }
    }
}

void makeShadow(Canvas& c) {
    const f32 cx = (c.width - 1) * 0.5f;
    const f32 cy = (c.height - 1) * 0.5f;
    for (u32 y = 0; y < c.height; ++y) {
        for (u32 x = 0; x < c.width; ++x) {
            const f32 dx = (x - cx) / cx;
            const f32 dy = (y - cy) / cy;
            const f32 d = std::sqrt(dx * dx + dy * dy);
            const f32 a = std::clamp(1.0f - d, 0.0f, 1.0f);
            c.Set(static_cast<i32>(x), static_cast<i32>(y), 255, 255, 255,
                  static_cast<u8>(a * a * 210.0f));
        }
    }
}

/// 大号树精灵（48x64，底部为树干根）。
void makeTree(Canvas& c) {
    // 底部软阴影
    c.Ellipse(24, 60, 15, 3, 30, 52, 34, 130);
    // 树干
    c.Rect(20, 38, 27, 61, 34, 28, 24);
    c.Rect(21, 39, 26, 60, 104, 76, 48);
    c.Rect(23, 40, 25, 59, 132, 98, 62);
    c.Rect(22, 54, 25, 55, 78, 56, 36);
    // 树冠描边
    c.Circle(24, 24, 17, 22, 48, 30);
    c.Circle(12, 30, 11, 22, 48, 30);
    c.Circle(36, 30, 11, 22, 48, 30);
    c.Circle(24, 36, 13, 22, 48, 30);
    // 树冠层次
    c.Circle(24, 24, 15, 52, 96, 52);
    c.Circle(13, 30, 9, 48, 90, 48);
    c.Circle(35, 30, 9, 48, 90, 48);
    c.Circle(24, 35, 11, 58, 106, 56);
    c.Circle(18, 20, 8, 74, 132, 68);
    c.Circle(30, 22, 7, 68, 124, 64);
    c.Circle(16, 16, 4, 100, 162, 86);
    c.Circle(32, 35, 4, 90, 148, 76);
    c.Set(20, 13, 132, 190, 104);
}

// ---------------------------------------------------------------------
// 世界构建
// ---------------------------------------------------------------------

struct GlowInfo {
    Entity entity = kNullEntity;
    Entity spriteEntity = kNullEntity;
    Vec3 basePosition = Vec3(0.0f);
    Vec4 color = Vec4(1.0f);
    f32 baseSize = 2.5f;
    f32 phase = 0.0f;
};

struct NpcInfo {
    Entity entity = kNullEntity;
    Vec3 anchor = Vec3(0.0f);
    f32 phase = 0.0f;
    f32 radius = 1.0f;
};

struct FireflyInfo {
    Entity entity = kNullEntity;
    Vec3 anchor = Vec3(0.0f);
    f32 phase = 0.0f;
    f32 radius = 1.0f;
};

constexpr i32 kMapColumns = 48;
constexpr i32 kMapRows = 30;

} // namespace

// =====================================================================
// 沙盒应用
// =====================================================================

class Sandbox2D final : public Application {
public:
    void ConfigureScreenshot(const String& path, u32 frame) {
        screenshotPath_ = path;
        screenshotFrame_ = frame;
    }

protected:
    bool OnStartup() override {
        assets_ = CreateScope<Asset::AssetManager>(GetDevice());
        renderer_ = CreateScope<Renderer2D>(GetDevice(), *assets_);
        if (!renderer_->Init(8192)) return false;
        renderer_->OnResize(GetWidth(), GetHeight());

        createTextures();
        buildWorld();
        initImGui();

        M7N_LOG_INFO("Sandbox2D", "world ready: %u entities", world_.AliveCount());
        return true;
    }

    void OnResize(u32 width, u32 height) override {
        if (renderer_) renderer_->OnResize(width, height);
    }

    void OnUpdate(f32 dt) override {
        time_ += dt;

        // --- 输入 ---
        Input& input = GetInput();
        if (input.IsKeyPressed(Key::F1)) debug_ = !debug_;
        if (input.IsKeyPressed(Key::Escape)) RequestQuit();

        const f32 moveX = (input.IsKeyDown(Key::D) ? 1.0f : 0.0f) -
                          (input.IsKeyDown(Key::A) ? 1.0f : 0.0f);
        const f32 moveY = (input.IsKeyDown(Key::W) ? 1.0f : 0.0f) -
                          (input.IsKeyDown(Key::S) ? 1.0f : 0.0f);
        Vec3 move(moveX, moveY, 0.0f);
        const f32 length = std::sqrt(move.x * move.x + move.y * move.y);
        if (length > 0.0001f) move = move / length;

        Transform* playerTransform = world_.GetComponent<Transform>(player_);
        SpriteComp* playerSprite = world_.GetComponent<SpriteComp>(player_);
        SpriteAnimatorComp* playerAnim = world_.GetComponent<SpriteAnimatorComp>(player_);
        if (playerTransform) {
            const f32 speed = 5.2f;
            playerTransform->position.x += move.x * speed * dt;
            playerTransform->position.y += move.y * speed * dt;
            playerTransform->position.x = std::clamp(playerTransform->position.x,
                                                     -22.0f, 22.0f);
            playerTransform->position.y = std::clamp(playerTransform->position.y,
                                                     -13.0f, 13.0f);
        }
        if (playerSprite) {
            if (moveX < -0.01f) playerSprite->flipX = true;
            else if (moveX > 0.01f) playerSprite->flipX = false;
        }
        if (playerAnim) {
            const bool moving = length > 0.0001f;
            playerAnim->playing = moving;
            if (!moving) {
                playerAnim->currentFrame = 0;
                playerAnim->time = 0.0f;
            } else {
                playerAnim->speed = 1.6f;
            }
        }

        // --- 相机跟随 / 缩放 ---
        Camera2DComp* cameraComp = world_.GetComponent<Camera2DComp>(camera_);
        Transform* cameraTransform = world_.GetComponent<Transform>(camera_);
        if (cameraComp && cameraTransform && playerTransform) {
            const Vec2 scroll = input.ScrollDelta();
            if (std::fabs(scroll.y) > 0.001f) {
                cameraComp->orthoHeight = std::clamp(
                    cameraComp->orthoHeight - scroll.y * 0.8f, 5.0f, 18.0f);
            }
            Vec3 target = playerTransform->position;
            target.y += 0.6f;
            const f32 follow = 1.0f - std::exp(-dt * 6.5f);
            cameraTransform->position.x += (target.x - cameraTransform->position.x) * follow;
            cameraTransform->position.y += (target.y - cameraTransform->position.y) * follow;
        }

        // --- NPC 漫游 ---
        for (const NpcInfo& npc : npcs_) {
            Transform* t = world_.GetComponent<Transform>(npc.entity);
            SpriteComp* sprite = world_.GetComponent<SpriteComp>(npc.entity);
            if (!t) continue;
            const f32 x = npc.anchor.x + std::sin(time_ * 0.55f + npc.phase) * npc.radius;
            const f32 y = npc.anchor.y + std::cos(time_ * 0.43f + npc.phase * 1.7f) * npc.radius * 0.55f;
            if (sprite) {
                if (x < t->position.x - 0.01f) sprite->flipX = true;
                else if (x > t->position.x + 0.01f) sprite->flipX = false;
            }
            t->position.x = x;
            t->position.y = y;
        }

        // --- 光晕脉动 ---
        for (GlowInfo& glow : glows_) {
            SpriteComp* sprite = world_.GetComponent<SpriteComp>(glow.spriteEntity);
            if (!sprite) continue;
            const f32 pulse = 0.86f + 0.14f * std::sin(time_ * 2.2f + glow.phase);
            sprite->size = Vec2(glow.baseSize * pulse, glow.baseSize * pulse);
            sprite->color = Vec4(glow.color.x, glow.color.y, glow.color.z,
                                 glow.color.w * (0.8f + 0.2f * pulse));
        }

        // --- 萤火虫 ---
        for (const FireflyInfo& firefly : fireflies_) {
            Transform* t = world_.GetComponent<Transform>(firefly.entity);
            SpriteComp* sprite = world_.GetComponent<SpriteComp>(firefly.entity);
            if (!t) continue;
            t->position.x = firefly.anchor.x +
                            std::sin(time_ * 0.8f + firefly.phase) * firefly.radius;
            t->position.y = firefly.anchor.y +
                            std::cos(time_ * 1.1f + firefly.phase * 1.7f) *
                            firefly.radius * 0.6f;
            if (sprite) {
                const f32 twinkle = 0.45f + 0.35f * std::sin(time_ * 3.0f + firefly.phase);
                sprite->color.w = twinkle;
            }
        }

        // --- 动画（渲染器内部不重复推进）---
        SpriteAnimatorSystem::OnUpdate(world_, dt);
    }

    void OnRender(f32 dt) override {
        (void)dt;

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        const Camera2D camera = MakeCamera2D(world_, camera_, GetAspect());
        renderer_->BeginScene(camera);
        renderer_->Submit(world_, 0.0f);

        if (debug_) drawDebug(camera);
        renderer_->EndScene();

        drawHud(camera);

        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        ++frame_;
        if (!screenshotPath_.empty() && frame_ >= screenshotFrame_) {
            SaveScreenshot(screenshotPath_);
            screenshotPath_.clear();
        }
    }

    void OnShutdown() override {
        if (ImGui::GetCurrentContext()) {
            ImGui_ImplOpenGL3_Shutdown();
            ImGui_ImplGlfw_Shutdown();
            ImGui::DestroyContext();
        }
        if (renderer_) {
            renderer_->Shutdown();
            renderer_.reset();
        }
        assets_.reset();
    }

private:
    // -----------------------------------------------------------------
    // 资源
    // -----------------------------------------------------------------
    void uploadCanvas(const String& name, Canvas& canvas, bool pixelArt = true) {
        std::vector<u8> flipped = flippedPixels(canvas);
        if (!assets_->RegisterTexture(name, canvas.width, canvas.height,
                                      flipped.data(), pixelArt)) {
            M7N_LOG_ERROR("Sandbox2D", "failed to register texture %s", name.c_str());
        }
    }

    void createTextures() {
        Canvas atlas(kAtlasCols * kTilePx, kAtlasRows * kTilePx);
        makeTileAtlas(atlas);
        uploadCanvas("atlas", atlas);

        Canvas player(128, 32);
        makePlayerSheet(player);
        uploadCanvas("player", player);

        Canvas glow(64, 64);
        makeGlow(glow);
        uploadCanvas("glow", glow);

        Canvas shadow(64, 32);
        makeShadow(shadow);
        uploadCanvas("shadow", shadow);

        Canvas tree(48, 64);
        makeTree(tree);
        uploadCanvas("tree", tree);
    }

    // -----------------------------------------------------------------
    // 世界
    // -----------------------------------------------------------------
    Entity addShadow(Entity parent, f32 width, f32 height) {
        Entity shadow = world_.CreateEntity("Shadow");
        world_.SetParent(shadow, parent);
        Transform& t = world_.AddComponent<Transform>(shadow);
        t.position = Vec3(0.0f, 0.08f, 0.0f);
        SpriteComp& sprite = world_.AddComponent<SpriteComp>(shadow);
        sprite.texture = "shadow";
        sprite.size = Vec2(width, height);
        sprite.pivot = Vec2(0.5f, 0.5f);
        sprite.color = Vec4(0.0f, 0.0f, 0.0f, 0.5f);
        sprite.layer = 4;
        return shadow;
    }

    void buildTilemaps() {
        const Vec2 origin(-static_cast<f32>(kMapColumns) * 0.5f,
                          -static_cast<f32>(kMapRows) * 0.5f);

        Entity groundEntity = world_.CreateEntity("Ground");
        world_.AddComponent<Transform>(groundEntity);
        TilemapComp& ground = world_.AddComponent<TilemapComp>(groundEntity);
        ground.texture = "atlas";
        ground.atlasColumns = kAtlasCols;
        ground.atlasRows = kAtlasRows;
        ground.tileWorldSize = 1.0f;
        ground.origin = origin;
        ground.layer = -20;
        ground.Resize(kMapColumns, kMapRows);

        Entity propsEntity = world_.CreateEntity("Props");
        world_.AddComponent<Transform>(propsEntity);
        TilemapComp& props = world_.AddComponent<TilemapComp>(propsEntity);
        props.texture = "atlas";
        props.atlasColumns = kAtlasCols;
        props.atlasRows = kAtlasRows;
        props.tileWorldSize = 1.0f;
        props.origin = origin;
        props.layer = -10;
        props.Resize(kMapColumns, kMapRows);

        // Emplace 扩容会让先前引用失效：填瓦片前按实体重新取指针。
        TilemapComp* groundMap = world_.GetComponent<TilemapComp>(groundEntity);
        TilemapComp* propsMap = world_.GetComponent<TilemapComp>(propsEntity);
        if (!groundMap || !propsMap) return;

        const f32 lakeX = 18.0f, lakeY = 11.0f;
        const f32 clearingX = 31.0f, clearingY = 14.0f;
        for (i32 y = 0; y < kMapRows; ++y) {
            const i32 pathColumn = 24 + static_cast<i32>(std::sin(y * 0.33f) * 3.0f) +
                                   static_cast<i32>(std::sin(y * 0.11f) * 2.0f);
            for (i32 x = 0; x < kMapColumns; ++x) {
                const u32 h = hash2(x, y, 1337);
                const f32 dx = static_cast<f32>(x) - lakeX;
                const f32 dy = static_cast<f32>(y) - lakeY;
                const f32 lakeDist = std::sqrt(dx * dx + dy * dy * 1.6f);
                const f32 cdx = static_cast<f32>(x) - clearingX;
                const f32 cdy = static_cast<f32>(y) - clearingY;
                const f32 clearingDist = std::sqrt(cdx * cdx + cdy * cdy);

                i32 tile = TileGrass;
                if (lakeDist < 4.2f) {
                    tile = TileWater;
                } else if (lakeDist < 5.8f) {
                    tile = TileSand;
                } else if (clearingDist < 3.6f) {
                    tile = (h % 5 == 0) ? TileDirt : TileStone;
                } else if (std::abs(x - pathColumn) <= 1) {
                    tile = TilePath;
                } else if (h % 23 == 0) {
                    tile = TileDirt;
                } else if (h % 5 == 0) {
                    tile = TileGrass2;
                } else if (h % 11 == 0) {
                    tile = TileGrassDark;
                }
                groundMap->SetTile(x, y, tile);

                // 道具（透明覆盖层）
                const i32 worldX = x;
                const i32 worldY = y;
                const bool nearSpawn = std::abs(worldX - 24) <= 2 && std::abs(worldY - 15) <= 2;
                if (nearSpawn) continue;
                if (tile == TileGrass || tile == TileGrass2 || tile == TileGrassDark) {
                    const u32 r = hash2(x, y, 99) % 200;
                    if (r < 6) propsMap->SetTile(x, y, TileTree);
                    else if (r < 9) propsMap->SetTile(x, y, TileBush);
                    else if (r < 16) propsMap->SetTile(x, y, TileFlower);
                    else if (r < 18) propsMap->SetTile(x, y, TileMushroom);
                } else if (tile == TileStone || tile == TileSand) {
                    if (h % 19 == 0) propsMap->SetTile(x, y, TileRock);
                } else if (tile == TileWater && lakeDist > 3.2f) {
                    if (h % 7 == 0) propsMap->SetTile(x, y, TileReed);
                }
            }
        }
    }

    void buildWorld() {
        buildTilemaps();

        // 玩家
        player_ = world_.CreateEntity("Player");
        Transform& pt = world_.AddComponent<Transform>(player_);
        pt.position = Vec3(0.0f, -0.4f, 0.0f);
        SpriteComp& ps = world_.AddComponent<SpriteComp>(player_);
        ps.texture = "player";
        ps.size = Vec2(1.7f, 1.7f);
        ps.pivot = Vec2(0.5f, 0.08f);
        ps.layer = 5;
        SpriteAnimatorComp& pa = world_.AddComponent<SpriteAnimatorComp>(player_);
        pa.columns = 4;
        pa.rows = 1;
        pa.frameCount = 4;
        pa.fps = 10.0f;
        pa.loop = true;
        addShadow(player_, 1.4f, 0.55f);

        // NPC
        const Vec4 npcTints[3] = {
            Vec4(0.80f, 1.0f, 0.86f, 1.0f),
            Vec4(1.0f, 0.82f, 0.80f, 1.0f),
            Vec4(0.82f, 0.90f, 1.0f, 1.0f),
        };
        const Vec3 npcAnchors[3] = {
            Vec3(-4.5f, 2.0f, 0.0f), Vec3(5.5f, -2.5f, 0.0f), Vec3(3.0f, 5.0f, 0.0f),
        };
        for (i32 i = 0; i < 3; ++i) {
            Entity npc = world_.CreateEntity("Npc");
            Transform& t = world_.AddComponent<Transform>(npc);
            t.position = npcAnchors[i];
            SpriteComp& sprite = world_.AddComponent<SpriteComp>(npc);
            sprite.texture = "player";
            sprite.size = Vec2(1.6f, 1.6f);
            sprite.pivot = Vec2(0.5f, 0.08f);
            sprite.color = npcTints[i];
            sprite.layer = 5;
            SpriteAnimatorComp& anim = world_.AddComponent<SpriteAnimatorComp>(npc);
            anim.columns = 4;
            anim.rows = 1;
            anim.startFrame = 1 + i;
            anim.frameCount = 1;
            anim.fps = 2.0f;
            addShadow(npc, 1.3f, 0.5f);
            npcs_.push_back(NpcInfo{ npc, npcAnchors[i],
                                     static_cast<f32>(i) * 2.1f, 1.2f + i * 0.5f });
        }

        // 大号树木（精灵，比瓦片小树更有层次）
        const Vec3 treePositions[4] = {
            Vec3(-6.2f, -1.2f, 0.0f), Vec3(5.4f, -3.2f, 0.0f),
            Vec3(4.6f, 3.6f, 0.0f), Vec3(-5.2f, 4.2f, 0.0f),
        };
        for (const Vec3& position : treePositions) {
            Entity tree = world_.CreateEntity("Tree");
            Transform& t = world_.AddComponent<Transform>(tree);
            t.position = position;
            SpriteComp& sprite = world_.AddComponent<SpriteComp>(tree);
            sprite.texture = "tree";
            sprite.size = Vec2(3.4f, 4.5f);
            sprite.pivot = Vec2(0.5f, 0.04f);
            sprite.layer = -5;
        }

        // 光晕（Additive）
        struct GlowDef { Vec3 pos; Vec4 color; f32 size; };
        const GlowDef defs[5] = {
            { Vec3(-5.0f, 1.2f, 0.0f), Vec4(1.0f, 0.62f, 0.24f, 0.95f), 3.2f },
            { Vec3(4.6f, 2.6f, 0.0f), Vec4(0.35f, 0.8f, 1.0f, 0.7f), 2.6f },
            { Vec3(-2.6f, -2.6f, 0.0f), Vec4(1.0f, 0.42f, 0.52f, 0.7f), 2.2f },
            { Vec3(5.2f, -1.4f, 0.0f), Vec4(0.7f, 1.0f, 0.5f, 0.6f), 2.8f },
            { Vec3(0.8f, 3.8f, 0.0f), Vec4(0.8f, 0.55f, 1.0f, 0.6f), 2.4f },
        };
        for (const GlowDef& def : defs) {
            Entity glow = world_.CreateEntity("Glow");
            Transform& t = world_.AddComponent<Transform>(glow);
            t.position = def.pos;
            SpriteComp& sprite = world_.AddComponent<SpriteComp>(glow);
            sprite.texture = "glow";
            sprite.size = Vec2(def.size, def.size);
            sprite.color = def.color;
            sprite.layer = 8;
            sprite.blendMode = static_cast<i32>(SpriteBlendMode::Additive);
            glows_.push_back(GlowInfo{ glow, glow, def.pos, def.color, def.size,
                                       static_cast<f32>(glows_.size()) * 1.7f });
        }

        // 萤火虫（小 Additive 光点）
        for (i32 i = 0; i < 8; ++i) {
            Entity firefly = world_.CreateEntity("Firefly");
            Transform& t = world_.AddComponent<Transform>(firefly);
            t.position = Vec3(static_cast<f32>((i % 4) - 2) * 2.2f,
                              static_cast<f32>(i / 4) * 2.0f - 0.5f, 0.0f);
            SpriteComp& sprite = world_.AddComponent<SpriteComp>(firefly);
            sprite.texture = "glow";
            sprite.size = Vec2(0.32f, 0.32f);
            sprite.color = Vec4(1.0f, 0.95f, 0.55f, 0.65f);
            sprite.layer = 7;
            sprite.blendMode = static_cast<i32>(SpriteBlendMode::Additive);
            fireflies_.push_back(FireflyInfo{ firefly, t.position,
                                              static_cast<f32>(i) * 1.3f, 1.4f });
        }

        // 相机
        camera_ = world_.CreateEntity("Camera2D");
        Transform& ct = world_.AddComponent<Transform>(camera_);
        ct.position = Vec3(0.0f, 0.6f, 0.0f);
        Camera2DComp& cam = world_.AddComponent<Camera2DComp>(camera_);
        cam.orthoHeight = 9.0f;
        cam.clearColor = Vec4(0.045f, 0.065f, 0.075f, 1.0f);
        cam.primary = true;
    }

    // -----------------------------------------------------------------
    // 调试 / HUD
    // -----------------------------------------------------------------
    void drawDebug(const Camera2D& camera) {
        const Rect2D bounds = camera.WorldBounds();
        const Vec4 border(0.25f, 0.95f, 0.55f, 0.5f);
        const Vec2 corners[4] = {
            Vec2(bounds.min.x, bounds.min.y), Vec2(bounds.max.x, bounds.min.y),
            Vec2(bounds.max.x, bounds.max.y), Vec2(bounds.min.x, bounds.max.y),
        };
        for (i32 i = 0; i < 4; ++i) {
            renderer_->DrawLine(corners[i], corners[(i + 1) % 4], 0.03f, border);
        }

        // 世界网格（2 单位）
        const Vec4 gridColor(1.0f, 1.0f, 1.0f, 0.06f);
        for (f32 x = std::floor(bounds.min.x / 2.0f) * 2.0f;
             x <= bounds.max.x; x += 2.0f) {
            renderer_->DrawLine(Vec2(x, bounds.min.y), Vec2(x, bounds.max.y),
                                0.012f, gridColor);
        }
        for (f32 y = std::floor(bounds.min.y / 2.0f) * 2.0f;
             y <= bounds.max.y; y += 2.0f) {
            renderer_->DrawLine(Vec2(bounds.min.x, y), Vec2(bounds.max.x, y),
                                0.012f, gridColor);
        }

        // 玩家 / NPC 包围盒
        world_.ForEach<Transform, SpriteComp>(
            [&](Entity e, Transform& t, SpriteComp& sprite) {
                if (sprite.layer != 5) return;
                const bool isPlayer = (e == player_);
                const Vec4 color = isPlayer ? Vec4(0.3f, 1.0f, 0.4f, 0.9f)
                                            : Vec4(1.0f, 0.9f, 0.3f, 0.7f);
                renderer_->DrawRectOutline(Vec2(t.position.x, t.position.y + 0.8f),
                                           Vec2(1.4f, 1.5f), 0.0f, 0.025f, color);
            });
    }

    void drawHud(const Camera2D& camera) {
        const Renderer2DStats& stats = renderer_->GetStats();

        ImGui::SetNextWindowPos(ImVec2(12.0f, 12.0f), ImGuiCond_Once);
        ImGui::SetNextWindowBgAlpha(0.82f);
        const ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration |
                                       ImGuiWindowFlags_AlwaysAutoResize |
                                       ImGuiWindowFlags_NoMove |
                                       ImGuiWindowFlags_NoSavedSettings |
                                       ImGuiWindowFlags_NoFocusOnAppearing |
                                       ImGuiWindowFlags_NoNav;
        if (ImGui::Begin("M7Next 2D Sandbox", nullptr, flags)) {
            ImGui::TextColored(ImVec4(1.0f, 0.78f, 0.35f, 1.0f), "M7Next 2D Sandbox");
            ImGui::TextDisabled("M7N v3 - batched sprites / tilemap / animation");
            ImGui::Separator();
            const f32 dtUi = ImGui::GetIO().DeltaTime;
            const int displayFps = (fps_ > 0) ? fps_
                : (dtUi > 0.0001f ? static_cast<int>(1.0f / dtUi) : 0);
            ImGui::Text("FPS        %d", displayFps);
            ImGui::Text("Draw calls %u   Batches %u", stats.drawCalls, stats.batches);
            ImGui::Text("Sprites    %u", stats.sprites);
            ImGui::Text("Tiles      %u", stats.tiles);
            ImGui::Text("Culled     %u", stats.culled);
            ImGui::Text("Quads      %u", stats.quads);
            ImGui::Separator();
            ImGui::Text("Camera     %.1f, %.1f", camera.position.x, camera.position.y);
            ImGui::Text("Zoom       %.1f", camera.orthoHeight);
            ImGui::Text("Entities   %u", world_.AliveCount());
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.55f, 0.85f, 1.0f, 1.0f),
                               "WASD move   Wheel zoom");
            ImGui::TextColored(ImVec4(0.55f, 0.85f, 1.0f, 1.0f),
                               "F1 debug    Esc quit");
        }
        ImGui::End();

        // FPS 统计（0.5s 窗口）
        fpsTimer_ += ImGui::GetIO().DeltaTime;
        fpsFrames_++;
        if (fpsTimer_ >= 0.5) {
            fps_ = static_cast<int>(static_cast<f32>(fpsFrames_) / fpsTimer_);
            fpsTimer_ = 0.0;
            fpsFrames_ = 0;
            if (screenshotPath_.empty()) {
                SetTitle("M7Next 2D Sandbox | " + std::to_string(fps_) + " FPS");
            }
        }
    }

    void initImGui() {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        io.IniFilename = nullptr;
        ImGui::StyleColorsDark();
        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowRounding = 8.0f;
        style.FrameRounding = 5.0f;
        style.WindowBorderSize = 0.0f;
        style.Colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.08f, 0.10f, 0.85f);
        ImGui_ImplGlfw_InitForOpenGL(GetNativeWindow(), true);
        ImGui_ImplOpenGL3_Init("#version 330");
    }

    Scope<Asset::AssetManager> assets_;
    Scope<Renderer2D> renderer_;
    World world_;
    Entity camera_ = kNullEntity;
    Entity player_ = kNullEntity;
    std::vector<NpcInfo> npcs_;
    std::vector<GlowInfo> glows_;
    std::vector<FireflyInfo> fireflies_;
    bool debug_ = true;
    f32 time_ = 0.0f;
    u32 frame_ = 0;
    u32 screenshotFrame_ = 8;
    String screenshotPath_;
    f32 fpsTimer_ = 0.0f;
    i32 fpsFrames_ = 0;
    i32 fps_ = 0;
};

// =====================================================================
// main
// =====================================================================

int main(int argc, char** argv) {
    String screenshotPath;
    u32 frames = 0;
    for (int i = 1; i < argc; ++i) {
        const String arg = argv[i];
        if (arg == "--screenshot" && i + 1 < argc) {
            screenshotPath = argv[++i];
            frames = 12;
        }
    }

    AppConfig config;
    config.title = "M7Next 2D Sandbox";
    config.width = 1280;
    config.height = 720;
    config.vsync = true;
    config.visible = screenshotPath.empty();
    config.fixedStep = 0.0f;

    Sandbox2D app;
    app.ConfigureScreenshot(screenshotPath, 10);
    if (!app.Init(config)) return 1;
    return app.Run(frames);
}
