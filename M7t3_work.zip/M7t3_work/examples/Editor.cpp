/**
 * @file Editor.cpp
 * @brief M7N-3 编辑器验收示例：三面板 + Play/Stop 双 World。
 *
 * 面板：
 *   Hierarchy —— 场景树（递归子节点，点击选中，按钮增删实体）
 *   Inspector —— 选中实体的组件属性编辑（反射表驱动，零手写 UI）
 *   Stats     —— 实体计数 / 存储规模 / FPS / 模式
 *
 * Play/Stop 语义（多 World 隔离的价值证明）：
 *   Play(F5) = 编辑世界序列化 -> 临时文件 -> 加载进 playWorld，仅 playWorld 跑系统
 *   Stop(Esc)= 丢弃 playWorld，编辑世界从未被运行时污染
 */
#include <M7N/2D/Animation2D.hpp>
#include <M7N/2D/Components.hpp>
#include <M7N/Net/Replication.hpp>
#include <M7N/RHI/IRenderDevice.hpp>
#include <M7N/Scene/Components.hpp>
#include <M7N/Scene/SceneSerializer.hpp>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "imgui.h"
#include "backends/imgui_impl_glfw.h"
#include "backends/imgui_impl_opengl3.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

using namespace M7N;
using namespace M7N::ECS;
using namespace M7N::Scene;
using namespace M7N::RHI;

// =====================================================================
// 着色器与网格数据
// =====================================================================

namespace {

constexpr const char* kVert = R"(
#version 330 core
layout(location = 0) in vec3 a_Position;
layout(location = 1) in vec3 a_Color;
uniform mat4 u_MVP;
uniform vec3 u_Tint;
out vec3 v_Color;
void main() {
    v_Color = a_Color * u_Tint;
    gl_Position = u_MVP * vec4(a_Position, 1.0);
}
)";

constexpr const char* kFrag = R"(
#version 330 core
in vec3 v_Color;
out vec4 FragColor;
void main() { FragColor = vec4(v_Color, 1.0); }
)";

/// 白色立方体（24 顶点 pos+color，顶点色全 1，靠 u_Tint 染色）。
constexpr f32 kCube[] = {
    -1,-1, 1,   1,1,1,    1,-1, 1,   1,1,1,    1, 1, 1,   1,1,1,   -1, 1, 1,   1,1,1,
     1,-1,-1,   1,1,1,   -1,-1,-1,   1,1,1,   -1, 1,-1,   1,1,1,    1, 1,-1,   1,1,1,
    -1, 1, 1,   1,1,1,    1, 1, 1,   1,1,1,    1, 1,-1,   1,1,1,   -1, 1,-1,   1,1,1,
    -1,-1,-1,   1,1,1,    1,-1,-1,   1,1,1,    1,-1, 1,   1,1,1,   -1,-1, 1,   1,1,1,
     1,-1, 1,   1,1,1,    1,-1,-1,   1,1,1,    1, 1,-1,   1,1,1,    1, 1, 1,   1,1,1,
    -1,-1,-1,   1,1,1,   -1,-1, 1,   1,1,1,   -1, 1, 1,   1,1,1,   -1, 1,-1,   1,1,1,
};

constexpr u32 kIndices[] = {
     0, 1, 2,  0, 2, 3,   4, 5, 6,  4, 6, 7,   8, 9,10,  8,10,11,
    12,13,14, 12,14,15,  16,17,18, 16,18,19,  20,21,22, 20,22,23,
};

/// 名字哈希 -> 稳定色彩（每个实体一种颜色）。
Vec3 ColorOf(const String& name) {
    u32 h = 2166136261u;
    for (char c : name) { h ^= static_cast<u8>(c); h *= 16777619u; }
    return Vec3(0.45f + 0.5f * ((h >>  0) & 0xFF) / 255.0f,
                0.45f + 0.5f * ((h >>  8) & 0xFF) / 255.0f,
                0.45f + 0.5f * ((h >> 16) & 0xFF) / 255.0f);
}

Entity g_selected{ kInvalidIndex, 0 };

} // namespace

// =====================================================================
// 反射驱动的属性编辑（Inspector 核心：新增组件只需注册反射）
// =====================================================================

namespace {

/// 单属性编辑控件；写穿组件内存。
bool EditProperty(void* base, const Reflect::PropertyInfo& prop) {
    u8* p = static_cast<u8*>(base) + prop.offset;
    ImGui::PushID(static_cast<int>(prop.offset * 31 + static_cast<u32>(prop.type)));
    ImGui::TableNextRow();
    ImGui::TableSetColumnIndex(0);
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted(prop.name);
    ImGui::TableSetColumnIndex(1);
    ImGui::SetNextItemWidth(-1.0f);

    bool changed = false;
    switch (prop.type) {
        case Reflect::PropType::Float: {
            f32 v; std::memcpy(&v, p, sizeof(f32));
            if (ImGui::DragFloat("##v", &v, 0.05f)) changed = true;
            std::memcpy(p, &v, sizeof(f32));
            break;
        }
        case Reflect::PropType::Int32: {
            i32 v; std::memcpy(&v, p, sizeof(i32));
            if (ImGui::InputInt("##v", &v)) changed = true;
            std::memcpy(p, &v, sizeof(i32));
            break;
        }
        case Reflect::PropType::Bool: {
            bool v; std::memcpy(&v, p, sizeof(bool));
            if (ImGui::Checkbox("##v", &v)) changed = true;
            std::memcpy(p, &v, sizeof(bool));
            break;
        }
        case Reflect::PropType::String: {
            auto* s = reinterpret_cast<String*>(p);
            char buf[256];
            std::snprintf(buf, sizeof(buf), "%s", s->c_str());
            if (ImGui::InputText("##v", buf, sizeof(buf))) { *s = buf; changed = true; }
            break;
        }
        case Reflect::PropType::Vec2: {
            auto* v = reinterpret_cast<Vec2*>(p);
            if (ImGui::DragFloat2("##v", &v->x, 0.05f)) changed = true;
            break;
        }
        case Reflect::PropType::Vec3: {
            auto* v = reinterpret_cast<Vec3*>(p);
            if (ImGui::DragFloat3("##v", &v->x, 0.05f)) changed = true;
            break;
        }
        case Reflect::PropType::Vec4: {
            auto* v = reinterpret_cast<Vec4*>(p);
            if (ImGui::DragFloat4("##v", &v->x, 0.05f)) changed = true;
            break;
        }
        case Reflect::PropType::Quat: {
            auto* q = reinterpret_cast<Quat*>(p);
            f32 v[4] = { q->x, q->y, q->z, q->w };
            if (ImGui::DragFloat4("##v", v, 0.01f)) {
                q->x = v[0]; q->y = v[1]; q->z = v[2]; q->w = v[3];
                changed = true;
            }
            break;
        }
        case Reflect::PropType::Int32Array: {
            auto* arr = reinterpret_cast<std::vector<i32>*>(p);
            ImGui::TextDisabled("%zu values", arr->size());
            break;
        }
    }
    ImGui::PopID();
    return changed;
}

/// 单组件区块：折叠头 + 属性表 + 删除按钮。
template <typename T>
bool DrawComponentBlock(World& world, Entity e) {
    T* comp = world.GetComponent<T>(e);
    if (!comp) return false;

    const Reflect::TypeInfo& info = Reflect::TypeOf<T>::Get();
    bool open = ImGui::CollapsingHeader(info.name, ImGuiTreeNodeFlags_DefaultOpen);

    ImGui::SameLine(ImGui::GetContentRegionAvail().x - 24.0f);
    ImGui::PushID("rm");
    bool remove = ImGui::SmallButton("-");
    ImGui::PopID();

    if (open && !remove) {
        if (ImGui::BeginTable("props", 2, ImGuiTableFlags_SizingStretchProp)) {
            ImGui::TableSetupColumn("name", ImGuiTableColumnFlags_WidthFixed, 90.0f);
            ImGui::TableSetupColumn("value");
            for (u32 i = 0; i < info.propCount; i++) {
                EditProperty(comp, info.props[i]);
            }
            ImGui::EndTable();
        }
    }
    if (remove) world.RemoveComponent<T>(e);
    return true;
}

void DrawInspector(World& world, Entity e) {
    ImGui::Text("Entity: %s", world.GetName(e).c_str());
    ImGui::TextDisabled("handle #%u  gen %u", e.index, e.generation);
    ImGui::Separator();

    bool any = DrawComponentBlock<Transform>(world, e);
    any |= DrawComponentBlock<MeshRef>(world, e);
    any |= DrawComponentBlock<CameraComp>(world, e);
    any |= DrawComponentBlock<Dim2::SpriteComp>(world, e);
    any |= DrawComponentBlock<Dim2::Camera2DComp>(world, e);
    any |= DrawComponentBlock<Dim2::SpriteAnimatorComp>(world, e);
    any |= DrawComponentBlock<Dim2::TilemapComp>(world, e);
    any |= DrawComponentBlock<Net::NetworkIdentity>(world, e);
    if (!any) ImGui::TextDisabled("(no components)");

    ImGui::Separator();
    if (ImGui::Button("Add Transform")) world.AddComponent<Transform>(e);
    ImGui::SameLine();
    if (ImGui::Button("Add MeshRef"))   world.AddComponent<MeshRef>(e);
    ImGui::SameLine();
    if (ImGui::Button("Add Camera"))    world.AddComponent<CameraComp>(e);
    ImGui::SameLine();
    if (ImGui::Button("Add Sprite"))    world.AddComponent<Dim2::SpriteComp>(e);
    ImGui::SameLine();
    if (ImGui::Button("Add Camera2D"))  world.AddComponent<Dim2::Camera2DComp>(e);
    if (ImGui::Button("Add SpriteAnim")) world.AddComponent<Dim2::SpriteAnimatorComp>(e);
    ImGui::SameLine();
    if (ImGui::Button("Add Tilemap"))   world.AddComponent<Dim2::TilemapComp>(e);
    ImGui::SameLine();
    if (ImGui::Button("Add NetworkId")) world.AddComponent<Net::NetworkIdentity>(e);
}

} // namespace

// =====================================================================
// Hierarchy：场景树
// =====================================================================

namespace {

void DrawEntityNode(World& world, Entity e) {
    ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_OpenOnArrow
                             | ImGuiTreeNodeFlags_SpanAvailWidth;
    const auto& kids = world.GetChildren(e);
    if (kids.empty()) flags |= ImGuiTreeNodeFlags_Leaf;

    bool opened = ImGui::TreeNodeEx(world.GetName(e).c_str(), flags);
    if (ImGui::IsItemClicked()) g_selected = e;

    if (ImGui::IsItemHovered()) {
        String comps;
        if (world.HasComponent<Transform>(e))  comps += "Transform ";
        if (world.HasComponent<MeshRef>(e))    comps += "MeshRef ";
        if (world.HasComponent<CameraComp>(e)) comps += "Camera ";
        if (world.HasComponent<Dim2::SpriteComp>(e)) comps += "Sprite ";
        if (world.HasComponent<Dim2::TilemapComp>(e)) comps += "Tilemap ";
        if (world.HasComponent<Net::NetworkIdentity>(e)) comps += "NetId";
        if (!comps.empty()) ImGui::SetTooltip("%s", comps.c_str());
    }

    if (opened) {
        for (Entity c : kids) DrawEntityNode(world, c);
        ImGui::TreePop();
    }
}

void DrawHierarchy(World& world) {
    if (ImGui::Button("+ Add Entity")) {
        Entity e = world.CreateEntity("Entity");
        if (world.IsAlive(g_selected)) world.SetParent(e, g_selected);
    }
    ImGui::SameLine();
    ImGui::BeginDisabled(!world.IsAlive(g_selected));
    if (ImGui::Button("Delete Selected")) {
        world.DestroyEntity(g_selected);
        g_selected = kNullEntity;
    }
    ImGui::EndDisabled();

    ImGui::Separator();

    std::vector<Entity> roots;
    world.ForEachEntity([&](Entity e) {
        if (!world.GetParent(e).IsValid()) roots.push_back(e);
    });
    std::sort(roots.begin(), roots.end(), [&](Entity a, Entity b) {
        return world.GetName(a) < world.GetName(b);
    });
    for (Entity r : roots) DrawEntityNode(world, r);
}

} // namespace

// =====================================================================
// Play 模式系统：旋转 + 浮动（只跑在 playWorld 上）
// =====================================================================

namespace {

void PlaySystem(World& world, f32 t, f32 dt) {
    world.ForEach<Transform, MeshRef>([&](Entity e, Transform& tr, MeshRef&) {
        tr.rotation.y += dt * 1.2f;
        tr.rotation.x += dt * 0.4f;
        tr.position.y = 0.5f * std::sin(t * 2.0f + static_cast<f32>(e.index));
    });
}

/// 编辑器序列化组件集：3D 场景 + 2D 组件 + 网络身份（Play 完整拷贝）。
bool SaveScene(World& world, const String& path) {
    return SceneSerializer::Save<Transform, MeshRef, CameraComp,
                                 Dim2::SpriteComp, Dim2::Camera2DComp,
                                 Dim2::SpriteAnimatorComp, Dim2::TilemapComp,
                                 Net::NetworkIdentity>(world, path);
}

bool LoadScene(World& world, const String& path) {
    return SceneSerializer::Load<Transform, MeshRef, CameraComp,
                                  Dim2::SpriteComp, Dim2::Camera2DComp,
                                  Dim2::SpriteAnimatorComp, Dim2::TilemapComp,
                                  Net::NetworkIdentity>(world, path);
}

} // namespace

// =====================================================================
// 主程序
// =====================================================================

int main() {
    if (!glfwInit()) return 1;

    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(1600, 900,
                                          "M7Next Editor (M7N-3)", nullptr, nullptr);
    if (!window) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    if (!gladLoadGLLoader(reinterpret_cast<GLADloadproc>(glfwGetProcAddress))) {
        std::fprintf(stderr, "glad init failed\n");
        return 1;
    }

    // --- ImGui ---
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init("#version 330");

    // --- RHI 资源 ---
    auto device = CreateGLDevice();
    if (!device) return 1;

    BufferHandle vbo = device->CreateBuffer({ kCube, sizeof(kCube),
                                              BufferUsage::Vertex, false });
    BufferHandle ibo = device->CreateBuffer({ kIndices, sizeof(kIndices),
                                              BufferUsage::Index, false });
    ShaderHandle shader = device->CreateShader({ kVert, kFrag });
    PipelineDesc pipe;
    pipe.shader = shader;
    pipe.layout = { { 0, 3, 24, 0, false }, { 1, 3, 24, 12, false } };
    pipe.cull = true;
    PipelineHandle pipeline = device->CreatePipeline(pipe);

    // --- 双世界：编辑（持久）/ 播放（Play 时深拷贝）---
    World editorWorld;
    World playWorld;
    bool playing = false;
    double simTime = 0.0;

    {
        Entity root = editorWorld.CreateEntity("Pillar");
        editorWorld.AddComponent<Transform>(root).position = Vec3(0.0f, 0.5f, 0.0f);
        editorWorld.AddComponent<MeshRef>(root).path = "cube";

        const char* kidNames[] = { "Orb_Red", "Orb_Green", "Orb_Blue", "Orb_Gold" };
        for (int i = 0; i < 4; i++) {
            Entity k = editorWorld.CreateEntity(kidNames[i]);
            Transform& t = editorWorld.AddComponent<Transform>(k);
            f32 a = i * (6.2831853f / 4.0f);
            t.position = Vec3(2.2f * std::cos(a), 0.8f + 0.4f * i, 2.2f * std::sin(a));
            t.scale = Vec3(0.35f);
            editorWorld.AddComponent<MeshRef>(k).path = "cube";

            Entity sat = editorWorld.CreateEntity(String(kidNames[i]) + "_Sat");
            Transform& st = editorWorld.AddComponent<Transform>(sat);
            st.position = Vec3(0.8f, 0.0f, 0.0f);
            st.scale = Vec3(0.4f);
            editorWorld.AddComponent<MeshRef>(sat).path = "cube";

            editorWorld.SetParent(sat, k);
            editorWorld.SetParent(k, root);
        }

        Entity cam = editorWorld.CreateEntity("MainCamera");
        editorWorld.AddComponent<CameraComp>(cam).fovYDeg = 50.0f;
        g_selected = root;
    }

    CommandList cmd;
    double last = glfwGetTime();
    double fpsTimer = 0.0;
    int frames = 0, lastFps = 0;

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        double now = glfwGetTime();
        f32 dt = static_cast<f32>(now - last);
        last = now;

        fpsTimer += dt; frames++;
        if (fpsTimer >= 0.5) {
            lastFps = static_cast<int>(frames / fpsTimer);
            fpsTimer = 0.0; frames = 0;
        }

        World& active = playing ? playWorld : editorWorld;
        if (playing) {
            simTime += dt;
            PlaySystem(playWorld, static_cast<f32>(simTime), dt);
            Dim2::SpriteAnimatorSystem::OnUpdate(playWorld, dt);
        }

        // --- 3D 视口：场景先渲染，UI 面板浮于其上 ---
        int w, h;
        glfwGetFramebufferSize(window, &w, &h);
        f32 aspect = (h > 0) ? static_cast<f32>(w) / static_cast<f32>(h) : 1.0f;
        Mat4 proj = glm::perspective(glm::radians(50.0f), aspect, 0.1f, 200.0f);
        Mat4 view = glm::lookAt(Vec3(7.0f, 6.0f, 10.0f), Vec3(0.0f, 1.0f, 0.0f),
                                Vec3(0.0f, 1.0f, 0.0f));

        cmd.Reset();
        cmd.Clear(0.10f, 0.11f, 0.15f, 1.0f);
        cmd.SetViewport(0, 0, w, h);
        cmd.BindPipeline(pipeline);
        cmd.BindVertexBuffer(vbo);
        cmd.BindIndexBuffer(ibo);
        active.ForEach<Transform, MeshRef>([&](Entity e, Transform&, MeshRef&) {
            cmd.SetMat4("u_MVP", proj * view * ComputeWorldMatrix(active, e));
            cmd.SetVec3("u_Tint", ColorOf(active.GetName(e)));
            cmd.DrawIndexed(36);
        });
        device->BeginFrame();
        device->Submit(cmd);

        // --- ImGui ---
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();

        // 顶部菜单栏
        ImGui::BeginMainMenuBar();
        if (ImGui::BeginMenu("World")) {
            if (!playing) {
                if (ImGui::MenuItem("Play", "F5")) {
                    SaveScene(editorWorld, "m7n_editor_play.json");
                    playWorld.Clear();
                    LoadScene(playWorld, "m7n_editor_play.json");
                    playing = true;
                    simTime = 0.0;
                }
            } else {
                if (ImGui::MenuItem("Stop", "Esc")) {
                    playing = false;
                    playWorld.Clear();
                }
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Save Scene")) {
                SaveScene(editorWorld, "editor_scene.json");
            }
            if (ImGui::MenuItem("Load Scene")) {
                editorWorld.Clear();
                LoadScene(editorWorld, "editor_scene.json");
                g_selected = kNullEntity;
            }
            ImGui::EndMenu();
        }
        ImGui::TextUnformatted(playing ? "| PLAYING (playWorld)" : "| EDITING (editorWorld)");
        ImGui::EndMainMenuBar();

        // 快捷键
        if (!playing && ImGui::IsKeyPressed(ImGuiKey_F5, false)) {
            SaveScene(editorWorld, "m7n_editor_play.json");
            playWorld.Clear();
            LoadScene(playWorld, "m7n_editor_play.json");
            playing = true;
            simTime = 0.0;
        }
        if (playing && ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
            playing = false;
            playWorld.Clear();
        }

        ImGui::Begin("Hierarchy");
        DrawHierarchy(editorWorld);   // 层级编辑永远作用于编辑世界
        ImGui::End();

        ImGui::Begin("Inspector");
        if (editorWorld.IsAlive(g_selected)) {
            DrawInspector(editorWorld, g_selected);
        } else {
            ImGui::TextDisabled("Select an entity in Hierarchy");
        }
        ImGui::End();

        ImGui::Begin("Stats");
        ImGui::Text("FPS: %d", lastFps);
        ImGui::Text("Mode: %s", playing ? "PLAY" : "EDIT");
        ImGui::Separator();
        ImGui::Text("Editor world: %u alive", editorWorld.AliveCount());
        ImGui::Text("Play world:    %u alive", playWorld.AliveCount());
        ImGui::Text("Transforms stored: %zu", editorWorld.GetStorage<Transform>().Size());
        ImGui::Text("MeshRefs stored:   %zu", editorWorld.GetStorage<MeshRef>().Size());
        ImGui::Separator();
        ImGui::TextWrapped("Play(F5) clones editorWorld into playWorld via "
                           "serializer; Stop(Esc) discards it. Runtime state "
                           "never pollutes the editing world.");
        ImGui::End();

        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        glfwSwapBuffers(window);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
