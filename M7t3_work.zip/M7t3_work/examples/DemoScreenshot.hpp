/**
 * @file DemoScreenshot.hpp
 * @brief 示例共用：把当前后备缓冲保存为 24 位 BMP（隐藏窗口验收）。
 */
#pragma once

#include <glad/glad.h>

#include <cstdio>
#include <vector>

namespace DemoUtil {

inline bool SaveFramebufferBmp(const char* path, int width, int height) {
    if (!path || width <= 0 || height <= 0) return false;
    std::vector<unsigned char> rgba(static_cast<size_t>(width) * height * 4);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, rgba.data());

    const unsigned int rowBytes = static_cast<unsigned int>(width) * 3u;
    const unsigned int padded = (rowBytes + 3u) & ~3u;
    const unsigned int imageSize = padded * static_cast<unsigned int>(height);
    std::FILE* file = std::fopen(path, "wb");
    if (!file) return false;

    unsigned char header[54] = {};
    header[0] = 'B'; header[1] = 'M';
    auto put32 = [&](unsigned int offset, unsigned int value) {
        header[offset + 0] = static_cast<unsigned char>(value & 0xFF);
        header[offset + 1] = static_cast<unsigned char>((value >> 8) & 0xFF);
        header[offset + 2] = static_cast<unsigned char>((value >> 16) & 0xFF);
        header[offset + 3] = static_cast<unsigned char>((value >> 24) & 0xFF);
    };
    put32(2, 54u + imageSize);
    put32(10, 54);
    put32(14, 40);
    put32(18, static_cast<unsigned int>(width));
    put32(22, static_cast<unsigned int>(height));
    header[26] = 1;
    header[28] = 24;
    put32(34, imageSize);
    std::fwrite(header, 1, sizeof(header), file);

    std::vector<unsigned char> row(padded, 0);
    for (int y = 0; y < height; ++y) {
        const unsigned char* src = rgba.data() + static_cast<size_t>(y) * width * 4;
        for (int x = 0; x < width; ++x) {
            row[static_cast<size_t>(x) * 3 + 0] = src[static_cast<size_t>(x) * 4 + 2];
            row[static_cast<size_t>(x) * 3 + 1] = src[static_cast<size_t>(x) * 4 + 1];
            row[static_cast<size_t>(x) * 3 + 2] = src[static_cast<size_t>(x) * 4 + 0];
        }
        std::fwrite(row.data(), 1, padded, file);
    }
    std::fclose(file);
    return true;
}

} // namespace DemoUtil
