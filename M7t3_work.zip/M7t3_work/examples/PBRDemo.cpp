/**
 * @file PBRDemo.cpp
 * @brief M7N 渲染管线验收示例：PBR + 阴影 + HDR 后处理全链路。
 *
 * 场景：暗室地板 + 中央金属球（metallic 0.98）+ 环形材质阶梯球
 *       （roughness 0.1 → 0.9）+ 三色点光（红/橙/青）+ 微弱方向光投影。
 * 展示：Cook-Torrance 高光、金属 Fake-IBL 反射、距离衰减、
 *       PCF 软阴影、ACES tone mapping、晴角。
 *
 * 全程经 RenderSystem 三 pass 命令流，零直接 GL 调用。
 */
#include <M7N/Render/RenderSystem.hpp>
#include <M7N/Scene/Components.hpp>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "DemoScreenshot.hpp"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

using namespace M7N;
using namespace M7N::ECS;
using namespace M7N::Scene;
using namespace M7N::Render;
using namespace M7N::Asset;

// =====================================================================
// 程序化网格生成（MeshData 填充，交错布局由 AssetManager 上传时建立）
// =====================================================================

namespace {

/// 经纬球体：法线 = 位置方向，外向 CCW 环绕。
MeshData MakeSphere(f32 radius, u32 segments) {
    MeshData md;
    const u32 rings = segments;
    for (u32 r = 0; r <= rings; r++) {
        const f32 theta = 3.14159265f * r / rings;
        const f32 sinT = std::sin(theta), cosT = std::cos(theta);
        for (u32 s = 0; s <= segments; s++) {
            const f32 phi = 2.0f * 3.14159265f * s / segments;
            const Vec3 n(std::cos(phi) * sinT, cosT, std::sin(phi) * sinT);
            md.positions.push_back(n * radius);
            md.normals.push_back(n);
            md.texCoords.emplace_back(static_cast<f32>(s) / segments,
                                      static_cast<f32>(r) / rings);
        }
    }
    for (u32 r = 0; r < rings; r++) {
        for (u32 s = 0; s < segments; s++) {
            const u32 first = r * (segments + 1) + s;
            const u32 second = first + segments + 1;
            md.indices.insert(md.indices.end(),
                { first, first + 1, second,  second, first + 1, second + 1 });
        }
    }
    md.submeshes.push_back({ 0, static_cast<u32>(md.indices.size()) });
    return md;
}

/// 立方体：六面独立顶点，外向 CCW。
MeshData MakeCube(f32 half) {
    MeshData md;
    struct Face { Vec3 n, a, b, c, d; };
    const Face faces[6] = {
        { {0,0, 1}, {-half,-half, half}, { half,-half, half}, { half, half, half}, {-half, half, half} },
        { {0,0,-1}, { half,-half,-half}, {-half,-half,-half}, {-half, half,-half}, { half, half,-half} },
        { {0, 1,0}, {-half, half, half}, { half, half, half}, { half, half,-half}, {-half, half,-half} },
        { {0,-1,0}, {-half,-half,-half}, { half,-half,-half}, { half,-half, half}, {-half,-half, half} },
        { { 1,0,0}, { half,-half, half}, { half,-half,-half}, { half, half,-half}, { half, half, half} },
        { {-1,0,0}, {-half,-half,-half}, {-half,-half, half}, {-half, half, half}, {-half, half,-half} },
    };
    for (const Face& f : faces) {
        const u32 base = static_cast<u32>(md.positions.size());
        const Vec3 v[4] = { f.a, f.b, f.c, f.d };
        const Vec2 uv[4] = { {0,0}, {1,0}, {1,1}, {0,1} };
        for (u32 i = 0; i < 4; i++) {
            md.positions.push_back(v[i]);
            md.normals.push_back(f.n);
            md.texCoords.push_back(uv[i]);
        }
        md.indices.insert(md.indices.end(), { base, base + 1, base + 2, base, base + 2, base + 3 });
    }
    md.submeshes.push_back({ 0, static_cast<u32>(md.indices.size()) });
    return md;
}

/// XZ 平面地板。
MeshData MakePlane(f32 half) {
    MeshData md;
    md.positions = { {-half,0, half}, { half,0, half}, { half,0,-half}, {-half,0,-half} };
    md.normals.assign(4, Vec3(0.0f, 1.0f, 0.0f));
    md.texCoords = { {0,0}, {1,0}, {1,1}, {0,1} };
    // 从 +Y 方向看为 CCW（否则背面剔除会隐藏地板）
    md.indices = { 0, 1, 2, 0, 2, 3 };
    md.submeshes.push_back({ 0, 6 });
    return md;
}

} // namespace

// =====================================================================
// 主程序
// =====================================================================

int main(int argc, char** argv) {
    std::string screenshotPath;
    bool noLightGrid = false;
    bool noShadowMask = false;
    bool noBloom = false;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--screenshot") == 0 && i + 1 < argc) {
            screenshotPath = argv[++i];
        } else if (std::strcmp(argv[i], "--nogi") == 0) {
            noLightGrid = true;
        } else if (std::strcmp(argv[i], "--nomask") == 0) {
            noShadowMask = true;
        } else if (std::strcmp(argv[i], "--nobloom") == 0) {
            noBloom = true;
        }
    }

    if (!glfwInit()) return 1;

    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_VISIBLE, screenshotPath.empty() ? GLFW_TRUE : GLFW_FALSE);

    GLFWwindow* window = glfwCreateWindow(1280, 720,
                                          "M7Next PBRDemo (G: PBR+Shadow+HDR)", nullptr, nullptr);
    if (!window) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(screenshotPath.empty() ? 1 : 0);

    if (!gladLoadGLLoader(reinterpret_cast<GLADloadproc>(glfwGetProcAddress))) {
        std::fprintf(stderr, "glad init failed\n");
        return 1;
    }

    auto device = RHI::CreateGLDevice();
    if (!device) return 1;

    AssetManager assets(*device);

    // 程序化图元注册（与 glTF 网格同路径）
    assets.RegisterProceduralMesh("sphere", MakeSphere(1.0f, 36));
    assets.RegisterProceduralMesh("cube",   MakeCube(0.6f));
    assets.RegisterProceduralMesh("plane",  MakePlane(16.0f));

    // --- 场景 ---
    World world;
    world.Reserve(16);

    {
        Entity floorEntity = world.CreateEntity("Floor");
        world.AddComponent<Transform>(floorEntity);
        MeshRef& floor = world.AddComponent<MeshRef>(floorEntity);
        floor.path = "plane";
        floor.baseColor = Vec4(0.10f, 0.105f, 0.115f, 1.0f);
        floor.roughness = 0.88f;

        // 中央铬球
        Entity chrome = world.CreateEntity("Chrome");
        Transform& tc = world.AddComponent<Transform>(chrome);
        tc.position = Vec3(0.0f, 1.0f, 0.0f);
        MeshRef& mc = world.AddComponent<MeshRef>(chrome);
        mc.path = "sphere";
        mc.baseColor = Vec4(0.90f, 0.91f, 0.94f, 1.0f);
        mc.metallic = 0.98f;
        mc.roughness = 0.18f;

        // 环形 roughness 阶梯球（0.1 → 0.9，全金属差异对比）
        for (int i = 0; i < 5; i++) {
            Entity e = world.CreateEntity("Ball");
            Transform& t = world.AddComponent<Transform>(e);
            const f32 a = i * (6.2831853f / 5.0f);
            t.position = Vec3(3.4f * std::cos(a), 0.7f, 3.4f * std::sin(a));
            MeshRef& m = world.AddComponent<MeshRef>(e);
            m.path = "sphere";
            m.baseColor = Vec4(0.85f, 0.55f + 0.08f * i, 0.35f, 1.0f);
            m.metallic = (i % 2 == 0) ? 0.9f : 0.1f;
            m.roughness = 0.10f + 0.20f * i;
        }

        // 后方哑光方块
        Entity box = world.CreateEntity("Box");
        Transform& tb = world.AddComponent<Transform>(box);
        tb.position = Vec3(-2.5f, 0.6f, -2.5f);
        MeshRef& mb = world.AddComponent<MeshRef>(box);
        mb.path = "cube";
        mb.baseColor = Vec4(0.6f, 0.6f, 0.62f, 1.0f);
        mb.metallic = 0.0f;
        mb.roughness = 0.75f;
    }

    // --- 渲染系统 ---
    RenderSystem renderer(*device, assets);
    RenderConfig cfg;
    cfg.exposure = 1.0f;
    cfg.vignette = 0.35f;
    cfg.shadowRadius = 12.0f;
    cfg.ambientSky = Vec3(0.10f, 0.11f, 0.14f);
    cfg.ambientGround = Vec3(0.05f, 0.045f, 0.04f);
    cfg.lightGrid = !noLightGrid;
    cfg.shadowMask = !noShadowMask;
    if (noBloom) cfg.bloomStrength = 0.0f;
    renderer.SetConfig(cfg);

    int w = 0, h = 0;
    glfwGetFramebufferSize(window, &w, &h);
    if (!renderer.Init(static_cast<u32>(w), static_cast<u32>(h))) {
        std::fprintf(stderr, "RenderSystem init failed\n");
        return 1;
    }

    // 相机轨道
    f32 orbitAngle = 0.0f, orbitPitch = 0.18f;
    const f32 orbitRadius = 9.0f;

    double last = glfwGetTime();
    double fpsTimer = 0.0;
    int frames = 0;
    u32 frameIndex = 0;

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        const double now = glfwGetTime();
        const f32 dt = static_cast<f32>(now - last);
        last = now;

        fpsTimer += dt; frames++;
        if (fpsTimer >= 0.5) {
            char title[96];
            std::snprintf(title, sizeof(title),
                          "M7Next PBRDemo (G: PBR+Shadow+HDR) | %.0f FPS",
                          frames / fpsTimer);
            glfwSetWindowTitle(window, title);
            fpsTimer = 0.0; frames = 0;
        }

        // 轨道相机（方向键）
        if (glfwGetKey(window, GLFW_KEY_LEFT)  == GLFW_PRESS) orbitAngle += dt * 1.2f;
        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) orbitAngle -= dt * 1.2f;
        if (glfwGetKey(window, GLFW_KEY_UP)    == GLFW_PRESS) orbitPitch = std::min(orbitPitch + dt * 0.8f, 1.2f);
        if (glfwGetKey(window, GLFW_KEY_DOWN)  == GLFW_PRESS) orbitPitch = std::max(orbitPitch - dt * 0.8f, -0.2f);

        glfwGetFramebufferSize(window, &w, &h);
        renderer.OnResize(static_cast<u32>(w), static_cast<u32>(h));

        const Vec3 eye(orbitRadius * std::cos(orbitPitch) * std::sin(orbitAngle),
                       1.5f + orbitRadius * std::sin(orbitPitch),
                       orbitRadius * std::cos(orbitPitch) * std::cos(orbitAngle));
        renderer.SetCamera(eye, Vec3(0.0f, 0.8f, 0.0f), 45.0f,
                           (h > 0) ? static_cast<f32>(w) / static_cast<f32>(h) : 1.0f,
                           0.1f, 100.0f);

        // 帧光照：微弱方向光（投影）+ 三色点光
        renderer.ClearLights();
        DirectionalLight sun;
        sun.direction = Vec3(-0.2f, -1.0f, -0.25f);
        sun.color = Vec3(1.0f, 0.98f, 0.94f);
        sun.intensity = 0.15f;
        sun.castShadows = true;
        renderer.SetDirectionalLight(sun);

        PointLight pl;
        pl.range = 14.0f;
        pl.color = Vec3(1.00f, 0.12f, 0.06f);
        pl.intensity = 26.0f;
        pl.position = Vec3(-3.3f, 1.05f, 0.4f);
        renderer.AddPointLight(pl);

        pl.color = Vec3(1.00f, 0.58f, 0.12f);
        pl.intensity = 38.0f;
        pl.position = Vec3(-0.2f, 2.8f, -1.8f);
        renderer.AddPointLight(pl);

        pl.color = Vec3(0.06f, 0.88f, 1.00f);
        pl.intensity = 30.0f;
        pl.position = Vec3(3.3f, 1.05f, 0.4f);
        renderer.AddPointLight(pl);

        renderer.RenderFrame(world, Vec3(0.0f, 1.0f, 0.0f));
        ++frameIndex;

        if (!screenshotPath.empty() && frameIndex >= 4) {
            const bool ok = DemoUtil::SaveFramebufferBmp(screenshotPath.c_str(), w, h);
            std::printf("PBR screenshot %s: %s\n", screenshotPath.c_str(),
                        ok ? "saved" : "failed");
            std::printf("render stats: scene draws %u, shadow draws %u, culled %u\n",
                        renderer.GetStats().sceneDraws, renderer.GetStats().shadowDraws,
                        renderer.GetStats().culled);
            glfwSwapBuffers(window);
            break;
        }

        glfwSwapBuffers(window);
    }

    renderer.Shutdown();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
