/**
 * @file SkinnedDemo.cpp
 * @brief M7N 动画系统验收：GPU 蒙皮 + 骨骼动画全链路（无 glTF 文件依赖）。
 *
 * 场景：程序化构建 3 关节骨骼链（root -> mid -> tip），
 * 网格为沿骨骼链的"触手"圆柱段（每顶点绑定最近关节），
 * 动画通道驱动 mid/tip 关节正弦摆动 —— 视觉验收标准：
 * 触手随骨骼平滑弯曲（静态管线渲染则为直棒）。
 *
 * 覆盖：SkeletonComp/AnimatorComp 组件、AnimationSystem 采样与调色板、
 * AssetManager 蒙皮缓冲上传（关节索引 + 权重）、
 * RenderSystem 蒙皮管线切换（场景 + 阴影双 pass 蒙皮一致）。
 */
#include <M7N/Render/RenderSystem.hpp>
#include <M7N/Animation/AnimationSystem.hpp>
#include <M7N/Scene/Components.hpp>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "DemoScreenshot.hpp"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>

using namespace M7N;
using namespace M7N::ECS;
using namespace M7N::Scene;
using namespace M7N::Asset;
using namespace M7N::Render;
using namespace M7N::Animation;

namespace {

constexpr u32 kJointCount = 3;   // root / mid / tip

/// 沿骨骼链的程序化"触手"网格：环状分段圆柱，顶点绑定最近关节。
/// 关节局部平移均为 +Y 1.2（绑定姿态为竖直链）。
MeshData MakeTentacle(u32 ringsPerSegment, f32 radius) {
    MeshData md;
    md.skinned = true;
    const f32 segLen = 1.2f;
    const u32 totalRings = kJointCount * ringsPerSegment;

    auto addRing = [&](f32 y, u32 joint) {
        const u32 base = static_cast<u32>(md.positions.size());
        // 半径向尖端收窄
        const f32 t = y / (segLen * kJointCount);
        const f32 r = radius * (1.0f - 0.55f * t);
        for (u32 s = 0; s < 8; s++) {
            const f32 a = s * (6.2831853f / 8.0f);
            const Vec3 n(std::cos(a), 0.0f, std::sin(a));
            md.positions.emplace_back(n.x * r, y, n.z * r);
            md.normals.push_back(n);
            md.texCoords.emplace_back(static_cast<f32>(s) / 8.0f, t);
            // 权重：主关节 1.0（简化单骨骼绑定；多骨骼混合由 glTF 路径验证）
            for (int k = 0; k < 4; k++) {
                md.jointIndices.push_back(k == 0 ? static_cast<i32>(joint) : 0);
                md.jointWeights.push_back(k == 0 ? 1.0f : 0.0f);
            }
        }
        return base;
    };

    std::vector<u32> ringBases;
    for (u32 r = 0; r <= totalRings; r++) {
        // 顶点归属关节 = 所在段的上关节（clamp 到链尾）
        const u32 joint = std::min(r / ringsPerSegment, kJointCount - 1);
        ringBases.push_back(addRing(r * segLen / ringsPerSegment, joint));
    }

    // 环间四边形（外向 CCW）
    for (u32 r = 0; r < totalRings; r++) {
        for (u32 s = 0; s < 8; s++) {
            const u32 s2 = (s + 1) % 8;
            const u32 a = ringBases[r] + s,  b = ringBases[r] + s2;
            const u32 c = ringBases[r + 1] + s2, d = ringBases[r + 1] + s;
            md.indices.insert(md.indices.end(), { a, b, c,  a, c, d });
        }
    }
    md.submeshes.push_back({ 0, static_cast<u32>(md.indices.size()) });
    return md;
}

} // namespace

int main(int argc, char** argv) {
    std::string screenshotPath;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--screenshot") == 0 && i + 1 < argc) {
            screenshotPath = argv[++i];
        }
    }

    if (!glfwInit()) return 1;
    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_VISIBLE, screenshotPath.empty() ? GLFW_TRUE : GLFW_FALSE);

    GLFWwindow* window = glfwCreateWindow(1280, 720,
                                          "M7Next SkinnedDemo (GPU 蒙皮验收)", nullptr, nullptr);
    if (!window) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(screenshotPath.empty() ? 1 : 0);

    if (!gladLoadGLLoader(reinterpret_cast<GLADloadproc>(glfwGetProcAddress))) return 1;

    auto device = RHI::CreateGLDevice();
    if (!device) return 1;
    AssetManager assets(*device);
    assets.RegisterProceduralMesh("tentacle", MakeTentacle(6, 0.45f));

    World world;
    AnimationSystem animSys;

    // --- 骨骼实体：root(0) -> mid(1) -> tip(2)，绑定姿态竖直链 ---
    Entity e = world.CreateEntity("Tentacle");
    Transform& tf = world.AddComponent<Transform>(e);
    tf.position = Vec3(0.0f, 0.2f, 0.0f);

    SkeletonComp& skel = world.AddComponent<SkeletonComp>(e);
    skel.parents = { -1, 0, 1 };
    skel.inverseBinds.resize(kJointCount, Mat4(1.0f));
    for (u32 j = 0; j < kJointCount; j++) {
        skel.restPoses.push_back(JointPose{
            Vec3(0.0f, j == 0 ? 0.0f : 1.2f, 0.0f),
            Quat(0.0f, 0.0f, 0.0f, 1.0f),
            Vec3(1.0f) });
    }
    // 逆绑定 = 绑定全局姿态的逆（程序化骨骼与网格同空间构建）。
    // 本库无 mat4 求逆；绑定链为纯平移，逆 = 平移取负。
    {
        Vec3 globalPos(0.0f);
        for (u32 j = 0; j < kJointCount; j++) {
            const JointPose& p = skel.restPoses[j];
            globalPos += p.translation;
            skel.inverseBinds[j] = glm::translate(Mat4(1.0f), -globalPos);
        }
    }
    skel.ResetToRest();
    skel.palette.assign(kJointCount, Mat4(1.0f));

    MeshRef& mesh = world.AddComponent<MeshRef>(e);
    mesh.path = "tentacle";
    mesh.baseColor = Vec4(0.85f, 0.45f, 0.25f, 1.0f);
    mesh.roughness = 0.35f;
    mesh.metallic = 0.15f;

    // --- 动画：mid/tip 绕 Z 正弦摆动（相位错开形成波动）---
    AnimatorComp& anim = world.AddComponent<AnimatorComp>(e);
    {
        std::vector<Asset::AnimationClip> clips(1);
        Asset::AnimationClip& clip = clips[0];
        clip.name = "sway";
        clip.duration = 4.0f;

        auto addSwayChannel = [&](u32 joint, f32 phase) {
            Asset::AnimChannel ch;
            ch.jointIndex = joint;
            ch.path = Asset::AnimPath::Rotation;
            ch.interp = Asset::AnimInterp::Linear;
            // 关键帧：5 点采样绕 Z 摆动 sin 曲线（±0.6 rad）
            const f32 times[5] = { 0.0f, 1.0f, 2.0f, 3.0f, 4.0f };
            for (int k = 0; k < 5; k++) {
                const f32 t = times[k];
                const f32 ang = 0.6f * std::sin(6.2831853f * t / 4.0f + phase);
                ch.times.push_back(t);
                // 绕 Z 轴四元数 (x, y, z, w)（本库布局）
                const f32 h = ang * 0.5f;
                ch.quatKeys.emplace_back(0.0f, 0.0f, std::sin(h), std::cos(h));
            }
            clip.channels.push_back(std::move(ch));
        };
        addSwayChannel(1, 0.0f);
        addSwayChannel(2, 1.5707963f);
        AnimationSystem::InitAnimatorFromAsset(clips, anim);
        anim.Play(0);
    }

    // --- 地板 + 光照 ---
    {
        MeshData plane;
        plane.positions = { {-8,0, 8}, { 8,0, 8}, { 8,0,-8}, {-8,0,-8} };
        plane.normals.assign(4, Vec3(0.0f, 1.0f, 0.0f));
        plane.texCoords = { {0,0}, {1,0}, {1,1}, {0,1} };
        plane.indices = { 0, 1, 2, 0, 2, 3 };   // +Y 方向 CCW
        plane.submeshes.push_back({ 0, 6 });
        assets.RegisterProceduralMesh("floor", plane);

        Entity floor = world.CreateEntity("Floor");
        world.AddComponent<Transform>(floor);
        MeshRef& fm = world.AddComponent<MeshRef>(floor);
        fm.path = "floor";
        fm.baseColor = Vec4(0.10f, 0.105f, 0.115f, 1.0f);
        fm.roughness = 0.9f;
    }

    {
        const GPUMesh gpu = assets.GetGPUMesh("tentacle");
        std::printf("skin upload: skinned=%d skinBuffer=%s indices=%u\n",
                    gpu.skinned ? 1 : 0, gpu.skin.IsValid() ? "valid" : "invalid",
                    gpu.indexCount);
    }

    RenderSystem renderer(*device, assets);
    RenderConfig cfg;
    cfg.vignette = 0.3f;
    cfg.shadowRadius = 10.0f;
    renderer.SetConfig(cfg);
    int w = 0, h = 0;
    glfwGetFramebufferSize(window, &w, &h);
    if (!renderer.Init(static_cast<u32>(w), static_cast<u32>(h))) return 1;

    double last = glfwGetTime();
    f32 camAngle = 0.6f;
    u32 frameIndex = 0;

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();
        const double now = glfwGetTime();
        const f32 dt = static_cast<f32>(now - last);
        last = now;

        if (glfwGetKey(window, GLFW_KEY_LEFT)  == GLFW_PRESS) camAngle += dt * 1.2f;
        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) camAngle -= dt * 1.2f;

        // 动画步进（采样 -> 调色板）
        animSys.OnUpdate(world, dt);

        glfwGetFramebufferSize(window, &w, &h);
        renderer.OnResize(static_cast<u32>(w), static_cast<u32>(h));
        const f32 eyeY = 2.2f, dist = 6.5f;
        renderer.SetCamera(Vec3(dist * std::sin(camAngle), eyeY, dist * std::cos(camAngle)),
                           Vec3(0.0f, 1.8f, 0.0f), 45.0f,
                           (h > 0) ? static_cast<f32>(w) / static_cast<f32>(h) : 1.0f,
                           0.1f, 100.0f);

        renderer.ClearLights();
        DirectionalLight sun;
        sun.direction = Vec3(-0.3f, -1.0f, -0.4f);
        sun.intensity = 1.6f;
        sun.castShadows = true;
        renderer.SetDirectionalLight(sun);

        PointLight pl;
        pl.position = Vec3(2.5f, 2.0f, 2.0f);
        pl.color = Vec3(0.15f, 0.5f, 1.0f);
        pl.intensity = 18.0f;
        pl.range = 12.0f;
        renderer.AddPointLight(pl);

        renderer.RenderFrame(world, Vec3(0.0f, 1.8f, 0.0f));
        ++frameIndex;

        if (!screenshotPath.empty() && frameIndex >= 4) {
            const bool ok = DemoUtil::SaveFramebufferBmp(screenshotPath.c_str(), w, h);
            std::printf("Skinned screenshot %s: %s\n", screenshotPath.c_str(),
                        ok ? "saved" : "failed");
            std::printf("render stats: scene draws %u, culled %u\n",
                        renderer.GetStats().sceneDraws, renderer.GetStats().culled);
            glfwSwapBuffers(window);
            break;
        }

        glfwSwapBuffers(window);
    }

    renderer.Shutdown();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
