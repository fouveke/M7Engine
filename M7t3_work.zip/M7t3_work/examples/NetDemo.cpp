/**
 * @file NetDemo.cpp
 * @brief M7N 网络演示：服务器权威运动 + 客户端复制/插值 + 可靠 RPC。
 *
 * 用法：
 *   NetDemo.exe              真实 UDP 回环（端口随机，避免占用冲突）
 *   NetDemo.exe --simulated  模拟网络（30ms 延迟 + 20% 丢包，虚拟时间快速跑）
 *
 * 输出：握手、RPC 往返、复制实体数、RTT/丢包/流量统计、客户端插值位置。
 */
#include <M7N/Core/Log.hpp>
#include <M7N/Net/NetClient.hpp>
#include <M7N/Net/NetServer.hpp>
#include <M7N/Net/Replication.hpp>
#include <M7N/Net/Transport.hpp>
#include <M7N/Scene/Components.hpp>

#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <thread>
#include <vector>

using namespace M7N;
using namespace M7N::Net;
using namespace M7N::ECS;
using namespace M7N::Scene;

namespace {

constexpr f32 kTwoPi = 6.2831853f;

struct DemoStats {
    bool connected = false;
    bool gotReply = false;
    int spawnCount = 0;
    int destroyCount = 0;
};

int run(bool simulated) {
    const String mode = simulated ? "SIMULATED (30ms, 20% loss)" : "REAL UDP LOOPBACK";
    std::printf("=== M7N NetDemo - %s ===\n\n", mode.c_str());

    // --- 模拟网络（可选）---
    SimulatedNetwork hub(0x5EED);
    hub.SetLatency(20, 45);
    hub.SetJitter(10);
    hub.SetPacketLoss(0.2f);
    hub.SetDuplicate(0.02f);

    // --- 服务器 ---
    NetServer server;
    NetConfig serverConfig;
    serverConfig.port = simulated ? 7777 : 0;   // 真实 UDP 用系统分配端口
    serverConfig.maxClients = 4;
    serverConfig.timeoutSeconds = 5.0f;

    if (simulated) {
        if (!server.Start(serverConfig, hub.CreateTransport())) {
            std::printf("server start failed\n");
            return 1;
        }
    } else {
        if (!server.Start(serverConfig)) {
            std::printf("server start failed (UDP)\n");
            return 1;
        }
    }
    std::printf("server listening on 127.0.0.1:%u\n", server.Port());

    // --- 服务器世界：5 个环绕运动的实体 ---
    World serverWorld;
    std::vector<Entity> serverEntities;
    for (int i = 0; i < 5; ++i) {
        Entity e = serverWorld.CreateEntity("Orb_" + std::to_string(i));
        Transform& t = serverWorld.AddComponent<Transform>(e);
        const f32 angle = static_cast<f32>(i) * kTwoPi / 5.0f;
        t.position = Vec3(std::cos(angle) * 6.0f, 1.0f + i * 0.35f,
                          std::sin(angle) * 6.0f);
        NetworkIdentity identity;
        serverWorld.AddComponent<NetworkIdentity>(e, identity);
        serverEntities.push_back(e);
    }

    ReplicationServer replication(server);
    replication.SetTickRate(20);

    DemoStats stats;
    server.SetCallbacks(
        [](ClientId id) { std::printf("server: client %u connected\n", id); },
        [](ClientId id, DisconnectReason reason) {
            std::printf("server: client %u disconnected (%s)\n", id,
                        ToString(reason));
        },
        [&](ClientId id, Channel channel, const u8* data, u32 size) {
            if (channel == Channel::Reliable && size == 5 &&
                std::memcmp(data, "hello", 5) == 0) {
                std::printf("server: received RPC \"hello\" from client %u\n", id);
                server.SendTo(id, Channel::Reliable, "world", 5);
            }
        });

    // --- 客户端 ---
    NetClient client;
    World clientWorld;
    ReplicationClient replicationClient(clientWorld);
    ReplicationClientConfig replicationConfig;
    replicationConfig.interpolationSeconds = 0.08f;
    replicationClient.Configure(replicationConfig);
    replicationClient.SetSpawnCallback([&](Entity, u32 netId) {
        stats.spawnCount++;
        std::printf("client: spawned netId=%u\n", netId);
    });
    replicationClient.SetDestroyCallback([&](Entity, u32 netId) {
        stats.destroyCount++;
        std::printf("client: destroyed netId=%u\n", netId);
    });

    client.SetCallbacks(
        [&]() {
            stats.connected = true;
            std::printf("client: connected as id %u\n", client.GetClientId());
            client.Send(Channel::Reliable, "hello", 5);
        },
        [&](DisconnectReason reason) {
            std::printf("client: disconnected (%s)\n", ToString(reason));
        },
        [&](Channel channel, const u8* data, u32 size) {
            replicationClient.OnPacket(channel, data, size);
            if (channel == Channel::Reliable && size == 5 &&
                std::memcmp(data, "world", 5) == 0) {
                stats.gotReply = true;
                std::printf("client: received RPC \"world\"\n");
            }
        });

    NetConfig clientConfig;
    bool connectStarted = false;
    if (simulated) {
        connectStarted = client.ConnectWithTransport(
            Address::Parse("127.0.0.1:7777"), clientConfig, hub.CreateTransport());
    } else {
        connectStarted = client.Connect("127.0.0.1:" + std::to_string(server.Port()),
                                        clientConfig);
    }
    if (!connectStarted) {
        std::printf("connect failed\n");
        return 1;
    }

    // --- 主循环 ---
    const u32 iterations = simulated ? 900 : 500;
    const f32 dt = 1.0f / 60.0f;
    f32 simTime = 0.0f;

    for (u32 i = 0; i < iterations; ++i) {
        if (simulated) hub.Advance(dt);
        else std::this_thread::sleep_for(std::chrono::milliseconds(4));
        simTime += dt;

        // 服务器权威运动
        for (size_t e = 0; e < serverEntities.size(); ++e) {
            Transform* t = serverWorld.GetComponent<Transform>(serverEntities[e]);
            if (!t) continue;
            const f32 angle = simTime * 0.9f + static_cast<f32>(e) * kTwoPi / 5.0f;
            t->position.x = std::cos(angle) * 6.0f;
            t->position.z = std::sin(angle) * 6.0f;
            t->position.y = 1.0f + static_cast<f32>(e) * 0.35f +
                            0.25f * std::sin(simTime * 2.0f + static_cast<f32>(e));
        }

        server.Poll();
        client.Poll();
        replication.OnUpdate(serverWorld, dt);
        replicationClient.OnUpdate(dt);
    }

    // --- 结果 ---
    const u32 tick = replicationClient.GetLastTick();
    Entity first = replicationClient.GetEntity(1);
    const Transform* firstTransform = clientWorld.GetComponent<Transform>(first);
    const NetStats clientStats = client.GetStats();
    const NetStats serverStats = server.GetClientStats(client.GetClientId());

    std::printf("\n--- results ---\n");
    std::printf("client state      : %s\n", ToString(client.GetState()));
    std::printf("server tick       : %u\n", tick);
    std::printf("replicated entities: %u (spawned %d)\n",
                replicationClient.EntityCount(), stats.spawnCount);
    if (firstTransform) {
        std::printf("netId1 position   : %.2f, %.2f, %.2f\n",
                    firstTransform->position.x, firstTransform->position.y,
                    firstTransform->position.z);
    }
    std::printf("RPC hello/world   : %s\n", stats.gotReply ? "OK" : "MISSING");
    std::printf("client RTT        : %.1f ms  jitter %.1f ms\n",
                clientStats.rttMs, clientStats.jitterMs);
    std::printf("client loss(est)  : %.1f%%  retransmits %u\n",
                clientStats.packetLoss * 100.0f, clientStats.retransmits);
    std::printf("client traffic    : sent %u pkts/%u B, recv %u pkts/%u B\n",
                clientStats.packetsSent, clientStats.bytesSent,
                clientStats.packetsReceived, clientStats.bytesReceived);
    std::printf("server RTT        : %.1f ms  inflight %u\n",
                serverStats.rttMs, serverStats.reliableInFlight);
    std::printf("server peers      : %u\n", server.ClientCount());
    if (simulated) {
        std::printf("simulated drops   : %u\n", hub.DropCount());
    }

    const bool ok = stats.connected && stats.gotReply &&
                    replicationClient.EntityCount() == 5 && tick > 0;
    std::printf("\n%s\n", ok ? "NetDemo OK" : "NetDemo FAILED");

    client.Disconnect(DisconnectReason::ClientQuit);
    server.Stop();
    return ok ? 0 : 1;
}

} // namespace

int main(int argc, char** argv) {
    Log::SetLevel(LogLevel::Warn);   // 演示输出由 printf 控制
    bool simulated = false;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--simulated") == 0) simulated = true;
    }
    return run(simulated);
}
