#pragma once
// Last Light: procedural textures and primitive meshes for the horror slice.

#include <M7N/Asset/AssetManager.hpp>

#include <algorithm>
#include <cmath>
#include <random>
#include <vector>

namespace LastLight {

using namespace M7N;
using namespace M7N::Asset;

inline f32 Clamp01(f32 v) { return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v); }

inline u32 HashMix(u32 h) {
    h ^= h >> 16; h *= 0x7feb352du;
    h ^= h >> 15; h *= 0x846ca68bu;
    h ^= h >> 16;
    return h;
}

inline f32 Hash01(u32 a, u32 b = 0) {
    return static_cast<f32>(HashMix(a * 0x9e3779b9u + b * 0x85ebca6bu) & 0xFFFFFFu) / 16777215.0f;
}

inline f32 Hash2(i32 x, i32 y, u32 seed) {
    u32 h = static_cast<u32>(x) * 374761393u + static_cast<u32>(y) * 668265263u + seed * 362437u;
    return static_cast<f32>(HashMix(h) & 0xFFFFFFu) / 16777215.0f;
}

inline f32 ValueNoise(f32 x, f32 y, u32 seed) {
    const i32 xi = static_cast<i32>(std::floor(x));
    const i32 yi = static_cast<i32>(std::floor(y));
    const f32 fx = x - std::floor(x);
    const f32 fy = y - std::floor(y);
    const f32 u = fx * fx * (3.0f - 2.0f * fx);
    const f32 v = fy * fy * (3.0f - 2.0f * fy);
    const f32 a = Hash2(xi, yi, seed);
    const f32 b = Hash2(xi + 1, yi, seed);
    const f32 c = Hash2(xi, yi + 1, seed);
    const f32 d = Hash2(xi + 1, yi + 1, seed);
    return (a + (b - a) * u) + ((c + (d - c) * u) - (a + (b - a) * u)) * v;
}

inline f32 Fbm(f32 x, f32 y, u32 seed, i32 octaves) {
    f32 sum = 0.0f, amp = 0.5f, norm = 0.0f;
    for (i32 i = 0; i < octaves; ++i) {
        sum += ValueNoise(x, y, seed + static_cast<u32>(i) * 17u) * amp;
        norm += amp;
        x *= 2.03f; y *= 2.01f; amp *= 0.5f;
    }
    return sum / std::max(norm, 1e-5f);
}

struct Image {
    int w = 0, h = 0;
    std::vector<u8> px;

    Image(int width, int height) : w(width), h(height), px(static_cast<size_t>(width) * height * 4, 0) {}

    void Set(int x, int y, f32 r, f32 g, f32 b, f32 a = 1.0f) {
        if (x < 0 || y < 0 || x >= w || y >= h) return;
        const size_t i = (static_cast<size_t>(y) * w + x) * 4;
        px[i + 0] = static_cast<u8>(Clamp01(r) * 255.0f + 0.5f);
        px[i + 1] = static_cast<u8>(Clamp01(g) * 255.0f + 0.5f);
        px[i + 2] = static_cast<u8>(Clamp01(b) * 255.0f + 0.5f);
        px[i + 3] = static_cast<u8>(Clamp01(a) * 255.0f + 0.5f);
    }
};

inline Image MakeConcrete(int n) {
    Image img(n, n);
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const f32 grain = Fbm(x * 0.045f, y * 0.045f, 11, 5);
            f32 base = 0.30f + 0.11f * grain;
            const f32 stain = Fbm(x * 0.007f, y * 0.007f, 23, 4);
            if (stain > 0.56f) base -= (stain - 0.56f) * 0.60f;
            const f32 drip = Fbm(x * 0.10f, y * 0.018f, 31, 3);
            if (drip > 0.64f) base -= 0.045f;
            if (Hash2(x, y, 7) < 0.0045f) base -= 0.14f;
            const f32 crack = std::fabs(Fbm(x * 0.018f, y * 0.020f, 61, 3) - 0.5f);
            if (crack < 0.004f) base = 0.10f;
            img.Set(x, y, base * 1.02f, base, base * 0.96f);
        }
    }
    return img;
}

inline Image MakeWallTile(int n) {
    Image img(n, n);
    const int cell = 64;
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const int tx = x / cell, ty = y / cell;
            const int fx = x % cell, fy = y % cell;
            const bool grout = fx < 3 || fy < 3;
            f32 v = 0.48f + 0.10f * Hash01(static_cast<u32>(tx * 131 + ty * 17), 5);
            const f32 dirt = Fbm(x * 0.028f, y * 0.028f, 41, 5);
            v -= dirt * 0.12f;
            f32 r = v, g = v * 1.02f, b = v * 0.93f;
            const f32 mold = Fbm(x * 0.012f, y * 0.012f, 51, 4);
            if (mold > 0.58f) { r -= 0.085f; g -= 0.02f; b -= 0.07f; }
            if (grout) { r = g = b = 0.105f + 0.02f * dirt; }
            const f32 crack = std::fabs(Fbm(x * 0.021f, y * 0.052f, 61, 3) - 0.5f);
            if (crack < 0.0035f) { r *= 0.35f; g *= 0.35f; b *= 0.35f; }
            if (Hash01(static_cast<u32>(tx * 97 + ty * 53), 9) < 0.05f) { r *= 0.82f; g *= 0.82f; b *= 0.82f; }
            img.Set(x, y, r, g, b);
        }
    }
    return img;
}

inline Image MakeFloorTile(int n) {
    Image img(n, n);
    const int cell = 96;
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const int tx = x / cell, ty = y / cell;
            const int fx = x % cell, fy = y % cell;
            const bool grout = fx < 2 || fy < 2;
            f32 v = 0.33f + 0.07f * Hash01(static_cast<u32>(tx * 71 + ty * 29), 13);
            v -= Fbm(x * 0.035f, y * 0.035f, 43, 5) * 0.10f;
            f32 r = v * 1.03f, g = v, b = v * 0.94f;
            const f32 stain = Fbm(x * 0.010f, y * 0.010f, 73, 4);
            if (stain > 0.60f) { r -= 0.06f; g -= 0.07f; b -= 0.04f; }
            const f32 scuff = Fbm(x * 0.16f, y * 0.04f, 83, 3);
            if (scuff > 0.68f) v -= 0.04f;
            if (grout) { r = g = b = 0.09f; }
            img.Set(x, y, r, g, b);
        }
    }
    return img;
}

inline Image MakeCeiling(int n) {
    Image img(n, n);
    const int cell = 128;
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const bool grid = (x % cell) < 4 || (y % cell) < 4;
            f32 v = 0.42f + 0.05f * Fbm(x * 0.04f, y * 0.04f, 91, 4);
            f32 r = v, g = v * 0.97f, b = v * 0.88f;
            const f32 water = Fbm(x * 0.008f, y * 0.008f, 97, 5);
            if (water > 0.54f) {
                const f32 t = (water - 0.54f) * 1.6f;
                r = r * (1.0f - t) + 0.30f * t;
                g = g * (1.0f - t) + 0.235f * t;
                b = b * (1.0f - t) + 0.13f * t;
            }
            if (grid) { r = g = b = 0.16f; }
            if (Hash2(x, y, 101) < 0.004f) { r *= 0.6f; g *= 0.6f; b *= 0.6f; }
            img.Set(x, y, r, g, b);
        }
    }
    return img;
}

inline Image MakeMetal(int n) {
    Image img(n, n);
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const f32 brush = Fbm(x * 0.55f, y * 0.035f, 111, 3);
            f32 v = 0.28f + 0.10f * brush;
            const f32 rust = Fbm(x * 0.020f, y * 0.020f, 113, 4);
            f32 r = v, g = v, b = v;
            if (rust > 0.62f) {
                const f32 t = Clamp01((rust - 0.62f) * 2.5f);
                r = r * (1.0f - t) + 0.36f * t;
                g = g * (1.0f - t) + 0.17f * t;
                b = b * (1.0f - t) + 0.08f * t;
            }
            const f32 scratch = std::fabs(Fbm(x * 0.09f, y * 0.55f, 127, 2) - 0.5f);
            if (scratch < 0.0025f) v += 0.18f;
            img.Set(x, y, r + v * 0.05f, g + v * 0.05f, b + v * 0.05f);
        }
    }
    return img;
}

inline Image MakeLocker(int n) {
    Image img(n, n);
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const f32 grime = Fbm(x * 0.020f, y * 0.006f, 131, 4);
            f32 r = 0.20f + grime * 0.06f;
            f32 g = 0.25f + grime * 0.07f;
            f32 b = 0.23f + grime * 0.05f;
            if (Fbm(x * 0.05f, y * 0.05f, 137, 3) > 0.66f) { r *= 0.7f; g *= 0.7f; b *= 0.7f; }
            if ((y % 128) < 3) { r *= 0.55f; g *= 0.55f; b *= 0.55f; }
            if (Hash2(x, y, 139) < 0.002f) { r += 0.15f; g += 0.15f; b += 0.15f; }
            img.Set(x, y, r, g, b);
        }
    }
    return img;
}

inline Image MakeWood(int n) {
    Image img(n, n);
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const f32 warp = Fbm(x * 0.012f, y * 0.05f, 151, 4);
            const f32 grain = std::sin(x * 0.22f + warp * 11.0f) * 0.5f + 0.5f;
            f32 r = 0.20f + grain * 0.075f + warp * 0.03f;
            f32 g = 0.125f + grain * 0.048f + warp * 0.02f;
            f32 b = 0.075f + grain * 0.028f;
            if (Fbm(x * 0.02f, y * 0.02f, 157, 3) < 0.34f) { r *= 0.7f; g *= 0.7f; b *= 0.7f; }
            img.Set(x, y, r, g, b);
        }
    }
    return img;
}

inline Image MakeFabric(int n) {
    Image img(n, n);
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const f32 weave = (Hash2(x, y, 161) - 0.5f) * 0.04f;
            const f32 fold = std::sin(x * 0.09f + Fbm(x * 0.02f, y * 0.02f, 163, 3) * 9.0f) * 0.025f;
            f32 v = 0.50f + weave + fold;
            const f32 stain = Fbm(x * 0.012f, y * 0.012f, 167, 4);
            f32 r = v, g = v * 0.985f, b = v * 0.92f;
            if (stain > 0.58f) {
                const f32 t = Clamp01((stain - 0.58f) * 2.2f);
                r = r * (1.0f - t) + 0.34f * t;
                g = g * (1.0f - t) + 0.24f * t;
                b = b * (1.0f - t) + 0.14f * t;
            }
            img.Set(x, y, r, g, b);
        }
    }
    return img;
}

inline Image MakeSkin(int n) {
    Image img(n, n);
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const f32 mottle = Fbm(x * 0.05f, y * 0.05f, 173, 5);
            const f32 vein = std::fabs(Fbm(x * 0.018f, y * 0.05f, 179, 3) - 0.5f);
            f32 v = 0.58f + mottle * 0.08f;
            f32 r = v * 1.00f, g = v * 0.98f, b = v * 0.96f;
            if (vein < 0.0035f) { r *= 0.72f; g *= 0.74f; b *= 0.80f; }
            if (Fbm(x * 0.07f, y * 0.07f, 181, 3) > 0.72f) { r *= 0.9f; g *= 0.9f; b *= 0.9f; }
            img.Set(x, y, r, g, b);
        }
    }
    return img;
}

inline Image MakeGown(int n) {
    Image img(n, n);
    for (int y = 0; y < n; ++y) {
        for (int x = 0; x < n; ++x) {
            const f32 fold = std::sin(x * 0.16f + Fbm(x * 0.02f, y * 0.02f, 191, 4) * 7.0f) * 0.035f;
            f32 v = 0.52f + fold;
            f32 r = v * 1.00f, g = v * 0.97f, b = v * 0.90f;
            const f32 stain = Fbm(x * 0.011f, y * 0.011f, 193, 5);
            if (stain > 0.57f) {
                const f32 t = Clamp01((stain - 0.57f) * 2.0f);
                r = r * (1.0f - t) + 0.22f * t;
                g = g * (1.0f - t) + 0.045f * t;
                b = b * (1.0f - t) + 0.035f * t;
            }
            img.Set(x, y, r, g, b);
        }
    }
    return img;
}

inline Image MakeBloodDecal(int n) {
    Image img(n, n);
    std::mt19937 rng(20261106u);
    std::uniform_real_distribution<f32> u01(0.0f, 1.0f);
    const f32 cx = n * 0.5f, cy = n * 0.52f;
    for (int i = 0; i < 90; ++i) {
        const f32 ang = u01(rng) * 6.28318f;
        const f32 radius = std::pow(u01(rng), 1.8f) * n * 0.30f;
        const f32 bx = cx + std::cos(ang) * radius;
        const f32 by = cy + std::sin(ang) * radius * 0.85f;
        const f32 br = 2.5f + u01(rng) * (i < 8 ? 16.0f : 5.0f);
        const f32 alpha = 0.5f + u01(rng) * 0.5f;
        for (int y = static_cast<int>(by - br); y <= static_cast<int>(by + br); ++y) {
            for (int x = static_cast<int>(bx - br); x <= static_cast<int>(bx + br); ++x) {
                const f32 dx = (x - bx) / br, dy = (y - by) / br;
                const f32 d = std::sqrt(dx * dx + dy * dy);
                if (d < 1.0f) {
                    const f32 a = (1.0f - d * d) * alpha;
                    const f32 tone = 0.24f + 0.10f * u01(rng);
                    img.Set(x, y, tone, tone * 0.12f, tone * 0.10f, a);
                }
            }
        }
    }
    for (int i = 0; i < 8; ++i) {
        const int x0 = static_cast<int>(cx + (u01(rng) - 0.5f) * n * 0.35f);
        const int len = static_cast<int>(n * (0.08f + u01(rng) * 0.22f));
        const int wdt = 1 + static_cast<int>(u01(rng) * 3.0f);
        for (int y = 0; y < len; ++y) {
            const int yy = static_cast<int>(cy) + y;
            for (int w = -wdt; w <= wdt; ++w) {
                img.Set(x0 + w, yy, 0.20f, 0.02f, 0.02f, 0.55f * (1.0f - static_cast<f32>(y) / len));
            }
        }
    }
    return img;
}

inline void RegisterLastLightAssets(AssetManager& assets) {
    auto reg = [&](const char* name, const Image& img) {
        assets.RegisterProceduralTexture(name, static_cast<u32>(img.w), static_cast<u32>(img.h),
                                         img.px.data(), true, true, true);
    };
    reg("tex_concrete", MakeConcrete(512));
    reg("tex_wall", MakeWallTile(512));
    reg("tex_floor", MakeFloorTile(512));
    reg("tex_ceiling", MakeCeiling(512));
    reg("tex_metal", MakeMetal(256));
    reg("tex_locker", MakeLocker(256));
    reg("tex_wood", MakeWood(256));
    reg("tex_fabric", MakeFabric(256));
    reg("tex_skin", MakeSkin(256));
    reg("tex_gown", MakeGown(256));
    reg("tex_blood", MakeBloodDecal(256));

    assets.RegisterProceduralMesh("cube", [](f32 half) {
        MeshData md;
        struct Face { Vec3 n, a, b, c, d; };
        const Face faces[6] = {
            {{0,0,1},{-half,-half,half},{half,-half,half},{half,half,half},{-half,half,half}},
            {{0,0,-1},{half,-half,-half},{-half,-half,-half},{-half,half,-half},{half,half,-half}},
            {{0,1,0},{-half,half,half},{half,half,half},{half,half,-half},{-half,half,-half}},
            {{0,-1,0},{-half,-half,-half},{half,-half,-half},{half,-half,half},{-half,-half,half}},
            {{1,0,0},{half,-half,half},{half,-half,-half},{half,half,-half},{half,half,half}},
            {{-1,0,0},{-half,-half,-half},{-half,-half,half},{-half,half,half},{-half,half,-half}},
        };
        for (const Face& f : faces) {
            const u32 base = static_cast<u32>(md.positions.size());
            const Vec3 v[4] = {f.a, f.b, f.c, f.d};
            const Vec2 uv[4] = {{0,0},{1,0},{1,1},{0,1}};
            for (u32 i = 0; i < 4; ++i) {
                md.positions.push_back(v[i]);
                md.normals.push_back(f.n);
                md.texCoords.push_back(uv[i]);
            }
            md.indices.insert(md.indices.end(), {base, base + 1, base + 2, base, base + 2, base + 3});
        }
        md.submeshes.push_back({0, static_cast<u32>(md.indices.size())});
        return md;
    }(0.5f));

    assets.RegisterProceduralMesh("plane", [] {
        MeshData md;
        md.positions = {{-0.5f,0,0.5f},{0.5f,0,0.5f},{0.5f,0,-0.5f},{-0.5f,0,-0.5f}};
        md.normals.assign(4, Vec3(0,1,0));
        md.texCoords = {{0,0},{1,0},{1,1},{0,1}};
        md.indices = {0,1,2,0,2,3};
        md.submeshes.push_back({0, 6});
        return md;
    }());

    assets.RegisterProceduralMesh("cylinder", [] {
        MeshData md;
        const u32 seg = 20;
        for (u32 i = 0; i <= seg; ++i) {
            const f32 a = 6.2831853f * static_cast<f32>(i) / static_cast<f32>(seg);
            const f32 c = std::cos(a), s = std::sin(a);
            md.positions.push_back(Vec3(c * 0.5f, -0.5f, s * 0.5f));
            md.normals.push_back(Vec3(c, 0, s));
            md.texCoords.emplace_back(static_cast<f32>(i) / seg, 1.0f);
            md.positions.push_back(Vec3(c * 0.5f, 0.5f, s * 0.5f));
            md.normals.push_back(Vec3(c, 0, s));
            md.texCoords.emplace_back(static_cast<f32>(i) / seg, 0.0f);
        }
        for (u32 i = 0; i < seg; ++i) {
            const u32 b0 = i * 2, t0 = b0 + 1, b1 = b0 + 2, t1 = b0 + 3;
            md.indices.insert(md.indices.end(), {b0, t0, b1, t0, t1, b1});
        }
        const u32 topCenter = static_cast<u32>(md.positions.size());
        md.positions.push_back(Vec3(0, 0.5f, 0));
        md.normals.push_back(Vec3(0, 1, 0));
        md.texCoords.emplace_back(0.5f, 0.5f);
        const u32 botCenter = static_cast<u32>(md.positions.size());
        md.positions.push_back(Vec3(0, -0.5f, 0));
        md.normals.push_back(Vec3(0, -1, 0));
        md.texCoords.emplace_back(0.5f, 0.5f);
        for (u32 i = 0; i < seg; ++i) {
            const u32 b0 = i * 2, t0 = b0 + 1, b1 = b0 + 2, t1 = b0 + 3;
            md.indices.insert(md.indices.end(), {topCenter, t1, t0});
            md.indices.insert(md.indices.end(), {botCenter, b0, b1});
        }
        md.submeshes.push_back({0, static_cast<u32>(md.indices.size())});
        return md;
    }());

    assets.RegisterProceduralMesh("sphere", [] {
        MeshData md;
        const u32 seg = 20, rings = 14;
        for (u32 r = 0; r <= rings; ++r) {
            const f32 theta = 3.14159265f * static_cast<f32>(r) / static_cast<f32>(rings);
            const f32 sinT = std::sin(theta), cosT = std::cos(theta);
            for (u32 s = 0; s <= seg; ++s) {
                const f32 phi = 6.2831853f * static_cast<f32>(s) / static_cast<f32>(seg);
                const Vec3 n(std::cos(phi) * sinT, cosT, std::sin(phi) * sinT);
                md.positions.push_back(n * 0.5f);
                md.normals.push_back(n);
                md.texCoords.emplace_back(static_cast<f32>(s) / seg, static_cast<f32>(r) / rings);
            }
        }
        for (u32 r = 0; r < rings; ++r) {
            for (u32 s = 0; s < seg; ++s) {
                const u32 first = r * (seg + 1) + s;
                const u32 second = first + seg + 1;
                md.indices.insert(md.indices.end(), {first, first + 1, second, second, first + 1, second + 1});
            }
        }
        md.submeshes.push_back({0, static_cast<u32>(md.indices.size())});
        return md;
    }());
}

} // namespace LastLight
