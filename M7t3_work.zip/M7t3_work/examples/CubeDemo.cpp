/**
 * @file CubeDemo.cpp
 * @brief M7N-2 RHI 验收示例：旋转彩色立方体。
 *
 * 验证链路：GLFW 窗口 + GL 上下文 -> RHI 资源创建 ->
 * CommandList 录制 -> Submit 回放 -> 交换链呈现。
 * 游戏代码零 GL 调用（对比旧版示例直接混写 GL 状态管理）。
 */
#include <M7N/RHI/IRenderDevice.hpp>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <cmath>
#include <cstdio>

using namespace M7N;
using namespace M7N::RHI;

namespace {

constexpr const char* kVert = R"(
#version 330 core
layout(location = 0) in vec3 a_Position;
layout(location = 1) in vec3 a_Color;
uniform mat4 u_MVP;
out vec3 v_Color;
void main() {
    v_Color = a_Color;
    gl_Position = u_MVP * vec4(a_Position, 1.0);
}
)";

constexpr const char* kFrag = R"(
#version 330 core
in vec3 v_Color;
out vec4 FragColor;
void main() { FragColor = vec4(v_Color, 1.0); }
)";

/// 立方体：24 顶点（pos + color），外向 CCW 环绕（引擎约定）。
constexpr f32 kCube[] = {
    // 前 (+Z)  红
    -1,-1, 1,   1, 0.2, 0.2,    1,-1, 1,   1, 0.2, 0.2,    1, 1, 1,   1, 0.2, 0.2,   -1, 1, 1,   1, 0.2, 0.2,
    // 后 (-Z)  蓝
     1,-1,-1,   0.2, 0.3, 1,   -1,-1,-1,   0.2, 0.3, 1,   -1, 1,-1,   0.2, 0.3, 1,    1, 1,-1,   0.2, 0.3, 1,
    // 上 (+Y)  绿
    -1, 1, 1,   0.2, 1, 0.3,    1, 1, 1,   0.2, 1, 0.3,    1, 1,-1,   0.2, 1, 0.3,   -1, 1,-1,   0.2, 1, 0.3,
    // 下 (-Y)  黄
    -1,-1,-1,   1, 0.9, 0.2,    1,-1,-1,   1, 0.9, 0.2,    1,-1, 1,   1, 0.9, 0.2,   -1,-1, 1,   1, 0.9, 0.2,
    // 右 (+X)  紫
     1,-1, 1,   0.8, 0.2, 1,    1,-1,-1,   0.8, 0.2, 1,    1, 1,-1,   0.8, 0.2, 1,    1, 1, 1,   0.8, 0.2, 1,
    // 左 (-X)  青
    -1,-1,-1,   0.2, 1, 1,     -1,-1, 1,   0.2, 1, 1,    -1, 1, 1,   0.2, 1, 1,    -1, 1,-1,   0.2, 1, 1,
};

constexpr u32 kIndices[] = {
     0, 1, 2,  0, 2, 3,    // 前
     4, 5, 6,  4, 6, 7,    // 后
     8, 9,10,  8,10,11,    // 上
    12,13,14, 12,14,15,    // 下
    16,17,18, 16,18,19,    // 右
    20,21,22, 20,22,23,    // 左
};

void glfwError(int code, const char* desc) {
    std::fprintf(stderr, "GLFW error %d: %s\n", code, desc ? desc : "?");
}

} // namespace

int main() {
    glfwSetErrorCallback(glfwError);
    if (!glfwInit()) return 1;

    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(1280, 720,
                                          "M7Next CubeDemo - RHI (M7N-2)", nullptr, nullptr);
    if (!window) { glfwTerminate(); return 1; }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    if (!gladLoadGLLoader(reinterpret_cast<GLADloadproc>(glfwGetProcAddress))) {
        std::fprintf(stderr, "glad init failed\n");
        return 1;
    }

    // --- RHI 资源 ---
    auto device = CreateGLDevice();
    if (!device) return 1;

    BufferDesc vboDesc;
    vboDesc.data = kCube;
    vboDesc.size = sizeof(kCube);
    vboDesc.usage = BufferUsage::Vertex;
    BufferHandle vbo = device->CreateBuffer(vboDesc);

    BufferDesc iboDesc;
    iboDesc.data = kIndices;
    iboDesc.size = sizeof(kIndices);
    iboDesc.usage = BufferUsage::Index;
    BufferHandle ibo = device->CreateBuffer(iboDesc);

    ShaderHandle shader = device->CreateShader({ kVert, kFrag });
    if (!shader.IsValid()) return 1;

    PipelineDesc pipe;
    pipe.shader = shader;
    pipe.layout = {
        { 0, 3, 24,  0, false },   // a_Position
        { 1, 3, 24, 12, false },   // a_Color
    };
    pipe.depthTest = true;
    pipe.depthWrite = true;
    pipe.cull = true;
    PipelineHandle pipeline = device->CreatePipeline(pipe);

    // --- 主循环 ---
    CommandList cmd;
    double last = glfwGetTime();
    double fpsTimer = 0.0;
    int frames = 0;

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        double now = glfwGetTime();
        f32 dt = static_cast<f32>(now - last);
        last = now;

        // FPS 统计
        fpsTimer += dt;
        frames++;
        if (fpsTimer >= 0.5) {
            char title[96];
            std::snprintf(title, sizeof(title),
                          "M7Next CubeDemo - RHI (M7N-2) | %.0f FPS",
                          frames / fpsTimer);
            glfwSetWindowTitle(window, title);
            fpsTimer = 0.0;
            frames = 0;
        }

        // MVP：透视 * 视图 * 旋转
        int w, h;
        glfwGetFramebufferSize(window, &w, &h);
        f32 aspect = (h > 0) ? static_cast<f32>(w) / static_cast<f32>(h) : 1.0f;

        static f32 t = 0.0f;
        t += dt;
        Mat4 proj = glm::perspective(glm::radians(45.0f), aspect, 0.1f, 100.0f);
        Mat4 view = glm::translate(Mat4(1.0f), Vec3(0.0f, 0.0f, -5.0f));
        Mat4 model = glm::rotate(glm::rotate(Mat4(1.0f), t * 0.7f, Vec3(1.0f, 0.0f, 0.0f)),
                                 t, Vec3(0.0f, 1.0f, 0.0f));
        Mat4 mvp = proj * view * model;

        // 录制本帧命令（无任何 GL 调用）
        cmd.Reset();
        cmd.Clear(0.07f, 0.08f, 0.12f, 1.0f);
        cmd.SetViewport(0, 0, w, h);
        cmd.BindPipeline(pipeline);
        cmd.SetMat4("u_MVP", mvp);
        cmd.BindVertexBuffer(vbo);
        cmd.BindIndexBuffer(ibo);
        cmd.DrawIndexed(36);

        device->BeginFrame();
        device->Submit(cmd);

        glfwSwapBuffers(window);
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
