/**
 * @file Frustum.hpp
 * @brief 视锥体：从 ViewProjection 提取 6 平面，AABB 剔除。
 *
 * 平面约定：n·p + d >= 0 为内侧。AABB 测试取每个平面的
 * p-vertex（正向顶点），任一平面外侧即判定不可见（保守正确）。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <cmath>

namespace M7N::Math {

struct Plane {
    Vec3 normal = Vec3(0.0f);
    f32  d = 0.0f;

    f32 Distance(const Vec3& point) const {
        return normal.x * point.x + normal.y * point.y + normal.z * point.z + d;
    }
};

class Frustum {
public:
    void FromViewProjection(const Mat4& vp) {
        // 行提取（列主序：row i = m[i], m[4+i], m[8+i], m[12+i]）
        const auto row = [&](int r) {
            return Vec4(vp.m[0 * 4 + r], vp.m[1 * 4 + r],
                        vp.m[2 * 4 + r], vp.m[3 * 4 + r]);
        };
        const Vec4 r0 = row(0), r1 = row(1), r2 = row(2), r3 = row(3);
        setPlane(0, r3 + r0);   // left
        setPlane(1, r3 - r0);   // right
        setPlane(2, r3 + r1);   // bottom
        setPlane(3, r3 - r1);   // top
        setPlane(4, r3 + r2);   // near
        setPlane(5, r3 - r2);   // far
    }

    bool IntersectsAABB(const Vec3& min, const Vec3& max) const {
        for (const Plane& plane : planes_) {
            const Vec3 positive(
                plane.normal.x >= 0.0f ? max.x : min.x,
                plane.normal.y >= 0.0f ? max.y : min.y,
                plane.normal.z >= 0.0f ? max.z : min.z);
            if (plane.Distance(positive) < 0.0f) return false;
        }
        return true;
    }

    bool ContainsPoint(const Vec3& point) const {
        for (const Plane& plane : planes_) {
            if (plane.Distance(point) < 0.0f) return false;
        }
        return true;
    }

    const Plane& GetPlane(u32 index) const { return planes_[index]; }

private:
    void setPlane(u32 index, const Vec4& coefficients) {
        Plane plane;
        plane.normal = Vec3(coefficients.x, coefficients.y, coefficients.z);
        plane.d = coefficients.w;
        const f32 length = std::sqrt(plane.normal.x * plane.normal.x +
                                     plane.normal.y * plane.normal.y +
                                     plane.normal.z * plane.normal.z);
        if (length > 1e-6f) {
            const f32 inv = 1.0f / length;
            plane.normal = plane.normal * inv;
            plane.d *= inv;
        }
        planes_[index] = plane;
    }

    Plane planes_[6];
};

/// 变换局部 AABB 到世界空间 AABB（8 角点包围）。
inline void TransformAABB(const Mat4& matrix, const Vec3& localMin,
                          const Vec3& localMax, Vec3& outMin, Vec3& outMax) {
    outMin = Vec3(1e30f);
    outMax = Vec3(-1e30f);
    for (u32 i = 0; i < 8; ++i) {
        const Vec3 corner((i & 1) ? localMax.x : localMin.x,
                          (i & 2) ? localMax.y : localMin.y,
                          (i & 4) ? localMax.z : localMin.z);
        const Vec4 world = matrix * Vec4(corner.x, corner.y, corner.z, 1.0f);
        outMin.x = world.x < outMin.x ? world.x : outMin.x;
        outMin.y = world.y < outMin.y ? world.y : outMin.y;
        outMin.z = world.z < outMin.z ? world.z : outMin.z;
        outMax.x = world.x > outMax.x ? world.x : outMax.x;
        outMax.y = world.y > outMax.y ? world.y : outMax.y;
        outMax.z = world.z > outMax.z ? world.z : outMax.z;
    }
}

} // namespace M7N::Math
