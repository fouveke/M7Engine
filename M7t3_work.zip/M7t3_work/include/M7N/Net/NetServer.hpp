/**
 * @file NetServer.hpp
 * @brief UDP 无连接服务器的会话层：握手、连接表、可靠/不可靠收发。
 *
 * 单线程轮询模型：
 *   Start(config) -> 每帧 Poll() -> 回调 / SendTo / Broadcast -> Stop()
 *
 * 默认自建 UdpTransport；测试可注入 SimulatedNetwork 的端点。
 */
#pragma once

#include "M7N/Net/NetTypes.hpp"
#include "M7N/Net/Transport.hpp"

#include <functional>
#include <vector>

namespace M7N::Net {

class NetServer {
public:
    using ConnectCallback = std::function<void(ClientId)>;
    using DisconnectCallback = std::function<void(ClientId, DisconnectReason)>;
    using MessageCallback = std::function<void(ClientId, Channel, const u8*, u32)>;

    NetServer();
    ~NetServer();

    NetServer(const NetServer&) = delete;
    NetServer& operator=(const NetServer&) = delete;

    /// 启动监听；transport 为空时自建 UDP。@return 是否成功。
    bool Start(const NetConfig& config, Scope<ITransport> transport = nullptr);
    void Stop();
    bool IsRunning() const;
    u16 Port() const;

    /// 收包 + ACK/重传 + 超时处理 + 分发回调。
    void Poll();

    void Broadcast(Channel channel, const void* data, u32 size);
    bool SendTo(ClientId client, Channel channel, const void* data, u32 size);
    void DisconnectClient(ClientId client,
                          DisconnectReason reason = DisconnectReason::ServerShutdown);

    void SetCallbacks(ConnectCallback onConnect,
                      DisconnectCallback onDisconnect,
                      MessageCallback onMessage);

    u32 ClientCount() const;
    std::vector<ClientId> GetClients() const;
    NetStats GetClientStats(ClientId client) const;
    const NetConfig& Config() const;
    ITransport* GetTransport();

private:
    struct Impl;
    Scope<Impl> impl_;
};

} // namespace M7N::Net
