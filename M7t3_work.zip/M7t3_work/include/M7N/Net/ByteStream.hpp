/**
 * @file ByteStream.hpp
 * @brief 网络字节流读写（小端序，越界安全）。
 *
 * 协议头 / 快照 / 自定义 RPC 共用；Reader 读超界后 ok() 变 false，
 * 后续读取返回 0，调用方只需在末尾检查一次。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <cstring>
#include <vector>

namespace M7N::Net {

class ByteWriter {
public:
    explicit ByteWriter(std::vector<u8>& buffer) : buffer_(buffer) {}

    void U8(u8 v) { buffer_.push_back(v); }

    void U16(u16 v) {
        buffer_.push_back(static_cast<u8>(v & 0xFF));
        buffer_.push_back(static_cast<u8>((v >> 8) & 0xFF));
    }

    void U32(u32 v) {
        buffer_.push_back(static_cast<u8>(v & 0xFF));
        buffer_.push_back(static_cast<u8>((v >> 8) & 0xFF));
        buffer_.push_back(static_cast<u8>((v >> 16) & 0xFF));
        buffer_.push_back(static_cast<u8>((v >> 24) & 0xFF));
    }

    void I16(i16 v) { U16(static_cast<u16>(v)); }
    void I32(i32 v) { U32(static_cast<u32>(v)); }

    void F32(f32 v) {
        u32 bits = 0;
        std::memcpy(&bits, &v, sizeof(bits));
        U32(bits);
    }

    void Bytes(const void* data, u32 size) {
        if (!data || size == 0) return;
        const u8* bytes = static_cast<const u8*>(data);
        buffer_.insert(buffer_.end(), bytes, bytes + size);
    }

    size_t Size() const { return buffer_.size(); }

private:
    std::vector<u8>& buffer_;
};

class ByteReader {
public:
    ByteReader(const u8* data, u32 size) : data_(data), size_(size) {}

    u8 U8() {
        if (!require(1)) return 0;
        return data_[pos_++];
    }

    u16 U16() {
        if (!require(2)) return 0;
        const u16 v = static_cast<u16>(data_[pos_]) |
                      static_cast<u16>(data_[pos_ + 1]) << 8;
        pos_ += 2;
        return v;
    }

    u32 U32() {
        if (!require(4)) return 0;
        const u32 v = static_cast<u32>(data_[pos_]) |
                      static_cast<u32>(data_[pos_ + 1]) << 8 |
                      static_cast<u32>(data_[pos_ + 2]) << 16 |
                      static_cast<u32>(data_[pos_ + 3]) << 24;
        pos_ += 4;
        return v;
    }

    i16 I16() { return static_cast<i16>(U16()); }
    i32 I32() { return static_cast<i32>(U32()); }
    f32 F32() {
        const u32 bits = U32();
        f32 v = 0.0f;
        std::memcpy(&v, &bits, sizeof(v));
        return v;
    }

    bool Bytes(void* out, u32 size) {
        if (!require(size)) return false;
        std::memcpy(out, data_ + pos_, size);
        pos_ += size;
        return true;
    }

    bool Skip(u32 size) { return require(size); }

    bool ReadBytes(std::vector<u8>& out, u32 size) {
        if (!require(size)) return false;
        out.assign(data_ + pos_, data_ + pos_ + size);
        pos_ += size;
        return true;
    }

    u32 Remaining() const { return size_ - pos_; }
    u32 Position() const { return pos_; }
    bool Ok() const { return ok_; }

private:
    bool require(u32 count) {
        if (!ok_) return false;
        if (pos_ + count > size_) {
            ok_ = false;
            return false;
        }
        return true;
    }

    const u8* data_ = nullptr;
    u32 size_ = 0;
    u32 pos_ = 0;
    bool ok_ = true;
};

} // namespace M7N::Net
