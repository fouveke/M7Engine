/**
 * @file NetTypes.hpp
 * @brief 网络公共类型：IPv4 地址、通道、连接状态、统计。
 */
#pragma once

#include "M7N/Core/Types.hpp"

namespace M7N::Net {

using ClientId = u16;
constexpr ClientId kInvalidClient = 0xFFFFu;
constexpr u32 kDefaultProtocolVersion = 1;

/// IPv4 地址（host 为逻辑数值，如 127.0.0.1 = 0x7F000001）。
struct Address {
    u32 host = 0;
    u16 port = 0;

    bool IsValid() const { return port != 0; }

    /// 解析 "a.b.c.d:port" 或 "a.b.c.d"（无端口时 port=0）。
    static Address Parse(const String& text);
    String ToString() const;

    bool operator==(const Address& o) const { return host == o.host && port == o.port; }
    bool operator!=(const Address& o) const { return !(*this == o); }

    u64 Key() const { return (static_cast<u64>(host) << 16) | port; }
};

/// 可靠/不可靠通道。
enum class Channel : u8 {
    Reliable = 0,   ///< 有序、去重、自动重传（RPC / 生成销毁事件）
    Unreliable = 1, ///< 最新优先（快照 / 高频状态）
};

enum class ConnectionState : u8 {
    Disconnected = 0,
    Connecting,
    Connected,
    TimedOut,
};

enum class DisconnectReason : u8 {
    None = 0,
    Timeout,
    ProtocolError,
    ServerFull,
    ServerShutdown,
    ClientQuit,
    ConnectionLost,
};

const char* ToString(ConnectionState state);
const char* ToString(DisconnectReason reason);

/// 连接统计（实时计算）。
struct NetStats {
    f32 rttMs = 0.0f;
    f32 jitterMs = 0.0f;
    f32 packetLoss = 0.0f;      ///< 可靠消息重传率近似
    u32 packetsSent = 0;
    u32 packetsReceived = 0;
    u32 bytesSent = 0;
    u32 bytesReceived = 0;
    u32 retransmits = 0;
    u32 reliableInFlight = 0;
};

/// 网络配置。
struct NetConfig {
    u16 port = 0;                        ///< 服务端监听端口；客户端忽略
    u32 maxClients = 32;
    u32 protocolVersion = kDefaultProtocolVersion;
    f32 timeoutSeconds = 8.0f;
    f32 handshakeIntervalSeconds = 0.25f;
};

} // namespace M7N::Net
