/**
 * @file NetClient.hpp
 * @brief UDP 客户端：握手重试、连接状态、可靠/不可靠收发。
 *
 * 非阻塞：
 *   Connect("127.0.0.1:7777") -> 每帧 Poll() -> IsConnected()
 */
#pragma once

#include "M7N/Net/NetTypes.hpp"
#include "M7N/Net/Transport.hpp"

#include <functional>

namespace M7N::Net {

class NetClient {
public:
    using ConnectCallback = std::function<void()>;
    using DisconnectCallback = std::function<void(DisconnectReason)>;
    using MessageCallback = std::function<void(Channel, const u8*, u32)>;

    NetClient();
    ~NetClient();

    NetClient(const NetClient&) = delete;
    NetClient& operator=(const NetClient&) = delete;

    bool Connect(const String& hostPort, const NetConfig& config = NetConfig{});
    /// 测试/嵌入入口：使用已解析地址与自定义传输（模拟网络）。
    bool ConnectWithTransport(const Address& server, const NetConfig& config,
                              Scope<ITransport> transport);

    void Disconnect(DisconnectReason reason = DisconnectReason::ClientQuit);
    void Poll();

    bool Send(Channel channel, const void* data, u32 size);

    bool IsConnected() const;
    ConnectionState GetState() const;
    ClientId GetClientId() const;
    Address GetServerAddress() const;
    u16 GetLocalPort() const;
    NetStats GetStats() const;

    void SetCallbacks(ConnectCallback onConnect,
                      DisconnectCallback onDisconnect,
                      MessageCallback onMessage);

private:
    struct Impl;
    Scope<Impl> impl_;
};

} // namespace M7N::Net
