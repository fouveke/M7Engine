/**
 * @file Transport.hpp
 * @brief 传输抽象：真实 UDP + 可注入丢包/延迟/重复的模拟网络。
 *
 * 协议层只依赖 ITransport，因此同一套可靠性/复制代码可：
 *   - 线上跑 UdpTransport（Windows Winsock / POSIX socket）
 *   - 单测跑 SimulatedNetwork（虚拟时间，快且确定性）
 *
 * 模拟网络仅路由 127.0.0.1，按端口寻址；每个端点一个接收队列。
 * Advance(seconds) 推进虚拟时间，配合 Connection 的 NowSeconds() 让
 * 超时/重传在测试中无需真实等待。
 */
#pragma once

#include "M7N/Net/NetTypes.hpp"

#include <memory>

namespace M7N::Net {

class ITransport {
public:
    virtual ~ITransport() = default;

    /// 打开本地端口（0 = 系统分配）。@return 是否成功。
    virtual bool Open(u16 port) = 0;
    virtual void Close() = 0;
    virtual bool IsOpen() const = 0;
    virtual u16 LocalPort() const = 0;

    /// 发送一个数据报。@return 是否成功排队/写出。
    virtual bool Send(const Address& to, const void* data, u32 size) = 0;

    /// 非阻塞接收：返回字节数；0 = 暂无数据；-1 = 致命错误。
    virtual int Receive(Address& from, void* data, u32 capacity) = 0;

    /// 时间源（模拟传输为虚拟时钟，UDP 为 steady_clock）。
    virtual f64 NowSeconds() const = 0;
};

/// 解析 "host:port"（支持 IPv4 字面量与主机名，getaddrinfo）。
bool ResolveAddress(const String& hostPort, Address& out);

/// 真实 UDP 传输（非阻塞）。
class UdpTransport final : public ITransport {
public:
    UdpTransport();
    ~UdpTransport() override;

    bool Open(u16 port) override;
    void Close() override;
    bool IsOpen() const override;
    u16 LocalPort() const override;
    bool Send(const Address& to, const void* data, u32 size) override;
    int Receive(Address& from, void* data, u32 capacity) override;
    f64 NowSeconds() const override;

private:
    struct Impl;
    Scope<Impl> impl_;
};

class SimulatedTransport;

/// 模拟网络共享状态（定义在 Transport.cpp；两个类共享同一队列集合）。
struct SimulatedNetworkState;

/// 模拟网络集合：延迟/丢包/重复/抖动 + 虚拟时间。
class SimulatedNetwork {
public:
    explicit SimulatedNetwork(u32 seed = 0x7E57u);
    ~SimulatedNetwork();

    SimulatedNetwork(const SimulatedNetwork&) = delete;
    SimulatedNetwork& operator=(const SimulatedNetwork&) = delete;

    /// 单向延迟区间（毫秒）；maxMs=0 时使用固定 minMs。
    void SetLatency(u32 minMs, u32 maxMs = 0);
    /// 丢包率 0..1。
    void SetPacketLoss(f32 rate);
    /// 重复投递率 0..1。
    void SetDuplicate(f32 rate);
    /// 抖动（毫秒），叠加在延迟区间上。
    void SetJitter(u32 milliseconds);

    void Advance(f64 seconds);
    f64 NowSeconds() const;
    u32 DropCount() const;   ///< 测试观测：被丢弃的包数

    /// 创建一个未打开的端点；Open 时注册。
    Scope<SimulatedTransport> CreateTransport();

private:
    friend class SimulatedTransport;
    std::shared_ptr<SimulatedNetworkState> state_;
};

/// 模拟端点（仅由 SimulatedNetwork::CreateTransport 创建）。
class SimulatedTransport final : public ITransport {
public:
    explicit SimulatedTransport(SimulatedNetwork& network);
    ~SimulatedTransport() override;

    bool Open(u16 port) override;
    void Close() override;
    bool IsOpen() const override;
    u16 LocalPort() const override;
    bool Send(const Address& to, const void* data, u32 size) override;
    int Receive(Address& from, void* data, u32 capacity) override;
    f64 NowSeconds() const override;

private:
    std::shared_ptr<SimulatedNetworkState> state_;
    u16 port_ = 0;
    bool open_ = false;
};

} // namespace M7N::Net
