/**
 * @file Replication.hpp
 * @brief ECS 状态复制：服务器权威快照 + 客户端生成/销毁 + 插值。
 *
 * 组件：
 *   NetworkIdentity —— netId（0 = 服务器自动分配）、ownerClient、isLocalPlayer
 *
 * 协议（保留消息类型 0xF0..0xF2，自定义 RPC 请避开）：
 *   Snapshot(0xF0, unreliable) —— tick + 分块实体状态（位置/欧拉角量化）
 *   Spawn(0xF1, reliable)      —— netId + owner
 *   Destroy(0xF2, reliable)    —— netId
 *
 * 客户端：
 *   NetClient::SetCallbacks(..., [&](Channel, const u8* data, u32 size) {
 *       replicationClient.OnPacket(channel, data, size);
 *   });
 *   replicationClient.OnUpdate(dt);      // 插值 + 过期清理
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Net/NetServer.hpp"
#include "M7N/Net/NetClient.hpp"
#include "M7N/Reflect/TypeInfo.hpp"

#include <functional>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace M7N::Net {

/// 网络身份组件（参与序列化；运行时映射另存于复制系统内部）。
struct NetworkIdentity {
    u32  netId = 0;              ///< 0 = 服务器自动分配
    u32  ownerClient = 0;        ///< 0 = 服务器/无主
    bool isLocalPlayer = false;  ///< 客户端本地控制标记（预留）
};

constexpr u8 kMsgSnapshot = 0xF0;
constexpr u8 kMsgSpawn = 0xF1;
constexpr u8 kMsgDestroy = 0xF2;

class ReplicationServer {
public:
    explicit ReplicationServer(NetServer& server);

    /// 服务器 tick 频率（默认 20 Hz）。
    void SetTickRate(u32 hz);
    u32 GetTickRate() const { return tickRate_; }

    /// 扫描实体 + 按 tick 广播快照。
    void OnUpdate(ECS::World& world, f32 dt);

    u32 GetTick() const { return tick_; }
    u32 TrackedEntityCount() const { return static_cast<u32>(tracked_.size()); }
    u32 AllocateNetId() { return nextNetId_++; }

private:
    void syncNewClients(ECS::World& world);
    void scanEntities(ECS::World& world);
    void sendSnapshot(ECS::World& world);
    void sendSpawn(ClientId client, u32 netId, u32 owner);

    NetServer& server_;
    u32 tickRate_ = 20;
    f32 accumulator_ = 0.0f;
    u32 tick_ = 0;
    u32 nextNetId_ = 1;
    std::unordered_map<u32, ECS::Entity> tracked_;   ///< netId -> server entity
    std::unordered_set<ClientId> knownClients_;
};

struct ReplicationClientConfig {
    f32 interpolationSeconds = 0.1f;
    f32 staleDropSeconds = 6.0f;
};

class ReplicationClient {
public:
    explicit ReplicationClient(ECS::World& world);

    void Configure(const ReplicationClientConfig& config) { config_ = config; }

    /// 新实体生成回调（实体已带 Transform + NetworkIdentity，可挂 Sprite/Mesh）。
    void SetSpawnCallback(std::function<void(ECS::Entity, u32 netId)> callback);
    void SetDestroyCallback(std::function<void(ECS::Entity, u32 netId)> callback);

    /// 由 NetClient 的消息回调转发；非复制消息会被忽略。
    void OnPacket(Channel channel, const u8* data, u32 size);

    /// 每帧调用：推进插值 + 清理长时间未更新的远端实体。
    void OnUpdate(f32 dt);

    u32 GetLastTick() const { return lastAppliedTick_; }
    u32 EntityCount() const { return static_cast<u32>(entities_.size()); }
    ECS::Entity GetEntity(u32 netId) const;

private:
    struct RemoteEntity {
        ECS::Entity entity;
        u32  owner = 0;
        bool initialized = false;
        bool hasTarget = false;
        Vec3 fromPos = Vec3(0.0f);
        Vec3 toPos = Vec3(0.0f);
        Vec3 fromRot = Vec3(0.0f);
        Vec3 toRot = Vec3(0.0f);
        f32  elapsed = 0.0f;
        f32  duration = 0.1f;
        f32  lastSeen = 0.0f;
    };

    struct State {
        u32 netId = 0;
        Vec3 position = Vec3(0.0f);
        Vec3 rotation = Vec3(0.0f);
    };

    struct ChunkAssembly {
        u16 chunkCount = 0;
        u16 received = 0;
        u64 mask = 0;
        f32 age = 0.0f;
        std::vector<State> states;
    };

    ECS::Entity ensureEntity(u32 netId, u32 owner);
    void handleSpawn(const u8* data, u32 size);
    void handleDestroy(const u8* data, u32 size);
    void handleSnapshot(const u8* data, u32 size);
    void applySnapshot(u32 tick, const std::vector<State>& states);

    ECS::World& world_;
    ReplicationClientConfig config_;
    std::unordered_map<u32, RemoteEntity> entities_;
    std::unordered_map<u32, ChunkAssembly> chunks_;
    std::unordered_set<u32> destroyedIds_;   ///< 墓碑：拒绝迟到的快照复活
    u32 lastAppliedTick_ = 0;
    f32 time_ = 0.0f;

    std::function<void(ECS::Entity, u32)> onSpawn_;
    std::function<void(ECS::Entity, u32)> onDestroy_;
};

} // namespace M7N::Net

// --- 反射注册 ---

M7N_REFLECT_BEGIN(M7N::Net::NetworkIdentity)
    M7N_PROP(netId,         Int32)
    M7N_PROP(ownerClient,   Int32)
    M7N_PROP(isLocalPlayer, Bool)
M7N_REFLECT_END(M7N::Net::NetworkIdentity)
