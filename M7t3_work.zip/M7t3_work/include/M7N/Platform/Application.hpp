/**
 * @file Application.hpp
 * @brief 桌面应用外壳：GLFW 窗口 + GL 上下文 + RHI 设备 + 主循环。
 *
 * 派生类只需重写生命周期：
 *   OnStartup / OnUpdate / OnFixedUpdate / OnRender / OnResize / OnShutdown
 *
 * 主循环负责：
 *   - 输入事件 -> Input（与 GLFW 键码一致，平台层直接转发）
 *   - 帧计时、固定步长（可选，防死亡螺旋）
 *   - 窗口可见性 / vsync / 截图（RequestScreenshot 在交换前抓取后备缓冲）
 *
 * 无头验证：AppConfig{ visible=false } + Run(3) + RequestScreenshot(path)，
 * 不抢前台焦点即可产出渲染结果。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/Core/Input.hpp"
#include "M7N/Core/Time.hpp"
#include "M7N/RHI/IRenderDevice.hpp"

struct GLFWwindow;

namespace M7N {

struct AppConfig {
    String title = "M7Next";
    u32 width = 1280;
    u32 height = 720;
    bool vsync = true;
    bool resizable = true;
    bool visible = true;

    /// 固定步长秒数（0 = 关闭；建议 1/60 或 1/120）。
    f32 fixedStep = 0.0f;
    u32 maxFixedSteps = 5;
};

class Application {
public:
    Application();
    virtual ~Application();

    Application(const Application&) = delete;
    Application& operator=(const Application&) = delete;

    /// 创建窗口/上下文/RHI 设备并安装输入回调。
    bool Init(const AppConfig& config);

    /// 运行主循环（阻塞）。@param maxFrames >0 时渲染指定帧数后退出（自动截图场景）。
    int Run(u32 maxFrames = 0);

    /// 请求退出（下一帧结束生效）。
    void RequestQuit();

    /// 请求在下一帧渲染完成后、交换缓冲前截图（BMP，24 位）。
    void RequestScreenshot(const String& path);

    /// 立即从当前后备缓冲抓图（需在渲染后、SwapBuffers 前调用）。
    bool SaveScreenshot(const String& path);

    RHI::IRenderDevice& GetDevice() { return *device_; }
    Input& GetInput() { return input_; }
    GLFWwindow* GetNativeWindow() const { return window_; }

    u32 GetWidth() const { return width_; }
    u32 GetHeight() const { return height_; }
    f32 GetAspect() const {
        return (height_ > 0) ? static_cast<f32>(width_) / static_cast<f32>(height_) : 1.0f;
    }
    f64 GetTime() const;

    void SetTitle(const String& title);
    void SetVsync(bool enabled);

    /// 关闭平台（析构时自动调用；重复调用安全）。
    void Shutdown();

protected:
    virtual bool OnStartup() { return true; }
    virtual void OnUpdate(f32 dt) { (void)dt; }
    virtual void OnFixedUpdate(f32 step) { (void)step; }
    virtual void OnRender(f32 dt) { (void)dt; }
    virtual void OnResize(u32 width, u32 height) { (void)width; (void)height; }
    virtual void OnShutdown() {}

private:
    static void installCallbacks(GLFWwindow* window);
    bool captureToBmp(const String& path);

    AppConfig config_;
    GLFWwindow* window_ = nullptr;
    Ref<RHI::IRenderDevice> device_;
    Input input_;
    FrameTimer timer_;
    u32 width_ = 0;
    u32 height_ = 0;
    bool started_ = false;
    bool shutdown_ = false;
    String pendingScreenshot_;
};

} // namespace M7N
