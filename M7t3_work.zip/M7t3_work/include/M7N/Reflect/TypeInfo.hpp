/**
 * @file TypeInfo.hpp
 * @brief 编译期反射：属性偏移表驱动序列化与编辑器 Inspector。
 *
 * 每个可序列化组件特化 TypeOf<T>，通过宏声明属性列表；
 * SceneSerializer 与编辑器共用同一张表，杜绝两处维护。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <cstddef>

namespace M7N::Reflect {

/// 属性值类型（序列化与 Inspector UI 渲染共用）。
enum class PropType : u8 {
    Float,
    Int32,
    Bool,
    String,
    Vec2,
    Vec3,
    Vec4,
    Quat,        ///< (x,y,z,w) 四元数，JSON 中以 4 元素数组存储
    Int32Array,  ///< std::vector<i32>：瓦片数据、帧序列等
};

/// 单个属性描述：名字 + 成员偏移 + 类型。
struct PropertyInfo {
    const char* name;
    u32         offset;
    PropType    type;
};

/// 组件类型描述。
struct TypeInfo {
    const char*          name;     // 组件名（JSON 键）
    u32                  size;
    const PropertyInfo*  props;
    u32                  propCount;
};

/// 成员指针 -> 字节偏移（比 offsetof 兼容非标准布局类型）。
template <typename T, typename M>
constexpr u32 OffsetOf(M T::*member) {
    return static_cast<u32>(reinterpret_cast<std::uintptr_t>(&(static_cast<T*>(nullptr)->*member)));
}

/// 主模板不定义：未注册类型在编译期报错。
template <typename T>
struct TypeOf;

} // namespace M7N::Reflect

// ---------------------------------------------------------------------------
// 注册宏
// ---------------------------------------------------------------------------

#define M7N_REFLECT_BEGIN(T)                                        \
    namespace M7N::Reflect {                                        \
    template <> struct TypeOf<T> {                                  \
        static const TypeInfo& Get() {                              \
            using Comp = T;                                         \
            static const PropertyInfo props[] = {

#define M7N_PROP(member, propType)                                  \
                { #member, OffsetOf(&Comp::member), PropType::propType },

#define M7N_REFLECT_END(T)                                          \
            };                                                      \
            static const TypeInfo info {                           \
                #T, sizeof(T), props,                               \
                static_cast<u32>(sizeof(props) / sizeof(props[0]))   \
            };                                                      \
            return info;                                            \
        }                                                           \
    };                                                              \
    } // namespace M7N::Reflect
