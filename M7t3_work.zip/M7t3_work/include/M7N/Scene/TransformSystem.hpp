/**
 * @file TransformSystem.hpp
 * @brief 层级变换缓存：每帧把 Transform 世界矩阵算一次，供渲染/游戏逻辑复用。
 *
 * 设计：
 *   - WorldTransform 组件缓存矩阵（不参与反射/序列化）
 *   - 根节点为「父级无效」或「父级没有 Transform」
 *   - 多个根可在 JobSystem 上并行（工作线程只写各自子树组件，不改结构）
 *   - GetWorldMatrix 在未更新缓存时回退到 ComputeWorldMatrix，保证正确性
 *
 * 用法：每帧渲染前调用 OnUpdate(world, jobs)；
 *       之后用 GetWorldMatrix 替代 O(深度) 的 ComputeWorldMatrix。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/Core/JobSystem.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Scene/Components.hpp"

namespace M7N::Scene {

struct WorldTransform {
    Mat4 matrix = Mat4(1.0f);
};

class TransformSystem {
public:
    /// 更新全部带 Transform 实体的世界矩阵；移除失效缓存。
    void OnUpdate(ECS::World& world, JobSystem* jobs = nullptr);

    /// 取缓存矩阵；缓存缺失时回退到实时计算。
    static Mat4 GetWorldMatrix(const ECS::World& world, ECS::Entity e);

    /// 上一次更新的根节点数（统计/测试用）。
    u32 LastRootCount() const { return lastRootCount_; }

private:
    u32 lastRootCount_ = 0;
};

} // namespace M7N::Scene
