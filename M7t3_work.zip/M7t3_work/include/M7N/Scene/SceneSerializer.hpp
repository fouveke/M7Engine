/**
 * @file SceneSerializer.hpp
 * @brief 场景 JSON 序列化：反射表驱动的实体树 + 组件存取。
 *
 * 用法（类型包显式列出参与序列化的组件）：
 *   SceneSerializer::Save<Transform, MeshRef, CameraComp>(world, "scene.json");
 *   SceneSerializer::Load<Transform, MeshRef, CameraComp>(world, "scene.json");
 *
 * 格式：
 *   { "entities": [ { "id": [index, generation], "name": "...",
 *       "parent": 旧index或-1,
 *       "components": { "Transform": { "position": [x,y,z], ... } } } ] }
 */
#pragma once

#include "M7N/ECS/World.hpp"
#include "M7N/Reflect/TypeInfo.hpp"

#include <nlohmann/json.hpp>

#include <fstream>
#include <unordered_map>
#include <utility>
#include <vector>

namespace M7N::Scene {

class SceneSerializer {
public:
    /// 保存存活实体的层级与指定组件。@return 是否成功。
    template <typename... Cs>
    static bool Save(const ECS::World& world, const String& path) {
        nlohmann::json doc;
        doc["entities"] = nlohmann::json::array();

        // 拷贝一份遍历（const World 无法用倒序回调内删）
        std::vector<ECS::Entity> alive;
        const_cast<ECS::World&>(world).ForEachEntity(
            [&](ECS::Entity e) { alive.push_back(e); });

        for (ECS::Entity e : alive) {
            nlohmann::json ent;
            ent["id"]   = { e.index, e.generation };
            ent["name"] = const_cast<ECS::World&>(world).GetName(e);

            ECS::Entity parent = const_cast<ECS::World&>(world).GetParent(e);
            ent["parent"] = parent.IsValid()
                ? nlohmann::json(static_cast<i64>(parent.index))
                : nlohmann::json(-1);

            nlohmann::json comps = nlohmann::json::object();
            (trySaveComponent<Cs>(const_cast<ECS::World&>(world), e, comps), ...);
            ent["components"] = comps;
            doc["entities"].push_back(ent);
        }

        return writeJson(doc, path);
    }

    /// 加载：清空 world 后重建。@return 是否成功。
    template <typename... Cs>
    static bool Load(ECS::World& world, const String& path) {
        nlohmann::json doc;
        if (!readJson(doc, path)) return false;
        if (!doc.contains("entities")) return false;

        world.Clear();

        // 第一遍：创建全部实体，建立 旧index -> 新句柄 映射
        std::unordered_map<u32, ECS::Entity> idMap;
        std::vector<std::pair<ECS::Entity, i64>> pendingParents;

        for (const auto& ent : doc["entities"]) {
            if (!ent.contains("id")) continue;
            String name = ent.value("name", "Entity");
            ECS::Entity e = world.CreateEntity(name);
            idMap[static_cast<u32>(ent["id"][0])] = e;

            i64 parentIdx = ent.value("parent", -1);
            pendingParents.emplace_back(e, parentIdx);

            if (ent.contains("components")) {
                (tryLoadComponent<Cs>(world, e, ent["components"]), ...);
            }
        }

        // 第二遍：恢复层级
        for (const auto& [child, parentIdx] : pendingParents) {
            if (parentIdx < 0) continue;
            auto it = idMap.find(static_cast<u32>(parentIdx));
            if (it != idMap.end()) {
                world.SetParent(child, it->second);
            }
        }
        return true;
    }

private:
    // --- 单组件写：反射表遍历属性 ---
    template <typename C>
    static void trySaveComponent(ECS::World& world, ECS::Entity e, nlohmann::json& out) {
        C* comp = world.GetComponent<C>(e);
        if (!comp) return;

        const Reflect::TypeInfo& info = Reflect::TypeOf<C>::Get();
        nlohmann::json props = nlohmann::json::object();
        serializeProps(info, comp, props);
        out[info.name] = props;
    }

    // --- 单组件读：默认构造 + 逐属性覆盖 ---
    template <typename C>
    static void tryLoadComponent(ECS::World& world, ECS::Entity e, const nlohmann::json& comps) {
        const Reflect::TypeInfo& info = Reflect::TypeOf<C>::Get();
        if (!comps.contains(info.name)) return;

        C& comp = world.AddComponent<C>(e);
        applyProps(info, &comp, comps[info.name]);
    }

    static void serializeProps(const Reflect::TypeInfo& info, const void* base,
                               nlohmann::json& out);
    static void applyProps(const Reflect::TypeInfo& info, void* base,
                           const nlohmann::json& in);

    static bool writeJson(const nlohmann::json& doc, const String& path);
    static bool readJson(nlohmann::json& doc, const String& path);
};

} // namespace M7N::Scene
