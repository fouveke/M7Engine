/**
 * @file Components.hpp
 * @brief M7Next 核心组件 + 反射注册。
 *
 * 组件是纯数据（POD 优先），不含行为；行为归系统与脚本。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Reflect/TypeInfo.hpp"

namespace M7N::Scene {

/// 局部变换（欧拉角，弧度）。世界矩阵由系统按层级计算。
struct Transform {
    Vec3 position = Vec3(0.0f);
    Vec3 rotation = Vec3(0.0f);   // 欧拉角 (pitch, yaw, roll)，弧度
    Vec3 scale    = Vec3(1.0f);

    /// 本地矩阵：T * Ry * Rx * Rz * S。
    Mat4 GetLocalMatrix() const {
        Mat4 m = glm::translate(Mat4(1.0f), position);
        m = glm::rotate(m, rotation.y, Vec3(0.0f, 1.0f, 0.0f));
        m = glm::rotate(m, rotation.x, Vec3(1.0f, 0.0f, 0.0f));
        m = glm::rotate(m, rotation.z, Vec3(0.0f, 0.0f, 1.0f));
        m = glm::scale(m, scale);
        return m;
    }
};

/// 世界矩阵计算：沿父链上溯逐级左乘。
Mat4 ComputeWorldMatrix(const ECS::World& world, ECS::Entity e);

/// 网格引用：资产路径 + 子网格索引 + PBR 材质参数。
///
/// 材质语义：MeshRef 上的材质字段直接生效（覆盖 glTF 材质表的
/// baseColor/metallic/roughness）；贴图仍来自资产材质表
/// （ModelMaterial::texturePath），便于 glTF 模型直接可用。
struct MeshRef {
    String path = "";
    u32    submesh = 0;

    /// 基础色贴图（图片资产路径 / data URI / 程序化纹理名）。
    /// 非空时覆盖资产材质表里的 baseColorTexture，程序化网格（地形/墙体）靠它上贴图。
    String texturePath = "";

    /// 法线贴图（切线空间；用屏幕导数构造 TBN，无需顶点切线）。
    String normalPath = "";
    /// 金属粗糙度贴图（G=roughness, B=metallic；可单独提供 R=AO）。
    String ormPath = "";
    /// 自发光颜色（灯头/贴图发光；配合后处理泛光）。
    Vec3   emissive = Vec3(0.0f);
    /// 自发光贴图（可选，乘在 emissive 颜色上）。
    String emissivePath = "";

    /// 烘焙光图（BSP 图集；非空时启用 u_UseLightmap，烘焙光替代太阳/环境漫反射）。
    String lightmapPath = "";
    /// 光图强度（Q3 光图数值偏暗，可按曝光微调）。
    f32    lightmapStrength = 1.0f;

    /// 贴图平铺次数（UV 乘子；箱体每面 UV 0..1，大墙面需要按尺寸放大）。
    Vec2   uvScale = Vec2(1.0f, 1.0f);

    /// 法线贴图强度（0 关闭；大面积地面可调低，避免掠射角条纹）。
    f32    normalStrength = 1.0f;

    /// 是否参与渲染（菜单/第一人称手部模型等需要临时隐藏的实体）。
    bool   visible = true;

    /// 是否参与碰撞/射线检测。静态盒体合并渲染后原实体 visible=false 但仍需挡人挡枪，
    /// 所以碰撞不再借用 visible 判断，而是用独立的 collider 标记。
    bool   collider = false;

    /// 按自带的世界 AABB 做视锥剔除。
    /// GLB 地图块把坐标烤进了顶点，Transform 的 position/scale 表达不了包围盒，
    /// 所以剔除框单独挂在网格上（盒子实体仍走 position/scale 那条老路）。
    bool   frustumCull = false;
    Vec3   cullCenter = Vec3(0.0f);
    Vec3   cullExtent = Vec3(1.0f);

    /// true = 基础色乘上 glTF 各材质的 baseColorFactor（多材质模型保留材质差异，
    /// 配合把 baseColor 当"增益"用，避免整枪一块纯色）。
    bool   useAssetColors = false;

    /// true = 金属度/粗糙度乘上 glTF 各材质的 metallicFactor/roughnessFactor。
    /// 与 useAssetColors 同理：MeshRef 上的标量当"增益"，材质表提供相对差异，
    /// 否则橡胶握把（m=0, r=0.82）和抛光钢（m=0.95, r=0.40）会被压成同一种表面。
    bool   useAssetPbr = false;

    /// 三平面细节法线强度（0 关闭）。给**没有 UV**的模型（Blender 直出的硬表面
    /// 模型常常只有 POSITION/NORMAL）加一层物体空间程序化微凹凸，避免大面积
    /// 光板看起来像"白模"。采样走物体空间，模型移动时细节不会滑动。
    f32    detailNormalStrength = 0.0f;

    /// 细节法线的平铺密度（每米重复次数）。金属机加工纹理约 30~60。
    f32    detailNormalScale = 40.0f;

    /// 用同一张噪声抖动粗糙度（0 = 关闭，1 = 强）。PBR 里"像金属"靠的是
    /// 高光沿表面碎开，只有法线没有粗糙度变化，金属会显得像一整块塑料。
    f32    detailRoughJitter = 0.0f;

    /// 是否写入阴影图。地形/地贴等大平面应设为 false：
    /// 否则会因深度自比较产生跟随等高线的大面积假阴影（"星轨"状暗带）。
    bool   castShadow = true;

    /// true = 走 alpha 混合通道（弹孔贴片 / 枪口火光 / 玻璃等）。
    /// 该类实体在不透明 pass 之后单独绘制，不写深度，alpha 取自基础色贴图的 A 通道。
    bool   alphaBlend = false;

    // --- PBR 材质标量 ---
    Vec4 baseColor = Vec4(0.8f, 0.8f, 0.8f, 1.0f);
    f32  metallic  = 0.1f;
    f32  roughness = 0.6f;
};

/// 相机组件。
struct CameraComp {
    f32  fovYDeg = 45.0f;
    f32  nearZ   = 0.1f;
    f32  farZ    = 1000.0f;
    bool primary = false;
};

} // namespace M7N::Scene

// --- 反射注册 ---

M7N_REFLECT_BEGIN(M7N::Scene::Transform)
    M7N_PROP(position, Vec3)
    M7N_PROP(rotation, Vec3)
    M7N_PROP(scale,    Vec3)
M7N_REFLECT_END(M7N::Scene::Transform)

M7N_REFLECT_BEGIN(M7N::Scene::MeshRef)
    M7N_PROP(path,        String)
    M7N_PROP(submesh,     Int32)
    M7N_PROP(texturePath, String)
    M7N_PROP(normalPath,  String)
    M7N_PROP(ormPath,     String)
    M7N_PROP(emissive,    Vec3)
    M7N_PROP(emissivePath, String)
    M7N_PROP(baseColor, Vec3)
    M7N_PROP(metallic,  Float)
    M7N_PROP(roughness, Float)
M7N_REFLECT_END(M7N::Scene::MeshRef)

M7N_REFLECT_BEGIN(M7N::Scene::CameraComp)
    M7N_PROP(fovYDeg, Float)
    M7N_PROP(nearZ,   Float)
    M7N_PROP(farZ,    Float)
    M7N_PROP(primary, Bool)
M7N_REFLECT_END(M7N::Scene::CameraComp)
