/**
 * @file Camera.hpp
 * @brief 3D 相机视图构建：从 CameraComp + Transform 生成 view/proj。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Scene/Components.hpp"

namespace M7N::Scene {

struct CameraView {
    Mat4 view = Mat4(1.0f);
    Mat4 proj = Mat4(1.0f);
    Mat4 viewProj = Mat4(1.0f);
    Vec3 position = Vec3(0.0f);
    Vec3 forward = Vec3(0.0f, 0.0f, -1.0f);
    Vec3 up = Vec3(0.0f, 1.0f, 0.0f);
    f32  fovYDeg = 45.0f;
    f32  nearZ = 0.1f;
    f32  farZ = 1000.0f;
};

/// 从实体构建相机；实体无 CameraComp 时返回默认视图（原点朝 -Z）。
CameraView BuildCameraView(const ECS::World& world, ECS::Entity cameraEntity, f32 aspect);

/// 查找 primary CameraComp；没有则返回第一个；再没有返回 kNullEntity。
ECS::Entity FindPrimaryCamera(const ECS::World& world);

} // namespace M7N::Scene
