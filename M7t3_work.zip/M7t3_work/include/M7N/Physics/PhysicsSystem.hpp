/**
 * @file PhysicsSystem.hpp
 * @brief M7N 物理系统：ECS World 与内部 PhysicsWorld 的桥接层。
 *
 * 职责（M7N-4A 迁移，自 M7T1 物理管理器去单例化而来）：
 *   - Attach：扫描带 RigidBodyComp 的实体，注册进内部物理世界，
 *     建立 Entity -> bodyId 映射
 *   - Step：步进模拟后，把 body 位置/朝向写回 Scene::Transform
 *     （朝向经 glm::eulerAngles 转欧拉角写入 rotation 字段）
 *   - SyncPending：对新增/移除的刚体做增量同步
 *   - Raycast：射线检测，直接返回 ECS::Entity
 *
 * 架构约定：ECS 组件是"声明"，内部 PhysicsWorld 是"模拟状态"；
 * 本系统是普通实例类（非单例、无静态可变状态），可多实例并存。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Physics/PhysicsWorld.hpp"
#include "M7N/Physics/PhysicsComponents.hpp"

#include <unordered_map>

namespace M7N::Physics {

class PhysicsSystem {
public:
    PhysicsSystem() = default;
    ~PhysicsSystem() = default;

    /// 绑定 ECS 世界并全量注册刚体（重复调用会清空重建）。
    void Attach(ECS::World& ecs);

    /// 步进物理（内部先做增量同步），并把位置/朝向写回 Transform。
    void Step(f32 dt);

    /// 增量同步：注册新增刚体、移除已销毁实体或已摘除组件的刚体。
    void SyncPending();

    /// 射线检测：命中返回 true，并给出实体、距离与法线。
    bool Raycast(const Vec3& origin, const Vec3& dir, f32 maxDist,
                 ECS::Entity& outEntity, f32& outDist, Vec3& outNormal);

    /// 范围查询（ECS 实体句柄）。
    std::vector<ECS::Entity> OverlapSphere(const Vec3& center, f32 radius);
    std::vector<ECS::Entity> OverlapBox(const AABB& box);

    /// 内部物理世界访问（施力/设重力/调试等）。
    PhysicsWorld& GetWorld() { return world_; }
    const PhysicsWorld& GetWorld() const { return world_; }

private:
    /// 注册单个实体的刚体到内部世界（读 RigidBodyComp + ColliderComp + Transform）。
    u32 RegisterBody(ECS::Entity e, const RigidBodyComp& rb);

    PhysicsWorld world_;                              ///< 内部模拟世界
    ECS::World*  ecs_ = nullptr;                      ///< 绑定的 ECS 世界
    std::unordered_map<size_t, u32> entityToBody_;    ///< Entity::index -> bodyId
};

} // namespace M7N::Physics
