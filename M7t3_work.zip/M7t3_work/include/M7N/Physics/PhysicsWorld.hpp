/**
 * @file PhysicsWorld.hpp
 * @brief M7N 物理模拟世界：AABB/球/胶囊碰撞检测 + 刚体动力学。
 *
 * 自 M7T1（Mutant7::PhysicsWorld）平移（M7N-4A 迁移）：
 *   - namespace Mutant7 -> M7N::Physics
 *   - void* entity 句柄 -> M7N::ECS::Entity（index + generation）
 *   - 数学调用 Math::X -> glm::X（M7N Types 直接暴露 glm）
 *
 * 实现：
 *   - 刚体动力学（重力、力、力矩积分）
 *   - 旋转动力学（角速度、四元数朝向、对角惯量张量近似）
 *   - Box(AABB)/Sphere/Capsule 碰撞形状，六对窄相完整派发表：
 *       Sphere-Sphere / Sphere-Box / Capsule-Sphere /
 *       Capsule-Capsule / Capsule-Box / Box-Box
 *   - 冲量法碰撞解算（含角冲量、库仑摩擦、Baumgarte 位置修正）
 *   - 全形状射线检测
 *
 * 本类为普通实例类（无单例、无静态可变状态），由 PhysicsSystem 持有。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/Entity.hpp"
#include <cmath>
#include <vector>

namespace M7N::Physics {

/// 碰撞形状类型（内部模拟状态用）。
enum class CollisionShape : u8 {
    Box,
    Sphere,
    Capsule,
    Mesh   ///< 预留；网格碰撞器实现前按 Box 处理
};

/// 轴对齐包围盒。
struct AABB {
    Vec3 min = Vec3(0.0f);
    Vec3 max = Vec3(0.0f);

    Vec3 GetCenter() const { return (min + max) * 0.5f; }
    Vec3 GetExtents() const { return (max - min) * 0.5f; }
    bool Contains(const Vec3& point) const {
        return point.x >= min.x && point.x <= max.x &&
               point.y >= min.y && point.y <= max.y &&
               point.z >= min.z && point.z <= max.z;
    }
};

/// 射线检测命中结果。
struct RaycastHit {
    bool        hit      = false;
    f32         distance = 0.0f;
    Vec3        point;
    Vec3        normal;
    ECS::Entity entity{};   ///< 命中的 ECS 实体
    u32         bodyId   = 0;
};

/// 刚体数据（内部模拟状态）。
struct RigidBody {
    u32            id = 0;
    ECS::Entity    entity{};
    CollisionShape shape = CollisionShape::Box;
    Vec3           position = Vec3(0.0f);
    Vec3           velocity = Vec3(0.0f);
    Vec3           force = Vec3(0.0f);

    // --- 旋转状态（orientation 随 angularVelocity 积分）---
    Quat           orientation = Quat(0.0f, 0.0f, 0.0f, 1.0f); // identity (x,y,z,w)
    Vec3           angularVelocity = Vec3(0.0f);
    Vec3           torque = Vec3(0.0f);
    f32            angularDamping = 0.05f;
    bool           freezeRotation = false;   // 静态/运动学式旋转锁定

    f32            mass = 1.0f;
    f32            invMass = 1.0f;
    f32            restitution = 0.3f;
    f32            friction = 0.5f;
    bool           isKinematic = false;
    bool           useGravity = true;
    bool           isStatic = false;

    // 碰撞体尺寸
    Vec3           halfExtents = Vec3(0.5f);  // Box 用
    f32            radius = 0.5f;              // Sphere / Capsule 用
    f32            halfHeight = 0.5f;          // Capsule 圆柱段半高（不含球冠）

    AABB GetAABB() const {
        if (shape == CollisionShape::Sphere) {
            return AABB{ position - Vec3(radius), position + Vec3(radius) };
        }
        if (shape == CollisionShape::Capsule) {
            // 胶囊轴端点（局部 +Y 经 orientation 旋转到世界空间）
            Vec3 axis = orientation * Vec3(0.0f, 1.0f, 0.0f);
            Vec3 top = position + axis * halfHeight;
            Vec3 bot = position - axis * halfHeight;
            Vec3 lo(std::fmin(bot.x, top.x) - radius,
                    std::fmin(bot.y, top.y) - radius,
                    std::fmin(bot.z, top.z) - radius);
            Vec3 hi(std::fmax(bot.x, top.x) + radius,
                    std::fmax(bot.y, top.y) + radius,
                    std::fmax(bot.z, top.z) + radius);
            return AABB{ lo, hi };
        }
        return AABB{ position - halfExtents, position + halfExtents };
    }

    /// 胶囊轴在世界空间的两个端点。
    void GetCapsuleSegment(Vec3& outTop, Vec3& outBottom) const {
        Vec3 axis = orientation * Vec3(0.0f, 1.0f, 0.0f);
        outTop    = position + axis * halfHeight;
        outBottom = position - axis * halfHeight;
    }
};

/// 物理世界（实例类，由 PhysicsSystem 持有，去单例化）。
class PhysicsWorld {
public:
    PhysicsWorld() = default;
    ~PhysicsWorld() = default;

    /// 初始化（可指定重力；重复调用会清空全部刚体）。
    void Init(const Vec3& gravity = Vec3(0.0f, -9.81f, 0.0f));

    /// 按 deltaTime 步进模拟。
    void Step(f32 deltaTime);

    /// 对全部碰撞体做射线检测。
    bool Raycast(const Vec3& origin, const Vec3& direction, f32 maxDist, RaycastHit& hit);

    /// 球体范围查询：命中实体写入 out（清空后填充）。
    void OverlapSphere(const Vec3& center, f32 radius,
                       std::vector<ECS::Entity>& out) const;

    /// AABB 范围查询。
    void OverlapBox(const AABB& box, std::vector<ECS::Entity>& out) const;

    /// 添加刚体到模拟。
    /// @return bodyId（控制句柄）。
    u32 AddRigidBody(ECS::Entity entity, CollisionShape shape, f32 mass = 1.0f);

    /// 按实体移除刚体。
    void RemoveRigidBody(ECS::Entity entity);

    /// 按 ID 移除刚体。
    void RemoveRigidBody(u32 bodyId);

    /// 按 ID 取刚体。
    RigidBody* GetBody(u32 bodyId);

    /// 按实体取刚体。
    RigidBody* GetBodyByEntity(ECS::Entity entity);

    /// 全部刚体。
    const std::vector<RigidBody>& GetBodies() const { return bodies_; }

    /// 全局重力开关。
    void SetGravityEnabled(bool enabled) { gravityEnabled_ = enabled; }
    bool IsGravityEnabled() const { return gravityEnabled_; }

    /// 活动刚体数量。
    u32 GetBodyCount() const { return static_cast<u32>(bodies_.size()); }

    /// 全局重力。
    void SetGravity(const Vec3& gravity) { gravity_ = gravity; }
    const Vec3& GetGravity() const { return gravity_; }

    /// 固定步长（0 = 直接用 deltaTime）。
    void SetFixedTimestep(f32 dt) { fixedTimestep_ = dt; }

private:
    Vec3  gravity_ = Vec3(0.0f, -9.81f, 0.0f);
    bool  gravityEnabled_ = true;
    f32   fixedTimestep_ = 0.0f;  // 0 = 可变步长
    f32   accumulator_ = 0.0f;
    u32   nextBodyId_ = 1;

    std::vector<RigidBody> bodies_;

    void integrateBodies(f32 dt);
    void detectAndResolveCollisions();
    bool checkAABBCollision(const AABB& a, const AABB& b);
    bool checkSphereCollision(const Vec3& posA, f32 radA, const Vec3& posB, f32 radB,
                              Vec3& outNormal, f32& outDepth);
    void resolveCollision(RigidBody& a, RigidBody& b, const Vec3& normal, f32 depth,
                          const Vec3& contactPoint);
    bool raycastAABB(const Vec3& origin, const Vec3& dir, const AABB& box, f32& outDist);
    bool raycastSphere(const Vec3& origin, const Vec3& dir, const Vec3& center,
                       f32 radius, f32& outDist);
    bool raycastCapsule(const Vec3& origin, const Vec3& dir, const RigidBody& body,
                        f32& outDist);
};

} // namespace M7N::Physics
