/**
 * @file PhysicsComponents.hpp
 * @brief M7N 物理组件：刚体声明 + 碰撞体声明（纯数据 + 反射注册）。
 *
 * 架构约定（与 M7N "组件 = 数据，系统 = 行为" 分层一致）：
 *   RigidBodyComp —— 刚体"声明"：质量/材料/阻尼等参数与初始运动
 *                   状态；实际模拟状态由 PhysicsSystem 内部的
 *                   PhysicsWorld::RigidBody 持有，Step 后仅把位置与
 *                   朝向写回 Scene::Transform。
 *   ColliderComp  —— 碰撞体"声明"：形状枚举 + 尺寸参数。
 *
 * 字段自 M7T1 PhysicsWorld 的 RigidBody 拆分而来（M7N-4A 迁移）。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Reflect/TypeInfo.hpp"

namespace M7N::Physics {

/// 碰撞形状（组件声明用；内部模拟的 CollisionShape 另含预留 Mesh）。
enum class ColliderShape : u8 {
    Box,      ///< 盒（halfExtents）
    Sphere,   ///< 球（radius）
    Capsule   ///< 胶囊（radius + halfHeight，轴为局部 +Y）
};

/// 刚体组件：质量、材料与初始运动状态。
struct RigidBodyComp {
    // --- 质量与材料 ---
    f32  mass           = 1.0f;   ///< 质量（<= 0 视为静态刚体）
    f32  invMass        = 1.0f;   ///< 逆质量（注册时按 mass 重算，以防不一致）
    f32  restitution    = 0.3f;   ///< 弹性系数
    f32  friction       = 0.5f;   ///< 摩擦系数
    f32  angularDamping = 0.05f;  ///< 角速度阻尼

    // --- 行为开关 ---
    bool useGravity     = true;   ///< 是否受全局重力
    bool isKinematic    = false;  ///< 运动学刚体（不受力，可推动别人）
    bool freezeRotation = false;  ///< 锁定旋转（静态/角色胶囊常用）

    // --- 运动状态（注册时作为初值注入内部物理世界）---
    Vec3 velocity        = Vec3(0.0f);                   ///< 线速度
    Vec3 angularVelocity = Vec3(0.0f);                   ///< 角速度
    Vec3 torque          = Vec3(0.0f);                   ///< 力矩累积（运行时）
    Quat orientation     = Quat(0.0f, 0.0f, 0.0f, 1.0f); ///< 朝向 (x,y,z,w)，identity
};

/// 碰撞体组件：形状 + 尺寸。
struct ColliderComp {
    ColliderShape shape = ColliderShape::Box;

    Vec3 halfExtents = Vec3(0.5f); ///< Box 半尺寸
    f32  radius      = 0.5f;       ///< Sphere / Capsule 半径
    f32  halfHeight  = 0.5f;       ///< Capsule 圆柱段半高（不含球冠）
};

} // namespace M7N::Physics

// --- 反射注册 ---

M7N_REFLECT_BEGIN(M7N::Physics::RigidBodyComp)
    M7N_PROP(mass,           Float)
    M7N_PROP(invMass,        Float)
    M7N_PROP(restitution,    Float)
    M7N_PROP(friction,       Float)
    M7N_PROP(angularDamping, Float)
    M7N_PROP(useGravity,     Bool)
    M7N_PROP(isKinematic,    Bool)
    M7N_PROP(freezeRotation, Bool)
    M7N_PROP(velocity,        Vec3)
    M7N_PROP(angularVelocity, Vec3)
    M7N_PROP(torque,          Vec3)
    M7N_PROP(orientation,     Quat)
M7N_REFLECT_END(M7N::Physics::RigidBodyComp)

M7N_REFLECT_BEGIN(M7N::Physics::ColliderComp)
    M7N_PROP(shape,       Int32)
    M7N_PROP(halfExtents, Vec3)
    M7N_PROP(radius,      Float)
    M7N_PROP(halfHeight,  Float)
M7N_REFLECT_END(M7N::Physics::ColliderComp)
