/**
 * @file Types.hpp
 * @brief M7Next 基础类型别名与数学库接入。
 *
 * 四元数约定：Quat = glm::quat，构造顺序为 (w, x, y, z)（glm 原生）。
 * identity = Quat(1, 0, 0, 0)。全库统一此口径。
 */
#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

namespace M7N {

// --- 定长整型 / 浮点 ---
using u8  = std::uint8_t;
using u16 = std::uint16_t;
using u32 = std::uint32_t;
using u64 = std::uint64_t;
using i8  = std::int8_t;
using i16 = std::int16_t;
using i32 = std::int32_t;
using i64 = std::int64_t;
using f32 = float;
using f64 = double;

using String = std::string;

// --- 数学别名（自研精简数学库，非标准 glm）---
using Vec2 = glm::vec2;
using Vec3 = glm::vec3;
using Vec4 = glm::vec4;
using Quat = glm::quat;   // (x, y, z, w) 布局；identity = Quat(0,0,0,1)
using Mat3 = glm::mat3;
using Mat4 = glm::mat4;

// --- 智能指针别名 ---
template <typename T> using Ref   = std::shared_ptr<T>;
template <typename T> using Scope = std::unique_ptr<T>;
template <typename T, typename... Args>
Ref<T> CreateRef(Args&&... args) { return std::make_shared<T>(std::forward<Args>(args)...); }
template <typename T, typename... Args>
Scope<T> CreateScope(Args&&... args) { return std::make_unique<T>(std::forward<Args>(args)...); }

} // namespace M7N
