/**
 * @file Input.hpp
 * @brief 平台无关输入状态 + 按键动作映射。
 *
 * 平台层（Application）把 GLFW 事件喂给 OnKey/OnMouseButton/OnMouseMove；
 * 游戏侧只查语义：
 *   input.IsKeyDown(Key::W)
 *   input.IsActionPressed("Jump")
 *   input.GetAxis("MoveX")        // -1..1，MapAxis 绑定负/正键
 *
 * Key 数值刻意与 GLFW 键码一致（如 W=87、Space=32、Escape=256），
 * 平台层直接转发无需查表；核心层不依赖 GLFW。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <unordered_map>
#include <utility>
#include <vector>

namespace M7N {

/// 键码（与 GLFW_KEY_* 数值一致）。
enum class Key : i32 {
    Unknown = -1,
    Space = 32,
    Apostrophe = 39,
    Comma = 44,
    Minus = 45,
    Period = 46,
    Slash = 47,
    Num0 = 48, Num1 = 49, Num2 = 50, Num3 = 51, Num4 = 52,
    Num5 = 53, Num6 = 54, Num7 = 55, Num8 = 56, Num9 = 57,
    Semicolon = 59,
    Equal = 61,
    A = 65, B = 66, C = 67, D = 68, E = 69, F = 70, G = 71,
    H = 72, I = 73, J = 74, K = 75, L = 76, M = 77, N = 78,
    O = 79, P = 80, Q = 81, R = 82, S = 83, T = 84, U = 85,
    V = 86, W = 87, X = 88, Y = 89, Z = 90,
    LeftBracket = 91, Backslash = 92, RightBracket = 93, GraveAccent = 96,
    Escape = 256, Enter = 257, Tab = 258, Backspace = 259,
    Insert = 260, Delete = 261,
    Right = 262, Left = 263, Down = 264, Up = 265,
    PageUp = 266, PageDown = 267, Home = 268, End = 269,
    CapsLock = 280, ScrollLock = 281, NumLock = 282,
    PrintScreen = 283, Pause = 284,
    F1 = 290, F2 = 291, F3 = 292, F4 = 293, F5 = 294, F6 = 295,
    F7 = 296, F8 = 297, F9 = 298, F10 = 299, F11 = 300, F12 = 301,
    KP0 = 320, KP1 = 321, KP2 = 322, KP3 = 323, KP4 = 324,
    KP5 = 325, KP6 = 326, KP7 = 327, KP8 = 328, KP9 = 329,
    KPDecimal = 330, KPDivide = 331, KPMultiply = 332,
    KPSubtract = 333, KPAdd = 334, KPEnter = 335, KPEqual = 336,
    LeftShift = 340, LeftControl = 341, LeftAlt = 342, LeftSuper = 343,
    RightShift = 344, RightControl = 345, RightAlt = 346, RightSuper = 347,
    Menu = 348,
};

/// 鼠标键（与 GLFW_MOUSE_BUTTON_* 一致）。
enum class MouseButton : i32 {
    None = -1,
    Left = 0,
    Right = 1,
    Middle = 2,
    X1 = 3,
    X2 = 4,
    Count = 5,
};

struct KeyBinding {
    Key key = Key::Unknown;
    MouseButton mouse = MouseButton::None;

    static KeyBinding FromKey(Key k) { KeyBinding b; b.key = k; return b; }
    static KeyBinding FromMouse(MouseButton m) { KeyBinding b; b.mouse = m; return b; }
};

class Input {
public:
    static constexpr u32 kKeySlots = 512;
    static constexpr u32 kMouseSlots = 8;

    // --- 平台层事件入口 ---
    void OnKey(i32 key, bool down);
    void OnMouseButton(i32 button, bool down);
    void OnMouseMove(f32 x, f32 y);
    void OnMouseScroll(f32 dx, f32 dy);
    void OnFocusLost();

    /// 每帧开始前调用：清空 pressed/released 与增量（按住状态保留）。
    void NewFrame();

    // --- 原始查询 ---
    bool IsKeyDown(Key key) const;
    bool IsKeyPressed(Key key) const;
    bool IsKeyReleased(Key key) const;
    bool IsMouseDown(MouseButton button) const;
    bool IsMousePressed(MouseButton button) const;
    bool IsMouseReleased(MouseButton button) const;

    Vec2 MousePosition() const { return mousePosition_; }
    Vec2 MouseDelta() const { return mouseDelta_; }
    Vec2 ScrollDelta() const { return scrollDelta_; }

    // --- 动作/轴映射 ---
    void MapAction(const String& action, Key key);
    void MapAction(const String& action, MouseButton button);
    void MapAxis(const String& axis, Key negative, Key positive);
    void ClearMappings();

    bool IsActionDown(const String& action) const;
    bool IsActionPressed(const String& action) const;
    bool IsActionReleased(const String& action) const;
    f32 GetAxis(const String& axis) const;

private:
    bool keyDown(u32 slot) const { return slot < kKeySlots && keyDown_[slot]; }
    bool keyPressed(u32 slot) const { return slot < kKeySlots && keyPressed_[slot]; }
    bool keyReleased(u32 slot) const { return slot < kKeySlots && keyReleased_[slot]; }
    bool bindingDown(const KeyBinding& b) const;
    bool bindingPressed(const KeyBinding& b) const;
    bool bindingReleased(const KeyBinding& b) const;

    u8 keyDown_[kKeySlots] = {};
    u8 keyPressed_[kKeySlots] = {};
    u8 keyReleased_[kKeySlots] = {};
    u8 mouseDown_[kMouseSlots] = {};
    u8 mousePressed_[kMouseSlots] = {};
    u8 mouseReleased_[kMouseSlots] = {};

    Vec2 mousePosition_ = Vec2(0.0f);
    Vec2 mouseDelta_ = Vec2(0.0f);
    Vec2 scrollDelta_ = Vec2(0.0f);
    bool hasMousePosition_ = false;

    std::unordered_map<String, std::vector<KeyBinding>> actions_;
    std::unordered_map<String, std::pair<Key, Key>> axes_;
};

} // namespace M7N
