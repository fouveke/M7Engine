/**
 * @file EventBus.hpp
 * @brief 类型安全事件总线（头文件实现）。
 *
 *   auto id = bus.Subscribe<PlayerDamaged>([](const PlayerDamaged& e) { ... });
 *   bus.Publish(PlayerDamaged{ ... });
 *   bus.Unsubscribe(id);
 *
 * 发布时拷贝订阅者快照：回调内新增/移除订阅不会使本次迭代失效。
 * 非线程安全（约定主线程使用；跨线程事件请投递到主线程队列）。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <functional>
#include <typeindex>
#include <unordered_map>
#include <utility>
#include <vector>

namespace M7N {

class EventBus {
public:
    using SubscriptionId = u64;

    template <typename Event>
    SubscriptionId Subscribe(std::function<void(const Event&)> handler) {
        const SubscriptionId id = nextId_++;
        Entry entry;
        entry.id = id;
        entry.invoke = [h = std::move(handler)](const void* e) {
            h(*static_cast<const Event*>(e));
        };
        listeners_[std::type_index(typeid(Event))].push_back(std::move(entry));
        return id;
    }

    template <typename Event>
    void Publish(const Event& event) {
        auto it = listeners_.find(std::type_index(typeid(Event)));
        if (it == listeners_.end()) return;
        // 快照：允许回调内退订/新增
        const std::vector<Entry> snapshot = it->second;
        for (const Entry& entry : snapshot) {
            entry.invoke(&event);
        }
    }

    bool Unsubscribe(SubscriptionId id) {
        for (auto& [type, entries] : listeners_) {
            (void)type;
            for (size_t i = 0; i < entries.size(); ++i) {
                if (entries[i].id == id) {
                    entries.erase(entries.begin() + static_cast<i64>(i));
                    return true;
                }
            }
        }
        return false;
    }

    template <typename Event>
    size_t SubscriberCount() const {
        auto it = listeners_.find(std::type_index(typeid(Event)));
        return (it != listeners_.end()) ? it->second.size() : 0;
    }

    void Clear() { listeners_.clear(); }

private:
    struct Entry {
        SubscriptionId id = 0;
        std::function<void(const void*)> invoke;
    };

    std::unordered_map<std::type_index, std::vector<Entry>> listeners_;
    SubscriptionId nextId_ = 1;
};

} // namespace M7N
