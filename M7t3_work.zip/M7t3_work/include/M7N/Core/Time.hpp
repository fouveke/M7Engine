/**
 * @file Time.hpp
 * @brief 帧计时与固定步长累加器（头文件实现）。
 *
 * FrameTimer  —— 墙钟增量 / 总时长 / 帧计数
 * FixedStepAccumulator —— 将可变帧间隔切成固定物理步长，带最大步数保护
 *                        （卡顿后最多补 N 步，避免死亡螺旋）。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <algorithm>
#include <chrono>

namespace M7N {

class FrameTimer {
public:
    FrameTimer()
        : start_(Clock::now()), last_(start_) {}

    /// 推进一帧并返回距上次的秒数（首帧为 0）。
    f32 Tick() {
        const TimePoint now = Clock::now();
        delta_ = std::chrono::duration<f32>(now - last_).count();
        last_ = now;
        total_ += static_cast<f64>(delta_);
        frames_++;
        return delta_;
    }

    f32 Delta() const { return delta_; }
    f64 TotalSeconds() const { return total_; }
    u64 FrameCount() const { return frames_; }

    void Reset() {
        start_ = last_ = Clock::now();
        delta_ = 0.0f;
        total_ = 0.0;
        frames_ = 0;
    }

private:
    using Clock = std::chrono::steady_clock;
    using TimePoint = Clock::time_point;

    TimePoint start_;
    TimePoint last_;
    f32 delta_ = 0.0f;
    f64 total_ = 0.0;
    u64 frames_ = 0;
};

class FixedStepAccumulator {
public:
    explicit FixedStepAccumulator(f32 stepSeconds = 1.0f / 60.0f, u32 maxStepsPerFrame = 5)
        : step_(stepSeconds > 0.0f ? stepSeconds : 1.0f / 60.0f),
          maxSteps_(maxStepsPerFrame > 0 ? maxStepsPerFrame : 1) {}

    /// 累积 dt，按固定步长调用 fn(step)；返回执行步数。
    template <typename Fn>
    u32 Advance(f32 dt, Fn&& fn) {
        if (dt < 0.0f) dt = 0.0f;
        accumulator_ += dt;

        // 死亡螺旋保护：丢弃超过上限的积压时间
        const f32 cap = step_ * static_cast<f32>(maxSteps_);
        if (accumulator_ > cap) accumulator_ = cap;

        u32 steps = 0;
        while (accumulator_ >= step_ && steps < maxSteps_) {
            fn(step_);
            accumulator_ -= step_;
            ++steps;
            ++totalSteps_;
        }
        return steps;
    }

    void SetStep(f32 stepSeconds) {
        if (stepSeconds > 0.0f) step_ = stepSeconds;
    }
    f32 Step() const { return step_; }
    f32 Accumulator() const { return accumulator_; }
    u64 TotalSteps() const { return totalSteps_; }
    void Reset() { accumulator_ = 0.0f; }

private:
    f32 step_;
    u32 maxSteps_;
    f32 accumulator_ = 0.0f;
    u64 totalSteps_ = 0;
};

} // namespace M7N
