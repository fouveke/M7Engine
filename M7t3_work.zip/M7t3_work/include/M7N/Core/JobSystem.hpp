/**
 * @file JobSystem.hpp
 * @brief 工作线程池：ParallelFor 并行区间任务。
 *
 * 语义：
 *   - ParallelFor 是阻塞调用，返回时全部区间已完成
 *   - 从工作线程内部调用会退化为串行（避免嵌套死锁）
 *   - job 回调内不得再次触发 ParallelFor 以外的调度；不得修改 ECS 结构
 *     （只读写各自分区数据，组件存储的增删必须回到主线程）
 *
 * 默认线程数 = hardware_concurrency - 1（主线程参与执行）。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <functional>

namespace M7N {

class JobSystem {
public:
    /// @param workerCount 工作线程数（0 = 自动：CPU 核数 - 1）。
    explicit JobSystem(u32 workerCount = 0);
    ~JobSystem();

    JobSystem(const JobSystem&) = delete;
    JobSystem& operator=(const JobSystem&) = delete;

    /// 并行执行 fn(i)，i ∈ [0, count)；grain 为每次原子领取的连续区间大小。
    /// count 小于 grain*2 或线程数为 0 时直接串行执行。
    void ParallelFor(u32 count, u32 grain, const std::function<void(u32)>& fn);

    /// 工作线程数（不含主线程）。
    u32 WorkerCount() const;

    /// 当前调用是否位于 JobSystem 工作线程（可用于断言）。
    static bool IsWorkerThread();

private:
    struct Impl;
    Scope<Impl> impl_;
};

} // namespace M7N
