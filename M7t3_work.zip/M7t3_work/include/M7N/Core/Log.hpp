/**
 * @file Log.hpp
 * @brief 线程安全分级日志：引擎模块统一输出通道。
 *
 * 用法：
 *   M7N_LOG_INFO("Net", "server listening on %u", port);
 *   M7N_LOG_WARN("Asset", "missing %s", path.c_str());
 *
 * 可替换 Sink（编辑器日志面板 / 远程采集），默认写 stdout/stderr。
 * 日志级别全局过滤，默认 Info（Debug 构建下为 Debug）。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <cstdarg>

namespace M7N {

enum class LogLevel : u8 {
    Trace = 0,
    Debug,
    Info,
    Warn,
    Error,
    Fatal,
    Off,
};

class Log {
public:
    /// 全局最低输出级别（低于该级别直接丢弃）。
    static void SetLevel(LogLevel level);
    static LogLevel GetLevel();

    /// 自定义输出槽（level + 已格式化整行，含换行）。
    using Sink = void (*)(LogLevel level, const char* line, void* user);
    static void SetSink(Sink sink, void* user = nullptr);

    /// 格式化写入（线程安全；内部加时间戳与级别前缀）。
    static void Write(LogLevel level, const char* category, const char* fmt, ...);

private:
    static void VWrite(LogLevel level, const char* category, const char* fmt, va_list args);
};

} // namespace M7N

#define M7N_LOG_TRACE(cat, ...) ::M7N::Log::Write(::M7N::LogLevel::Trace, cat, __VA_ARGS__)
#define M7N_LOG_DEBUG(cat, ...) ::M7N::Log::Write(::M7N::LogLevel::Debug, cat, __VA_ARGS__)
#define M7N_LOG_INFO(cat, ...)  ::M7N::Log::Write(::M7N::LogLevel::Info,  cat, __VA_ARGS__)
#define M7N_LOG_WARN(cat, ...)  ::M7N::Log::Write(::M7N::LogLevel::Warn,  cat, __VA_ARGS__)
#define M7N_LOG_ERROR(cat, ...) ::M7N::Log::Write(::M7N::LogLevel::Error, cat, __VA_ARGS__)
#define M7N_LOG_FATAL(cat, ...) ::M7N::Log::Write(::M7N::LogLevel::Fatal, cat, __VA_ARGS__)
