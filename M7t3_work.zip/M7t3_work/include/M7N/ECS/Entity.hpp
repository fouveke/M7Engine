/**
 * @file Entity.hpp
 * @brief 实体句柄：index + generation 双字段防悬空引用。
 *
 * Entity 只是 8 字节轻量句柄，不携带任何数据。
 * index 定位记录槽位；generation 在实体销毁后自增，
 * 使旧句柄在 IsAlive 检查中自然失效。
 */
#pragma once

#include "M7N/Core/Types.hpp"

namespace M7N::ECS {

/// 无效实体索引（= u32 最大值）。
constexpr u32 kInvalidIndex = 0xFFFFFFFFu;

struct Entity {
    u32 index      = kInvalidIndex;
    u32 generation = 0;

    /// index 有效即视为非空句柄。
    bool IsValid() const { return index != kInvalidIndex; }

    bool operator==(const Entity& o) const { return index == o.index && generation == o.generation; }
    bool operator!=(const Entity& o) const { return !(*this == o); }
};

/// 空句柄常量。
constexpr Entity kNullEntity{ kInvalidIndex, 0 };

} // namespace M7N::ECS

/// std::hash 支持（可用于 unordered_map）。
template <>
struct std::hash<M7N::ECS::Entity> {
    size_t operator()(const M7N::ECS::Entity& e) const noexcept {
        return (static_cast<size_t>(e.generation) << 32) | e.index;
    }
};
