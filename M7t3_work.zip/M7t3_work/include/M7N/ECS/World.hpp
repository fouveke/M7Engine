/**
 * @file World.hpp
 * @brief World：实体池 + 组件存储注册表 + 场景图层级。
 *
 * 与 M7T1 全局 static 单例的根本区别：
 *   - World 是普通实例，可多开（编辑器 World / Play World / 服务器 World）
 *   - 组件存储按类型惰性创建，类型擦除统一持有
 *   - 层级（parent/children）按 index 对齐存放，销毁级联子树
 */
#pragma once

#include "M7N/ECS/Entity.hpp"
#include "M7N/ECS/ComponentStorage.hpp"

#include <atomic>
#include <cassert>

namespace M7N::ECS {

/// 组件类型槽位：每个 T 首次使用时分配一个进程内唯一小整数。
/// 取代 type_index 哈希查找 —— GetComponent 是每帧最热的路径之一。
inline u32 NextComponentTypeId() {
    static std::atomic<u32> next{0};
    return next.fetch_add(1, std::memory_order_relaxed);
}

template <typename T>
u32 ComponentTypeIdOf() {
    static const u32 id = NextComponentTypeId();
    return id;
}

class World {
public:
    World() = default;
    ~World() = default;

    // ------------------------------------------------------------------
    // 实体生命周期
    // ------------------------------------------------------------------

    /// 创建实体（优先复用空闲槽位）。
    Entity CreateEntity(const String& name = "Entity");

    /// 销毁实体：移除全部组件 + 从父级子列表摘除 + 级联销毁子树。
    void DestroyEntity(Entity e);

    /// 句柄是否指向存活实体（校验 generation）。
    bool IsAlive(Entity e) const;

    /// 存活实体总数。
    u32 AliveCount() const { return aliveCount_; }

    /// 遍历所有存活实体（回调式，倒序遍历允许回调内销毁）。
    template <typename Fn>
    void ForEachEntity(Fn&& fn) const {
        for (u32 i = static_cast<u32>(records_.size()); i-- > 0;) {
            if (!records_[i].alive) continue;
            Entity e{ i, records_[i].generation };
            fn(e);
        }
    }

    // ------------------------------------------------------------------
    // 名称（编辑器 / 调试用）
    // ------------------------------------------------------------------

    const String& GetName(Entity e) const;
    void SetName(Entity e, const String& name);

    // ------------------------------------------------------------------
    // 组件操作（对死亡句柄安全返回，Debug 断言拦截非法挂载）
    // ------------------------------------------------------------------

    template <typename T, typename... Args>
    T& AddComponent(Entity e, Args&&... args) {
        assert(IsAlive(e) && "AddComponent: dead entity");
        return GetStorage<T>().Emplace(e, std::forward<Args>(args)...);
    }

    template <typename T>
    T* GetComponent(Entity e) const {
        return const_cast<World*>(this)->GetStorage<T>().Get(e);
    }

    template <typename T>
    bool HasComponent(Entity e) const {
        return const_cast<World*>(this)->GetStorage<T>().Has(e);
    }

    template <typename T>
    bool RemoveComponent(Entity e) {
        if (!IsAlive(e)) return false;
        return GetStorage<T>().Remove(e);
    }

    /// 取（或惰性创建）某类型的组件存储（O(1) 类型槽位，无哈希）。
    template <typename T>
    ComponentStorage<T>& GetStorage() {
        const u32 id = ComponentTypeIdOf<T>();
        if (id >= storages_.size()) storages_.resize(static_cast<size_t>(id) + 1);
        Scope<IComponentStorage>& slot = storages_[id];
        if (!slot) slot = CreateScope<ComponentStorage<T>>();
        return *static_cast<ComponentStorage<T>*>(slot.get());
    }

    // ------------------------------------------------------------------
    // 场景图层级
    // ------------------------------------------------------------------

    /// 设置父级（kNullEntity = 摘除为根）。拒绝环（祖先链回溯检查）。
    /// @return 是否成功。
    bool SetParent(Entity child, Entity parent);

    Entity GetParent(Entity e) const;

    /// 直接子节点列表（无拷贝；勿在遍历此列表时改层级）。
    const std::vector<Entity>& GetChildren(Entity e) const;

    /// ancestor 是否为 e 的祖先（含直接父级）。
    bool IsAncestorOf(Entity ancestor, Entity e) const;

    // ------------------------------------------------------------------
    // 遍历
    // ------------------------------------------------------------------

    /// 拥有全部指定组件的实体遍历。
    /// 以 T0 的 dense 数组为主导倒序扫描（支持回调中增删组件/实体）。
    template <typename T0, typename... Rest, typename Fn>
    void ForEach(Fn&& fn) const {
        auto& lead = const_cast<World*>(this)->GetStorage<T0>();
        for (u32 i = static_cast<u32>(lead.Size()); i-- > 0;) {
            Entity e = lead.OwnerAt(i);
            if (!IsAlive(e)) continue; // swap-remove 后尾部补位，稳妥复查
            if ((const_cast<World*>(this)->GetStorage<Rest>().Has(e) && ...)) {
                fn(e, lead.ComponentAt(i),
                   *const_cast<World*>(this)->GetStorage<Rest>().Get(e)...);
            }
        }
    }

    /// 预留实体容量（批量创建前调用，避免多次扩容搬移）。
    void Reserve(u32 entityCount) {
        records_.reserve(entityCount);
        names_.reserve(entityCount);
        parents_.reserve(entityCount);
        children_.reserve(entityCount);
    }

    /// 清空世界（销毁全部实体，保留存储容量）。
    void Clear();

private:
    struct Record {
        u32 generation = 0;
        bool alive = false;
    };

    void growTo(u32 index);

    std::vector<Record>              records_;    // index 对齐：代数 + 存活位
    std::vector<String>              names_;      // index 对齐
    std::vector<Entity>              parents_;    // index 对齐：父句柄
    std::vector<std::vector<Entity>> children_;   // index 对齐：子句柄列表
    std::vector<u32>                 freeList_;   // 空闲槽位栈
    u32                              aliveCount_ = 0;

    std::vector<Scope<IComponentStorage>> storages_;   // 类型 id -> 存储
};

} // namespace M7N::ECS
