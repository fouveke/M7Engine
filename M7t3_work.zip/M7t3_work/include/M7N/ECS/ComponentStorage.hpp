/**
 * @file ComponentStorage.hpp
 * @brief SparseSet 组件存储：dense 数组缓存友好 + sparse 索引 O(1) 定位。
 *
 * 内存布局：
 *   components_ : 紧凑数组，正序遍历零缓存失效
 *   owners_     : 与 components_ 逐槽对齐的实体句柄
 *   sparse_     : entity.index -> dense 下标（kNoSlot 表示未挂组件）
 *
 * 删除采用 swap-remove：尾部元素补位，O(1) 且无空洞。
 * Get/Has 校验 generation，天然拒绝已销毁实体的悬空句柄。
 *
 * 引用稳定性约定（与 EnTT 一致）：
 *   Emplace 返回的引用在后续扩容后失效；同实体重复 Emplace 为重置语义。
 */
#pragma once

#include "M7N/ECS/Entity.hpp"

#include <typeinfo>

namespace M7N::ECS {

constexpr u32 kNoSlot = 0xFFFFFFFFu;

/// 类型擦除基类：World 在实体销毁时逐存储回调清理。
class IComponentStorage {
public:
    virtual ~IComponentStorage() = default;
    virtual void OnEntityDestroyed(Entity e) = 0;
    virtual const char* DebugName() const = 0;
    virtual size_t Size() const = 0;
};

template <typename T>
class ComponentStorage final : public IComponentStorage {
public:
    /// 挂载组件（已存在则原地覆盖 = 重置语义）。
    template <typename... Args>
    T& Emplace(Entity e, Args&&... args) {
        u32 slot = slotOf(e);
        if (slot != kNoSlot) {
            components_[slot] = T(std::forward<Args>(args)...);
            owners_[slot] = e;
            return components_[slot];
        }
        u32 newSlot = static_cast<u32>(components_.size());
        components_.emplace_back(std::forward<Args>(args)...);
        owners_.push_back(e);
        ensureSparse(e.index);
        sparse_[e.index] = newSlot;
        return components_[newSlot];
    }

    /// 移除组件（swap-remove，尾部补位）。
    bool Remove(Entity e) {
        u32 slot = slotOf(e);
        if (slot == kNoSlot) return false;

        u32 last = static_cast<u32>(components_.size() - 1);
        if (slot != last) {
            components_[slot] = std::move(components_[last]);
            owners_[slot]     = owners_[last];
            sparse_[owners_[slot].index] = slot;
        }
        components_.pop_back();
        owners_.pop_back();
        sparse_[e.index] = kNoSlot;
        return true;
    }

    /// 取组件指针；句柄过期（generation 不匹配）返回 nullptr。
    T* Get(Entity e) {
        u32 slot = slotOf(e);
        return (slot != kNoSlot) ? &components_[slot] : nullptr;
    }
    const T* Get(Entity e) const {
        u32 slot = slotOf(e);
        return (slot != kNoSlot) ? &components_[slot] : nullptr;
    }

    bool Has(Entity e) const { return slotOf(e) != kNoSlot; }

    /// 预留容量（避免批量挂载中途扩容搬移）。
    void Reserve(size_t count) {
        components_.reserve(count);
        owners_.reserve(count);
    }

    // --- dense 直访（View 遍历用）---
    size_t Size() const override { return components_.size(); }
    Entity OwnerAt(u32 slot) const { return owners_[slot]; }
    T&     ComponentAt(u32 slot)   { return components_[slot]; }
    const T& ComponentAt(u32 slot) const { return components_[slot]; }

    void OnEntityDestroyed(Entity e) override { Remove(e); }
    const char* DebugName() const override { static const char* n = typeid(T).name(); return n; }

private:
    u32 slotOf(Entity e) const {
        if (e.index >= sparse_.size()) return kNoSlot;
        u32 slot = sparse_[e.index];
        if (slot == kNoSlot) return kNoSlot;
        if (owners_[slot].generation != e.generation) return kNoSlot; // 悬空句柄
        return slot;
    }

    void ensureSparse(u32 index) {
        if (index >= sparse_.size()) sparse_.resize(static_cast<size_t>(index) + 1, kNoSlot);
    }

    std::vector<T>      components_;  // dense：紧凑组件数据
    std::vector<Entity> owners_;      // dense：与 components_ 对齐
    std::vector<u32>    sparse_;      // entity.index -> slot
};

} // namespace M7N::ECS
