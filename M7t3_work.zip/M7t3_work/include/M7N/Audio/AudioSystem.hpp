/**
 * @file AudioSystem.hpp
 * @brief 音频系统：播放 / 3D 空间化 / 麦克风采集（miniaudio 后端）。
 *
 * 能力（自 M7T1 AudioEngine 平移）：
 *  - 多格式解码：WAV / MP3 / FLAC / Ogg Vorbis
 *  - 软件混音（立体声 16-bit 输出）
 *  - 3D 定位音频：距离衰减 + 等功率立体声像（监听者朝向导出）+ 多普勒
 *  - 逐源控制：音量 / 音调 / 声像 / 循环 / 播放状态
 *  - 麦克风采集：RMS 电平表 + 采样回读（环形缓冲）
 *
 * 与 M7T1 的区别：全部状态为实例成员（消灭 static 全局状态），
 * 可多实例并存。miniaudio 类型不暴露在本公共头文件——设备对象
 * 藏于 cpp 内定义的私有 Impl（pimpl）。
 *
 * 线程安全：设备回调线程与主线程共享 sources_ 等列表，由成员
 * mutex_ 保护（沿用 M7T1 方案）；回调经 pUserData 指回本实例。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Audio/AudioComponents.hpp"

#include <deque>
#include <memory>
#include <mutex>
#include <vector>

namespace M7N::Audio {

/// 声源播放状态。
enum class AudioState : u8 {
    Stopped,   ///< 已停止（待清理）
    Playing,   ///< 播放中
    Paused,    ///< 已暂停
    Finished   ///< 播放完毕（待清理）
};

/// 解码后的音频缓冲（统一为引擎混音格式的交错 PCM）。
struct AudioBuffer {
    String name;                    ///< 缓冲名（文件名，缓存查重用）
    std::vector<u8> data;           ///< PCM 采样（交错 s16 立体声）
    u32 sampleRate    = 44100;
    u16 channels      = 2;
    u16 bitsPerSample = 16;
    u32 totalSamples  = 0;          ///< 总帧数（1 帧 = 每声道 1 采样）
    bool valid        = false;
};

/// 活动声源（一个播放实例）。
struct AudioSource {
    u32          id = 0;                     ///< 播放句柄
    AudioBuffer* buffer = nullptr;           ///< 数据缓冲
    AudioState   state = AudioState::Stopped;
    f32          volume = 1.0f;
    f32          pitch = 1.0f;
    bool         looping = false;
    f64          position = 0.0;             ///< 当前采样位置（浮点，供多普勒重采样）
    Vec3         position3D = Vec3(0.0f);    ///< 世界坐标（3D 源）
    Vec3         velocity = Vec3(0.0f);      ///< 世界速度（米/秒，多普勒）
    f32          range = 10.0f;              ///< 3D 可听半径
    bool         is3D = false;
    f32          pan = 0.0f;                 ///< 2D 源立体声像（-1 左 .. +1 右）
};

/// 音频系统（普通实例类；每个实例独占一套设备与源列表）。
class AudioSystem {
public:
    AudioSystem();
    ~AudioSystem();

    AudioSystem(const AudioSystem&) = delete;
    AudioSystem& operator=(const AudioSystem&) = delete;

    // ------------------------------------------------------------------
    // 生命周期
    // ------------------------------------------------------------------

    /// 初始化（打开播放设备）。@return 失败返回 false。
    bool Init();

    /// 关闭并释放全部资源。
    void Shutdown();

    /// 帧更新（ECS 集成 + 已结束声源清理）：
    ///  - AudioSourceComp：playOnStart 且未触发的播放；is3D 源用实体
    ///    Transform.position 更新声源位置
    ///  - AudioListenerComp 实体：更新监听者位置/朝向（前向由
    ///    Transform.rotation 欧拉角计算）与增益
    void OnUpdate(f32 dt, ECS::World& world);

    // ------------------------------------------------------------------
    // 声音控制
    // ------------------------------------------------------------------

    /// 加载声音文件到缓冲（同名复用缓存）。
    /// 支持 WAV / MP3 / FLAC / OGG（按内容识别，非扩展名）。
    /// @return 缓冲指针，失败返回 nullptr。
    AudioBuffer* LoadSound(const String& filepath);

    /// 播放声音文件（2D，不做空间化）。
    /// @return 播放句柄（失败 0）。
    u32 Play(const String& filepath, f32 volume = 1.0f, bool looping = false);

    /// 在 3D 位置播放（衰减 + 声像 + 多普勒）。
    /// @return 播放句柄（失败 0）。
    u32 Play3D(const String& filepath, const Vec3& position,
               f32 volume = 1.0f, f32 range = 10.0f);

    /// 播放已加载的缓冲。
    /// @return 播放句柄（失败 0）。
    u32 PlayBuffer(AudioBuffer* buffer, f32 volume = 1.0f, bool looping = false);

    /// 停止指定源。
    void Stop(u32 sourceId);

    /// 暂停 / 恢复。
    void Pause(u32 sourceId);
    void Resume(u32 sourceId);

    /// 逐源音量（0.0 .. 1.0）。
    void SetVolume(u32 sourceId, f32 volume);

    /// 逐源音调缩放（0.25 .. 4.0）。
    void SetPitch(u32 sourceId, f32 pitch);

    /// 2D 源立体声像（-1.0 左 .. +1.0 右）；3D 源忽略
    /// （其声像由监听者朝向导出）。
    void SetPan(u32 sourceId, f32 pan);

    /// 设置源 3D 位置（同时把源标记为 3D）。
    void SetPosition(u32 sourceId, const Vec3& position);

    /// 设置源世界速度（米/秒），供多普勒计算。
    void SetVelocity(u32 sourceId, const Vec3& velocity);

    /// 设置监听者位置与朝向。
    void SetListener(const Vec3& position, const Vec3& forward, const Vec3& up);

    /// 设置监听者世界速度（米/秒），供多普勒计算。
    void SetListenerVelocity(const Vec3& velocity);

    /// 主音量（0.0 .. 1.0）。
    void SetMasterVolume(f32 volume);
    f32  GetMasterVolume() const;

    /// 全局多普勒开关。
    void SetDopplerEnabled(bool enabled);
    bool IsDopplerEnabled() const;

    // ------------------------------------------------------------------
    // 采集（麦克风输入）
    // ------------------------------------------------------------------

    /// 打开默认采集设备并开始录音。
    /// @return 无麦克风或权限被拒时返回 false。
    bool StartCapture();

    /// 停止录音并释放采集设备。
    void StopCapture();

    /// 是否正在采集。
    bool IsCapturing() const;

    /// 最近麦克风响度（RMS，0.0 .. 1.0；未采集时 0）。
    f32 GetCaptureLevel() const;

    /// 拷贝最近采集的采样到 out（交错 s16 单声道 @ 采集率）。
    /// @return 实际拷贝的帧数（语音可视化 / 声控逻辑用）。
    u32 ReadCaptureSamples(i16* out, u32 frameCount);

    // ------------------------------------------------------------------
    // 状态查询
    // ------------------------------------------------------------------

    /// 播放中的源数量。
    u32 GetActiveSourceCount();

    // ------------------------------------------------------------------
    // 内部：设备回调线程调用（勿在主线程直接调用）
    // ------------------------------------------------------------------

    /// 混音一个输出块（播放设备回调入口）。
    void mixAudio(i16* output, u32 frameCount);

    /// 处理一块采集输入（采集设备回调入口）。
    void handleCapture(const i16* input, u32 frameCount);

private:
    /// 私有实现：持有 miniaudio 设备与采集环形缓冲（仅 cpp 内可见）。
    struct Impl;
    std::unique_ptr<Impl> impl_;

    /// 写监听者完整状态（含增益）。调用方必须已持 mutex_。
    void setListenerLocked(const Vec3& position, const Vec3& forward,
                           const Vec3& up, f32 gain);

    /// 解码声音文件（WAV/MP3/FLAC/OGG）。
    bool decodeFile(const String& filepath, AudioBuffer& outBuffer);

    /// 按 id 查源。调用方必须已持 mutex_。
    AudioSource* findSource(u32 id);

    // --- 实例状态（原 M7T1 的 static 全局状态迁于此）---
    bool initialized_    = false;
    f32  masterVolume_   = 1.0f;
    u32  nextSourceId_   = 1;      ///< 播放句柄发号器
    bool dopplerEnabled_ = true;
    f32  listenerGain_   = 1.0f;   ///< 监听者增益（乘到总输出）

    /// 缓冲池。用 deque：元素地址稳定——播放中的源持有的
    /// AudioBuffer* 不会因后续加载触发扩容而悬空（M7T1 用 vector
    /// 存在此风险，迁移时修正）。
    std::deque<AudioBuffer> buffers_;

    std::vector<AudioSource> sources_; ///< 活动源列表
    std::mutex mutex_;             ///< 主线程 <-> 音频回调线程

    // 监听者状态
    Vec3 listenerPos_      = Vec3(0.0f);
    Vec3 listenerForward_  = Vec3(0.0f, 0.0f, -1.0f);
    Vec3 listenerUp_       = Vec3(0.0f, 1.0f, 0.0f);
    Vec3 listenerVelocity_ = Vec3(0.0f);
};

} // namespace M7N::Audio
