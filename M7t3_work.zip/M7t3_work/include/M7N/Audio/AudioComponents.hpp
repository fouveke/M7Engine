/**
 * @file AudioComponents.hpp
 * @brief M7Next 音频组件：声源配置 + 监听者标记。
 *
 * 组件为纯数据；播放行为与 3D 空间化归 AudioSystem
 * （src/Audio/AudioSystem.cpp），与 M7N"组件 = 数据，系统 = 行为"分层一致。
 *
 * runtimeSourceId / started 为运行时字段，由 AudioSystem 每帧写入，
 * 不参与反射与序列化（序列化后恢复播放属场景运行时行为）。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/Reflect/TypeInfo.hpp"

namespace M7N::Audio {

/// 声源组件。
struct AudioSourceComp {
    // --- 配置（可序列化）---
    String soundFile;             ///< 音频文件路径（WAV/MP3/FLAC/OGG，按内容识别）
    f32    volume      = 1.0f;    ///< 音量（0..1）
    f32    pitch       = 1.0f;    ///< 音调缩放（0.25..4）
    bool   looping     = false;   ///< 循环播放
    bool   playOnStart = false;   ///< 组件出现后自动播放一次
    bool   is3D        = false;   ///< 3D 空间化（距离衰减 + 声像 + 多普勒）
    f32    range       = 10.0f;   ///< 3D 可听半径（米，线性衰减）

    // --- 运行时状态（AudioSystem 写，不参与反射/序列化）---
    u32 runtimeSourceId = 0;      ///< 播放句柄（0 = 无）
    bool started        = false;  ///< playOnStart 是否已触发
};

/// 音频监听者组件：标记实体为"耳朵"（位置/朝向取实体 Transform）。
struct AudioListenerComp {
    f32 gain = 1.0f;              ///< 监听者增益（乘到总输出）
};

} // namespace M7N::Audio

// --- 反射注册 ---

M7N_REFLECT_BEGIN(M7N::Audio::AudioSourceComp)
    M7N_PROP(soundFile,   String)
    M7N_PROP(volume,      Float)
    M7N_PROP(pitch,       Float)
    M7N_PROP(looping,     Bool)
    M7N_PROP(playOnStart, Bool)
    M7N_PROP(is3D,        Bool)
    M7N_PROP(range,       Float)
M7N_REFLECT_END(M7N::Audio::AudioSourceComp)

M7N_REFLECT_BEGIN(M7N::Audio::AudioListenerComp)
    M7N_PROP(gain, Float)
M7N_REFLECT_END(M7N::Audio::AudioListenerComp)
