/**
 * @file AssetManager.hpp
 * @brief 资产管理器：解析缓存 + 经 RHI 上传 GPU + 生命周期管理。
 *
 * 实例类，构造接 RHI::IRenderDevice&；一切 GPU 资源以 RHI 句柄持有，
 * 不直接调用 GL/GLFW。网格与纹理均按 path 缓存（首次加载上传，重复请求命中缓存）。
 *
 * 顶点交错布局约定（上传时建立，渲染管线按此绑定）：
 *   location 0: position  vec3  offset  0 字节
 *   location 1: normal    vec3  offset 12 字节
 *   location 2: texCoord  vec2  offset 24 字节
 *   location 5: lightmapUV vec2 offset 32 字节
 *   stride = 10 浮点 = 40 字节/顶点
 */
#pragma once

#include "M7N/Asset/Types.hpp"
#include "M7N/RHI/IRenderDevice.hpp"

#include <unordered_map>

namespace M7N::Asset {

/// GPU 侧网格（句柄 + 索引数，供渲染系统取用）。
struct GPUMesh {
    RHI::BufferHandle vbo;         ///< 顶点缓冲（交错布局，40 字节/顶点）
    RHI::BufferHandle ibo;         ///< 索引缓冲（u32 索引）
    u32 indexCount = 0;            ///< 总索引数（子网格区间查 AssetManager::GetModelData）

    // --- 可选蒙皮附加缓冲（location 3/4：jointIdx 位模式 + weight）---
    RHI::BufferHandle skin;        ///< 蒙皮属性缓冲（32 字节/顶点；无效 = 静态网格）
    bool skinned = false;          ///< 是否带蒙皮

    // --- 局部空间包围盒（视锥剔除用）---
    Vec3 boundsMin = Vec3(0.0f);
    Vec3 boundsMax = Vec3(0.0f);
};

/// GPU 纹理与尺寸（Renderer2D 依尺寸推默认世界大小）。
struct TextureInfo {
    RHI::TextureHandle handle;
    u32 width = 0;
    u32 height = 0;
};

/// 资产管理器：path -> ModelData（CPU）/ GPUMesh / TextureHandle（GPU）缓存。
class AssetManager {
public:
    /// 构造（持有设备引用，不拥有设备）。
    explicit AssetManager(RHI::IRenderDevice& device);

    /// 析构：经 RHI 销毁全部缓存的 vbo/ibo/texture。
    ~AssetManager();

    AssetManager(const AssetManager&) = delete;
    AssetManager& operator=(const AssetManager&) = delete;

    /// 取或建网格：解析 path -> ModelData 缓存 -> 首次把交错顶点
    /// （pos3+normal3+uv2 = 8 浮点/顶点）CreateBuffer Vertex、
    /// indices CreateBuffer Index 上传 -> 缓存句柄；重复请求返回缓存。
    /// @return 顶点缓冲句柄（解析或上传失败为无效句柄）
    RHI::BufferHandle GetOrCreateMesh(const String& path);

    /// 注册程序化网格：把现成 MeshData（CPU）按 name 缓存并上传 GPU。
    /// 适合运行时生成的几何（示例内置图元、程序化地形等），
    /// 与 glTF 加载的网格共用同一套缓存/渲染路径。
    /// @return 是否成功（空网格 / 同名已存在 / 上传失败返回 false）
    bool RegisterProceduralMesh(const String& name, const MeshData& data);

    /// 取 GPU 网格（未加载时自动触发 GetOrCreateMesh）。失败时句柄无效。
    GPUMesh GetGPUMesh(const String& path);

    /// 取缓存的 CPU 侧模型数据（含 submesh 区间与材质表）；未加载返回 nullptr。
    /// 注意：指针不跨帧持有（后续加载其它资产可能使 unordered_map 重哈希）。
    const ModelData* GetModelData(const String& path);

    /// 取或建纹理：path 为外部文件路径或 data:...;base64, URI
    /// （来自 ModelMaterial::texturePath / MeshRef::texturePath）。stb_image 解码（强制 4 通道）
    /// -> TextureDesc RGBA8 上传 -> 缓存。默认 Repeat 环绕 + mipmap（地形/墙体平铺）。
    /// @param srgb 颜色贴图传 true（sRGB 解码）；法线/粗糙度等数据贴图传 false
    /// @return 纹理句柄（解码或上传失败为无效句柄）
    RHI::TextureHandle GetOrCreateTexture(const String& path, bool srgb = true);

    /// 取纹理并附带像素尺寸（未加载则触发加载）。
    /// @param pixelArt true 使用 Nearest 过滤（2D 像素美术；缓存键独立）
    bool GetTextureInfo(const String& path, TextureInfo& out, bool pixelArt = false);

    /// 注册程序化 RGBA8 纹理（像素美术默认 Nearest）。
    /// @param name 纹理键（后续 GetTextureInfo/GetOrCreateTexture 同名取得）
    /// @return 是否成功（同名已存在 / 像素为空 / 上传失败返回 false）
    bool RegisterTexture(const String& name, u32 width, u32 height,
                         const void* rgbaPixels, bool pixelArt = false);

    /// 注册程序化纹理：name 为查表键（与 MeshRef::texturePath 对应），
    /// pixels 为 RGBA8（宽*高*4 字节，可为 nullptr 表示纯白）。
    /// 用于无外部图片资产的场景（程序化沙地/混凝土/危险条纹等）。
    /// @return 是否成功（同名已存在 / 上传失败返回 false）
    bool RegisterProceduralTexture(const String& name, u32 width, u32 height,
                                   const u8* rgba, bool repeat = true, bool mipmaps = true,
                                   bool srgb = true);

    /// 手动卸载网格：经 RHI 销毁 vbo/ibo，并丢弃对应 CPU/GPU 缓存。
    void Unload(const String& path);

    /// 引用计数简化版：当前策略为全部保留（本函数为空操作）；
    /// 需要释放时由调用方手动 Unload(path)。
    void ReleaseUnused();

    /// 资源版本号：网格/纹理新增、注册或卸载时递增。
    /// 渲染侧缓存以该版本判断句柄是否可能失效，避免每帧重新哈希资产表。
    u64 Revision() const { return revision_; }

private:
    /// 交错上传 + 缓存（GetOrCreateMesh / RegisterProceduralMesh 共用）。
    /// @return 是否成功（失败时半途缓冲已回收）。
    bool uploadMesh(const String& name, ModelData model);

    /// 纹理加载/上传统一入口（sRGB 与像素美术过滤分表存放，避免拼接缓存键）。
    RHI::TextureHandle loadTexture(const String& path, bool srgb, bool pixelArt);

    using TextureMap = std::unordered_map<String, TextureInfo>;
    TextureMap& textureMap(bool srgb, bool pixelArt) {
        if (pixelArt) return texturesNearest_;
        return srgb ? texturesSrgb_ : texturesLinear_;
    }

    RHI::IRenderDevice& device_;                             ///< 设备引用

    std::unordered_map<String, ModelData> models_;           ///< CPU 侧模型缓存
    std::unordered_map<String, GPUMesh>   meshes_;           ///< GPU 侧网格缓存
    TextureMap texturesSrgb_;                                ///< 颜色贴图（sRGB 采样）
    TextureMap texturesLinear_;                              ///< 数据贴图（线性采样）
    TextureMap texturesNearest_;                             ///< 像素美术（Nearest）
    u64 revision_ = 1;                                       ///< 资产句柄版本
};

} // namespace M7N::Asset
