/**
 * @file Types.hpp
 * @brief 资产系统 CPU 侧数据结构：网格 / 材质 / 蒙皮 / 动画。
 *
 * 全部为纯 CPU 数据（std::vector 平铺），零 GL/RHI 依赖：
 * GLTFLoader 负责从 .gltf 填充这些结构，AssetManager 负责上传 GPU。
 */
#pragma once

#include "M7N/Core/Types.hpp"

namespace M7N::Asset {

/// 子网格在合并索引缓冲中的区间。
struct SubMeshRange {
    u32 indexOffset = 0;   ///< 起始索引（相对整体 indices 数组）
    u32 indexCount  = 0;   ///< 索引个数
};

/// CPU 侧网格数据（按属性分列存放；上传 GPU 时由 AssetManager 交错化）。
struct MeshData {
    std::vector<Vec3> positions;          ///< 顶点位置（必有）
    std::vector<Vec3> normals;             ///< 法线（缺失补 (0,1,0)；长度 0 或等于顶点数）
    std::vector<Vec2> texCoords;           ///< UV（glTF 左上原点已翻转为 GL 左下原点；长度 0 或等于顶点数）
    std::vector<Vec2> texCoords2;          ///< 第二套 UV（BSP 烘焙光图坐标；长度 0 或等于顶点数）
    std::vector<u32>  indices;             ///< 合并后的索引（u32）
    std::vector<SubMeshRange> submeshes;   ///< 子网格区间表（与 ModelData::submeshMaterials 一一对应）

    // --- 可选蒙皮（模型含 JOINTS_0/WEIGHTS_0 时填充，每顶点 4 个展平）---
    std::vector<i32> jointIndices;         ///< 关节索引 [4]/顶点 展平（无蒙皮时为空）
    std::vector<f32>  jointWeights;        ///< 关节权重 [4]/顶点 展平（无蒙皮时为空）
    bool skinned = false;                   ///< 是否带蒙皮数据（蒙皮模型缺失属性的顶点补 0）
};

/// CPU 侧材质（PBR：反照率 + 法线 + 金属粗糙度 + 自发光）。
struct ModelMaterial {
    String name = "material";              ///< 材质名
    Vec4   baseColor = Vec4(1.0f);          ///< baseColorFactor
    f32    metallic  = 1.0f;                ///< metallicFactor（glTF 缺省 1.0）
    f32    roughness = 1.0f;                ///< roughnessFactor（glTF 缺省 1.0）
    String texturePath = "";                ///< baseColorTexture 来源：外部文件为相对 .gltf 目录的解析结果；内嵌为 data:...;base64, 原样 URI（由 AssetManager 解码上传）
    String normalPath = "";                 ///< 法线贴图（glTF normalTexture；切线空间，OpenGL 约定 +Y）
    String metallicRoughnessPath = "";      ///< 金属粗糙度贴图（glTF metallicRoughnessTexture：G=roughness, B=metallic）
    Vec3   emissiveFactor = Vec3(0.0f);     ///< 自发光颜色（glTF emissiveFactor）
    String emissivePath = "";               ///< 自发光贴图（glTF emissiveTexture）
    /// 透明度裁剪阈值：采样到的 alpha 低于它就丢弃片元（0 = 不裁剪）。
    /// 只由 glTF 的 alphaMode=MASK 填；BLEND 不映射——引擎没有透明排序 pass，
    /// 拿裁剪冒充混合会把软边贴图削成方块。
    f32    alphaCutoff = 0.0f;
};

/// CPU 侧骨骼关节（绑定姿态）。
struct JointData {
    String name;                            ///< 关节名（来自节点名）
    i32    parent = -1;                     ///< 父关节索引（-1 = 根）
    Mat4   inverseBind = Mat4(1.0f);        ///< 逆绑定矩阵
    Vec3   restTranslation = Vec3(0.0f);    ///< 绑定姿态平移
    Quat   restRotation = Quat(0.0f, 0.0f, 0.0f, 1.0f); ///< 绑定姿态旋转（identity，本库 (x,y,z,w)）
    Vec3   restScale = Vec3(1.0f);          ///< 绑定姿态缩放
};

/// CPU 侧皮肤。
struct SkinData {
    String name;                            ///< 皮肤名
    std::vector<JointData> joints;          ///< 关节表（顺序 = glTF joints 数组顺序）

    /// 骨架根矩阵：所有根关节的共同父节点（非关节）的世界变换。
    /// 蒙皮顶点生活在骨架根的局部空间里，动画通道驱动根关节时会顶掉
    /// 烤进 rest pose 的祖先变换，所以这个矩阵必须**单独**乘在调色板最外层
    /// （等价于 three.js 的 bindMatrix）。Mixamo 导出的模型这里是
    /// "0.01 缩放 + Z-up→Y-up 旋转"；无缩放/旋转的模型它是单位阵。
    Mat4 rootMatrix = Mat4(1.0f);
};

/// 动画通道目标属性。
enum class AnimPath : u8 { Translation, Rotation, Scale };

/// 动画采样插值（CUBICSPLINE 不支持，按 LINEAR 处理）。
enum class AnimInterp : u8 { Linear, Step };

/// CPU 侧动画通道（单关节单曲线）。
struct AnimChannel {
    u32      jointIndex = 0;                ///< 目标关节索引
    AnimPath path = AnimPath::Translation;  ///< 目标属性
    AnimInterp interp = AnimInterp::Linear; ///< 插值方式
    std::vector<f32> times;                 ///< 采样时间轴（秒）
    std::vector<Vec3> vecKeys;              ///< Translation/Scale 关键帧
    std::vector<Quat> quatKeys;             ///< Rotation 关键帧
};

/// CPU 侧动画片段。
struct AnimationClip {
    String name = "animation";              ///< 片段名
    f32    duration = 0.0f;                 ///< 最长通道末时间（秒）
    std::vector<AnimChannel> channels;      ///< 通道表
};

/// CPU 侧完整模型：合并网格 + 材质表 + 蒙皮 + 动画。
struct ModelData {
    MeshData mesh;                           ///< 合并网格
    std::vector<ModelMaterial> materials;   ///< 材质表（glTF materials 顺序）
    std::vector<i32> submeshMaterials;      ///< submesh i -> materials 索引（-1 = 无材质/越界）
    SkinData skeleton;                      ///< 骨骼（无蒙皮时 joints 为空）
    std::vector<AnimationClip> animations;  ///< 动画片段

    // --- 局部空间包围盒（上传时计算；视锥剔除用）---
    Vec3 boundsMin = Vec3(0.0f);
    Vec3 boundsMax = Vec3(0.0f);
};

} // namespace M7N::Asset
