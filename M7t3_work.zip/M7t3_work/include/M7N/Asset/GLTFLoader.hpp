/**
 * @file GLTFLoader.hpp
 * @brief glTF 2.0 加载器：.gltf（文本）与 .glb（二进制）双容器，解析到 CPU 侧 ModelData。
 *
 * 纯 CPU 解析，零 GL/RHI 依赖；GPU 上传归 AssetManager。
 * 支持：mesh primitive（POSITION/NORMAL/TEXCOORD_0/JOINTS_0/WEIGHTS_0）、
 *       材质 baseColorFactor / baseColorTexture（data URI、外部文件、.glb bufferView 内嵌）、
 *       节点层级（TRS/matrix/children，世界变换烘焙进顶点）、skin joints（含逆绑定矩阵）、
 *       LINEAR/STEP 动画通道（CUBICSPLINE 降级 LINEAR，取中间值）、base64 内嵌 buffer、
 *       .glb 二进制容器（JSON/BIN chunk）。
 * 不支持：morph target（weights 通道）。
 */
#pragma once

#include "M7N/Asset/Types.hpp"

namespace M7N::Asset {

/// glTF 加载器（无状态，全部入口为静态函数）。
class GLTFLoader {
public:
    /// 解析 .gltf 文件填充 out（先清空旧内容）。
    /// @param filepath .gltf 文件路径（外部 buffer/纹理相对其所在目录解析）
    /// @param out     输出模型数据
    /// @return 是否解析出几何数据（至少一个含 POSITION 的 primitive）
    static bool Load(const String& filepath, ModelData& out);
};

/// base64 解码（跳过非表内字符；供 data URI buffer 与内嵌纹理共用）。
/// @param in  base64 载荷（不含 "base64," 前缀，即逗号之后的内容）
/// @param out 解码字节
/// @return 是否解出非空数据
bool DecodeBase64(const String& in, std::vector<u8>& out);

} // namespace M7N::Asset
