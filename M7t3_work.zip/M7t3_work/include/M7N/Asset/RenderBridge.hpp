/**
 * @file RenderBridge.hpp
 * @brief 渲染桥（小工具头）：ECS 场景 -> 命令录制。
 *
 * 示范渲染系统如何消费资产：遍历 Transform+MeshRef 实体，
 * 逐个 BindVertexBuffer / BindIndexBuffer / SetMat4("u_MVP") / DrawIndexed。
 * 着色器/管线由调用方先行绑定（cmd.BindPipeline 已录好），本函数只补实体绘制。
 */
#pragma once

#include "M7N/Asset/AssetManager.hpp"
#include "M7N/RHI/CommandList.hpp"
#include "M7N/Scene/Components.hpp"

namespace M7N::Asset {

/// 遍历 world 中带 Transform + MeshRef 的实体，逐个录制实体绘制命令。
/// @param world    场景世界
/// @param cmd      命令列表（调用方已录好 Clear/Viewport/BindPipeline）
/// @param assets   资产管理器（提供 GPUMesh 与 submesh 区间）
/// @param viewProj 视图投影矩阵（proj * view）
inline void BuildMeshDrawCommands(ECS::World& world, RHI::CommandList& cmd,
                                  AssetManager& assets, const Mat4& viewProj) {
    world.ForEach<Scene::Transform, Scene::MeshRef>(
        [&](ECS::Entity e, Scene::Transform& /*transform*/, Scene::MeshRef& meshRef) {
            const GPUMesh gpu = assets.GetGPUMesh(meshRef.path);
            if (!gpu.vbo.IsValid() || !gpu.ibo.IsValid()) return;

            cmd.BindVertexBuffer(gpu.vbo);
            cmd.BindIndexBuffer(gpu.ibo);
            cmd.SetMat4("u_MVP", viewProj * Scene::ComputeWorldMatrix(world, e));

            // 子网格区间：MeshRef::submesh 越界时退化为整网格绘制
            u32 firstIndex = 0;
            u32 indexCount = gpu.indexCount;
            const ModelData* model = assets.GetModelData(meshRef.path);
            if (model && meshRef.submesh < model->mesh.submeshes.size()) {
                firstIndex = model->mesh.submeshes[meshRef.submesh].indexOffset;
                indexCount = model->mesh.submeshes[meshRef.submesh].indexCount;
            }
            cmd.DrawIndexed(indexCount, firstIndex);
        });
}

} // namespace M7N::Asset
