/**
 * @file IRenderDevice.hpp
 * @brief 渲染设备抽象：资源创建 + 帧调度。
 *
 * 窗口/上下文归平台层（demo 中为 GLFW），设备只负责资源与命令。
 * 后端工厂：CreateGLDevice()（GL 3.3 core / GLES3 兼容子集）。
 */
#pragma once

#include "M7N/RHI/RHI.hpp"
#include "M7N/RHI/CommandList.hpp"

namespace M7N::RHI {

/// 设备能力（用于纹理尺寸/过滤/HDR 目标的安全回退）。
struct DeviceCaps {
    u32   maxTextureSize = 4096;
    f32   maxAnisotropy = 1.0f;
    bool  gles = false;                 ///< 当前是否是 OpenGL ES 上下文
    bool  halfFloatRenderTargets = true; ///< RGBA16F 是否可渲染（否则 HDR 用 RGBA8 回退）
};

class IRenderDevice {
public:
    virtual ~IRenderDevice() = default;

    /// 后端能力查询（Init 完成后有效）。
    virtual const DeviceCaps& GetCapabilities() const = 0;

    // --- 资源创建（失败返回无效句柄）---
    virtual BufferHandle  CreateBuffer(const BufferDesc& desc) = 0;
    virtual TextureHandle CreateTexture(const TextureDesc& desc) = 0;
    virtual ShaderHandle  CreateShader(const ShaderDesc& desc) = 0;
    virtual PipelineHandle CreatePipeline(const PipelineDesc& desc) = 0;
    virtual FramebufferHandle CreateFramebuffer(const FramebufferDesc& desc) = 0;

    // --- 资源更新 / 销毁 ---
    virtual void UpdateBuffer(BufferHandle buffer, const void* data,
                              u32 size, u32 offset = 0) = 0;
    virtual void DestroyBuffer(BufferHandle buffer) = 0;
    virtual void DestroyTexture(TextureHandle texture) = 0;
    virtual void DestroyShader(ShaderHandle shader) = 0;
    virtual void DestroyPipeline(PipelineHandle pipeline) = 0;
    virtual void DestroyFramebuffer(FramebufferHandle framebuffer) = 0;

    // --- 帧缓冲查询 ---
    /// 阴影采样用：取 DepthOnly 帧缓冲的深度附件纹理。
    /// （其他模式返回无效句柄）
    virtual TextureHandle GetFramebufferDepthTexture(FramebufferHandle fb) = 0;
    /// 后处理采样用：取 Scene/HDR 帧缓冲的颜色附件纹理。
    /// （DepthOnly 模式返回无效句柄）
    virtual TextureHandle GetFramebufferColorTexture(FramebufferHandle fb) = 0;
    /// 帧缓冲尺寸（视口跟随用）。
    virtual bool GetFramebufferSize(FramebufferHandle fb, u32& outW, u32& outH) = 0;

    // --- 帧调度 ---
    /// 帧首（绑定全局状态，如 VAO）。
    virtual void BeginFrame() = 0;
    /// 回放命令列表（立即执行；未来可异步/排序合并）。
    virtual void Submit(CommandList& cmd) = 0;
};

/// GL 后端工厂。要求调用线程已绑定 GL 上下文。
Ref<IRenderDevice> CreateGLDevice();

} // namespace M7N::RHI
