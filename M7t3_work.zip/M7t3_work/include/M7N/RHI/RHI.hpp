/**
 * @file RHI.hpp
 * @brief 渲染硬件接口公共类型：句柄 / 描述结构。
 *
 * 后端策略：M7N-2 的 GLDevice 使用 GL 3.3 core 桌面上下文，
 * 但所有调用严格限制在 GLES3 兼容子集内 —— 同一份后端代码
 * 在移动端原生 GLES3 上下文可直接复用，无需 #ifdef 分叉。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <vector>

namespace M7N::RHI {

constexpr u32 kInvalidId = 0;

// --- 句柄（id 从 1 起，0 恒为无效）---
struct BufferHandle {
    u32 id = kInvalidId;
    bool IsValid() const { return id != kInvalidId; }
};
struct TextureHandle {
    u32 id = kInvalidId;
    bool IsValid() const { return id != kInvalidId; }
};
struct ShaderHandle {
    u32 id = kInvalidId;
    bool IsValid() const { return id != kInvalidId; }
};
struct PipelineHandle {
    u32 id = kInvalidId;
    bool IsValid() const { return id != kInvalidId; }
};
struct FramebufferHandle {
    u32 id = kInvalidId;
    bool IsValid() const { return id != kInvalidId; }
};

/// 缓冲用途。
enum class BufferUsage : u8 { Vertex, Index };

/// 纹理格式（GLES3 均原生支持）。
enum class Format : u8 { RGBA8, RGB8, RGBA16F, Depth24 };

/// 纹理过滤（2D 像素美术用 Nearest，3D 用 Linear）。
enum class TextureFilter : u8 { Linear, Nearest };

/// 纹理采样参数（阴影贴图需要 border-clamp， GLES3 子集内支持）。
enum class SamplerWrap : u8 { Repeat, ClampToEdge, ClampToBorder };

/// 帧缓冲用途（决定附件组合）。
enum class FramebufferMode : u8 {
    /// RGBA8 颜色 + Depth24（普通场景目标）。
    Scene,
    /// 仅 Depth24 附件（阴影贴图；深度附件可作纹理采样）。
    DepthOnly,
    /// RGBA16F 颜色 + Depth24（HDR 场景目标，配合后处理）。
    HDR,
};

// --- 创建描述 ---

struct BufferDesc {
    const void* data = nullptr;   // 初始数据（可为 null）
    u32 size = 0;                 // 字节数
    BufferUsage usage = BufferUsage::Vertex;
    bool dynamic = false;         // true -> GL_DYNAMIC_DRAW（每帧更新）
};

struct TextureDesc {
    u32 width = 1;
    u32 height = 1;
    Format format = Format::RGBA8;
    const void* pixels = nullptr; // RGBA8: 字节；16F: 半浮点
    TextureFilter filter = TextureFilter::Linear;
    SamplerWrap wrap = SamplerWrap::ClampToEdge; // 地形/墙体平铺用 Repeat
    bool mipmaps = false;          // 生成 mipmap 链（远处不闪烁）
    bool anisotropy = false;       // 各向异性过滤（桌面 GL 扩展）
    bool srgb = false;             // 颜色贴图用 sRGB 内部格式（法线/粗糙度等数据贴图必须 false）
};

struct ShaderDesc {
    const char* vert = nullptr;   // GLSL ES 兼容源码
    const char* frag = nullptr;
};

/// 顶点属性布局（类型固定 FLOAT，M7N-2 够用）。
struct VertexAttrib {
    u32 location = 0;
    u32 size = 3;          // 分量数 1-4
    u32 stride = 0;        // 字节
    u32 offset = 0;        // 字节
    bool normalized = false;
    u32 divisor = 0;       // 1 = 每实例前进一次（实例化矩阵 6..9）
};

/// 混合模式（仅 blend=true 时生效）。
enum class BlendMode : u8 {
    Alpha,     ///< src*a + dst*(1-a)
    Additive,  ///< src*a + dst（发光/粒子）
};

/// 管线 = 着色器 + 顶点布局 + 光栅状态。
struct PipelineDesc {
    ShaderHandle shader;
    std::vector<VertexAttrib> layout;
    bool depthTest = true;
    bool depthWrite = true;
    bool cull = true;      // 背面剔除（CCW 正面）
    bool cullFront = false; // true = 剔除正面（阴影 pass 用，消除自阴影摩尔纹）
    bool blend = false;    // 启用混合
    bool colorWrite = true; // false = 只写深度（深度预通道）
    BlendMode blendMode = BlendMode::Alpha;
};

/// 帧缓冲描述。
struct FramebufferDesc {
    u32 width = 1;
    u32 height = 1;
    FramebufferMode mode = FramebufferMode::Scene;
};

} // namespace M7N::RHI
