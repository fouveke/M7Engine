/**
 * @file CommandList.hpp
 * @brief 命令录制：游戏侧录制一帧渲染指令，设备侧一次回放。
 *
 * 与 M7T1 "调用即执行" 的根本区别：
 *   - 渲染逻辑（录命令）与执行（GL 调用）解耦，未来可换后端/多线程提交
 *   - 每帧 Reset 复用，无逐次堆分配（命令为 POD 结构数组）
 *
 * 注意：单条命令为定长胖结构（~200B），后续做 SOP 压缩；
 *       uniform 名字上限 31 字符。
 */
#pragma once

#include "M7N/RHI/RHI.hpp"

#include <cstring>
#include <vector>

namespace M7N::RHI {

enum class CmdType : u8 {
    Clear,
    SetViewport,
    BindFramebuffer,   // M7N-G1：渲染目标切换（id=0 回默认帧缓冲）
    BindPipeline,
    BindVertexBuffer,
    BindIndexBuffer,
    BindSkinBuffer,       // M7N-A2：蒙皮附加缓冲（location 3/4）
    BindInstanceBuffer,   // 实例化矩阵缓冲（location 6..9，stride 64）
    SetUniform,
    SetMat4ArrayUniform,  // M7N-A2：骨骼调色板批量上传
    BindTexture,
    UpdateBuffer,         // 动态缓冲上传（数据复制进命令 blob，回放时生效）
    UpdateTexture,        // 纹理子区域上传（光照网格等逐帧小纹理）
    Draw,
    DrawIndexed,
    DrawIndexedInstanced,
};

/// 单条命令（胖 POD；字段按命令类型复用）。
struct Command {
    CmdType type = CmdType::Draw;

    // Clear
    f32 color[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
    u8  clearDepth = 1;

    // SetViewport
    i32 viewport[4] = { 0, 0, 0, 0 };

    // BindFramebuffer
    FramebufferHandle framebuffer;

    // Bind*
    PipelineHandle pipeline;
    BufferHandle   buffer;

    // SetUniform / BindTexture
    char name[32] = {};
    u32  floatCount = 0;    // 1/2/3/4/16
    u8   isMatrix = 0;      // floatCount==16 时生效
    f32  values[16] = {};
    u32  slot = 0;          // 纹理槽

    // Draw* / UpdateBuffer
    u32 count = 0;
    u32 instanceCount = 0;
    u32 offset = 0;   // Draw 起笔索引；UpdateBuffer 时借用为 blob 池偏移

    // UpdateBuffer（data 存放于命令列表附属 blob）
    u32 dataOffset = 0;
    u32 dataSize = 0;
};

class CommandList {
public:
    /// 清空已录命令（容量保留，下帧复用）。附属矩阵池/blob 同步清空。
    void Reset() { commands_.clear(); matrices_.clear(); blob_.clear(); }

    // --- 录制 API ---

    void Clear(f32 r, f32 g, f32 b, f32 a, bool clearDepth = true) {
        Command& c = alloc(CmdType::Clear);
        c.color[0] = r; c.color[1] = g; c.color[2] = b; c.color[3] = a;
        c.clearDepth = clearDepth ? 1 : 0;
    }

    void SetViewport(i32 x, i32 y, i32 w, i32 h) {
        Command& c = alloc(CmdType::SetViewport);
        c.viewport[0] = x; c.viewport[1] = y; c.viewport[2] = w; c.viewport[3] = h;
    }

    /// 绑定渲染目标（无效句柄 = 回退默认帧缓冲即后备缓冲）。
    void BindFramebuffer(FramebufferHandle fb) {
        Command& c = alloc(CmdType::BindFramebuffer);
        c.framebuffer = fb;
    }

    void BindPipeline(PipelineHandle p) {
        Command& c = alloc(CmdType::BindPipeline);
        c.pipeline = p;
    }

    void BindVertexBuffer(BufferHandle b) {
        Command& c = alloc(CmdType::BindVertexBuffer);
        c.buffer = b;
    }

    void BindIndexBuffer(BufferHandle b) {
        Command& c = alloc(CmdType::BindIndexBuffer);
        c.buffer = b;
    }

    /// 蒙皮附加缓冲（jointIdx 位模式 + weight，各 vec4，stride 32）。
    /// 必须在 BindPipeline（蒙皮管线）之后、Draw 之前录制。
    void BindSkinBuffer(BufferHandle b) {
        Command& c = alloc(CmdType::BindSkinBuffer);
        c.buffer = b;
    }

    /// 实例化矩阵缓冲（每实例一个 mat4，stride 64；location 6..9 补发）。
    void BindInstanceBuffer(BufferHandle b) {
        Command& c = alloc(CmdType::BindInstanceBuffer);
        c.buffer = b;
    }

    /// 骨骼调色板批量上传（u_BoneMatrices[n]）。
    /// @param name uniform 数组名（如 "u_BoneMatrices"）
    /// @param matrices 连续 mat4 数组（最多 64，超出截断）
    void SetMat4Array(const char* uniformName, const Mat4* matrices, u32 count) {
        Command& c = alloc(CmdType::SetMat4ArrayUniform);
        copyName(c.name, uniformName);
        c.count = (count > 64) ? 64 : count;
        // 命令结构放不下 64 个 mat4（约 4KB）：矩阵数据存入附属数组，
        // 命令内记录起始索引（见 matrices_ 旁注）。
        c.offset = static_cast<u32>(matrices_.size());
        matrices_.insert(matrices_.end(), matrices, matrices + c.count);
    }

    void SetFloat(const char* uniformName, f32 v) {
        Command& c = alloc(CmdType::SetUniform);
        copyName(c.name, uniformName);
        c.floatCount = 1;
        c.values[0] = v;
    }

    void SetVec2(const char* uniformName, const Vec2& v) {
        Command& c = alloc(CmdType::SetUniform);
        copyName(c.name, uniformName);
        c.floatCount = 2;
        c.values[0] = v.x; c.values[1] = v.y;
    }

    void SetVec3(const char* uniformName, const Vec3& v) {
        Command& c = alloc(CmdType::SetUniform);
        copyName(c.name, uniformName);
        c.floatCount = 3;
        c.values[0] = v.x; c.values[1] = v.y; c.values[2] = v.z;
    }

    void SetVec4(const char* uniformName, const Vec4& v) {
        Command& c = alloc(CmdType::SetUniform);
        copyName(c.name, uniformName);
        c.floatCount = 4;
        c.values[0] = v.x; c.values[1] = v.y; c.values[2] = v.z; c.values[3] = v.w;
    }

    void SetMat4(const char* uniformName, const Mat4& m) {
        Command& c = alloc(CmdType::SetUniform);
        copyName(c.name, uniformName);
        c.floatCount = 16;
        c.isMatrix = 1;
        std::memcpy(c.values, glm::value_ptr(m), sizeof(f32) * 16);
    }

    void BindTexture(const char* uniformName, u32 textureSlot, TextureHandle t) {
        Command& c = alloc(CmdType::BindTexture);
        copyName(c.name, uniformName);
        c.slot = textureSlot;
        c.pipeline = {};   // 复用字段不携带
        c.buffer = {};
        // 纹理句柄借用 buffer.id 字段
        c.buffer.id = t.id;
    }

    /// 动态缓冲上传：数据立即拷贝进命令 blob（调用方可复用临时数组），
    /// 设备回放到该命令时执行 glBufferSubData —— 保证与 Draw 的先后顺序。
    void UpdateBuffer(BufferHandle buffer, const void* data, u32 size, u32 offset = 0) {
        if (!data || size == 0) return;
        Command& c = alloc(CmdType::UpdateBuffer);
        c.buffer = buffer;
        c.dataOffset = offset;
        c.dataSize = size;
        c.offset = static_cast<u32>(blob_.size());
        const auto* bytes = static_cast<const u8*>(data);
        blob_.insert(blob_.end(), bytes, bytes + size);
    }

    /// 纹理子区域上传（RGBA8；回放时 glTexSubImage2D）。
    void UpdateTexture(TextureHandle texture, i32 x, i32 y, u32 width, u32 height,
                       const void* data, u32 size) {
        if (!texture.IsValid() || !data || size == 0) return;
        Command& c = alloc(CmdType::UpdateTexture);
        c.buffer.id = texture.id;
        c.viewport[0] = x;
        c.viewport[1] = y;
        c.viewport[2] = static_cast<i32>(width);
        c.viewport[3] = static_cast<i32>(height);
        c.dataSize = size;
        c.offset = static_cast<u32>(blob_.size());
        const auto* bytes = static_cast<const u8*>(data);
        blob_.insert(blob_.end(), bytes, bytes + size);
    }

    void Draw(u32 vertexCount, u32 firstVertex = 0) {
        Command& c = alloc(CmdType::Draw);
        c.count = vertexCount;
        c.offset = firstVertex;
    }

    void DrawIndexed(u32 indexCount, u32 firstIndex = 0) {
        Command& c = alloc(CmdType::DrawIndexed);
        c.count = indexCount;
        c.offset = firstIndex;
    }

    void DrawIndexedInstanced(u32 indexCount, u32 instanceCount, u32 firstIndex = 0) {
        Command& c = alloc(CmdType::DrawIndexedInstanced);
        c.count = indexCount;
        c.instanceCount = instanceCount;
        c.offset = firstIndex;
    }

    /// 设备回放入口。
    const std::vector<Command>& Commands() const { return commands_; }

    /// 调色板矩阵池访问（SetMat4ArrayUniform 命令按 offset/count 引用）。
    const f32* MatrixPool() const {
        return matrices_.empty() ? nullptr : glm::value_ptr(matrices_[0]);
    }

    /// 动态上传数据池（UpdateBuffer 命令按 offset/dataSize 引用）。
    const u8* Blob() const { return blob_.empty() ? nullptr : blob_.data(); }

private:
    Command& alloc(CmdType t) {
        commands_.emplace_back();
        Command& c = commands_.back();
        c.type = t;
        return c;
    }

    static void copyName(char* dst, const char* src) {
        if (!src) { dst[0] = '\0'; return; }
        std::strncpy(dst, src, 31);
        dst[31] = '\0';
    }

    std::vector<Command> commands_;
    /// SetMat4ArrayUniform 的附属矩阵池（扁平 f32：16 个/矩阵，逐命令段引用）。
    std::vector<Mat4> matrices_;
    /// UpdateBuffer 的附属数据池（逐命令段引用）。
    std::vector<u8> blob_;
};

} // namespace M7N::RHI
