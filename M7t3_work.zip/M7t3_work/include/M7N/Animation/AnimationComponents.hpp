/**
 * @file AnimationComponents.hpp
 * @brief 动画组件：骨骼运行时姿态 + 动画播放器状态。
 *
 * 组件职责（纯数据 + 少量内联计算）：
 *   SkeletonComp —— 单实体骨骼：关节局部 TRS 姿态 + 调色板缓存
 *   AnimatorComp —— 播放状态：片段索引/时间/速度/循环 + 运行时通道表
 *
 * 采样与调色板计算归 AnimationSystem（src/Animation/AnimationSystem.cpp），
 * 与 M7N"组件 = 数据，系统 = 行为"的分层一致。
 *
 * 通道数据（channels）在运行时由 AnimationSystem 从 Asset::AnimationClip
 * 拷贝注入（glTF 加载或程序化构建后），不参与反射/序列化。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Asset/Types.hpp"
#include "M7N/Reflect/TypeInfo.hpp"

#include <vector>

namespace M7N::Animation {

/// 单关节的动画姿态（局部 TRS）。
struct JointPose {
    Vec3 translation = Vec3(0.0f);
    Quat rotation    = Quat(0.0f, 0.0f, 0.0f, 1.0f);   // identity（本库 (x,y,z,w) 布局）
    Vec3 scale       = Vec3(1.0f);
};

/// 骨骼组件：关节层级 + 当前姿态 + 蒙皮调色板。
struct SkeletonComp {
    // --- 结构（加载后不变）---
    std::vector<i32>       parents;        ///< 父关节索引（-1 = 根）
    std::vector<Mat4>      inverseBinds;   ///< 逆绑定矩阵
    std::vector<JointPose> restPoses;      ///< 绑定姿态
    Mat4                   rootMatrix = Mat4(1.0f); ///< 骨架根矩阵（见 SkinData::rootMatrix）

    // --- 每帧状态（AnimationSystem 写）---
    std::vector<JointPose> localPoses;     ///< 当前局部姿态
    std::vector<Mat4>      palette;        ///< 调色板：global * inverseBind（上传 shader）

    /// 关节数。
    u32 JointCount() const { return static_cast<u32>(parents.size()); }

    /// 姿态复位到绑定姿态。
    void ResetToRest() { localPoses = restPoses; }
};

/// 动画播放器组件。
struct AnimatorComp {
    // --- 配置（可序列化）---
    bool  looping = true;
    f32   speed   = 1.0f;

    // --- 运行时状态（系统写，不序列化）---
    i32   activeClip = -1;                 ///< 播放中的片段索引（-1 停止）
    f32   time = 0.0f;                     ///< 片段内时间（秒）
    bool  playing = false;                 ///< 播放中标志

    /// 运行时通道表（按片段注入；[clip][channel]）。
    std::vector<std::vector<Asset::AnimChannel>> clips;

    /// 片段时长表（与 clips 对齐）。
    std::vector<f32> durations;

    /// 按索引播放。
    bool Play(u32 clipIndex) {
        if (clipIndex >= clips.size()) return false;
        activeClip = static_cast<i32>(clipIndex);
        time = 0.0f;
        playing = true;
        return true;
    }

    void Stop() { activeClip = -1; playing = false; time = 0.0f; }

    /// 当前片段时长（0 = 无）。
    f32 Duration() const {
        return (activeClip >= 0 &&
                static_cast<u32>(activeClip) < durations.size())
            ? durations[static_cast<u32>(activeClip)] : 0.0f;
    }
};

} // namespace M7N::Animation

// --- 反射注册 ---

M7N_REFLECT_BEGIN(M7N::Animation::AnimatorComp)
    M7N_PROP(looping, Bool)
    M7N_PROP(speed,   Float)
M7N_REFLECT_END(M7N::Animation::AnimatorComp)
