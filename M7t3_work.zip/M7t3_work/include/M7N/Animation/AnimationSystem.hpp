/**
 * @file AnimationSystem.hpp
 * @brief 动画系统：采样 -> 姿态 -> 调色板，ECS 实例驱动。
 *
 * 每帧流程（OnUpdate）：
 *   1. 遍历 AnimatorComp + SkeletonComp 实体
 *   2. 推进片段时间（速度/循环/结束停止）
 *   3. 采样通道（lerp/slerp，M7T1 验证过的四元数插值）
 *   4. 姿态级联计算全局变换，乘逆绑定得调色板
 *
 * 调色板上传 shader 由渲染系统读取（本系统只算 CPU 数组）。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Animation/AnimationComponents.hpp"

namespace M7N::Animation {

class AnimationSystem {
public:
    /// 步进全部动画实体。@param dt 帧间隔秒。
    void OnUpdate(ECS::World& world, f32 dt);

    /// 单实体采样 + 调色板（OnUpdate 内部使用，可单独调用）。
    void Evaluate(ECS::Entity e, ECS::World& world, f32 dt);

    /// 只重算调色板（时间推进由调用方控制时用）。
    static void ComputePalette(SkeletonComp& skeleton);

    /// 从资产数据初始化骨骼组件（拷贝结构 + 绑定姿态）。
    static void InitSkeletonFromAsset(const Asset::SkinData& skin,
                                      SkeletonComp& outSkeleton);

    /// 从资产动画表注入播放器通道（清空旧片段）。
    static void InitAnimatorFromAsset(const std::vector<Asset::AnimationClip>& clips,
                                      AnimatorComp& outAnimator);
};

} // namespace M7N::Animation
