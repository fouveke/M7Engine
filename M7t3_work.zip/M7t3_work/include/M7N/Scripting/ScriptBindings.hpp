/**
 * @file ScriptBindings.hpp
 * @brief C++ / C# 桥：extern "C" C API（m7_script_*，命名与签名与 M7T1
 * 完全一致，托管侧经 [DllImport] P/Invoke 调用）。
 *
 * 实体句柄编码约定（M7N 的 ECS::World 没有 FindEntityByID，实体句柄是
 * {index, generation}，故约定 64 位线性编码）：
 *
 *   entityId = (u64(index) << 32) | generation
 *
 *   解码：index      = u32(entityId & 0xFFFFFFFF)
 *         generation = u32(entityId >> 32)
 *   解码后构造 ECS::Entity，并经 World::IsAlive 校验存活；不存活按无效
 *   实体处理（访问器直接返回，创建/销毁为 no-op）。
 *   0 保留为失败哨兵（m7_script_instantiate_entity 失败时返回 0）。
 *
 * g_scriptWorld 是 extern "C" 桥的全局锚点——M7N 架构约定「无 static
 * 可变状态」的**唯一例外**：唯一写入点是 ScriptSystem::Attach()。
 *
 * 待接入（M7N 尚无对应子系统，现为空实现）：
 *   - 音频：play_sound / play_sound_3d（M7N-5 接入 AudioSystem 后补）
 *   - 输入：is_key_down / is_key_pressed / mouse_position
 *   - 时间：delta_time / elapsed_time（接入 Time 系统后补）
 *   - 全局浮点黑板：set/get_global_float（M7T1 用匿名 namespace 的
 *     static 可变 map，为遵守「无 static 可变状态」约定暂不迁移）
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"

#include <cstdint>

namespace M7N::Scripting {

/// C 桥当前操作的世界（定义在 ScriptBindings.cpp）。
/// 唯一写入点：ScriptSystem::Attach()。未绑定时全部实体访问器为 no-op。
extern ECS::World* g_scriptWorld;

/// 实体句柄编码：(index << 32) | generation。
inline u64 EncodeEntityID(ECS::Entity e) {
    return (static_cast<u64>(e.index) << 32) | static_cast<u64>(e.generation);
}

/// 实体句柄解码 + 存活校验。
/// @param id  64 位编码句柄
/// @param e   解码输出（无论校验是否通过都会写入解码结果）
/// @return g_scriptWorld 已绑定且实体存活为 true；否则 false
inline bool DecodeEntityID(u64 id, ECS::Entity& e) {
    e = ECS::Entity{};
    e.index      = static_cast<u32>(id & 0xFFFFFFFFull);
    e.generation = static_cast<u32>(id >> 32);
    return g_scriptWorld != nullptr && g_scriptWorld->IsAlive(e);
}

} // namespace M7N::Scripting

// ---------------------------------------------------------------------------
// C 链接 API（P/Invoke 目标）。签名与 M7T1 完全一致。
// ---------------------------------------------------------------------------

extern "C" {

/// 输出脚本日志（stdout）。
void   m7_script_log(const char* message);

/// 帧间隔秒。TODO(M7N)：接入 Time 系统前恒为 0。
float  m7_script_get_delta_time(void);

/// 累计时间秒。TODO(M7N)：接入 Time 系统前恒为 0。
float  m7_script_get_elapsed_time(void);

/// 位置访问（Transform.position）。实体无效或无 Transform 时输出 0。
void   m7_script_get_position(uint64_t entityId, float* outX, float* outY, float* outZ);
void   m7_script_set_position(uint64_t entityId, float x, float y, float z);

/// 旋转访问（Transform.rotation，欧拉角弧度，直接读写）。
void   m7_script_get_rotation(uint64_t entityId, float* outX, float* outY, float* outZ);
void   m7_script_set_rotation(uint64_t entityId, float x, float y, float z);

/// 缩放读取（只读）。实体无效或无 Transform 时输出 1。
void   m7_script_get_scale(uint64_t entityId, float* outX, float* outY, float* outZ);

/// 键盘状态。TODO(M7N)：接入输入系统前恒为 false。
bool   m7_script_is_key_down(int keyCode);
bool   m7_script_is_key_pressed(int keyCode);

/// 鼠标位置。TODO(M7N)：接入输入系统前恒为 0。
void   m7_script_get_mouse_position(float* outX, float* outY);

/// 创建实体（带名字与默认 Transform），返回编码句柄；失败返回 0。
uint64_t m7_script_instantiate_entity(const char* name);

/// 销毁实体。无效句柄为 no-op。
void   m7_script_destroy_entity(uint64_t entityId);

/// 播放音频。TODO(M7N-5)：接入 AudioSystem 前为空实现。
void   m7_script_play_sound(const char* soundFile, float volume, bool looping);
void   m7_script_play_sound_3d(const char* soundFile,
                               float x, float y, float z,
                               float volume, float range);

/// 全局浮点黑板。TODO(M7N)：接入全局状态存储前为空实现 / 返回默认值。
void   m7_script_set_global_float(const char* name, float value);
float  m7_script_get_global_float(const char* name, float defaultValue);

} // extern "C"
