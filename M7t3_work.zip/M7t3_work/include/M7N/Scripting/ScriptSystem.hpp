/**
 * @file ScriptSystem.hpp
 * @brief CoreCLR 脚本系统（实例类，自 M7T1 ScriptEngine 去单例化迁移）。
 *
 * 通过 CoreCLR 公共宿主 API（Windows: coreclr.dll / Linux: libcoreclr.so）
 * 承载 .NET 运行时，并用 coreclr_create_delegate 创建的函数指针与托管代码
 * 互调：
 *
 *   C++（引擎） --[P/Invoke m7_script_* C API]--> C#（脚本逻辑）
 *   C#（ScriptHost）--[UnmanagedCallersOnly 委托]--> C++（分派）
 *
 * C# 侧契约（每个脚本程序集须包含此类，类型名与 M7T1 保持一致，
 * 现有 M7T1 脚本程序集无需改动即可被 M7N 加载）：
 * @code
 *   public static class Mutant7.ScriptHost
 *   {
 *       [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
 *       public static unsafe void* Load(sbyte* assemblyPath, sbyte* className);
 *
 *       [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
 *       public static unsafe void Unload(void* handle);
 *
 *       [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
 *       public static bool OnCreate(void* handle);
 *
 *       [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
 *       public static bool OnUpdate(void* handle, float deltaTime);
 *
 *       [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
 *       public static bool OnDestroy(void* handle);
 *   }
 * @endcode
 *
 * 托管侧经 [DllImport] 回调引擎（ScriptBindings 的 m7_script_*），
 * 要求引擎以共享库形式构建并导出这些 C 符号。
 *
 * 若机器上没有 .NET 运行时：Init() 返回 false（引擎继续运行、无脚本）。
 *
 * 与 M7T1 的差异（去单例化）：
 *   - 原 ScriptEngine 静态成员与宿主全局状态全部转为 ScriptSystem 实例成员
 *   - 新增 ECS 集成：Attach 绑定 World，OnSceneCreate/Update/Destroy 驱动
 *     挂有 ScriptComp 的实体
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"

#include <unordered_map>
#include <vector>

namespace M7N::Scripting {

/// 单个已加载脚本实例（语义同 M7T1 ScriptEngine::ScriptInstance）。
struct ScriptInstance {
    String assemblyPath;               ///< .dll 路径
    String className;                  ///< 完整类名（如 "Game.PlayerController"）
    void*  objectHandle = nullptr;     ///< 托管对象句柄（ScriptHost.Load 返回）
    bool   isValid      = false;       ///< 加载是否成功
};

namespace Detail {

// --- CoreCLR 宿主入口签名（coreclr.dll 导出函数） ---

using FnCoreCLRInitialize = int (*)(
    const char* exePath, const char* appDomainFriendlyName,
    int propertyCount, const char** propertyKeys, const char** propertyValues,
    void** hostHandle, unsigned int* domainId);

using FnCoreCLRCreateDelegate = int (*)(
    void* hostHandle, unsigned int domainId,
    const char* entryPointAssemblyName, const char* entryPointTypeName,
    const char* entryPointMethodName, void** delegate);

using FnCoreCLRShutdown = int (*)(
    void* hostHandle, unsigned int domainId, int* latchedExitCode);

// --- 托管侧桥签名（Mutant7.ScriptHost，cdecl） ---

using FnHostLoad      = void* (*)(const char* assemblyPath, const char* className);
using FnHostUnload    = void  (*)(void* handle);
using FnHostOnCreate  = bool  (*)(void* handle);
using FnHostOnUpdate  = bool  (*)(void* handle, float deltaTime);
using FnHostOnDestroy = bool  (*)(void* handle);

/// 单个程序集的托管桥（delegate 缓存条目）。
struct AssemblyBridge {
    FnHostLoad      load      = nullptr;
    FnHostUnload    unload    = nullptr;
    FnHostOnCreate  onCreate  = nullptr;
    FnHostOnUpdate  onUpdate  = nullptr;
    FnHostOnDestroy onDestroy = nullptr;
};

} // namespace Detail

/// CoreCLR 脚本系统。实例类：由应用 / 编辑器持有，可多实例并存。
class ScriptSystem {
public:
    ScriptSystem() = default;
    ~ScriptSystem();

    ScriptSystem(const ScriptSystem&) = delete;
    ScriptSystem& operator=(const ScriptSystem&) = delete;

    /// 初始化 .NET (CoreCLR) 运行时。
    /// @param runtimeConfig 可选 .runtimeconfig.json 路径（其目录同时用于
    ///                      定位应用程序集）。
    /// @return false 表示运行时未安装或启动失败；此时引擎继续无脚本运行。
    bool Init(const String& runtimeConfig = "");

    /// 关停运行时并卸载全部脚本。
    void Shutdown();

    /// 运行时是否已就绪。
    bool IsInitialized() const { return isInitialized_; }

    /// 默认程序集（ScriptComp 只写类名时使用）。格式 "path/to/Game.dll" 或空。
    void SetDefaultAssembly(const String& assemblyPath);
    const String& GetDefaultAssembly() const;

    /// 加载 C# 程序集并实例化脚本类。
    /// @param assemblyPath 编译产物 .dll 路径
    /// @param className 含命名空间的完整类名
    /// @return 脚本实例句柄（加载失败时 isValid=false）
    ScriptInstance LoadScript(const String& assemblyPath, const String& className);

    /// 卸载脚本实例。
    void UnloadScript(const ScriptInstance& instance);

    /// 在脚本实例上调用生命周期方法（真实托管调用）。
    bool CallOnCreate(const ScriptInstance& instance);
    bool CallOnUpdate(const ScriptInstance& instance, f32 deltaTime);
    bool CallOnDestroy(const ScriptInstance& instance);

    /// 全部脚本热重载（开发期用）：重启运行时后逐个重载并 OnCreate。
    void ReloadAll();

    // --- ECS 集成 ---

    /// 绑定 ECS World：记录世界指针，并把它注册给 C 桥
    /// （Scripting::g_scriptWorld 的唯一写入点）。
    void Attach(ECS::World& world);

    /// 场景创建：扫描全部 ScriptComp，解析 scriptName
    /// （"Assembly.dll|Full.Class" 或默认程序集格式），加载并 OnCreate。
    /// 运行时未启动时静默跳过（引擎可无 .NET 运行）。
    void OnSceneCreate(ECS::World& world);

    /// 场景更新：驱动全部已加载且 enabled 的脚本 OnUpdate。
    void OnSceneUpdate(f32 dt);

    /// 场景销毁：对已加载脚本 OnDestroy + 卸载，清空组件运行时字段。
    void OnSceneDestroy();

private:
    /// 解析（并缓存）某程序集的托管桥（coreclr_create_delegate）。
    Detail::AssemblyBridge* getBridge(const String& assemblyPath);

    /// 释放运行时库句柄并清空 CoreCLR 入口指针（Init 失败 / Shutdown 用）。
    void releaseRuntime();

    bool  isInitialized_ = false;
    std::vector<ScriptInstance> loadedScripts_;   ///< 全部已加载脚本

    // --- CoreCLR 宿主状态（自 M7T1 全局态转为实例成员） ---
    Detail::FnCoreCLRInitialize     coreclrInitialize_     = nullptr;
    Detail::FnCoreCLRCreateDelegate coreclrCreateDelegate_ = nullptr;
    Detail::FnCoreCLRShutdown       coreclrShutdown_       = nullptr;

    void*    hostHandle_ = nullptr;    ///< coreclr_initialize 主机句柄
    unsigned domainId_   = 0;          ///< AppDomain id
    void*    runtimeLib_ = nullptr;    ///< LoadLibrary / dlopen 句柄
    String   defaultAssembly_;         ///< 默认程序集路径

    /// delegate 缓存：程序集名 -> 托管桥（照搬 M7T1 g_bridges）。
    std::unordered_map<String, Detail::AssemblyBridge> bridges_;

    ECS::World* world_ = nullptr;      ///< Attach 记录的世界（ECS 驱动用）
};

} // namespace M7N::Scripting
