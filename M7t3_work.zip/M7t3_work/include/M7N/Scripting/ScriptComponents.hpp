/**
 * @file ScriptComponents.hpp
 * @brief M7N C# 脚本组件：组件只持有脚本描述与运行时实例句柄。
 *
 * 组件是纯数据（不含行为）；加载与生命周期调用由 ScriptSystem 驱动
 * （OnSceneCreate / OnSceneUpdate / OnSceneDestroy）。
 *
 * scriptName 两种格式（与 M7T1 ScriptComponent 相同）：
 *   1. "path/to/Assembly.dll|Full.Class.Name" —— 显式指定程序集
 *   2. "Full.Class.Name" —— 使用 ScriptSystem::SetDefaultAssembly
 *      设置的默认程序集
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/Reflect/TypeInfo.hpp"

namespace M7N::Scripting {

/// C# 脚本组件（纯数据）。
struct ScriptComp {
    String scriptName;               ///< "Assembly.dll|Full.Class" 或裸类名
    bool   enabled      = true;      ///< 为 false 时跳过全部生命周期调用
    void*  instanceData = nullptr;   ///< 运行时：指向 new ScriptInstance（ScriptSystem 管理）
    bool   loaded       = false;     ///< 运行时：是否已成功加载
};

} // namespace M7N::Scripting

// --- 反射注册（编辑器 / 序列化只关心 scriptName） ---

M7N_REFLECT_BEGIN(M7N::Scripting::ScriptComp)
    M7N_PROP(scriptName, String)
M7N_REFLECT_END(M7N::Scripting::ScriptComp)
