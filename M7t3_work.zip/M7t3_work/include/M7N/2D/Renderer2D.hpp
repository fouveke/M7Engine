/**
 * @file Renderer2D.hpp
 * @brief 2D 批渲染器：正交相机 + 精灵/瓦片批合并 + 视锥剔除 + 图集 UV。
 *
 * 关键优化：
 *   - 按 (layer, order, blend, texture) 排序，同纹理连续绘制 = 1 draw call
 *   - 每帧只上传实际顶点（CommandList::UpdateBuffer -> 回放期 glBufferSubData）
 *   - 屏幕外精灵/瓦片直接剔除（统计可查）
 *   - 像素美术纹理可选 Nearest 过滤；程序化纹理可注册
 *
 * 用法：
 *   renderer.BeginScene(camera);
 *   renderer.Submit(world, dt);          // 精灵 + 瓦片 + 帧动画
 *   renderer.DrawRect(...);              // 调试框（白纹理）
 *   renderer.EndScene();                 // 提交命令流到设备
 */
#pragma once

#include "M7N/2D/Components.hpp"
#include "M7N/2D/Math2D.hpp"
#include "M7N/2D/Animation2D.hpp"
#include "M7N/Asset/AssetManager.hpp"
#include "M7N/RHI/IRenderDevice.hpp"
#include "M7N/Scene/TransformSystem.hpp"

#include <vector>

namespace M7N::Dim2 {

/// 2D 相机视图（由 Camera2DComp + Transform 构建）。
struct Camera2D {
    Vec2 position = Vec2(0.0f);
    f32  rotation = 0.0f;
    f32  orthoHeight = 10.0f;
    f32  aspect = 16.0f / 9.0f;
    f32  nearZ = -100.0f;
    f32  farZ = 100.0f;
    Vec4 clearColor = Vec4(0.06f, 0.07f, 0.10f, 1.0f);
    bool clear = true;

    Mat4 ViewProjection() const;
    Rect2D WorldBounds() const;

    /// 世界 -> 屏幕像素（左上原点），viewport 为像素尺寸。
    Vec2 WorldToScreen(const Vec2& world, const Vec2& viewport) const;
    /// 屏幕像素 -> 世界坐标。
    Vec2 ScreenToWorld(const Vec2& screen, const Vec2& viewport) const;
};

/// 从实体构建相机（Transform 提供位置/旋转/缩放，缺失时给出默认相机）。
Camera2D MakeCamera2D(const ECS::World& world, ECS::Entity cameraEntity, f32 aspect);

/// 查找 primary Camera2DComp；没有返回 kNullEntity。
ECS::Entity FindPrimaryCamera2D(const ECS::World& world);

struct Renderer2DStats {
    u32 drawCalls = 0;
    u32 quads = 0;
    u32 sprites = 0;
    u32 tiles = 0;
    u32 culled = 0;
    u32 batches = 0;
};

class Renderer2D {
public:
    Renderer2D(RHI::IRenderDevice& device, Asset::AssetManager& assets);
    ~Renderer2D();

    Renderer2D(const Renderer2D&) = delete;
    Renderer2D& operator=(const Renderer2D&) = delete;

    bool Init(u32 maxQuadsPerBatch = 16384);
    void Shutdown();
    void OnResize(u32 width, u32 height);

    // --- 帧 ---
    void BeginScene(const Camera2D& camera);
    /// 收集世界中全部 Sprite/Tilemap；dt>0 时顺带推进精灵帧动画。
    void Submit(ECS::World& world, f32 dtSeconds = 0.0f);
    void EndScene();

    /// BeginScene + Submit + EndScene 的便捷入口。
    void RenderFrame(ECS::World& world, const Camera2D& camera, f32 dtSeconds = 0.0f);
    /// 自动寻找 primary 2D 相机（无则默认相机）。
    void RenderFrameAuto(ECS::World& world, f32 dtSeconds = 0.0f);

    // --- 调试绘制（世界坐标，layer 最高）---
    void DrawRect(const Vec2& center, const Vec2& size, f32 rotation,
                  const Vec4& color);
    void DrawRectOutline(const Vec2& center, const Vec2& size, f32 rotation,
                         f32 thickness, const Vec4& color);
    void DrawLine(const Vec2& a, const Vec2& b, f32 thickness, const Vec4& color);

    const Renderer2DStats& GetStats() const { return stats_; }
    u32 GetViewportWidth() const { return viewportW_; }
    u32 GetViewportHeight() const { return viewportH_; }
    f32 GetAspectSafe() const {
        return (viewportH_ > 0) ? static_cast<f32>(viewportW_) /
                                      static_cast<f32>(viewportH_) : 1.0f;
    }

private:
    struct DrawItem {
        RHI::TextureHandle texture;
        i32 layer = 0;
        i32 order = 0;
        i32 blend = 0;
        Vec2 corners[4];   // BL, BR, TR, TL（世界空间）
        Vec4 uv = Vec4(0.0f, 0.0f, 1.0f, 1.0f);
        Vec4 color = Vec4(1.0f);
        u32 sequence = 0;
    };

    struct Vertex {
        f32 x, y;
        f32 u, v;
        f32 r, g, b, a;
    };

    void collectSprites(ECS::World& world);
    void collectTilemaps(ECS::World& world);
    void pushItem(RHI::TextureHandle texture, i32 layer, i32 order, i32 blend,
                  const Vec2 corners[4], const Vec4& uv, const Vec4& color);
    void flushBatch();
    RHI::PipelineHandle pipelineFor(i32 blend) const;

    RHI::IRenderDevice& device_;
    Asset::AssetManager& assets_;
    RHI::CommandList cmd_;
    Scene::TransformSystem transformSystem_;

    RHI::ShaderHandle shader_;
    RHI::PipelineHandle alphaPipeline_;
    RHI::PipelineHandle additivePipeline_;
    RHI::BufferHandle vbo_;
    RHI::BufferHandle ibo_;
    RHI::TextureHandle whiteTexture_;

    u32 maxQuads_ = 0;
    u32 viewportW_ = 1;
    u32 viewportH_ = 1;

    Camera2D camera_;
    Mat4 viewProj_ = Mat4(1.0f);
    Rect2D cameraBounds_;
    bool inScene_ = false;

    std::vector<DrawItem> items_;
    std::vector<Vertex> batchVertices_;
    u32 batchQuads_ = 0;
    RHI::TextureHandle batchTexture_;
    i32 batchBlend_ = 0;
    u32 sequence_ = 0;

    Renderer2DStats stats_;
};

} // namespace M7N::2D
