/**
 * @file Math2D.hpp
 * @brief 2D 数学：矩形/圆碰撞、图集帧 UV、坐标变换（头文件实现）。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <algorithm>
#include <cmath>
#include <limits>

namespace M7N::Dim2 {

/// 轴对齐矩形（min <= max）。
struct Rect2D {
    Vec2 min = Vec2(0.0f);
    Vec2 max = Vec2(0.0f);

    static Rect2D FromCenterSize(const Vec2& center, const Vec2& size) {
        const Vec2 half = size * 0.5f;
        return Rect2D{ center - half, center + half };
    }

    Vec2 Center() const { return (min + max) * 0.5f; }
    Vec2 Size() const { return max - min; }
    bool IsValid() const { return max.x >= min.x && max.y >= min.y; }

    bool Contains(const Vec2& p) const {
        return p.x >= min.x && p.x <= max.x && p.y >= min.y && p.y <= max.y;
    }
    bool Intersects(const Rect2D& other) const {
        return !(other.min.x > max.x || other.max.x < min.x ||
                 other.min.y > max.y || other.max.y < min.y);
    }

    Rect2D Expanded(f32 amount) const {
        return Rect2D{ Vec2(min.x - amount, min.y - amount),
                       Vec2(max.x + amount, max.y + amount) };
    }
};

inline Rect2D UnionRect(const Rect2D& a, const Rect2D& b) {
    if (!a.IsValid()) return b;
    if (!b.IsValid()) return a;
    return Rect2D{ Vec2(std::min(a.min.x, b.min.x), std::min(a.min.y, b.min.y)),
                   Vec2(std::max(a.max.x, b.max.x), std::max(a.max.y, b.max.y)) };
}

inline bool CircleIntersectsRect(const Vec2& center, f32 radius, const Rect2D& rect) {
    const f32 closestX = std::clamp(center.x, rect.min.x, rect.max.x);
    const f32 closestY = std::clamp(center.y, rect.min.y, rect.max.y);
    const f32 dx = center.x - closestX;
    const f32 dy = center.y - closestY;
    return dx * dx + dy * dy <= radius * radius;
}

inline bool CircleIntersectsCircle(const Vec2& a, f32 ra, const Vec2& b, f32 rb) {
    const Vec2 d = a - b;
    const f32 r = ra + rb;
    return d.x * d.x + d.y * d.y <= r * r;
}

/// 把局部矩形四角变换到世界空间（XY），返回世界 AABB。
inline Rect2D TransformRectToAABB(const Mat4& matrix, const Rect2D& local) {
    const Vec2 corners[4] = {
        Vec2(local.min.x, local.min.y),
        Vec2(local.max.x, local.min.y),
        Vec2(local.max.x, local.max.y),
        Vec2(local.min.x, local.max.y),
    };
    Rect2D out;
    out.min = Vec2(std::numeric_limits<f32>::max(), std::numeric_limits<f32>::max());
    out.max = Vec2(std::numeric_limits<f32>::lowest(), std::numeric_limits<f32>::lowest());
    for (const Vec2& c : corners) {
        const Vec4 p = matrix * Vec4(c.x, c.y, 0.0f, 1.0f);
        out.min.x = std::min(out.min.x, p.x);
        out.min.y = std::min(out.min.y, p.y);
        out.max.x = std::max(out.max.x, p.x);
        out.max.y = std::max(out.max.y, p.y);
    }
    return out;
}

/// 变换单点（用于 sprite 四角）。
inline Vec2 TransformPoint(const Mat4& matrix, const Vec2& p) {
    const Vec4 out = matrix * Vec4(p.x, p.y, 0.0f, 1.0f);
    return Vec2(out.x, out.y);
}

/// 图集帧 UV（行优先、0 在左上；纹理经 stb 上下翻转后 v=0 为图像底部）。
/// @return (u0, v0, u1, v1)
inline Vec4 FrameUV(u32 frame, u32 columns, u32 rows) {
    if (columns == 0) columns = 1;
    if (rows == 0) rows = 1;
    const u32 col = frame % columns;
    const u32 row = (frame / columns) % rows;
    const f32 du = 1.0f / static_cast<f32>(columns);
    const f32 dv = 1.0f / static_cast<f32>(rows);
    const f32 u0 = static_cast<f32>(col) * du;
    const f32 u1 = u0 + du;
    const f32 v0 = 1.0f - static_cast<f32>(row + 1) * dv;
    const f32 v1 = 1.0f - static_cast<f32>(row) * dv;
    return Vec4(u0, v0, u1, v1);
}

/// 平滑插值（smootherstep）。
inline f32 SmoothStep(f32 t) {
    t = std::clamp(t, 0.0f, 1.0f);
    return t * t * (3.0f - 2.0f * t);
}

} // namespace M7N::2D
