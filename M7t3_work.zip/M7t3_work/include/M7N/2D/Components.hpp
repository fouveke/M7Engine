/**
 * @file Components.hpp
 * @brief 2D 组件：精灵 / 瓦片地图 / 2D 相机 / 精灵帧动画。
 *
 * 与 3D 组件一致：组件是纯数据 + 反射注册（序列化 / Inspector 共用）。
 * 渲染行为归 Renderer2D，动画推进归 SpriteAnimatorSystem。
 */
#pragma once

#include "M7N/Core/Types.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Reflect/TypeInfo.hpp"

#include <vector>

namespace M7N::Dim2 {

/// 精灵混合模式（字段用 i32 存储以直接走反射）。
enum class SpriteBlendMode : i32 {
    Alpha = 0,
    Additive = 1,
};

/// 精灵：世界单位尺寸、UV 子矩形、轴心、层级/次序。
struct SpriteComp {
    String texture = "";                 ///< AssetManager 纹理键（空 = 纯色矩形）
    Vec4   color = Vec4(1.0f);           ///< 乘色（RGBA）
    Vec2   size = Vec2(0.0f);            ///< 世界尺寸；为 0 时用纹理像素 / pixelsPerUnit
    Vec4   uv = Vec4(0.0f, 0.0f, 1.0f, 1.0f); ///< (u0,v0,u1,v1)
    Vec2   pivot = Vec2(0.5f, 0.5f);     ///< 轴心（0..1）
    i32    layer = 0;                    ///< 大者后绘制
    i32    order = 0;                    ///< 同层次序，小者先绘制
    bool   flipX = false;
    bool   flipY = false;
    bool   visible = true;
    bool   pixelArt = true;              ///< Nearest 过滤
    f32    pixelsPerUnit = 100.0f;       ///< size 为 0 时的纹理像素换算
    i32    blendMode = 0;                ///< SpriteBlendMode
};

/// 2D 相机：由实体 Transform 提供位置/旋转，组件提供正交高度与清屏色。
struct Camera2DComp {
    f32  orthoHeight = 10.0f;            ///< 可视世界高度（半高 = /2）
    f32  nearZ = -100.0f;
    f32  farZ = 100.0f;
    Vec4 clearColor = Vec4(0.06f, 0.07f, 0.10f, 1.0f);
    bool clearScreen = true;
    bool primary = true;
    i32  layerMask = 0x7FFFFFFF;         ///< 预留：按层过滤
};

/// 精灵帧动画：按图集网格推进当前帧并写入 SpriteComp::uv。
struct SpriteAnimatorComp {
    // --- 配置（序列化）---
    i32  startFrame = 0;
    i32  frameCount = 1;
    i32  columns = 1;                    ///< 图集列数
    i32  rows = 1;                       ///< 图集行数
    f32  fps = 10.0f;
    f32  speed = 1.0f;
    bool loop = true;
    bool pingPong = false;
    bool playing = true;

    // --- 运行时（不序列化）---
    f32  time = 0.0f;
    i32  currentFrame = 0;
    i32  direction = 1;

    i32 ResolveFrame() const {
        if (frameCount <= 0) return startFrame;
        i32 f = startFrame + (currentFrame % frameCount);
        if (f < 0) f += frameCount;
        return f;
    }
};

/// 瓦片地图：单纹理图集 + 行优先瓦片索引（-1 = 空）。
struct TilemapComp {
    String texture = "";
    i32    columns = 0;
    i32    rows = 0;
    f32    tileWorldSize = 1.0f;
    Vec2   origin = Vec2(0.0f);
    i32    atlasColumns = 1;
    i32    atlasRows = 1;
    i32    layer = -1;
    i32    order = 0;
    Vec4   tint = Vec4(1.0f);
    bool   visible = true;
    bool   pixelArt = true;
    std::vector<i32> tiles;              ///< columns * rows；-1 空

    void Resize(i32 cols, i32 rowCount) {
        columns = cols > 0 ? cols : 0;
        rows = rowCount > 0 ? rowCount : 0;
        tiles.assign(static_cast<size_t>(columns) * static_cast<size_t>(rows), -1);
    }

    i32 GetTile(i32 x, i32 y) const {
        if (x < 0 || y < 0 || x >= columns || y >= rows) return -1;
        const size_t i = static_cast<size_t>(y) * static_cast<size_t>(columns) +
                         static_cast<size_t>(x);
        return (i < tiles.size()) ? tiles[i] : -1;
    }

    void SetTile(i32 x, i32 y, i32 tile) {
        if (x < 0 || y < 0 || x >= columns || y >= rows) return;
        const size_t i = static_cast<size_t>(y) * static_cast<size_t>(columns) +
                         static_cast<size_t>(x);
        if (i < tiles.size()) tiles[i] = tile;
    }
};

} // namespace M7N::2D

// --- 反射注册 ---

M7N_REFLECT_BEGIN(M7N::Dim2::SpriteComp)
    M7N_PROP(texture,       String)
    M7N_PROP(color,         Vec4)
    M7N_PROP(size,          Vec2)
    M7N_PROP(uv,            Vec4)
    M7N_PROP(pivot,         Vec2)
    M7N_PROP(layer,         Int32)
    M7N_PROP(order,         Int32)
    M7N_PROP(flipX,         Bool)
    M7N_PROP(flipY,         Bool)
    M7N_PROP(visible,       Bool)
    M7N_PROP(pixelArt,      Bool)
    M7N_PROP(pixelsPerUnit, Float)
    M7N_PROP(blendMode,     Int32)
M7N_REFLECT_END(M7N::Dim2::SpriteComp)

M7N_REFLECT_BEGIN(M7N::Dim2::Camera2DComp)
    M7N_PROP(orthoHeight, Float)
    M7N_PROP(nearZ,       Float)
    M7N_PROP(farZ,        Float)
    M7N_PROP(clearColor,  Vec4)
    M7N_PROP(clearScreen, Bool)
    M7N_PROP(primary,     Bool)
    M7N_PROP(layerMask,   Int32)
M7N_REFLECT_END(M7N::Dim2::Camera2DComp)

M7N_REFLECT_BEGIN(M7N::Dim2::SpriteAnimatorComp)
    M7N_PROP(startFrame,  Int32)
    M7N_PROP(frameCount,  Int32)
    M7N_PROP(columns,     Int32)
    M7N_PROP(rows,        Int32)
    M7N_PROP(fps,         Float)
    M7N_PROP(speed,       Float)
    M7N_PROP(loop,        Bool)
    M7N_PROP(pingPong,    Bool)
    M7N_PROP(playing,     Bool)
M7N_REFLECT_END(M7N::Dim2::SpriteAnimatorComp)

M7N_REFLECT_BEGIN(M7N::Dim2::TilemapComp)
    M7N_PROP(texture,      String)
    M7N_PROP(columns,      Int32)
    M7N_PROP(rows,         Int32)
    M7N_PROP(tileWorldSize, Float)
    M7N_PROP(origin,       Vec2)
    M7N_PROP(atlasColumns, Int32)
    M7N_PROP(atlasRows,    Int32)
    M7N_PROP(layer,        Int32)
    M7N_PROP(order,        Int32)
    M7N_PROP(tint,         Vec4)
    M7N_PROP(visible,      Bool)
    M7N_PROP(pixelArt,     Bool)
    M7N_PROP(tiles,        Int32Array)
M7N_REFLECT_END(M7N::Dim2::TilemapComp)
