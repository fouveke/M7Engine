/**
 * @file Animation2D.hpp
 * @brief 精灵帧动画系统：时间推进 + 图集 UV 写入。
 */
#pragma once

#include "M7N/2D/Components.hpp"
#include "M7N/ECS/World.hpp"

namespace M7N::Dim2 {

class SpriteAnimatorSystem {
public:
    /// 推进全部 SpriteAnimatorComp 实体；自动同步到 SpriteComp::uv。
    static void OnUpdate(ECS::World& world, f32 dt);
};

} // namespace M7N::2D
