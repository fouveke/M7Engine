/**
 * @file RenderSystem.hpp
 * @brief 前向渲染系统：PBR + 阴影 + 深度预通道 + 屏幕分块光照 + HDR 后处理。
 *
 * 实例类（非单例），组合 RHI 设备与资产管理器。一帧：
 *   1. 阴影图：DepthOnly 帧缓冲 + 光空间正交矩阵渲染投射物
 *   2. 场景深度预通道：只写深度（不透明、非裁剪材质）
 *   3. 半分辨率阴影遮罩：从深度重建世界坐标，写入硬件 PCF 结果
 *   4. 场景 pass：同材质实例化 + 8 盏/屏幕块动态光 + Cook-Torrance
 *   5. 泛光链（1/4 分辨率）+ ACES tone map 后处理
 *
 * 全程经 CommandList 录制，零直接 GL 调用。
 */
#pragma once

#include "M7N/RHI/IRenderDevice.hpp"
#include "M7N/Asset/AssetManager.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Animation/AnimationComponents.hpp"
#include "M7N/Scene/TransformSystem.hpp"
#include "M7N/Math/Frustum.hpp"

#include <memory>
#include <vector>

namespace M7N {

class JobSystem;

namespace Render {

/// 方向光（太阳）参数。
struct DirectionalLight {
    Vec3 direction = Vec3(-0.5f, -1.0f, -0.3f);   // 光传播方向
    Vec3 color     = Vec3(1.0f, 0.98f, 0.92f);
    f32  intensity = 1.0f;
    bool castShadows = true;
};

/// 点光参数（带距离衰减）。
struct PointLight {
    Vec3 position = Vec3(0.0f);
    Vec3 color    = Vec3(1.0f);
    f32  intensity = 10.0f;
    f32  range     = 12.0f;
};

/// 聚光灯参数（手电/探照灯；锥形衰减 + 距离衰减，不投影）。
struct SpotLight {
    Vec3 position  = Vec3(0.0f);
    Vec3 direction = Vec3(0.0f, -1.0f, 0.0f);   // 光传播方向
    Vec3 color     = Vec3(1.0f);
    f32  intensity = 20.0f;
    f32  range     = 20.0f;
    f32  innerCos  = 0.92f;    // 内锥角余弦（全亮）
    f32  outerCos  = 0.72f;    // 外锥角余弦（衰减到 0）
};

/// 渲染系统配置。
struct RenderConfig {
    f32 exposure = 1.0f;     // HDR 曝光
    f32 vignette = 0.25f;    // 晴角强度（0 关闭）
    f32 gamma    = 2.2f;
    u32 shadowMapSize = 1536;   // 覆盖 30m 时约 2cm/texel；2048 视觉几乎无差但更吃填充率
    f32 shadowRadius  = 14.0f;   // 阴影覆盖世界半径（以场景中心为球心）
    u32 shadowUpdateInterval = 1;  // 每 N 帧重绘一次阴影图（静态场景可 >1，省整趟阴影 pass）
    u32 bloomDownscale = 4;      // 泛光链相对 HDR 目标的分辨率除数（4 = 1/4）
    Vec3 ambientSky    = Vec3(0.35f, 0.45f, 0.62f);
    Vec3 ambientGround = Vec3(0.22f, 0.20f, 0.18f);
    Vec3 skyColor      = Vec3(0.05f, 0.06f, 0.09f);  // 场景清屏色（无天空盒，作为天顶底色）
    f32  bloomStrength = 0.55f;                      // 泛光强度（自发光/灯头光晕）
    f32  renderScale   = 1.0f;                       // 3D 内部分辨率倍率（<1 = 降分辨率渲染再放大，省填充率）
    bool lightmapDebug = false;                      // 只输出烘焙光图（调试 UV/亮度）
    bool frustumCulling = true;                      // 通用视锥剔除（调试可关）
    bool depthPrepass = true;                        // 先写深度再做 PBR，砍掉被遮挡片元
    bool shadowMask = true;                          // 半分辨率阴影遮罩：PBR 每像素只采 1 次
    bool lightGrid = true;                           // 屏幕分块光照：每像素只算附近的光
    bool cheapDynamicLights = true;                  // 次要动态光用轻量 BRDF（主光仍全 PBR）
    u32  dynamicLightFullCount = 2;                   // 每块最强的 N 盏动态光保留完整 PBR
};

/// 单帧渲染统计。
struct RenderStats {
    u32 sceneDraws = 0;   ///< 场景 pass 实际提交的 submesh draw 数
    u32 shadowDraws = 0;  ///< 阴影 pass 实际提交的 draw 数
    u32 meshes = 0;       ///< 通过剔除的实体数
    u32 culled = 0;       ///< 被视锥剔除的实体数
    u32 batches = 0;      ///< 材质批次（同材质连续绘制的组数）
    u32 lights = 0;       ///< 本帧动态光总数（点光 + 聚光）
    u32 prepassDraws = 0; ///< 深度预通道 draw 数
    u32 lightOverflows = 0; ///< 光照网格中因单块超过 8 盏而丢弃的次数
    f32 cpuTransformMs = 0.0f;
    f32 cpuPrepareMs = 0.0f;
    f32 cpuCollectMs = 0.0f;
    f32 cpuSortMs = 0.0f;
    f32 cpuBatchMs = 0.0f;
    f32 cpuRecordMs = 0.0f;
    f32 cpuSubmitMs = 0.0f;
};

class RenderSystem {
public:
    RenderSystem(RHI::IRenderDevice& device, Asset::AssetManager& assets);

    /// 创建管线与帧缓冲（GL 上下文就绪后调用一次）。
    bool Init(u32 viewportWidth, u32 viewportHeight);

    /// 释放全部 GPU 资源。
    void Shutdown();

    /// 窗口尺寸变化时重建 HDR 帧缓冲。
    void OnResize(u32 width, u32 height);

    // --- 帧级状态 ---

    void SetCamera(const Vec3& eye, const Vec3& target,
                   f32 fovYDeg, f32 aspect, f32 nearZ, f32 farZ);

    /// 帧首清空上一帧点光（方向光为覆盖式设置）。
    void SetDirectionalLight(const DirectionalLight& light);
    void AddPointLight(const PointLight& light);
    void AddSpotLight(const SpotLight& light);
    void ClearLights();

    void SetConfig(const RenderConfig& config) { config_ = config; }
    const RenderConfig& GetConfig() const { return config_; }

    /// 可选：并行更新世界矩阵的作业系统（nullptr = 串行）。
    void SetJobSystem(JobSystem* jobs) { jobs_ = jobs; }
    const RenderStats& GetStats() const { return stats_; }

    // --- 帧入口 ---

    /// 阴影 pass + 场景 pass + 后处理 pass（一条命令流）。
    void RenderFrame(ECS::World& world, const Vec3& sceneCenter);

    /// 仅场景+后处理（调试用：跳过阴影 pass）。
    void RenderFrameNoShadows(ECS::World& world);

private:
    /// 编译三条管线（PBR / 阴影 / 后处理）。@return 是否全部成功。
    bool createPipelines();

    /// 按方向光与场景中心计算光空间矩阵（正交，覆盖 shadowRadius）。
    Mat4 computeLightSpaceMatrix(const Vec3& lightDir, const Vec3& center) const;

    // --- 绘制数据（一帧只收集一次，阴影/场景共用）---

    /// 解析后的单 submesh 材质（材质批次按 key 合并后只上传一次）。
    struct MaterialState {
        RHI::TextureHandle baseTex, normalTex, ormTex, emissiveTex, lightmapTex;
        Vec4 baseColor = Vec4(1.0f);
        Vec3 emissive = Vec3(0.0f);
        Vec2 uvScale = Vec2(1.0f);
        f32 metallic = 0.0f;
        f32 roughness = 1.0f;
        f32 alphaCutoff = 0.0f;
        f32 normalStrength = 1.0f;
        f32 detailScale = 40.0f;
        f32 detailStrength = 0.0f;
        f32 detailRoughJitter = 0.0f;
        f32 lightmapStrength = 1.0f;
        bool useDetail = false;
        u64 key = 0;
    };

    struct CachedSub {
        u32 indexOffset = 0;
        u32 indexCount = 0;
        MaterialState mat;
    };

    /// 每个实体的解析缓存：路径/材质字段不变时跨帧复用，避免每帧哈希资产表。
    struct CachedDraw {
        String path;
        u64 settingsHash = 0;
        u32 generation = 0;
        Asset::GPUMesh gpu;
        bool skinned = false;
        std::vector<CachedSub> subs;

        // 静止根实体的世界矩阵 / 世界 AABB 跨帧缓存（动态实体每帧重算）。
        bool hasTransform = false;
        Scene::Transform lastTransform;
        u32 lastParentIndex = ECS::kInvalidIndex;
        Mat4 lastWorld = Mat4(1.0f);
        bool hasBounds = false;
        Vec3 worldMin = Vec3(0.0f);
        Vec3 worldMax = Vec3(0.0f);
    };

    struct DrawItem {
        ECS::Entity entity;
        Mat4 world;
        const CachedDraw* cached = nullptr;
        const CachedSub* sub = nullptr;
        const Animation::SkeletonComp* skeleton = nullptr;
        f32 depth = 0.0f;
    };

    struct ShadowItem {
        ECS::Entity entity;
        Mat4 world;
        const CachedDraw* cached = nullptr;
        const Animation::SkeletonComp* skeleton = nullptr;
        f32 depth = 0.0f;
    };

    /// 同材质 + 同网格 + 同索引区间的实例批次（每实例只传一个 mat4）。
    struct InstancedBatch {
        const CachedDraw* cached = nullptr;
        const CachedSub* sub = nullptr;
        u64 materialKey = 0;
        f32 depth = 0.0f;   ///< 平均深度平方（批次按此前到后排序，利于 early-z）
        std::vector<Mat4> models;
    };

    struct ShadowInstancedBatch {
        const CachedDraw* cached = nullptr;
        std::vector<Mat4> models;
    };

    /// 收集可见绘制（一次遍历同时完成场景剔除与阴影剔除）。
    void prepareDraws(ECS::World& world, bool doShadow);

    CachedDraw* getCachedDraw(ECS::Entity entity, const Scene::MeshRef& meshRef);

    /// 阴影 pass：录制投射物深度。
    void recordShadowPass();

    /// 深度预通道：只写深度，不写颜色（排除 alpha 裁剪材质）。
    void recordDepthPrepass();

    /// 半分辨率阴影遮罩：从场景深度重建世界坐标，写入遮蔽因子。
    void recordShadowMaskPass();

    /// 重建半分辨率阴影遮罩目标。
    bool createShadowMaskTarget(u32 width, u32 height);

    /// 场景 pass：HDR 目标上的 PBR 几何绘制。
    void recordScenePass();

    /// 上传本帧实例矩阵并缓存句柄（深度预通道与颜色 pass 共用）。
    void prepareInstanceBuffers();

    /// 重建光照网格纹理（视口尺寸变化时）。
    void createLightGridTexture();

    /// 每帧把动态光投影到屏幕分块表（每块最多 8 盏）。
    void buildLightGrid();

    /// 降采样泛光链：预过滤 → 横向模糊 → 纵向模糊（1/4 分辨率）。
    void recordBloomPass();

    /// 后处理 pass：全屏三角合成到后备缓冲。
    void recordPostPass();

    /// 重建 1/4 分辨率的泛光目标（失败时静默关闭泛光）。
    bool createBloomTargets(u32 width, u32 height);

    /// 相机/方向光/点光/聚光/阴影等全局 uniform（按着色器程序各发一次）。
    void setSceneGlobals();

    /// 同一材质的 uniform + 贴图只下发一次。
    void applyMaterial(const MaterialState& mat);
    void drawItems(const std::vector<DrawItem>& items, bool skinned);

    /// 把排序后的绘制列表压缩成实例批次，剩余零散项留在原列表。
    void buildInstanceBatches();
    void drawInstancedOpaque();
    void drawInstancedShadow();
    RHI::BufferHandle ensureInstanceBuffer(
        std::vector<RHI::BufferHandle>& buffers, std::vector<u32>& capacities,
        u32 index, const std::vector<Mat4>& models);

    RHI::IRenderDevice&   device_;
    Asset::AssetManager&  assets_;
    RHI::CommandList      cmd_;
    Scene::TransformSystem transformSystem_;
    JobSystem*            jobs_ = nullptr;
    RenderStats           stats_;

    // 管线
    RHI::ShaderHandle    pbrShader_;
    RHI::ShaderHandle    pbrSkinShader_;    ///< 蒙皮变体顶点着色器
    RHI::ShaderHandle    pbrInstShader_;    ///< 实例化变体顶点着色器
    RHI::ShaderHandle    pbrOpaqueShader_;      ///< 无 discard 的不透明变体（early-z）
    RHI::ShaderHandle    pbrSkinOpaqueShader_;
    RHI::ShaderHandle    pbrInstOpaqueShader_;
    RHI::ShaderHandle    shadowShader_;
    RHI::ShaderHandle    shadowSkinShader_; ///< 阴影蒙皮变体
    RHI::ShaderHandle    shadowInstShader_; ///< 阴影实例化变体
    RHI::ShaderHandle    depthShader_;
    RHI::ShaderHandle    depthSkinShader_;
    RHI::ShaderHandle    depthInstShader_;
    RHI::ShaderHandle    shadowMaskShader_;
    RHI::ShaderHandle    bloomShader_;
    RHI::ShaderHandle    postShader_;
    RHI::PipelineHandle  depthPipeline_;
    RHI::PipelineHandle  depthSkinPipeline_;
    RHI::PipelineHandle  depthInstPipeline_;
    RHI::PipelineHandle  shadowMaskPipeline_;
    RHI::PipelineHandle  bloomPipeline_;
    RHI::PipelineHandle  pbrPipeline_;
    RHI::PipelineHandle  pbrSkinPipeline_;  ///< 蒙皮 PBR 管线（location 3/4）
    RHI::PipelineHandle  pbrInstPipeline_;  ///< 实例化 PBR 管线（location 6..9）
    RHI::PipelineHandle  pbrNoDepthPipeline_;      ///< 深度预通道后的颜色 pass（不写深度）
    RHI::PipelineHandle  pbrSkinNoDepthPipeline_;
    RHI::PipelineHandle  pbrInstNoDepthPipeline_;
    RHI::PipelineHandle  pbrBlendPipeline_;      ///< alpha 混合 PBR（弹孔/火光贴片）
    RHI::PipelineHandle  pbrBlendSkinPipeline_;  ///< alpha 混合 + 蒙皮
    RHI::PipelineHandle  shadowPipeline_;
    RHI::PipelineHandle  shadowSkinPipeline_; ///< 阴影蒙皮管线
    RHI::PipelineHandle  shadowInstPipeline_; ///< 阴影实例化管线
    RHI::PipelineHandle  postPipeline_;

    // 帧缓冲
    RHI::FramebufferHandle hdrFB_;
    RHI::FramebufferHandle shadowFB_;
    RHI::FramebufferHandle bloomFB_[2];
    RHI::FramebufferHandle shadowMaskFB_;
    u32 bloomW_ = 1;
    u32 bloomH_ = 1;
    bool shadowMaskActive_ = false;
    u32 viewportW_ = 1;
    u32 viewportH_ = 1;

    // 帧级状态
    Mat4 viewMatrix_       = Mat4(1.0f);
    Mat4 projMatrix_       = Mat4(1.0f);
    Mat4 lightSpaceMatrix_ = Mat4(1.0f);
    Vec3 cameraPos_ = Vec3(0.0f);
    f32  fovY_ = 0.7853982f;
    f32  aspect_ = 1.0f;
    f32  nearZ_ = 0.1f;
    f32  farZ_ = 1000.0f;
    u32  renderW_ = 1;            ///< HDR 目标实际像素尺寸（renderScale 之后）
    u32  renderH_ = 1;
    u32  shadowFrame_  = 0;      ///< 帧计数（决定本帧是否重绘阴影图）
    bool shadowValid_  = false;  ///< 阴影图是否已有可用内容

    RHI::TextureHandle lightGridTex_;
    u32 lightGridTilesX_ = 0;
    u32 lightGridTilesY_ = 0;
    bool lightGridActive_ = false;

    DirectionalLight      dirLight_;
    bool                  dirLightEnabled_ = false;
    std::vector<PointLight> pointLights_;   // 上限 32
    std::vector<SpotLight>  spotLights_;    // 上限 8

    RenderConfig config_;

    // 绘制缓存与绘制列表
    std::vector<std::unique_ptr<CachedDraw>> drawCache_;
    u64 cachedAssetRevision_ = 0;
    RHI::TextureHandle detailNormalTex_{};
    std::vector<DrawItem>   opaqueStatic_, opaqueSkinned_;
    std::vector<DrawItem>   blendStatic_, blendSkinned_;
    std::vector<ShadowItem> shadowStatic_, shadowSkinned_;
    std::vector<InstancedBatch> opaqueInst_;
    std::vector<ShadowInstancedBatch> shadowInst_;
    std::vector<RHI::BufferHandle> instBuffers_;
    std::vector<u32> instBufferCaps_;
    std::vector<RHI::BufferHandle> opaqueInstHandles_;
    std::vector<RHI::BufferHandle> shadowInstBuffers_;
    std::vector<u32> shadowInstBufferCaps_;
    bool opaqueHasCutout_ = false;   ///< 任一不透明材质有 alpha 裁剪 → 颜色 pass 必须写深度

    static constexpr u32 kMaxPointLights = 32;
    static constexpr u32 kMaxSpotLights  = 8;
};

} // namespace Render
} // namespace M7N
