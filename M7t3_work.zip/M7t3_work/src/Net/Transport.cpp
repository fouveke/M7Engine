/**
 * @file Transport.cpp
 * @brief UDP / 模拟网络传输实现。
 */
#include "M7N/Net/Transport.hpp"
#include "M7N/Core/Log.hpp"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <map>
#include <random>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#if defined(_WIN32)
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #ifndef NOMINMAX
        #define NOMINMAX
    #endif
    #include <winsock2.h>
    #include <ws2tcpip.h>
#else
    #include <arpa/inet.h>
    #include <fcntl.h>
    #include <netdb.h>
    #include <netinet/in.h>
    #include <sys/socket.h>
    #include <unistd.h>
    #include <cerrno>
#endif

namespace M7N::Net {

// =====================================================================
// 基础类型
// =====================================================================

const char* ToString(ConnectionState state) {
    switch (state) {
        case ConnectionState::Disconnected: return "Disconnected";
        case ConnectionState::Connecting:   return "Connecting";
        case ConnectionState::Connected:    return "Connected";
        case ConnectionState::TimedOut:     return "TimedOut";
    }
    return "Unknown";
}

const char* ToString(DisconnectReason reason) {
    switch (reason) {
        case DisconnectReason::None:           return "None";
        case DisconnectReason::Timeout:        return "Timeout";
        case DisconnectReason::ProtocolError:  return "ProtocolError";
        case DisconnectReason::ServerFull:     return "ServerFull";
        case DisconnectReason::ServerShutdown: return "ServerShutdown";
        case DisconnectReason::ClientQuit:     return "ClientQuit";
        case DisconnectReason::ConnectionLost: return "ConnectionLost";
    }
    return "Unknown";
}

namespace {

bool parseIPv4(const String& text, u32& outHost) {
    u32 parts[4] = {};
    i32 dots = 0;
    u32 value = 0;
    bool hasDigit = false;
    for (char c : text) {
        if (c >= '0' && c <= '9') {
            value = value * 10u + static_cast<u32>(c - '0');
            if (value > 255u) return false;
            hasDigit = true;
        } else if (c == '.') {
            if (!hasDigit || dots >= 3) return false;
            parts[dots++] = value;
            value = 0;
            hasDigit = false;
        } else {
            return false;
        }
    }
    if (!hasDigit || dots != 3) return false;
    parts[3] = value;
    outHost = (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3];
    return true;
}

constexpr u32 kLoopbackHost = 0x7F000001u;

f64 steadyNow() {
    using Clock = std::chrono::steady_clock;
    static const Clock::time_point start = Clock::now();
    return std::chrono::duration<f64>(Clock::now() - start).count();
}

#if defined(_WIN32)
struct WinsockGuard {
    WinsockGuard() {
        WSADATA data{};
        WSAStartup(MAKEWORD(2, 2), &data);
    }
    ~WinsockGuard() { WSACleanup(); }
};
void ensureWinsock() {
    static WinsockGuard guard;
    (void)guard;
}
using SocketHandle = SOCKET;
constexpr SocketHandle kInvalidSocket = INVALID_SOCKET;
void closeSocket(SocketHandle s) { if (s != kInvalidSocket) closesocket(s); }
#else
using SocketHandle = int;
constexpr SocketHandle kInvalidSocket = -1;
void closeSocket(SocketHandle s) { if (s >= 0) ::close(s); }
void ensureWinsock() {}
#endif

} // namespace

Address Address::Parse(const String& text) {
    Address address;
    String hostPart = text;
    const size_t colon = text.rfind(':');
    if (colon != String::npos) {
        hostPart = text.substr(0, colon);
        const String portPart = text.substr(colon + 1);
        if (!portPart.empty()) {
            address.port = static_cast<u16>(std::strtoul(portPart.c_str(), nullptr, 10));
        }
    }
    if (!parseIPv4(hostPart, address.host)) address.host = 0;
    return address;
}

String Address::ToString() const {
    char buffer[64];
    std::snprintf(buffer, sizeof(buffer), "%u.%u.%u.%u:%u",
                  (host >> 24) & 0xFF, (host >> 16) & 0xFF,
                  (host >> 8) & 0xFF, host & 0xFF, port);
    return String(buffer);
}

bool ResolveAddress(const String& hostPort, Address& out) {
    String host = hostPort;
    String port = "0";
    const size_t colon = hostPort.rfind(':');
    if (colon != String::npos) {
        host = hostPort.substr(0, colon);
        port = hostPort.substr(colon + 1);
    }
    if (host.empty() || port.empty() || port == "0") return false;

    ensureWinsock();
    addrinfo hints{};
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_DGRAM;
    addrinfo* result = nullptr;
    if (getaddrinfo(host.c_str(), port.c_str(), &hints, &result) != 0 || !result) {
        return false;
    }
    const auto* sin = reinterpret_cast<const sockaddr_in*>(result->ai_addr);
    out.host = ntohl(sin->sin_addr.s_addr);
    out.port = ntohs(sin->sin_port);
    freeaddrinfo(result);
    return out.IsValid();
}

// =====================================================================
// UDP
// =====================================================================

struct UdpTransport::Impl {
    SocketHandle socket = kInvalidSocket;
    bool open = false;
    u16 port = 0;
};

UdpTransport::UdpTransport() : impl_(CreateScope<Impl>()) {}
UdpTransport::~UdpTransport() { Close(); }

bool UdpTransport::Open(u16 port) {
    ensureWinsock();
    Close();

    impl_->socket = ::socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (impl_->socket == kInvalidSocket) {
        M7N_LOG_ERROR("Net", "socket() failed");
        return false;
    }

#if defined(_WIN32)
    u_long mode = 1;
    if (ioctlsocket(impl_->socket, FIONBIO, &mode) != 0) {
        M7N_LOG_ERROR("Net", "ioctlsocket(FIONBIO) failed");
        Close();
        return false;
    }
#else
    const int flags = fcntl(impl_->socket, F_GETFL, 0);
    fcntl(impl_->socket, F_SETFL, flags | O_NONBLOCK);
#endif

    int bufferSize = 1 << 20;
    setsockopt(impl_->socket, SOL_SOCKET, SO_RCVBUF,
               reinterpret_cast<const char*>(&bufferSize), sizeof(bufferSize));
    setsockopt(impl_->socket, SOL_SOCKET, SO_SNDBUF,
               reinterpret_cast<const char*>(&bufferSize), sizeof(bufferSize));

    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(port);
    if (bind(impl_->socket, reinterpret_cast<sockaddr*>(&address), sizeof(address)) != 0) {
        M7N_LOG_ERROR("Net", "bind port %u failed", port);
        Close();
        return false;
    }

    sockaddr_in local{};
    socklen_t localLen = sizeof(local);
    if (getsockname(impl_->socket, reinterpret_cast<sockaddr*>(&local), &localLen) == 0) {
        impl_->port = ntohs(local.sin_port);
    } else {
        impl_->port = port;
    }

    impl_->open = true;
    return true;
}

void UdpTransport::Close() {
    if (!impl_) return;
    if (impl_->socket != kInvalidSocket) {
        closeSocket(impl_->socket);
        impl_->socket = kInvalidSocket;
    }
    impl_->open = false;
    impl_->port = 0;
}

bool UdpTransport::IsOpen() const { return impl_ && impl_->open; }
u16 UdpTransport::LocalPort() const { return impl_ ? impl_->port : 0; }
f64 UdpTransport::NowSeconds() const { return steadyNow(); }

bool UdpTransport::Send(const Address& to, const void* data, u32 size) {
    if (!impl_ || !impl_->open || !data || size == 0 || !to.IsValid()) return false;
    if (size > 65507u) return false;

    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = htons(to.port);
    address.sin_addr.s_addr = htonl(to.host);

    const int sent = static_cast<int>(sendto(
        impl_->socket, static_cast<const char*>(data), static_cast<int>(size),
        0, reinterpret_cast<const sockaddr*>(&address), sizeof(address)));
    return sent == static_cast<int>(size);
}

int UdpTransport::Receive(Address& from, void* data, u32 capacity) {
    if (!impl_ || !impl_->open) return 0;

    sockaddr_in address{};
#if defined(_WIN32)
    int addressLen = sizeof(address);
#else
    socklen_t addressLen = sizeof(address);
#endif
    const int received = static_cast<int>(recvfrom(
        impl_->socket, static_cast<char*>(data), static_cast<int>(capacity), 0,
        reinterpret_cast<sockaddr*>(&address), &addressLen));
    if (received < 0) {
#if defined(_WIN32)
        const int error = WSAGetLastError();
        if (error == WSAEWOULDBLOCK || error == WSAECONNRESET) return 0;
#else
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == ECONNRESET) return 0;
#endif
        return -1;
    }
    if (received == 0) return 0;

    from.host = ntohl(address.sin_addr.s_addr);
    from.port = ntohs(address.sin_port);
    return received;
}

// =====================================================================
// 模拟网络
// =====================================================================

struct SimulatedPacket {
    Address from;
    std::vector<u8> data;
    f64 deliverAt = 0.0;
};

struct SimulatedNetworkState {
    std::mt19937 rng;
    f64 now = 0.0;
    u32 minLatencyMs = 0;
    u32 maxLatencyMs = 0;
    u32 jitterMs = 0;
    f32 loss = 0.0f;
    f32 duplicate = 0.0f;
    u32 drops = 0;
    u16 nextEphemeralPort = 49152;
    std::unordered_map<u16, std::multimap<f64, SimulatedPacket>> inboxes;
};

SimulatedNetwork::SimulatedNetwork(u32 seed)
    : state_(std::make_shared<SimulatedNetworkState>()) {
    state_->rng.seed(seed == 0 ? 0x7E57u : seed);
}

SimulatedNetwork::~SimulatedNetwork() = default;

void SimulatedNetwork::SetLatency(u32 minMs, u32 maxMs) {
    state_->minLatencyMs = minMs;
    state_->maxLatencyMs = (maxMs >= minMs) ? maxMs : minMs;
}

void SimulatedNetwork::SetPacketLoss(f32 rate) {
    state_->loss = std::clamp(rate, 0.0f, 1.0f);
}

void SimulatedNetwork::SetDuplicate(f32 rate) {
    state_->duplicate = std::clamp(rate, 0.0f, 1.0f);
}

void SimulatedNetwork::SetJitter(u32 milliseconds) { state_->jitterMs = milliseconds; }

void SimulatedNetwork::Advance(f64 seconds) {
    if (seconds > 0.0) state_->now += seconds;
}

f64 SimulatedNetwork::NowSeconds() const { return state_->now; }
u32 SimulatedNetwork::DropCount() const { return state_->drops; }

Scope<SimulatedTransport> SimulatedNetwork::CreateTransport() {
    return CreateScope<SimulatedTransport>(*this);
}

SimulatedTransport::SimulatedTransport(SimulatedNetwork& network)
    : state_(network.state_) {}

SimulatedTransport::~SimulatedTransport() { Close(); }

bool SimulatedTransport::Open(u16 port) {
    if (!state_ || open_) return false;

    if (port == 0) {
        while (state_->inboxes.count(state_->nextEphemeralPort) != 0) {
            state_->nextEphemeralPort++;
        }
        port = state_->nextEphemeralPort++;
    }
    if (state_->inboxes.count(port) != 0) return false;

    state_->inboxes.emplace(port, std::multimap<f64, SimulatedPacket>{});
    port_ = port;
    open_ = true;
    return true;
}

void SimulatedTransport::Close() {
    if (!state_ || !open_) return;
    state_->inboxes.erase(port_);
    open_ = false;
    port_ = 0;
}

bool SimulatedTransport::IsOpen() const { return open_; }
u16 SimulatedTransport::LocalPort() const { return port_; }
f64 SimulatedTransport::NowSeconds() const { return state_ ? state_->now : 0.0; }

bool SimulatedTransport::Send(const Address& to, const void* data, u32 size) {
    if (!state_ || !open_ || !data || size == 0 || !to.IsValid()) return false;

    auto it = state_->inboxes.find(to.port);
    if (it == state_->inboxes.end()) return true;   // 目标不存在：视为丢包

    std::uniform_real_distribution<f32> chance(0.0f, 1.0f);
    if (chance(state_->rng) < state_->loss) {
        state_->drops++;
        return true;
    }

    u32 delayMs = state_->minLatencyMs;
    if (state_->maxLatencyMs > state_->minLatencyMs) {
        std::uniform_int_distribution<u32> latency(state_->minLatencyMs,
                                                   state_->maxLatencyMs);
        delayMs = latency(state_->rng);
    }
    if (state_->jitterMs > 0) {
        std::uniform_int_distribution<u32> jitter(0, state_->jitterMs);
        delayMs += jitter(state_->rng);
    }

    SimulatedPacket packet;
    packet.from.host = kLoopbackHost;
    packet.from.port = port_;
    packet.data.assign(static_cast<const u8*>(data),
                       static_cast<const u8*>(data) + size);
    packet.deliverAt = state_->now + static_cast<f64>(delayMs) / 1000.0;
    it->second.emplace(packet.deliverAt, packet);

    if (chance(state_->rng) < state_->duplicate) {
        SimulatedPacket copy = packet;
        copy.deliverAt += 0.001;
        it->second.emplace(copy.deliverAt, copy);
    }
    return true;
}

int SimulatedTransport::Receive(Address& from, void* data, u32 capacity) {
    if (!state_ || !open_) return 0;
    auto it = state_->inboxes.find(port_);
    if (it == state_->inboxes.end()) return 0;

    auto& queue = it->second;
    for (auto packet = queue.begin(); packet != queue.end(); ++packet) {
        if (packet->second.deliverAt > state_->now) continue;
        const u32 size = static_cast<u32>(packet->second.data.size());
        if (size > capacity) {
            queue.erase(packet);
            return 0;
        }
        std::memcpy(data, packet->second.data.data(), size);
        from = packet->second.from;
        queue.erase(packet);
        return static_cast<int>(size);
    }
    return 0;
}

} // namespace M7N::Net
