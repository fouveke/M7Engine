/**
 * @file Replication.cpp
 * @brief 状态复制实现：量化快照分块、生成/销毁事件、客户端平滑。
 */
#include "M7N/Net/Replication.hpp"
#include "M7N/Net/ByteStream.hpp"
#include "M7N/Scene/Components.hpp"
#include "M7N/Core/Log.hpp"

#include <algorithm>
#include <cmath>
#include <string>
#include <unordered_set>

namespace M7N::Net {

namespace {

constexpr f32 kPositionScale = 32.0f;      ///< 1/32 米精度
constexpr f32 kRotationScale = 100.0f;     ///< 1/100 弧度
constexpr u32 kEntitiesPerChunk = 60;
constexpr f32 kTwoPi = 6.28318530718f;

i16 quantize(f32 value, f32 scale) {
    const f32 scaled = value * scale;
    if (scaled > 32767.0f) return 32767;
    if (scaled < -32767.0f) return -32767;
    return static_cast<i16>(std::lround(scaled));
}

f32 wrapAngle(f32 angle) {
    angle = std::fmod(angle + glm::PI, kTwoPi);
    if (angle < 0.0f) angle += kTwoPi;
    return angle - glm::PI;
}

f32 lerpAngle(f32 from, f32 to, f32 t) {
    f32 delta = wrapAngle(to - from);
    return from + delta * t;
}

} // namespace

// =====================================================================
// 服务器
// =====================================================================

ReplicationServer::ReplicationServer(NetServer& server) : server_(server) {}

void ReplicationServer::SetTickRate(u32 hz) {
    tickRate_ = (hz >= 1 && hz <= 120) ? hz : 20;
}

void ReplicationServer::OnUpdate(ECS::World& world, f32 dt) {
    syncNewClients(world);
    scanEntities(world);

    const f32 interval = 1.0f / static_cast<f32>(tickRate_);
    accumulator_ += dt;
    if (accumulator_ > interval * 4.0f) accumulator_ = interval * 4.0f;

    u32 steps = 0;
    while (accumulator_ >= interval && steps < 4) {
        accumulator_ -= interval;
        tick_++;
        sendSnapshot(world);
        steps++;
    }
}

void ReplicationServer::sendSpawn(ClientId client, u32 netId, u32 owner) {
    std::vector<u8> payload;
    ByteWriter writer(payload);
    writer.U8(kMsgSpawn);
    writer.U32(netId);
    writer.U32(owner);
    server_.SendTo(client, Channel::Reliable, payload.data(),
                   static_cast<u32>(payload.size()));
}

void ReplicationServer::syncNewClients(ECS::World& world) {
    const std::vector<ClientId> current = server_.GetClients();
    std::unordered_set<ClientId> currentSet(current.begin(), current.end());

    for (auto it = knownClients_.begin(); it != knownClients_.end();) {
        if (currentSet.count(*it) == 0) it = knownClients_.erase(it);
        else ++it;
    }

    for (ClientId client : current) {
        if (!knownClients_.insert(client).second) continue;
        // 新接入客户端：补发当前全部实体的生成事件
        for (const auto& [netId, entity] : tracked_) {
            if (!world.IsAlive(entity)) continue;
            const NetworkIdentity* identity = world.GetComponent<NetworkIdentity>(entity);
            sendSpawn(client, netId, identity ? identity->ownerClient : 0);
        }
    }
}

void ReplicationServer::scanEntities(ECS::World& world) {
    world.ForEach<Scene::Transform, NetworkIdentity>(
        [&](ECS::Entity e, Scene::Transform&, NetworkIdentity& identity) {
            const bool conflict = identity.netId != 0 &&
                                  tracked_.count(identity.netId) != 0 &&
                                  tracked_[identity.netId] != e;
            if (identity.netId == 0 || conflict) {
                identity.netId = nextNetId_++;
            } else if (identity.netId >= nextNetId_) {
                nextNetId_ = identity.netId + 1;
            }

            auto it = tracked_.find(identity.netId);
            if (it == tracked_.end()) {
                tracked_[identity.netId] = e;
                std::vector<u8> payload;
                ByteWriter writer(payload);
                writer.U8(kMsgSpawn);
                writer.U32(identity.netId);
                writer.U32(identity.ownerClient);
                server_.Broadcast(Channel::Reliable, payload.data(),
                                  static_cast<u32>(payload.size()));
            } else if (it->second != e) {
                it->second = e;
            }
        });

    for (auto it = tracked_.begin(); it != tracked_.end();) {
        bool alive = world.IsAlive(it->second);
        if (alive) {
            const NetworkIdentity* identity = world.GetComponent<NetworkIdentity>(it->second);
            alive = identity && identity->netId == it->first;
        }
        if (!alive) {
            std::vector<u8> payload;
            ByteWriter writer(payload);
            writer.U8(kMsgDestroy);
            writer.U32(it->first);
            server_.Broadcast(Channel::Reliable, payload.data(),
                              static_cast<u32>(payload.size()));
            it = tracked_.erase(it);
        } else {
            ++it;
        }
    }
}

void ReplicationServer::sendSnapshot(ECS::World& world) {
    struct SnapshotEntity {
        u32 netId = 0;
        Vec3 position = Vec3(0.0f);
        Vec3 rotation = Vec3(0.0f);
    };
    std::vector<SnapshotEntity> states;
    states.reserve(tracked_.size());

    for (const auto& [netId, entity] : tracked_) {
        if (!world.IsAlive(entity)) continue;
        const Scene::Transform* transform = world.GetComponent<Scene::Transform>(entity);
        if (!transform) continue;
        SnapshotEntity state;
        state.netId = netId;
        state.position = transform->position;
        state.rotation = Vec3(wrapAngle(transform->rotation.x),
                              wrapAngle(transform->rotation.y),
                              wrapAngle(transform->rotation.z));
        states.push_back(state);
    }

    const u32 chunkCount = std::max<u32>(
        1, (static_cast<u32>(states.size()) + kEntitiesPerChunk - 1) / kEntitiesPerChunk);

    for (u32 chunk = 0; chunk < chunkCount; ++chunk) {
        const u32 begin = chunk * kEntitiesPerChunk;
        const u32 end = std::min<u32>(begin + kEntitiesPerChunk,
                                      static_cast<u32>(states.size()));

        std::vector<u8> payload;
        payload.reserve(32 + (end - begin) * 16);
        ByteWriter writer(payload);
        writer.U8(kMsgSnapshot);
        writer.U32(tick_);
        writer.U16(static_cast<u16>(chunk));
        writer.U16(static_cast<u16>(chunkCount));
        writer.U16(static_cast<u16>(end - begin));

        for (u32 i = begin; i < end; ++i) {
            const SnapshotEntity& state = states[i];
            writer.U32(state.netId);
            writer.I16(quantize(state.position.x, kPositionScale));
            writer.I16(quantize(state.position.y, kPositionScale));
            writer.I16(quantize(state.position.z, kPositionScale));
            writer.I16(quantize(state.rotation.x, kRotationScale));
            writer.I16(quantize(state.rotation.y, kRotationScale));
            writer.I16(quantize(state.rotation.z, kRotationScale));
        }

        server_.Broadcast(Channel::Unreliable, payload.data(),
                          static_cast<u32>(payload.size()));
    }
}

// =====================================================================
// 客户端
// =====================================================================

ReplicationClient::ReplicationClient(ECS::World& world) : world_(world) {}

void ReplicationClient::SetSpawnCallback(std::function<void(ECS::Entity, u32)> callback) {
    onSpawn_ = std::move(callback);
}

void ReplicationClient::SetDestroyCallback(std::function<void(ECS::Entity, u32)> callback) {
    onDestroy_ = std::move(callback);
}

ECS::Entity ReplicationClient::GetEntity(u32 netId) const {
    auto it = entities_.find(netId);
    return (it != entities_.end()) ? it->second.entity : ECS::kNullEntity;
}

ECS::Entity ReplicationClient::ensureEntity(u32 netId, u32 owner) {
    auto it = entities_.find(netId);
    if (it != entities_.end()) {
        if (owner != 0) it->second.owner = owner;
        return it->second.entity;
    }

    ECS::Entity entity = world_.CreateEntity("NetEntity_" + std::to_string(netId));
    world_.AddComponent<Scene::Transform>(entity);
    NetworkIdentity identity;
    identity.netId = netId;
    identity.ownerClient = owner;
    world_.AddComponent<NetworkIdentity>(entity, identity);

    RemoteEntity remote;
    remote.entity = entity;
    remote.owner = owner;
    remote.lastSeen = time_;
    entities_.emplace(netId, remote);

    if (onSpawn_) onSpawn_(entity, netId);
    return entity;
}

void ReplicationClient::OnPacket(Channel channel, const u8* data, u32 size) {
    (void)channel;
    if (!data || size < 1) return;
    ByteReader reader(data, size);
    const u8 type = reader.U8();
    switch (type) {
        case kMsgSpawn:
            if (channel == Channel::Reliable) handleSpawn(data + 1, size - 1);
            break;
        case kMsgDestroy:
            if (channel == Channel::Reliable) handleDestroy(data + 1, size - 1);
            break;
        case kMsgSnapshot:
            if (channel == Channel::Unreliable) handleSnapshot(data + 1, size - 1);
            break;
        default:
            break;
    }
}

void ReplicationClient::handleSpawn(const u8* data, u32 size) {
    ByteReader reader(data, size);
    const u32 netId = reader.U32();
    const u32 owner = reader.U32();
    if (!reader.Ok() || netId == 0) return;

    destroyedIds_.erase(netId);
    bool isNew = entities_.find(netId) == entities_.end();
    ensureEntity(netId, owner);
    if (isNew) {
        M7N_LOG_DEBUG("Net", "spawn entity netId=%u", netId);
    }
}

void ReplicationClient::handleDestroy(const u8* data, u32 size) {
    ByteReader reader(data, size);
    const u32 netId = reader.U32();
    if (!reader.Ok()) return;

    auto it = entities_.find(netId);
    if (it == entities_.end()) return;

    const ECS::Entity entity = it->second.entity;
    const u32 owner = it->second.owner;
    entities_.erase(it);
    destroyedIds_.insert(netId);
    if (world_.IsAlive(entity)) world_.DestroyEntity(entity);
    if (onDestroy_) onDestroy_(entity, owner);
}

void ReplicationClient::handleSnapshot(const u8* data, u32 size) {
    ByteReader reader(data, size);
    const u32 tick = reader.U32();
    const u16 chunkIndex = reader.U16();
    const u16 chunkCount = reader.U16();
    const u16 count = reader.U16();
    if (!reader.Ok() || chunkCount == 0 || chunkCount > 64 ||
        chunkIndex >= chunkCount) {
        return;
    }
    if (tick <= lastAppliedTick_) return;

    ChunkAssembly& assembly = chunks_[tick];
    if (assembly.chunkCount == 0) {
        assembly.chunkCount = chunkCount;
    } else if (assembly.chunkCount != chunkCount) {
        chunks_.erase(tick);
        return;
    }

    const u64 bit = 1ull << chunkIndex;
    if (assembly.mask & bit) return;

    for (u16 i = 0; i < count; ++i) {
        State state;
        state.netId = reader.U32();
        state.position.x = static_cast<f32>(reader.I16()) / kPositionScale;
        state.position.y = static_cast<f32>(reader.I16()) / kPositionScale;
        state.position.z = static_cast<f32>(reader.I16()) / kPositionScale;
        state.rotation.x = static_cast<f32>(reader.I16()) / kRotationScale;
        state.rotation.y = static_cast<f32>(reader.I16()) / kRotationScale;
        state.rotation.z = static_cast<f32>(reader.I16()) / kRotationScale;
        if (!reader.Ok()) {
            chunks_.erase(tick);
            return;
        }
        assembly.states.push_back(state);
    }

    assembly.mask |= bit;
    assembly.received++;

    if (assembly.received == chunkCount) {
        std::vector<State> states = std::move(assembly.states);
        chunks_.erase(tick);
        applySnapshot(tick, states);
    }

    // 丢弃过期 tick（乱序/长时间未集齐）
    if (chunks_.size() > 8) {
        chunks_.erase(chunks_.begin());
    }
}

void ReplicationClient::applySnapshot(u32 tick, const std::vector<State>& states) {
    if (tick <= lastAppliedTick_) return;
    lastAppliedTick_ = tick;

    for (const State& state : states) {
        if (destroyedIds_.count(state.netId) != 0) continue;   // 已销毁，拒绝复活
        auto it = entities_.find(state.netId);
        if (it == entities_.end()) {
            ensureEntity(state.netId, 0);
            it = entities_.find(state.netId);
            if (it == entities_.end()) continue;
        }

        RemoteEntity& remote = it->second;
        Scene::Transform* transform = world_.GetComponent<Scene::Transform>(remote.entity);
        if (!transform) continue;

        remote.lastSeen = time_;
        if (!remote.initialized) {
            transform->position = state.position;
            transform->rotation = state.rotation;
            remote.initialized = true;
            remote.hasTarget = false;
            continue;
        }

        remote.fromPos = transform->position;
        remote.fromRot = transform->rotation;
        remote.toPos = state.position;
        remote.toRot = state.rotation;
        remote.elapsed = 0.0f;
        remote.duration = std::max(config_.interpolationSeconds, 0.001f);
        remote.hasTarget = true;
    }
}

void ReplicationClient::OnUpdate(f32 dt) {
    if (dt < 0.0f) dt = 0.0f;
    time_ += dt;

    for (auto it = entities_.begin(); it != entities_.end();) {
        RemoteEntity& remote = it->second;
        if (!world_.IsAlive(remote.entity)) {
            it = entities_.erase(it);
            continue;
        }

        Scene::Transform* transform = world_.GetComponent<Scene::Transform>(remote.entity);
        if (!transform) {
            ++it;
            continue;
        }

        if (remote.hasTarget) {
            remote.elapsed += dt;
            const f32 t = std::clamp(remote.elapsed / remote.duration, 0.0f, 1.0f);
            const f32 smooth = t * t * (3.0f - 2.0f * t);
            transform->position.x = remote.fromPos.x + (remote.toPos.x - remote.fromPos.x) * smooth;
            transform->position.y = remote.fromPos.y + (remote.toPos.y - remote.fromPos.y) * smooth;
            transform->position.z = remote.fromPos.z + (remote.toPos.z - remote.fromPos.z) * smooth;
            transform->rotation.x = lerpAngle(remote.fromRot.x, remote.toRot.x, smooth);
            transform->rotation.y = lerpAngle(remote.fromRot.y, remote.toRot.y, smooth);
            transform->rotation.z = lerpAngle(remote.fromRot.z, remote.toRot.z, smooth);
            if (t >= 1.0f) remote.hasTarget = false;
        }

        if (remote.initialized &&
            time_ - remote.lastSeen > config_.staleDropSeconds) {
            const ECS::Entity entity = remote.entity;
            const u32 owner = remote.owner;
            if (world_.IsAlive(entity)) world_.DestroyEntity(entity);
            if (onDestroy_) onDestroy_(entity, owner);
            it = entities_.erase(it);
            continue;
        }
        ++it;
    }

    for (auto it = chunks_.begin(); it != chunks_.end();) {
        it->second.age += dt;
        if (it->second.age > 2.0f) it = chunks_.erase(it);
        else ++it;
    }
}

} // namespace M7N::Net
