/**
 * @file NetServer.cpp
 * @brief 会话层实现：地址表 + 握手 + 事件队列 + 超时清理。
 */
#include "M7N/Net/NetServer.hpp"
#include "M7N/Net/ByteStream.hpp"
#include "M7N/Core/Log.hpp"
#include "Connection.hpp"
#include "Protocol.hpp"

#include <algorithm>
#include <atomic>
#include <memory>
#include <unordered_map>
#include <utility>

namespace M7N::Net {

struct NetServer::Impl {
    struct Event {
        enum class Kind : u8 { Connected, Disconnected, Message } kind = Kind::Message;
        ClientId client = kInvalidClient;
        Channel channel = Channel::Reliable;
        DisconnectReason reason = DisconnectReason::None;
        std::vector<u8> data;
    };

    struct Peer {
        ClientId id = kInvalidClient;
        Address address;
        u32 clientNonce = 0;
        u32 serverNonce = 0;
        std::unique_ptr<Detail::Connection> connection;
        bool remove = false;
    };

    NetConfig config;
    Scope<ITransport> transport;
    bool running = false;
    std::unordered_map<u64, std::unique_ptr<Peer>> peers;
    std::vector<bool> usedIds;
    std::vector<Event> events;

    ConnectCallback onConnect;
    DisconnectCallback onDisconnect;
    MessageCallback onMessage;

    Detail::Connection* findById(ClientId id) {
        for (auto& [key, peer] : peers) {
            (void)key;
            if (!peer->remove && peer->id == id) return peer->connection.get();
        }
        return nullptr;
    }

    Peer* findByAddress(const Address& address) {
        auto it = peers.find(address.Key());
        return it == peers.end() ? nullptr : it->second.get();
    }

    ClientId allocateId() {
        for (u32 i = 1; i <= config.maxClients && i < usedIds.size(); ++i) {
            if (!usedIds[i]) {
                usedIds[i] = true;
                return static_cast<ClientId>(i);
            }
        }
        return kInvalidClient;
    }

    u32 countClients() const {
        u32 count = 0;
        for (const auto& [key, peer] : peers) {
            (void)key;
            if (!peer->remove) count++;
        }
        return count;
    }

    void sendAccept(Peer& peer, f64 now) {
        std::vector<u8> payload;
        ByteWriter writer(payload);
        writer.U16(peer.id);
        writer.U32(peer.clientNonce);
        writer.U32(peer.serverNonce);
        peer.connection->SendControl(Detail::PacketType::ConnectAccept,
                                     payload.data(),
                                     static_cast<u32>(payload.size()), now);
    }

    void reject(const Address& address, DisconnectReason reason, f64 now) {
        // 临时连接仅用于编码一包拒绝（不进入连接表）
        Detail::Connection temp(*transport, address, static_cast<u16>(config.protocolVersion));
        const u8 payload = static_cast<u8>(reason);
        temp.SendControl(Detail::PacketType::ConnectReject, &payload, 1, now);
    }

    void handleConnectRequest(const Address& from, const u8* payload, u32 size, f64 now) {
        ByteReader reader(payload, size);
        const u32 nonce = reader.U32();
        if (!reader.Ok()) return;

        if (Peer* existing = findByAddress(from)) {
            if (existing->clientNonce == nonce) {
                existing->connection->Touch(now);
                sendAccept(*existing, now);
                return;
            }
            // 同一端点重新握手：丢弃旧会话
            existing->remove = true;
            existing->connection->SetConnected(false, now);
            events.push_back({ Event::Kind::Disconnected, existing->id, Channel::Reliable,
                               DisconnectReason::ConnectionLost, {} });
            if (existing->id < usedIds.size()) usedIds[existing->id] = false;
            peers.erase(from.Key());
        }

        if (countClients() >= config.maxClients) {
            reject(from, DisconnectReason::ServerFull, now);
            return;
        }
        const ClientId id = allocateId();
        if (id == kInvalidClient) {
            reject(from, DisconnectReason::ServerFull, now);
            return;
        }

        static std::atomic<u32> nonceCounter{ 1 };
        auto peer = std::make_unique<Peer>();
        peer->id = id;
        peer->address = from;
        peer->clientNonce = nonce;
        peer->serverNonce = nonceCounter.fetch_add(1) * 2654435761u;

        peer->connection = std::make_unique<Detail::Connection>(
            *transport, from, static_cast<u16>(config.protocolVersion));
        peer->connection->SetConnected(true, now);

        const ClientId peerId = id;
        peer->connection->SetMessageHandler(
            [this, peerId](Channel channel, const u8* data, u32 dataSize) {
                Event event;
                event.kind = Event::Kind::Message;
                event.client = peerId;
                event.channel = channel;
                event.data.assign(data, data + dataSize);
                events.push_back(std::move(event));
            });
        peer->connection->SetDisconnectHandler(
            [this, peerId](DisconnectReason reason) {
                events.push_back({ Event::Kind::Disconnected, peerId, Channel::Reliable,
                                   reason, {} });
            });

        sendAccept(*peer, now);
        events.push_back({ Event::Kind::Connected, id, Channel::Reliable,
                           DisconnectReason::None, {} });
        peers.emplace(from.Key(), std::move(peer));

        M7N_LOG_INFO("Net", "client %u connected from %s", id, from.ToString().c_str());
    }

    void dispatchEvents() {
        if (events.empty()) return;
        std::vector<Event> local;
        local.swap(events);
        for (const Event& event : local) {
            switch (event.kind) {
                case Event::Kind::Connected:
                    if (onConnect) onConnect(event.client);
                    break;
                case Event::Kind::Disconnected:
                    if (onDisconnect) onDisconnect(event.client, event.reason);
                    break;
                case Event::Kind::Message:
                    if (onMessage) {
                        onMessage(event.client, event.channel,
                                  event.data.empty() ? nullptr : event.data.data(),
                                  static_cast<u32>(event.data.size()));
                    }
                    break;
            }
        }
    }

    void removeMarkedPeers() {
        for (auto it = peers.begin(); it != peers.end();) {
            Peer& peer = *it->second;
            if (peer.remove) {
                if (peer.id != kInvalidClient && peer.id < usedIds.size()) {
                    usedIds[peer.id] = false;
                }
                M7N_LOG_INFO("Net", "client %u removed", peer.id);
                it = peers.erase(it);
            } else {
                ++it;
            }
        }
    }
};

NetServer::NetServer() : impl_(CreateScope<Impl>()) {}
NetServer::~NetServer() { Stop(); }

bool NetServer::Start(const NetConfig& config, Scope<ITransport> transport) {
    Stop();
    impl_->config = config;
    if (impl_->config.maxClients == 0) impl_->config.maxClients = 1;
    if (impl_->config.protocolVersion == 0) {
        impl_->config.protocolVersion = kDefaultProtocolVersion;
    }

    if (transport) {
        impl_->transport = std::move(transport);
    } else {
        auto udp = CreateScope<UdpTransport>();
        impl_->transport = std::move(udp);
    }

    if (!impl_->transport->IsOpen()) {
        if (!impl_->transport->Open(config.port)) {
            M7N_LOG_ERROR("Net", "server failed to open port %u", config.port);
            impl_->transport.reset();
            return false;
        }
    }

    impl_->usedIds.assign(impl_->config.maxClients + 1, false);
    impl_->events.clear();
    impl_->peers.clear();
    impl_->running = true;

    M7N_LOG_INFO("Net", "server listening on port %u (max %u clients)",
                 impl_->transport->LocalPort(), impl_->config.maxClients);
    return true;
}

void NetServer::Stop() {
    if (!impl_ || !impl_->running) return;
    const f64 now = impl_->transport ? impl_->transport->NowSeconds() : 0.0;
    for (auto& [key, peer] : impl_->peers) {
        (void)key;
        if (peer->connection) {
            peer->connection->SendDisconnect(DisconnectReason::ServerShutdown, now);
        }
    }
    if (impl_->transport) impl_->transport->Close();
    impl_->peers.clear();
    impl_->events.clear();
    impl_->running = false;
}

bool NetServer::IsRunning() const { return impl_->running; }
u16 NetServer::Port() const {
    return (impl_->transport && impl_->running) ? impl_->transport->LocalPort() : 0;
}

void NetServer::Poll() {
    if (!impl_->running || !impl_->transport) return;
    f64 now = impl_->transport->NowSeconds();

    Address from;
    u8 buffer[2048];
    for (u32 i = 0; i < 512; ++i) {
        const int received = impl_->transport->Receive(from, buffer, sizeof(buffer));
        if (received <= 0) break;

        Detail::PacketHeader header;
        const u8* payload = nullptr;
        u32 payloadSize = 0;
        if (!Detail::ReadPacket(buffer, static_cast<u32>(received),
                                static_cast<u16>(impl_->config.protocolVersion),
                                header, payload, payloadSize)) {
            continue;
        }

        if (header.type == Detail::PacketType::ConnectRequest) {
            impl_->handleConnectRequest(from, payload, payloadSize, now);
            continue;
        }
        if (header.type == Detail::PacketType::ConnectAccept ||
            header.type == Detail::PacketType::ConnectReject) {
            continue;
        }

        Impl::Peer* peer = impl_->findByAddress(from);
        if (!peer || peer->remove) continue;
        peer->connection->Touch(now);
        peer->connection->HandlePacket(header, payload, payloadSize, now);
        if (!peer->connection->IsConnected()) {
            peer->remove = true;
        }
    }

    for (auto& [key, peer] : impl_->peers) {
        (void)key;
        if (peer->remove) continue;
        peer->connection->Flush(now);
        if (peer->connection->TimedOut(now, impl_->config.timeoutSeconds)) {
            impl_->events.push_back({ Impl::Event::Kind::Disconnected, peer->id,
                                      Channel::Reliable, DisconnectReason::Timeout, {} });
            peer->connection->SetConnected(false, now);
            peer->remove = true;
        }
    }

    impl_->dispatchEvents();
    impl_->removeMarkedPeers();
}

void NetServer::Broadcast(Channel channel, const void* data, u32 size) {
    if (!impl_->running || !impl_->transport) return;
    const f64 now = impl_->transport->NowSeconds();
    for (auto& [key, peer] : impl_->peers) {
        (void)key;
        if (peer->remove || !peer->connection->IsConnected()) continue;
        peer->connection->Send(channel, data, size, now);
    }
}

bool NetServer::SendTo(ClientId client, Channel channel, const void* data, u32 size) {
    if (!impl_->transport) return false;
    Detail::Connection* connection = impl_->findById(client);
    if (!connection || !connection->IsConnected()) return false;
    return connection->Send(channel, data, size, impl_->transport->NowSeconds());
}

void NetServer::DisconnectClient(ClientId client, DisconnectReason reason) {
    if (!impl_->transport) return;
    for (auto& [key, peer] : impl_->peers) {
        (void)key;
        if (peer->id != client || peer->remove) continue;
        peer->connection->SendDisconnect(reason, impl_->transport->NowSeconds());
        impl_->events.push_back({ Impl::Event::Kind::Disconnected, client,
                                  Channel::Reliable, reason, {} });
        peer->remove = true;
        return;
    }
}

void NetServer::SetCallbacks(ConnectCallback onConnect,
                             DisconnectCallback onDisconnect,
                             MessageCallback onMessage) {
    impl_->onConnect = std::move(onConnect);
    impl_->onDisconnect = std::move(onDisconnect);
    impl_->onMessage = std::move(onMessage);
}

u32 NetServer::ClientCount() const { return impl_->countClients(); }

std::vector<ClientId> NetServer::GetClients() const {
    std::vector<ClientId> clients;
    for (const auto& [key, peer] : impl_->peers) {
        (void)key;
        if (!peer->remove) clients.push_back(peer->id);
    }
    return clients;
}

NetStats NetServer::GetClientStats(ClientId client) const {
    for (const auto& [key, peer] : impl_->peers) {
        (void)key;
        if (peer->id == client) return peer->connection->Stats();
    }
    return NetStats{};
}

const NetConfig& NetServer::Config() const { return impl_->config; }
ITransport* NetServer::GetTransport() { return impl_->transport.get(); }

} // namespace M7N::Net
