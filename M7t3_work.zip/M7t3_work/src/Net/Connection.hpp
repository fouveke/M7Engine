/**
 * @file Connection.hpp
 * @brief 单对端连接：可靠有序流 + 不可靠最新优先 + 分片重组 + RTT/重传。
 *
 * 握手（ConnectRequest/Accept/Reject）由 NetServer/NetClient 处理；
 * 本类只负责已建立连接上的数据与保活。
 */
#pragma once

#include "M7N/Net/Transport.hpp"
#include "Protocol.hpp"

#include <functional>
#include <map>
#include <vector>

namespace M7N::Net::Detail {

class Connection {
public:
    using MessageHandler = std::function<void(Channel, const u8*, u32)>;
    using DisconnectHandler = std::function<void(DisconnectReason)>;

    Connection(ITransport& transport, const Address& remote, u16 protocolVersion);

    void SetMessageHandler(MessageHandler handler);
    void SetDisconnectHandler(DisconnectHandler handler);

    // --- 状态 ---
    void SetConnected(bool connected, f64 now);
    bool IsConnected() const { return connected_; }
    void Touch(f64 now) { lastReceiveTime_ = now; }
    f64 LastReceiveTime() const { return lastReceiveTime_; }
    bool TimedOut(f64 now, f32 timeoutSeconds) const {
        return connected_ && (now - lastReceiveTime_) > timeoutSeconds;
    }

    const Address& Remote() const { return remote_; }
    void SetRemote(const Address& address) { remote_ = address; }

    // --- 发送 / 接收 ---
    bool Send(Channel channel, const void* data, u32 size, f64 now);
    void SendControl(PacketType type, const void* payload, u32 size, f64 now);
    void SendDisconnect(DisconnectReason reason, f64 now);
    void HandlePacket(const PacketHeader& header, const u8* payload, u32 size, f64 now);
    void Flush(f64 now);

    NetStats Stats() const;

private:
    struct Pending {
        std::vector<u8> payload;
        u8 flags = 0;
        f64 firstSent = 0.0;
        f64 lastSent = 0.0;
    };

    struct HeldMessage {
        std::vector<u8> data;
        u8 flags = 0;
    };

    struct Assembly {
        std::vector<u8> data;
        std::vector<u8> got;
        u32 received = 0;
        f64 lastUpdate = 0.0;
    };

    bool sendPacket(PacketType type, u8 flags, u16 seq,
                    const void* payload, u32 size, f64 now);
    void queueReliable(const void* data, u32 size, u8 flags, f64 now);
    void queueFragment(const void* data, u32 size, f64 now);
    void handleReliable(u16 seq, u8 flags, const u8* payload, u32 size, f64 now);
    void handleUnreliable(u16 seq, const u8* payload, u32 size);
    void deliverReliable(const u8* payload, u32 size, u8 flags, f64 now);
    void markReceived(u16 seq);
    void applyAck(u16 ack, u32 ackBits, f64 now);
    void updateRtt(f32 sampleMs);
    f32 retransmitTimeoutMs() const;

    ITransport& transport_;
    Address remote_;
    u16 protocolVersion_;
    bool connected_ = false;

    u16 sendSeq_ = 0;
    std::map<u16, Pending> pending_;

    u16 recvExpected_ = 0;
    std::map<u16, HeldMessage> held_;
    bool hasAck_ = false;
    u16 ackHigh_ = 0;
    u32 ackBits_ = 0;

    u16 unreliableSendSeq_ = 0;
    u16 unreliableLastRecv_ = 0;
    bool hasUnreliableRecv_ = false;

    u16 nextMessageId_ = 1;
    std::map<u16, Assembly> assemblies_;

    f64 lastReceiveTime_ = 0.0;
    f64 lastSendTime_ = 0.0;
    f32 rttMs_ = 100.0f;
    f32 jitterMs_ = 0.0f;
    bool hasRttSample_ = false;

    u32 packetsSent_ = 0;
    u32 packetsReceived_ = 0;
    u32 bytesSent_ = 0;
    u32 bytesReceived_ = 0;
    u32 reliableSent_ = 0;
    u32 reliableAcked_ = 0;
    u32 retransmits_ = 0;

    MessageHandler onMessage_;
    DisconnectHandler onDisconnect_;
};

} // namespace M7N::Net::Detail
