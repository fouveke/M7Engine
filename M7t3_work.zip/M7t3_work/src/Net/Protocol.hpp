/**
 * @file Protocol.hpp
 * @brief 私有线协议：包头、分片头、包类型、序列号比较。
 *
 * 包头（16 字节，小端）：
 *   magic u16 | version u16 | type u8 | flags u8 |
 *   seq u16 | ack u16 | ackBits u32 | payloadSize u16
 *
 * 可靠消息：seq = 该消息的可靠序号；接收方按序交付。
 * 不可靠消息：seq = 不可靠序号；接收方只接受更新的序号（最新优先）。
 * 控制包（握手/Ping/Pong/断开）：seq 未使用。
 */
#pragma once

#include "M7N/Core/Types.hpp"

#include <cstring>

namespace M7N::Net::Detail {

constexpr u16 kMagic = 0x4D37u;
constexpr u32 kHeaderSize = 16;
constexpr u32 kMtu = 1200;
constexpr u32 kMaxPayload = 1100;                 ///< 普通包安全负载
constexpr u32 kMaxUnreliableMessage = 1100;
constexpr u32 kMaxReliableMessage = 256u * 1024u;
constexpr u32 kFragmentHeaderSize = 10;           ///< messageId, index, count, totalSize
constexpr u32 kMaxFragmentData = kMaxPayload - kFragmentHeaderSize;
constexpr u32 kMaxAckWindow = 32;

enum class PacketType : u8 {
    ConnectRequest = 1,
    ConnectAccept = 2,
    ConnectReject = 3,
    Disconnect = 4,
    Ping = 5,
    Pong = 6,
    Reliable = 7,
    Unreliable = 8,
};

constexpr u8 kFlagFragmented = 0x01;

struct PacketHeader {
    PacketType type = PacketType::Reliable;
    u8 flags = 0;
    u16 seq = 0;
    u16 ack = 0;
    u32 ackBits = 0;
    u16 payloadSize = 0;
};

struct FragmentHeader {
    u16 messageId = 0;
    u16 index = 0;
    u16 count = 0;
    u32 totalSize = 0;
};

/// u16 序列号回绕比较：a 是否比 b 新。
inline bool IsSequenceNewer(u16 a, u16 b) {
    return static_cast<i16>(static_cast<u16>(a - b)) > 0;
}

inline u32 WritePacket(u8* buffer, u32 capacity, const PacketHeader& header,
                       u16 version, const void* payload) {
    const u32 total = kHeaderSize + header.payloadSize;
    if (!buffer || capacity < total) return 0;

    buffer[0] = static_cast<u8>(kMagic & 0xFF);
    buffer[1] = static_cast<u8>((kMagic >> 8) & 0xFF);
    buffer[2] = static_cast<u8>(version & 0xFF);
    buffer[3] = static_cast<u8>((version >> 8) & 0xFF);
    buffer[4] = static_cast<u8>(header.type);
    buffer[5] = header.flags;
    buffer[6] = static_cast<u8>(header.seq & 0xFF);
    buffer[7] = static_cast<u8>((header.seq >> 8) & 0xFF);
    buffer[8] = static_cast<u8>(header.ack & 0xFF);
    buffer[9] = static_cast<u8>((header.ack >> 8) & 0xFF);
    buffer[10] = static_cast<u8>(header.ackBits & 0xFF);
    buffer[11] = static_cast<u8>((header.ackBits >> 8) & 0xFF);
    buffer[12] = static_cast<u8>((header.ackBits >> 16) & 0xFF);
    buffer[13] = static_cast<u8>((header.ackBits >> 24) & 0xFF);
    buffer[14] = static_cast<u8>(header.payloadSize & 0xFF);
    buffer[15] = static_cast<u8>((header.payloadSize >> 8) & 0xFF);

    if (header.payloadSize > 0 && payload) {
        std::memcpy(buffer + kHeaderSize, payload, header.payloadSize);
    }
    return total;
}

inline bool ReadPacket(const u8* data, u32 size, u16 expectedVersion,
                       PacketHeader& header, const u8*& payload, u32& payloadSize) {
    if (!data || size < kHeaderSize) return false;
    const u16 magic = static_cast<u16>(data[0]) | static_cast<u16>(data[1]) << 8;
    if (magic != kMagic) return false;
    const u16 version = static_cast<u16>(data[2]) | static_cast<u16>(data[3]) << 8;
    if (version != expectedVersion) return false;

    header.type = static_cast<PacketType>(data[4]);
    header.flags = data[5];
    header.seq = static_cast<u16>(data[6]) | static_cast<u16>(data[7]) << 8;
    header.ack = static_cast<u16>(data[8]) | static_cast<u16>(data[9]) << 8;
    header.ackBits = static_cast<u32>(data[10]) |
                     static_cast<u32>(data[11]) << 8 |
                     static_cast<u32>(data[12]) << 16 |
                     static_cast<u32>(data[13]) << 24;
    header.payloadSize = static_cast<u16>(data[14]) | static_cast<u16>(data[15]) << 8;

    if (header.payloadSize > size - kHeaderSize) return false;
    payload = data + kHeaderSize;
    payloadSize = header.payloadSize;
    return true;
}

inline void WriteFragmentHeader(u8* out, const FragmentHeader& header) {
    out[0] = static_cast<u8>(header.messageId & 0xFF);
    out[1] = static_cast<u8>((header.messageId >> 8) & 0xFF);
    out[2] = static_cast<u8>(header.index & 0xFF);
    out[3] = static_cast<u8>((header.index >> 8) & 0xFF);
    out[4] = static_cast<u8>(header.count & 0xFF);
    out[5] = static_cast<u8>((header.count >> 8) & 0xFF);
    out[6] = static_cast<u8>(header.totalSize & 0xFF);
    out[7] = static_cast<u8>((header.totalSize >> 8) & 0xFF);
    out[8] = static_cast<u8>((header.totalSize >> 16) & 0xFF);
    out[9] = static_cast<u8>((header.totalSize >> 24) & 0xFF);
}

inline bool ReadFragmentHeader(const u8* data, u32 size, FragmentHeader& header) {
    if (!data || size < kFragmentHeaderSize) return false;
    header.messageId = static_cast<u16>(data[0]) | static_cast<u16>(data[1]) << 8;
    header.index = static_cast<u16>(data[2]) | static_cast<u16>(data[3]) << 8;
    header.count = static_cast<u16>(data[4]) | static_cast<u16>(data[5]) << 8;
    header.totalSize = static_cast<u32>(data[6]) |
                       static_cast<u32>(data[7]) << 8 |
                       static_cast<u32>(data[8]) << 16 |
                       static_cast<u32>(data[9]) << 24;
    return header.count > 0 && header.index < header.count &&
           header.totalSize > 0 && header.totalSize <= kMaxReliableMessage;
}

} // namespace M7N::Net::Detail
