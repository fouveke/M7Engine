/**
 * @file Connection.cpp
 * @brief 可靠层实现：ACK 位图、重传、分片重组、保活与统计。
 */
#include "Connection.hpp"
#include "M7N/Core/Log.hpp"

#include <algorithm>
#include <cstring>

namespace M7N::Net::Detail {

namespace {
constexpr size_t kMaxPending = 4096;
constexpr size_t kMaxHeldMessages = 512;
constexpr size_t kMaxAssemblies = 16;
} // namespace

Connection::Connection(ITransport& transport, const Address& remote, u16 protocolVersion)
    : transport_(transport), remote_(remote), protocolVersion_(protocolVersion) {
    lastReceiveTime_ = transport_.NowSeconds();
    lastSendTime_ = lastReceiveTime_;
}

void Connection::SetMessageHandler(MessageHandler handler) {
    onMessage_ = std::move(handler);
}

void Connection::SetDisconnectHandler(DisconnectHandler handler) {
    onDisconnect_ = std::move(handler);
}

void Connection::SetConnected(bool connected, f64 now) {
    connected_ = connected;
    lastReceiveTime_ = now;
    lastSendTime_ = now;
}

// ---------------------------------------------------------------------
// 发送
// ---------------------------------------------------------------------

bool Connection::sendPacket(PacketType type, u8 flags, u16 seq,
                            const void* payload, u32 size, f64 now) {
    if (size > kMaxPayload) return false;

    u8 buffer[kMtu];
    PacketHeader header;
    header.type = type;
    header.flags = flags;
    header.seq = seq;
    header.ack = ackHigh_;
    header.ackBits = ackBits_;
    header.payloadSize = static_cast<u16>(size);

    const u32 total = WritePacket(buffer, sizeof(buffer), header, protocolVersion_, payload);
    if (total == 0) return false;

    const bool sent = transport_.Send(remote_, buffer, total);
    packetsSent_++;
    bytesSent_ += total;
    lastSendTime_ = now;
    return sent;
}

void Connection::queueFragment(const void* data, u32 size, f64 now) {
    const u32 count = (size + kMaxFragmentData - 1) / kMaxFragmentData;
    u16 messageId = nextMessageId_++;
    if (messageId == 0) messageId = nextMessageId_++;

    const u8* bytes = static_cast<const u8*>(data);
    for (u32 i = 0; i < count; ++i) {
        const u32 offset = i * kMaxFragmentData;
        const u32 chunk = std::min(kMaxFragmentData, size - offset);
        std::vector<u8> payload(kFragmentHeaderSize + chunk);

        FragmentHeader fh;
        fh.messageId = messageId;
        fh.index = static_cast<u16>(i);
        fh.count = static_cast<u16>(count);
        fh.totalSize = size;
        WriteFragmentHeader(payload.data(), fh);
        std::memcpy(payload.data() + kFragmentHeaderSize, bytes + offset, chunk);

        const u16 seq = sendSeq_++;
        Pending pending;
        pending.payload = std::move(payload);
        pending.flags = kFlagFragmented;
        pending.firstSent = now;
        pending.lastSent = now;
        pending_[seq] = std::move(pending);
        reliableSent_++;
        sendPacket(PacketType::Reliable, kFlagFragmented, seq,
                   pending_[seq].payload.data(),
                   static_cast<u32>(pending_[seq].payload.size()), now);
    }
}

bool Connection::Send(Channel channel, const void* data, u32 size, f64 now) {
    if (!connected_ || !data || size == 0) return false;

    if (channel == Channel::Reliable) {
        if (size > kMaxReliableMessage || pending_.size() >= kMaxPending) return false;
        if (size <= kMaxPayload) {
            const u16 seq = sendSeq_++;
            Pending pending;
            pending.payload.assign(static_cast<const u8*>(data),
                                   static_cast<const u8*>(data) + size);
            pending.firstSent = now;
            pending.lastSent = now;
            pending_[seq] = std::move(pending);
            reliableSent_++;
            return sendPacket(PacketType::Reliable, 0, seq, data, size, now);
        }
        queueFragment(data, size, now);
        return true;
    }

    if (size > kMaxUnreliableMessage) return false;
    const u16 seq = unreliableSendSeq_++;
    return sendPacket(PacketType::Unreliable, 0, seq, data, size, now);
}

void Connection::SendControl(PacketType type, const void* payload, u32 size, f64 now) {
    sendPacket(type, 0, 0, payload, size, now);
}

void Connection::SendDisconnect(DisconnectReason reason, f64 now) {
    const u8 payload = static_cast<u8>(reason);
    sendPacket(PacketType::Disconnect, 0, 0, &payload, 1, now);
    connected_ = false;
}

// ---------------------------------------------------------------------
// ACK / RTT
// ---------------------------------------------------------------------

void Connection::markReceived(u16 seq) {
    if (!hasAck_) {
        hasAck_ = true;
        ackHigh_ = seq;
        ackBits_ = 1;
        return;
    }

    if (seq == ackHigh_) {
        ackBits_ |= 1u;
        return;
    }

    if (IsSequenceNewer(seq, ackHigh_)) {
        const u16 shift = static_cast<u16>(seq - ackHigh_);
        ackBits_ = (shift >= kMaxAckWindow) ? 1u : ((ackBits_ << shift) | 1u);
        ackHigh_ = seq;
        return;
    }

    const u16 diff = static_cast<u16>(ackHigh_ - seq);
    if (diff >= 1 && diff <= kMaxAckWindow) {
        ackBits_ |= (1u << (diff - 1));
    }
}

void Connection::applyAck(u16 ack, u32 ackBits, f64 now) {
    if (ackBits == 0 || pending_.empty()) return;

    for (auto it = pending_.begin(); it != pending_.end();) {
        const u16 seq = it->first;
        bool acked = (seq == ack);

        if (!acked) {
            const u16 diff = static_cast<u16>(ack - seq);
            if (diff >= 1 && diff <= kMaxAckWindow) {
                acked = (ackBits & (1u << (diff - 1))) != 0;
            }
        }

        if (acked) {
            const f32 sample = static_cast<f32>((now - it->second.lastSent) * 1000.0);
            updateRtt(sample);
            reliableAcked_++;
            it = pending_.erase(it);
        } else {
            ++it;
        }
    }
}

void Connection::updateRtt(f32 sampleMs) {
    if (sampleMs < 0.0f || sampleMs > 10000.0f) return;
    if (!hasRttSample_) {
        rttMs_ = sampleMs;
        jitterMs_ = 0.0f;
        hasRttSample_ = true;
        return;
    }
    jitterMs_ = jitterMs_ * 0.9f + std::abs(sampleMs - rttMs_) * 0.1f;
    rttMs_ = rttMs_ * 0.8f + sampleMs * 0.2f;
}

f32 Connection::retransmitTimeoutMs() const {
    const f32 rto = rttMs_ * 1.5f + 30.0f;
    return std::clamp(rto, 70.0f, 500.0f);
}

// ---------------------------------------------------------------------
// 接收
// ---------------------------------------------------------------------

void Connection::HandlePacket(const PacketHeader& header, const u8* payload,
                              u32 size, f64 now) {
    lastReceiveTime_ = now;
    packetsReceived_++;
    bytesReceived_ += kHeaderSize + size;

    applyAck(header.ack, header.ackBits, now);

    switch (header.type) {
        case PacketType::Reliable:
            handleReliable(header.seq, header.flags, payload, size, now);
            break;

        case PacketType::Unreliable:
            handleUnreliable(header.seq, payload, size);
            break;

        case PacketType::Ping: {
            u8 echo[4] = {};
            if (size <= sizeof(echo)) {
                if (size > 0) std::memcpy(echo, payload, size);
                SendControl(PacketType::Pong, echo, static_cast<u32>(size), now);
            }
            break;
        }

        case PacketType::Pong: {
            if (size >= 4) {
                u32 sentMs = 0;
                std::memcpy(&sentMs, payload, sizeof(sentMs));
                const f32 sample = static_cast<f32>(now * 1000.0 - static_cast<f64>(sentMs));
                if (sample >= 0.0f && sample < 5000.0f) updateRtt(sample);
            }
            break;
        }

        case PacketType::Disconnect: {
            const DisconnectReason reason = (size >= 1)
                ? static_cast<DisconnectReason>(payload[0])
                : DisconnectReason::ConnectionLost;
            connected_ = false;
            if (onDisconnect_) onDisconnect_(reason);
            break;
        }

        default:
            break;
    }
}

void Connection::handleReliable(u16 seq, u8 flags, const u8* payload,
                                u32 size, f64 now) {
    if (size > kMaxPayload) return;

    markReceived(seq);

    if (seq == recvExpected_) {
        deliverReliable(payload, size, flags, now);
        recvExpected_++;

        for (;;) {
            auto it = held_.find(recvExpected_);
            if (it == held_.end()) break;
            // 拷贝出来：回调可能触发重组/删表
            const std::vector<u8> data = std::move(it->second.data);
            const u8 heldFlags = it->second.flags;
            held_.erase(it);
            deliverReliable(data.data(), static_cast<u32>(data.size()), heldFlags, now);
            recvExpected_++;
        }
        return;
    }

    if (IsSequenceNewer(seq, recvExpected_)) {
        if (held_.size() < kMaxHeldMessages && held_.find(seq) == held_.end()) {
            HeldMessage held;
            held.flags = flags;
            held.data.assign(payload, payload + size);
            held_[seq] = std::move(held);
        }
    }
    // 更旧的序号 = 重复包（ACK 已在 markReceived 中更新）
}

void Connection::deliverReliable(const u8* payload, u32 size, u8 flags, f64 now) {
    if (!(flags & kFlagFragmented)) {
        if (onMessage_) onMessage_(Channel::Reliable, payload, size);
        return;
    }

    FragmentHeader fh;
    if (!ReadFragmentHeader(payload, size, fh)) {
        M7N_LOG_WARN("Net", "malformed fragment");
        return;
    }

    auto it = assemblies_.find(fh.messageId);
    if (it == assemblies_.end()) {
        if (assemblies_.size() >= kMaxAssemblies) {
            assemblies_.erase(assemblies_.begin());
        }
        Assembly assembly;
        assembly.data.resize(fh.totalSize);
        assembly.got.assign(fh.count, 0);
        assembly.lastUpdate = now;
        it = assemblies_.emplace(fh.messageId, std::move(assembly)).first;
    }

    Assembly& assembly = it->second;
    if (fh.count != assembly.got.size() || fh.totalSize != assembly.data.size()) {
        assemblies_.erase(it);
        return;
    }
    if (assembly.got[fh.index]) return;   // 重复分片

    const u32 chunkSize = size - kFragmentHeaderSize;
    const u32 offset = static_cast<u32>(fh.index) * kMaxFragmentData;
    const u32 expected = std::min(kMaxFragmentData, fh.totalSize - offset);
    if (offset >= fh.totalSize || chunkSize != expected) {
        assemblies_.erase(it);
        return;
    }

    std::memcpy(assembly.data.data() + offset, payload + kFragmentHeaderSize, chunkSize);
    assembly.got[fh.index] = 1;
    assembly.received++;
    assembly.lastUpdate = now;

    if (assembly.received == fh.count) {
        std::vector<u8> completed = std::move(assembly.data);
        assemblies_.erase(it);
        if (onMessage_) {
            onMessage_(Channel::Reliable, completed.data(),
                       static_cast<u32>(completed.size()));
        }
    }
}

void Connection::handleUnreliable(u16 seq, const u8* payload, u32 size) {
    if (hasUnreliableRecv_ && !IsSequenceNewer(seq, unreliableLastRecv_)) return;
    hasUnreliableRecv_ = true;
    unreliableLastRecv_ = seq;
    if (onMessage_) onMessage_(Channel::Unreliable, payload, size);
}

void Connection::Flush(f64 now) {
    if (!connected_) return;

    const f32 rtoMs = retransmitTimeoutMs();
    for (auto& [seq, pending] : pending_) {
        const f32 elapsed = static_cast<f32>((now - pending.lastSent) * 1000.0);
        if (elapsed >= rtoMs) {
            pending.lastSent = now;
            retransmits_++;
            sendPacket(PacketType::Reliable, pending.flags, seq,
                       pending.payload.data(),
                       static_cast<u32>(pending.payload.size()), now);
        }
    }

    // 保活：空闲 0.5s 发 Ping（附带 ack 信息）
    if (now - lastSendTime_ > 0.5) {
        u32 sentMs = static_cast<u32>(now * 1000.0);
        SendControl(PacketType::Ping, &sentMs, sizeof(sentMs), now);
    }

    // 清理超时未完成的分片
    for (auto it = assemblies_.begin(); it != assemblies_.end();) {
        if (now - it->second.lastUpdate > 10.0) it = assemblies_.erase(it);
        else ++it;
    }
}

NetStats Connection::Stats() const {
    NetStats stats;
    stats.rttMs = rttMs_;
    stats.jitterMs = jitterMs_;
    stats.packetsSent = packetsSent_;
    stats.packetsReceived = packetsReceived_;
    stats.bytesSent = bytesSent_;
    stats.bytesReceived = bytesReceived_;
    stats.retransmits = retransmits_;
    stats.reliableInFlight = static_cast<u32>(pending_.size());

    const u32 totalSent = reliableSent_ + retransmits_;
    if (totalSent > 0) {
        const f32 loss = static_cast<f32>(totalSent - reliableAcked_) /
                         static_cast<f32>(totalSent);
        stats.packetLoss = std::clamp(loss, 0.0f, 1.0f);
    }
    return stats;
}

} // namespace M7N::Net::Detail
