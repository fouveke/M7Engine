/**
 * @file NetClient.cpp
 * @brief 客户端会话：握手重试 + 连接状态机 + 数据收发。
 */
#include "M7N/Net/NetClient.hpp"
#include "M7N/Net/ByteStream.hpp"
#include "M7N/Core/Log.hpp"
#include "Connection.hpp"
#include "Protocol.hpp"

#include <atomic>
#include <chrono>
#include <memory>
#include <utility>

namespace M7N::Net {

struct NetClient::Impl {
    NetConfig config;
    Scope<ITransport> transport;
    std::unique_ptr<Detail::Connection> connection;
    Address server;
    ConnectionState state = ConnectionState::Disconnected;
    ClientId clientId = kInvalidClient;
    u32 nonce = 0;
    f64 connectStart = 0.0;
    f64 lastRequest = -1000.0;

    ConnectCallback onConnect;
    DisconnectCallback onDisconnect;
    MessageCallback onMessage;

    static u32 makeNonce() {
        static std::atomic<u32> counter{ 1 };
        const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                            std::chrono::steady_clock::now().time_since_epoch()).count();
        u32 value = static_cast<u32>(ms) ^ (counter.fetch_add(1) * 2654435761u);
        if (value == 0) value = 1;
        return value;
    }

    void sendConnectRequest(f64 now) {
        if (!connection) return;
        std::vector<u8> payload;
        ByteWriter writer(payload);
        writer.U32(nonce);
        connection->SendControl(Detail::PacketType::ConnectRequest,
                                payload.data(),
                                static_cast<u32>(payload.size()), now);
    }

    void setupConnection() {
        connection->SetMessageHandler(
            [this](Channel channel, const u8* data, u32 size) {
                if (onMessage) onMessage(channel, data, size);
            });
        connection->SetDisconnectHandler([this](DisconnectReason reason) {
            if (state == ConnectionState::Disconnected ||
                state == ConnectionState::TimedOut) {
                return;
            }
            state = ConnectionState::Disconnected;
            if (transport) transport->Close();
            if (onDisconnect) onDisconnect(reason);
        });
    }

    void fail(DisconnectReason reason) {
        state = ConnectionState::TimedOut;
        if (transport) transport->Close();
        if (onDisconnect) onDisconnect(reason);
    }
};

NetClient::NetClient() : impl_(CreateScope<Impl>()) {}
NetClient::~NetClient() {
    if (impl_ && impl_->state == ConnectionState::Connected && impl_->connection) {
        impl_->connection->SendDisconnect(DisconnectReason::ClientQuit,
                                          impl_->transport ? impl_->transport->NowSeconds() : 0.0);
    }
    if (impl_ && impl_->transport) impl_->transport->Close();
}

bool NetClient::Connect(const String& hostPort, const NetConfig& config) {
    Address address;
    if (!ResolveAddress(hostPort, address)) {
        M7N_LOG_ERROR("Net", "cannot resolve %s", hostPort.c_str());
        return false;
    }
    auto udp = CreateScope<UdpTransport>();
    if (!udp->Open(0)) {
        M7N_LOG_ERROR("Net", "client failed to open local port");
        return false;
    }
    return ConnectWithTransport(address, config, std::move(udp));
}

bool NetClient::ConnectWithTransport(const Address& server, const NetConfig& config,
                                     Scope<ITransport> transport) {
    // 清理旧会话（不触发用户回调）
    if (impl_->transport) impl_->transport->Close();
    impl_->connection.reset();
    impl_->state = ConnectionState::Disconnected;
    impl_->clientId = kInvalidClient;
    impl_->transport.reset();

    if (!server.IsValid() || !transport) return false;
    impl_->config = config;
    if (impl_->config.protocolVersion == 0) {
        impl_->config.protocolVersion = kDefaultProtocolVersion;
    }
    if (impl_->config.timeoutSeconds <= 0.0f) impl_->config.timeoutSeconds = 8.0f;
    if (impl_->config.handshakeIntervalSeconds <= 0.0f) {
        impl_->config.handshakeIntervalSeconds = 0.25f;
    }

    if (!transport->IsOpen()) {
        if (!transport->Open(0)) return false;
    }

    impl_->transport = std::move(transport);
    impl_->server = server;
    impl_->connection = std::make_unique<Detail::Connection>(
        *impl_->transport, server,
        static_cast<u16>(impl_->config.protocolVersion));
    impl_->setupConnection();

    impl_->state = ConnectionState::Connecting;
    impl_->nonce = Impl::makeNonce();
    impl_->connectStart = impl_->transport->NowSeconds();
    impl_->lastRequest = -1000.0;
    impl_->sendConnectRequest(impl_->connectStart);
    impl_->lastRequest = impl_->connectStart;

    M7N_LOG_INFO("Net", "connecting to %s ...", server.ToString().c_str());
    return true;
}

void NetClient::Disconnect(DisconnectReason reason) {
    if (!impl_) return;
    if (impl_->state == ConnectionState::Connected && impl_->connection) {
        impl_->connection->SendDisconnect(reason,
            impl_->transport ? impl_->transport->NowSeconds() : 0.0);
    }
    if (impl_->transport) impl_->transport->Close();
    impl_->state = ConnectionState::Disconnected;
    impl_->clientId = kInvalidClient;
}

bool NetClient::Send(Channel channel, const void* data, u32 size) {
    if (!impl_ || impl_->state != ConnectionState::Connected ||
        !impl_->connection || !impl_->transport) {
        return false;
    }
    return impl_->connection->Send(channel, data, size,
                                   impl_->transport->NowSeconds());
}

void NetClient::Poll() {
    if (!impl_ || !impl_->transport || !impl_->connection) return;
    if (impl_->state == ConnectionState::Disconnected ||
        impl_->state == ConnectionState::TimedOut) {
        return;
    }

    f64 now = impl_->transport->NowSeconds();

    Address from;
    u8 buffer[2048];
    for (u32 i = 0; i < 512; ++i) {
        const int received = impl_->transport->Receive(from, buffer, sizeof(buffer));
        if (received <= 0) break;
        if (!(from == impl_->server)) continue;

        Detail::PacketHeader header;
        const u8* payload = nullptr;
        u32 payloadSize = 0;
        if (!Detail::ReadPacket(buffer, static_cast<u32>(received),
                                static_cast<u16>(impl_->config.protocolVersion),
                                header, payload, payloadSize)) {
            continue;
        }
        now = impl_->transport->NowSeconds();

        if (impl_->state == ConnectionState::Connecting) {
            if (header.type == Detail::PacketType::ConnectAccept) {
                ByteReader reader(payload, payloadSize);
                const ClientId assigned = reader.U16();
                const u32 echoedNonce = reader.U32();
                reader.U32();   // serverNonce（预留）
                if (!reader.Ok() || echoedNonce != impl_->nonce) continue;

                impl_->clientId = assigned;
                impl_->state = ConnectionState::Connected;
                impl_->connection->SetConnected(true, now);
                M7N_LOG_INFO("Net", "connected as client %u", assigned);
                if (impl_->onConnect) impl_->onConnect();
            } else if (header.type == Detail::PacketType::ConnectReject) {
                const DisconnectReason reason = (payloadSize >= 1)
                    ? static_cast<DisconnectReason>(payload[0])
                    : DisconnectReason::ProtocolError;
                impl_->state = ConnectionState::Disconnected;
                impl_->transport->Close();
                if (impl_->onDisconnect) impl_->onDisconnect(reason);
                return;
            } else if (header.type == Detail::PacketType::Disconnect) {
                const DisconnectReason reason = (payloadSize >= 1)
                    ? static_cast<DisconnectReason>(payload[0])
                    : DisconnectReason::ConnectionLost;
                impl_->state = ConnectionState::Disconnected;
                impl_->transport->Close();
                if (impl_->onDisconnect) impl_->onDisconnect(reason);
                return;
            } else {
                impl_->connection->Touch(now);
            }
            continue;
        }

        // Connected
        impl_->connection->HandlePacket(header, payload, payloadSize, now);
        if (impl_->state != ConnectionState::Connected) return;
    }

    if (impl_->state == ConnectionState::Connecting) {
        if (now - impl_->connectStart > impl_->config.timeoutSeconds) {
            M7N_LOG_WARN("Net", "connect timeout");
            impl_->fail(DisconnectReason::Timeout);
            return;
        }
        if (now - impl_->lastRequest >= impl_->config.handshakeIntervalSeconds) {
            impl_->sendConnectRequest(now);
            impl_->lastRequest = now;
        }
        return;
    }

    if (impl_->state == ConnectionState::Connected) {
        impl_->connection->Flush(now);
        if (impl_->connection->TimedOut(now, impl_->config.timeoutSeconds)) {
            M7N_LOG_WARN("Net", "connection timed out");
            impl_->fail(DisconnectReason::Timeout);
        }
    }
}

bool NetClient::IsConnected() const {
    return impl_ && impl_->state == ConnectionState::Connected;
}
ConnectionState NetClient::GetState() const { return impl_ ? impl_->state : ConnectionState::Disconnected; }
ClientId NetClient::GetClientId() const { return impl_ ? impl_->clientId : kInvalidClient; }
Address NetClient::GetServerAddress() const { return impl_ ? impl_->server : Address{}; }
u16 NetClient::GetLocalPort() const {
    return (impl_ && impl_->transport) ? impl_->transport->LocalPort() : 0;
}
NetStats NetClient::GetStats() const {
    return (impl_ && impl_->connection) ? impl_->connection->Stats() : NetStats{};
}

void NetClient::SetCallbacks(ConnectCallback onConnect,
                             DisconnectCallback onDisconnect,
                             MessageCallback onMessage) {
    impl_->onConnect = std::move(onConnect);
    impl_->onDisconnect = std::move(onDisconnect);
    impl_->onMessage = std::move(onMessage);
}

} // namespace M7N::Net
