/**
 * @file AudioSystem.cpp
 * @brief 音频系统实现（miniaudio 后端）。
 *
 * 自 M7T1 AudioEngine.cpp 平移：
 *  - 设备 I/O 经 miniaudio（Windows/WASAPI、macOS/CoreAudio、Linux/ALSA...）
 *  - 解码经 miniaudio 内置解码器：WAV / MP3 / FLAC / OGG
 *  - 3D 空间化：距离衰减、监听者朝向导出的等功率立体声像、多普勒变调
 *  - 麦克风采集进环形缓冲 + RMS 电平表
 *
 * 迁移要点：
 *  - 原 static 全局状态（设备、源列表、监听者、锁）全部变为
 *    AudioSystem 成员；miniaudio 对象藏于私有 Impl。
 *  - 设备回调为无状态自由函数，经 ma_device_config::pUserData
 *    指回实例，调用成员函数 mixAudio / handleCapture。
 *  - 新增 ECS 集成：OnUpdate 遍历 AudioSourceComp / AudioListenerComp。
 *
 * M7T1 已知问题修正（其余逻辑逐行平移，公式未动）：
 *  1. buffers_ 由 vector 改 deque：M7T1 播放中的源持有 AudioBuffer*，
 *     后续 LoadSound 触发 vector 扩容会使指针悬空（音频回调线程
 *     use-after-free 风险）；deque 元素地址稳定。
 *  2. 解码移出锁外：M7T1 在 mutex_ 内做磁盘 IO + 整文件解码，
 *     长时间持锁会阻塞音频回调线程（可闻卡顿）；现改为锁外解码 +
 *     锁内双检插入。
 */
#include "M7N/Audio/AudioSystem.hpp"
#include "M7N/Scene/Components.hpp"   // Transform（监听者朝向 / 3D 源位置）

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <utility>

#define STB_VORBIS_HEADER_ONLY
#include "stb_vorbis.c"     // 只取声明；实现单独编译（third_party/stb/stb_vorbis.c）

#define MINIAUDIO_IMPLEMENTATION
#include "miniaudio.h"

#if defined(_WIN32)
// miniaudio 的 WASAPI 后端需要 ole32（COM）；其他平台无害。
#pragma comment(lib, "ole32.lib")
#endif

namespace M7N::Audio {

namespace {

// 引擎混音格式（所有文件解码为此格式，混音器只处理一种布局；
// miniaudio 内部再转换到物理设备的实际格式）。
constexpr u32 kOutputSampleRate = 44100;
constexpr u16 kOutputChannels = 2;

constexpr f32 kSpeedOfSound = 343.0f;   // 米/秒，多普勒
constexpr f32 kHalfPi = 1.57079632679f; // PI/2，等功率声像

/// 点积（自包含，避免依赖具体数学库的函数集）。
f32 vecDot(const Vec3& a, const Vec3& b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

/// 叉积。
Vec3 vecCross(const Vec3& a, const Vec3& b) {
    return Vec3(a.y * b.z - a.z * b.y,
                a.z * b.x - a.x * b.z,
                a.x * b.y - a.y * b.x);
}

/// 向量长度。
f32 vecLength(const Vec3& v) {
    return std::sqrt(vecDot(v, v));
}

/// 取路径中的文件名（兼容 / 与 \，替代 M7T1 的 FileSystem::GetFileName）。
String getFileName(const String& filepath) {
    const size_t pos = filepath.find_last_of("/\\");
    return (pos == String::npos) ? filepath : filepath.substr(pos + 1);
}

} // namespace

// =====================================================================
// 私有实现（miniaudio 对象只在此处出现）
// =====================================================================

struct AudioSystem::Impl {
    // --- 播放设备 ---
    ma_device playbackDevice{};
    bool      playbackDeviceValid = false;

    // --- 采集设备 ---
    ma_device captureDevice{};
    bool      captureDeviceValid = false;
    std::mutex captureMutex;   // 保护采集设备的启停

    // --- 采集环形缓冲：最近 2 秒单声道 s16 采样 ---
    static constexpr u32 kCaptureRingFrames = kOutputSampleRate * 2;
    i16 captureRing[kCaptureRingFrames] = {};
    std::atomic<u32> captureWritePos{0}; ///< 累计已写入帧数（回绕取模）
    std::atomic<f32> captureLevel{0.0f}; ///< 最新 RMS 电平（0..1）
};

namespace {

/// 播放设备回调：经 pUserData 指回 AudioSystem 实例（无任何静态状态）。
void playbackCallback(ma_device* pDevice, void* pOutput,
                      const void* pInput, ma_uint32 frameCount) {
    (void)pInput;
    auto* self = static_cast<AudioSystem*>(pDevice->pUserData);
    if (self) {
        self->mixAudio(static_cast<i16*>(pOutput),
                       static_cast<u32>(frameCount));
    }
}

/// 采集设备回调：经 pUserData 指回 AudioSystem 实例（无任何静态状态）。
void captureCallback(ma_device* pDevice, void* pOutput,
                     const void* pInput, ma_uint32 frameCount) {
    (void)pOutput;
    auto* self = static_cast<AudioSystem*>(pDevice->pUserData);
    if (self) {
        self->handleCapture(static_cast<const i16*>(pInput),
                            static_cast<u32>(frameCount));
    }
}

} // namespace

// =====================================================================
// 生命周期
// =====================================================================

AudioSystem::AudioSystem() : impl_(std::make_unique<Impl>()) {}

AudioSystem::~AudioSystem() {
    Shutdown();
}

bool AudioSystem::Init() {
    if (initialized_) return true;

    ma_device_config cfg = ma_device_config_init(ma_device_type_playback);
    cfg.playback.format   = ma_format_s16;
    cfg.playback.channels = kOutputChannels;
    cfg.sampleRate        = kOutputSampleRate;
    cfg.dataCallback      = playbackCallback;
    cfg.pUserData         = this;   // 回调指回本实例

    if (ma_device_init(nullptr, &cfg, &impl_->playbackDevice) != MA_SUCCESS) {
        std::fprintf(stderr, "[Audio] failed to open playback device\n");
        return false;
    }
    impl_->playbackDeviceValid = true;

    if (ma_device_start(&impl_->playbackDevice) != MA_SUCCESS) {
        std::fprintf(stderr, "[Audio] failed to start playback device\n");
        ma_device_uninit(&impl_->playbackDevice);
        impl_->playbackDeviceValid = false;
        return false;
    }

    initialized_ = true;
    return true;
}

void AudioSystem::Shutdown() {
    if (!initialized_) return;

    StopCapture();

    {
        std::lock_guard<std::mutex> lock(mutex_);
        sources_.clear();
        buffers_.clear();
    }

    if (impl_->playbackDeviceValid) {
        ma_device_uninit(&impl_->playbackDevice);
        impl_->playbackDeviceValid = false;
    }

    initialized_ = false;
}

// =====================================================================
// 加载 / 解码（WAV / MP3 / FLAC / OGG 经 miniaudio 解码器）
// =====================================================================

bool AudioSystem::decodeFile(const String& filepath, AudioBuffer& outBuffer) {
    ma_decoder_config cfg = ma_decoder_config_init(ma_format_s16,
                                                   kOutputChannels,
                                                   kOutputSampleRate);
    ma_decoder decoder;

    const ma_result result = ma_decoder_init_file(filepath.c_str(), &cfg, &decoder);
    if (result != MA_SUCCESS) {
        std::fprintf(stderr, "[Audio] failed to open '%s' (ma_result=%d)\n",
                     filepath.c_str(), static_cast<i32>(result));
        return false;
    }

    constexpr ma_uint64 kChunkFrames = 16384;
    std::vector<u8> chunk(static_cast<size_t>(kChunkFrames) * kOutputChannels *
                          sizeof(i16));
    ma_uint64 totalFrames = 0;

    for (;;) {
        ma_uint64 framesRead = 0;
        ma_decoder_read_pcm_frames(&decoder, chunk.data(), kChunkFrames, &framesRead);
        if (framesRead == 0) break;

        const size_t bytes = static_cast<size_t>(framesRead) * kOutputChannels *
                             sizeof(i16);
        outBuffer.data.insert(outBuffer.data.end(),
                              chunk.begin(), chunk.begin() + bytes);
        totalFrames += framesRead;
    }

    ma_decoder_uninit(&decoder);

    if (totalFrames == 0) {
        std::fprintf(stderr, "[Audio] no samples decoded from '%s'\n",
                     filepath.c_str());
        return false;
    }

    outBuffer.name          = getFileName(filepath);
    outBuffer.sampleRate    = kOutputSampleRate;
    outBuffer.channels      = kOutputChannels;
    outBuffer.bitsPerSample = 16;
    outBuffer.totalSamples  = static_cast<u32>(totalFrames);
    outBuffer.valid         = true;
    return true;
}

AudioBuffer* AudioSystem::LoadSound(const String& filepath) {
    const String name = getFileName(filepath);

    // 快路径：命中缓存直接返回（不在锁内解码，避免阻塞音频回调线程）。
    {
        std::lock_guard<std::mutex> lock(mutex_);
        for (auto& buf : buffers_) {
            if (buf.name == name) return &buf;
        }
    }

    AudioBuffer buffer;
    if (!decodeFile(filepath, buffer)) return nullptr;

    // 慢路径：解码完成后重新加锁插入（双检防止并发重复加载）。
    std::lock_guard<std::mutex> lock(mutex_);
    for (auto& buf : buffers_) {
        if (buf.name == name) return &buf;
    }
    buffers_.push_back(std::move(buffer));
    return &buffers_.back();
}

// =====================================================================
// 声源控制
// =====================================================================

AudioSource* AudioSystem::findSource(u32 id) {
    for (auto& src : sources_) {
        if (src.id == id) return &src;
    }
    return nullptr;
}

u32 AudioSystem::Play(const String& filepath, f32 volume, bool looping) {
    if (!initialized_) return 0;

    AudioBuffer* buffer = LoadSound(filepath);
    if (!buffer) return 0;

    return PlayBuffer(buffer, volume, looping);
}

u32 AudioSystem::Play3D(const String& filepath, const Vec3& position,
                        f32 volume, f32 range) {
    if (!initialized_) return 0;

    AudioBuffer* buffer = LoadSound(filepath);
    if (!buffer) return 0;

    std::lock_guard<std::mutex> lock(mutex_);

    AudioSource source;
    source.id         = nextSourceId_++;
    source.buffer     = buffer;
    source.state      = AudioState::Playing;
    source.volume     = volume;
    source.looping    = false;
    source.position   = 0.0;
    source.position3D = position;
    source.range      = range;
    source.is3D       = true;
    sources_.push_back(source);

    return source.id;
}

u32 AudioSystem::PlayBuffer(AudioBuffer* buffer, f32 volume, bool looping) {
    if (!initialized_ || !buffer) return 0;

    std::lock_guard<std::mutex> lock(mutex_);

    AudioSource source;
    source.id       = nextSourceId_++;
    source.buffer   = buffer;
    source.state    = AudioState::Playing;
    source.volume   = volume;
    source.looping  = looping;
    source.position = 0.0;
    source.is3D     = false;
    sources_.push_back(source);

    return source.id;
}

void AudioSystem::Stop(u32 sourceId) {
    std::lock_guard<std::mutex> lock(mutex_);
    AudioSource* src = findSource(sourceId);
    if (src) src->state = AudioState::Stopped;
}

void AudioSystem::Pause(u32 sourceId) {
    std::lock_guard<std::mutex> lock(mutex_);
    AudioSource* src = findSource(sourceId);
    if (src && src->state == AudioState::Playing) src->state = AudioState::Paused;
}

void AudioSystem::Resume(u32 sourceId) {
    std::lock_guard<std::mutex> lock(mutex_);
    AudioSource* src = findSource(sourceId);
    if (src && src->state == AudioState::Paused) src->state = AudioState::Playing;
}

void AudioSystem::SetVolume(u32 sourceId, f32 volume) {
    std::lock_guard<std::mutex> lock(mutex_);
    AudioSource* src = findSource(sourceId);
    if (src) src->volume = std::clamp(volume, 0.0f, 1.0f);
}

void AudioSystem::SetPitch(u32 sourceId, f32 pitch) {
    std::lock_guard<std::mutex> lock(mutex_);
    AudioSource* src = findSource(sourceId);
    if (src) src->pitch = std::clamp(pitch, 0.25f, 4.0f);
}

void AudioSystem::SetPan(u32 sourceId, f32 pan) {
    std::lock_guard<std::mutex> lock(mutex_);
    AudioSource* src = findSource(sourceId);
    if (src && !src->is3D) src->pan = std::clamp(pan, -1.0f, 1.0f);
}

void AudioSystem::SetPosition(u32 sourceId, const Vec3& position) {
    std::lock_guard<std::mutex> lock(mutex_);
    AudioSource* src = findSource(sourceId);
    if (src) {
        src->position3D = position;
        src->is3D = true;
    }
}

void AudioSystem::SetVelocity(u32 sourceId, const Vec3& velocity) {
    std::lock_guard<std::mutex> lock(mutex_);
    AudioSource* src = findSource(sourceId);
    if (src) src->velocity = velocity;
}

void AudioSystem::SetListener(const Vec3& position, const Vec3& forward,
                              const Vec3& up) {
    std::lock_guard<std::mutex> lock(mutex_);
    setListenerLocked(position, forward, up, listenerGain_);
}

void AudioSystem::setListenerLocked(const Vec3& position, const Vec3& forward,
                                    const Vec3& up, f32 gain) {
    listenerPos_     = position;
    listenerForward_ = forward;
    listenerUp_      = up;
    listenerGain_    = gain;
}

void AudioSystem::SetListenerVelocity(const Vec3& velocity) {
    std::lock_guard<std::mutex> lock(mutex_);
    listenerVelocity_ = velocity;
}

void AudioSystem::SetMasterVolume(f32 volume) {
    masterVolume_ = std::clamp(volume, 0.0f, 1.0f);
}

f32 AudioSystem::GetMasterVolume() const {
    return masterVolume_;
}

void AudioSystem::SetDopplerEnabled(bool enabled) {
    dopplerEnabled_ = enabled;
}

bool AudioSystem::IsDopplerEnabled() const {
    return dopplerEnabled_;
}

// =====================================================================
// 帧更新：ECS 集成 + 声源清理
// =====================================================================

void AudioSystem::OnUpdate(f32 dt, ECS::World& world) {
    (void)dt;   // 混音与清理不依赖帧间隔（多普勒用显式速度而非差分）

    using Scene::Transform;

    // --- 声源组件：playOnStart 触发 + 3D 位置跟随实体 ---
    world.ForEach<AudioSourceComp>(
        [&](ECS::Entity e, AudioSourceComp& comp) {
            if (comp.playOnStart && !comp.started) {
                comp.started = true;
                if (comp.is3D) {
                    Vec3 pos(0.0f);
                    if (const Transform* t = world.GetComponent<Transform>(e)) {
                        pos = t->position;
                    }
                    comp.runtimeSourceId =
                        Play3D(comp.soundFile, pos, comp.volume, comp.range);
                } else {
                    comp.runtimeSourceId =
                        Play(comp.soundFile, comp.volume, comp.looping);
                }
            }

            // is3D 源每帧跟随实体位置。
            if (comp.is3D && comp.runtimeSourceId != 0) {
                if (const Transform* t = world.GetComponent<Transform>(e)) {
                    SetPosition(comp.runtimeSourceId, t->position);
                }
            }
        });

    // --- 监听者组件：位置 + 朝向（前向由欧拉角计算）+ 增益 ---
    // 多个监听者时取第一个带 Transform 的生效。
    bool listenerSet = false;
    world.ForEach<AudioListenerComp>(
        [&](ECS::Entity e, AudioListenerComp& comp) {
            if (listenerSet) return;
            const Transform* t = world.GetComponent<Transform>(e);
            if (!t) return;

            // 前向：pitch = rotation.x，yaw = rotation.y（弧度）。
            const f32 pitch = t->rotation.x;
            const f32 yaw   = t->rotation.y;
            const Vec3 forward(-std::cos(pitch) * std::sin(yaw),
                               std::sin(pitch),
                               -std::cos(pitch) * std::cos(yaw));

            {
                std::lock_guard<std::mutex> lock(mutex_);
                setListenerLocked(t->position, forward,
                                  Vec3(0.0f, 1.0f, 0.0f), comp.gain);
            }
            listenerSet = true;
        });

    // --- 清理已结束声源（M7T1 原逻辑）---
    {
        std::lock_guard<std::mutex> lock(mutex_);
        sources_.erase(
            std::remove_if(sources_.begin(), sources_.end(),
                [](const AudioSource& src) {
                    return src.state == AudioState::Stopped ||
                           src.state == AudioState::Finished;
                }),
            sources_.end());
    }
}

u32 AudioSystem::GetActiveSourceCount() {
    std::lock_guard<std::mutex> lock(mutex_);
    u32 count = 0;
    for (const auto& src : sources_) {
        if (src.state == AudioState::Playing) count++;
    }
    return count;
}

// =====================================================================
// 混音（3D 空间化）
// =====================================================================

void AudioSystem::mixAudio(i16* output, u32 frameCount) {
    std::memset(output, 0,
                static_cast<size_t>(kOutputChannels) * frameCount * sizeof(i16));

    std::lock_guard<std::mutex> lock(mutex_);

    // 监听者右向量：forward x up。
    // 引擎约定 forward=(0,0,-1)、up=(0,1,0) 时结果为 +X。
    Vec3 right = vecCross(listenerForward_, listenerUp_);
    const f32 rightLen = vecLength(right);
    right = (rightLen > 0.0001f) ? right / rightLen : Vec3(1.0f, 0.0f, 0.0f);

    for (auto& src : sources_) {
        if (src.state != AudioState::Playing || !src.buffer || !src.buffer->valid) {
            continue;
        }
        const AudioBuffer& buf = *src.buffer;

        f32 gainL = src.volume * masterVolume_ * listenerGain_;
        f32 gainR = gainL;

        // 监听者 -> 源 的单位方向（声像与多普勒共用）。
        const Vec3 toSrc = src.position3D - listenerPos_;
        const f32 dist = vecLength(toSrc);
        const Vec3 dir = (dist > 0.0001f) ? toSrc / dist
                                          : Vec3(0.0f, 0.0f, -1.0f);

        if (src.is3D) {
            // 距离衰减（线性，与旧版本模型一致）。
            const f32 attenuation =
                1.0f - std::clamp(dist / src.range, 0.0f, 1.0f);
            if (attenuation <= 0.001f) continue;

            // 由监听者朝向导出的等功率立体声像。
            // pan = -1（纯左）.. +1（纯右）
            const f32 pan = std::clamp(vecDot(dir, right), -1.0f, 1.0f);
            const f32 angle = (pan + 1.0f) * 0.5f * kHalfPi;
            gainL *= attenuation * std::cos(angle);
            gainR *= attenuation * std::sin(angle);
        } else {
            const f32 pan = std::clamp(src.pan, -1.0f, 1.0f);
            const f32 angle = (pan + 1.0f) * 0.5f * kHalfPi;
            gainL *= std::cos(angle);
            gainR *= std::sin(angle);
        }

        // 播放速率 = 音调 x 多普勒比。
        f32 rate = src.pitch;
        if (dopplerEnabled_ && src.is3D) {
            // 沿视线方向相向运动时为正。
            const f32 vListener = -vecDot(listenerVelocity_, dir);
            const f32 vSource   = vecDot(src.velocity, dir);

            f32 denom = kSpeedOfSound - vSource;
            if (denom < 1.0f) denom = 1.0f;

            const f32 doppler = (kSpeedOfSound + vListener) / denom;
            rate *= std::clamp(doppler, 0.5f, 2.0f);
        }

        // 缓冲已解码为设备格式（stereo s16 @ kOutputSampleRate），
        // 混音器只做音调/多普勒重采样（线性插值）。
        const i16* samples = reinterpret_cast<const i16*>(buf.data.data());
        const u32 total = buf.totalSamples;
        const f64 rateD = static_cast<f64>(rate);

        f64 pos = src.position;
        for (u32 i = 0; i < frameCount; i++) {
            if (static_cast<u32>(pos) >= total) {
                if (src.looping && total > 0) {
                    pos = std::fmod(pos, static_cast<f64>(total));
                } else {
                    src.state = AudioState::Finished;
                    break;
                }
            }

            const u32 i0 = static_cast<u32>(pos);
            const u32 i1 = (i0 + 1 < total) ? i0 + 1 : i0;
            const f32 frac = static_cast<f32>(pos - static_cast<f64>(i0));

            const f32 l = static_cast<f32>(samples[i0 * 2]) +
                    static_cast<f32>(samples[i1 * 2] - samples[i0 * 2]) * frac;
            const f32 r = static_cast<f32>(samples[i0 * 2 + 1]) +
                    static_cast<f32>(samples[i1 * 2 + 1] - samples[i0 * 2 + 1]) * frac;

            const i32 outL = static_cast<i32>(output[i * 2]) +
                             static_cast<i32>(l * gainL);
            const i32 outR = static_cast<i32>(output[i * 2 + 1]) +
                             static_cast<i32>(r * gainR);
            output[i * 2]     = static_cast<i16>(std::clamp(outL, -32768, 32767));
            output[i * 2 + 1] = static_cast<i16>(std::clamp(outR, -32768, 32767));

            pos += rateD;
        }
        src.position = pos;
    }
}

// =====================================================================
// 麦克风采集
// =====================================================================

bool AudioSystem::StartCapture() {
    std::lock_guard<std::mutex> lock(impl_->captureMutex);
    if (impl_->captureDeviceValid) return true;

    ma_device_config cfg = ma_device_config_init(ma_device_type_capture);
    cfg.capture.format   = ma_format_s16;
    cfg.capture.channels = 1;
    cfg.sampleRate       = kOutputSampleRate;
    cfg.dataCallback     = captureCallback;
    cfg.pUserData        = this;   // 回调指回本实例

    if (ma_device_init(nullptr, &cfg, &impl_->captureDevice) != MA_SUCCESS) {
        std::fprintf(stderr,
                     "[Audio] failed to open capture device (microphone unavailable?)\n");
        return false;
    }
    impl_->captureDeviceValid = true;

    if (ma_device_start(&impl_->captureDevice) != MA_SUCCESS) {
        std::fprintf(stderr, "[Audio] failed to start capture device\n");
        ma_device_uninit(&impl_->captureDevice);
        impl_->captureDeviceValid = false;
        return false;
    }

    impl_->captureWritePos.store(0, std::memory_order_relaxed);
    impl_->captureLevel.store(0.0f, std::memory_order_relaxed);
    return true;
}

void AudioSystem::StopCapture() {
    std::lock_guard<std::mutex> lock(impl_->captureMutex);
    if (!impl_->captureDeviceValid) return;

    ma_device_uninit(&impl_->captureDevice);
    impl_->captureDeviceValid = false;
    impl_->captureLevel.store(0.0f, std::memory_order_relaxed);
}

bool AudioSystem::IsCapturing() const {
    return impl_->captureDeviceValid;
}

f32 AudioSystem::GetCaptureLevel() const {
    return impl_->captureLevel.load(std::memory_order_relaxed);
}

u32 AudioSystem::ReadCaptureSamples(i16* out, u32 frameCount) {
    if (!impl_->captureDeviceValid || !out || frameCount == 0) return 0;

    const u32 written =
        impl_->captureWritePos.load(std::memory_order_relaxed);
    // 括号抑制 min/max 宏污染（windows.h / miniaudio 头可能定义）
    u32 avail = (frameCount < written) ? frameCount : written;
    if (avail > Impl::kCaptureRingFrames) avail = Impl::kCaptureRingFrames;
    if (avail == 0) return 0;

    for (u32 i = 0; i < avail; i++) {
        const u32 srcIdx = written - avail + i;
        out[i] = impl_->captureRing[srcIdx % Impl::kCaptureRingFrames];
    }
    return avail;
}

void AudioSystem::handleCapture(const i16* input, u32 frameCount) {
    if (!input) return;

    u32 pos = impl_->captureWritePos.load(std::memory_order_relaxed);

    f64 sumSquares = 0.0;
    for (u32 i = 0; i < frameCount; i++) {
        const f32 s = static_cast<f32>(input[i]) / 32768.0f;
        sumSquares += static_cast<f64>(s * s);
        impl_->captureRing[pos % Impl::kCaptureRingFrames] = input[i];
        pos++;
    }
    impl_->captureWritePos.store(pos, std::memory_order_relaxed);

    const f32 rms = static_cast<f32>(
        std::sqrt(sumSquares / static_cast<f64>(frameCount ? frameCount : 1)));
    impl_->captureLevel.store(rms, std::memory_order_relaxed);
}

} // namespace M7N::Audio
