/**
 * @file ScriptBindings.cpp
 * @brief m7_script_* C API 的 M7N 实现（自 M7T1 ScriptBindings.cpp 迁移）。
 *
 * 与 M7T1 的差异：
 *   - 实体解析：M7T1 经 Scene::FindEntityByID(u64)；M7N 的 ECS::World
 *     没有该接口，改为 64 位编码句柄（见 ScriptBindings.hpp 的
 *     EncodeEntityID / DecodeEntityID 与编码约定注释）+ IsAlive 校验，
 *     组件访问走 world.GetComponent<Scene::Transform>(e)。
 *   - M7T1 的活动场景指针（s_activeScene）由 ScriptSystem::Attach 设置的
 *     g_scriptWorld 取代（唯一写入点，见头文件注释）。
 *   - 音频 / 输入 / 时间 / 全局浮点：M7N 尚无对应子系统，空实现 + TODO
 *     （见各函数注释）。
 *   - M7T1 的匿名 namespace 可变状态（s_activeScene / s_globalFloats）不再
 *     迁移：架构约定「无 static 可变状态」，g_scriptWorld 是唯一例外。
 */

#include "M7N/Scripting/ScriptBindings.hpp"
#include "M7N/Scene/Components.hpp"   // Scene::Transform

#include <cstdio>

namespace M7N::Scripting {

/// C 桥世界锚点——唯一定义点。
/// 唯一写入点：ScriptSystem::Attach()（extern "C" 桥需要的全局锚点，
/// 架构约定「无 static 可变状态」的唯一例外）。
ECS::World* g_scriptWorld = nullptr;

} // namespace M7N::Scripting

// ---------------------------------------------------------------------------
// C 链接导出（P/Invoke 目标）
// ---------------------------------------------------------------------------

extern "C" {

using namespace M7N;
using Scripting::DecodeEntityID;
using Scripting::EncodeEntityID;

void m7_script_log(const char* message) {
    std::fprintf(stdout, "[script] %s\n", message ? message : "(null)");
}

float m7_script_get_delta_time(void) {
    // TODO(M7N): M7N 尚无 Time 系统；接入后返回真实帧间隔秒。
    return 0.0f;
}

float m7_script_get_elapsed_time(void) {
    // TODO(M7N): M7N 尚无 Time 系统；接入后返回真实累计时间秒。
    return 0.0f;
}

void m7_script_get_position(uint64_t entityId, float* outX, float* outY, float* outZ) {
    if (outX) *outX = 0.0f;
    if (outY) *outY = 0.0f;
    if (outZ) *outZ = 0.0f;

    ECS::Entity e;
    if (!DecodeEntityID(entityId, e)) return;
    Scene::Transform* tr = Scripting::g_scriptWorld->GetComponent<Scene::Transform>(e);
    if (!tr) return;

    if (outX) *outX = tr->position.x;
    if (outY) *outY = tr->position.y;
    if (outZ) *outZ = tr->position.z;
}

void m7_script_set_position(uint64_t entityId, float x, float y, float z) {
    ECS::Entity e;
    if (!DecodeEntityID(entityId, e)) return;
    Scene::Transform* tr = Scripting::g_scriptWorld->GetComponent<Scene::Transform>(e);
    if (!tr) return;

    tr->position = Vec3(x, y, z);
}

void m7_script_get_rotation(uint64_t entityId, float* outX, float* outY, float* outZ) {
    if (outX) *outX = 0.0f;
    if (outY) *outY = 0.0f;
    if (outZ) *outZ = 0.0f;

    ECS::Entity e;
    if (!DecodeEntityID(entityId, e)) return;
    Scene::Transform* tr = Scripting::g_scriptWorld->GetComponent<Scene::Transform>(e);
    if (!tr) return;

    // M7N Transform.rotation 即欧拉角（弧度），直接读取。
    if (outX) *outX = tr->rotation.x;
    if (outY) *outY = tr->rotation.y;
    if (outZ) *outZ = tr->rotation.z;
}

void m7_script_set_rotation(uint64_t entityId, float x, float y, float z) {
    ECS::Entity e;
    if (!DecodeEntityID(entityId, e)) return;
    Scene::Transform* tr = Scripting::g_scriptWorld->GetComponent<Scene::Transform>(e);
    if (!tr) return;

    // M7T1 的 SetRotationFromEuler 在 M7N 中即直接写欧拉角字段。
    tr->rotation = Vec3(x, y, z);
}

void m7_script_get_scale(uint64_t entityId, float* outX, float* outY, float* outZ) {
    if (outX) *outX = 1.0f;
    if (outY) *outY = 1.0f;
    if (outZ) *outZ = 1.0f;

    ECS::Entity e;
    if (!DecodeEntityID(entityId, e)) return;
    Scene::Transform* tr = Scripting::g_scriptWorld->GetComponent<Scene::Transform>(e);
    if (!tr) return;

    if (outX) *outX = tr->scale.x;
    if (outY) *outY = tr->scale.y;
    if (outZ) *outZ = tr->scale.z;
}

bool m7_script_is_key_down(int keyCode) {
    // TODO(M7N): M7N 尚无输入系统；接入后返回按键按住状态。
    (void)keyCode;
    return false;
}

bool m7_script_is_key_pressed(int keyCode) {
    // TODO(M7N): M7N 尚无输入系统；接入后返回按键按下沿。
    (void)keyCode;
    return false;
}

void m7_script_get_mouse_position(float* outX, float* outY) {
    // TODO(M7N): M7N 尚无输入系统；接入后返回鼠标位置。
    if (outX) *outX = 0.0f;
    if (outY) *outY = 0.0f;
}

uint64_t m7_script_instantiate_entity(const char* name) {
    if (!Scripting::g_scriptWorld || !name) return 0;

    ECS::Entity e = Scripting::g_scriptWorld->CreateEntity(String(name));
    if (!e.IsValid()) return 0;

    // 脚本创建的实体默认带 Transform，随后位置/旋转/缩放访问即可工作。
    Scripting::g_scriptWorld->AddComponent<Scene::Transform>(e);
    return EncodeEntityID(e);
}

void m7_script_destroy_entity(uint64_t entityId) {
    ECS::Entity e;
    if (!DecodeEntityID(entityId, e)) return;
    Scripting::g_scriptWorld->DestroyEntity(e);
}

void m7_script_play_sound(const char* soundFile, float volume, bool looping) {
    // TODO(M7N-5): M7N 尚无音频系统；接入 AudioSystem 后播放
    // （soundFile / volume / looping 语义同 M7T1 AudioEngine::Play）。
    (void)soundFile; (void)volume; (void)looping;
}

void m7_script_play_sound_3d(const char* soundFile,
                             float x, float y, float z,
                             float volume, float range) {
    // TODO(M7N-5): M7N 尚无音频系统；接入 AudioSystem 后播放 3D 音效
    // （语义同 M7T1 AudioEngine::Play3D）。
    (void)soundFile; (void)x; (void)y; (void)z; (void)volume; (void)range;
}

void m7_script_set_global_float(const char* name, float value) {
    // TODO(M7N): M7T1 用匿名 namespace 的 static 可变 map 存全局浮点；
    // 为遵守「无 static 可变状态」架构约定暂不迁移（g_scriptWorld 是唯一
    // 例外锚点）。接入全局黑板（如 World 侧存储或 ScriptSystem 实例状态）后补。
    (void)name; (void)value;
}

float m7_script_get_global_float(const char* name, float defaultValue) {
    // TODO(M7N): 同 m7_script_set_global_float——接入全局黑板后返回存储值。
    (void)name;
    return defaultValue;
}

} // extern "C"
