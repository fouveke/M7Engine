/**
 * @file ScriptSystem.cpp
 * @brief CoreCLR 宿主实现（自 M7T1 ScriptEngine.cpp 平移，去单例化）。
 *
 * 真实宿主流程（照搬 M7T1）：
 *   1. LoadLibrary / dlopen 加载 CoreCLR 运行时库
 *   2. 解析 coreclr_initialize / coreclr_create_delegate / coreclr_shutdown_2
 *   3. 以可执行文件目录构建 TRUSTED_PLATFORM_ASSEMBLIES + APP_PATHS 并
 *      coreclr_initialize（自包含发布与「运行时 dll 挨着 exe」两种布局均可）
 *   4. 对每个脚本程序集创建 Mutant7.ScriptHost 入口委托，经委托驱动托管生命周期
 *
 * 机器上没有 .NET 运行时时 Init() 返回 false，全部脚本 API 退化为
 * no-op（只记录一次）——引擎本体继续运行。
 *
 * 平移适配点：
 *   - M7T1 的 ScriptEngine::isInitialized_/loadedScripts_ 静态成员与匿名
 *     namespace 全局（g_coreclr 系列、g_hostHandle、g_domainId、
 *     g_runtimeLib、g_defaultAssembly、g_bridges）全部转为实例成员
 *   - FileSystem::GetDirectory/GetFileName → 自写 getDirectory/getFileName
 *     （M7N 暂无 FileSystem）
 *   - M7_LOG_* → fprintf（M7N 暂无日志系统；警告/错误走 stderr）
 *   - 新增 ECS 驱动：OnSceneCreate/Update/Destroy（逻辑参考 M7T1
 *     Scene.cpp 对 ScriptComponent 的处理）
 */

#include "M7N/Scripting/ScriptSystem.hpp"
#include "M7N/Scripting/ScriptComponents.hpp"
#include "M7N/Scripting/ScriptBindings.hpp"

#include <algorithm>
#include <cstdio>

#if defined(_WIN32)
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #ifndef NOMINMAX
        #define NOMINMAX
    #endif
    #include <windows.h>
#else
    #include <dlfcn.h>
    #include <unistd.h>
    #include <limits.h>
#endif

namespace M7N::Scripting {

namespace {

/// 托管侧桥类型名（契约与 M7T1 一致，现有脚本程序集无需改动）。
constexpr const char* kHostTypeName = "Mutant7.ScriptHost";

/// 取目录：最后一个 / 或 \ 之前（不含分隔符）；无分隔符返回空串。
String getDirectory(const String& path) {
    const size_t pos = path.find_last_of("/\\");
    return (pos == String::npos) ? String() : path.substr(0, pos);
}

/// 取文件名：最后一个 / 或 \ 之后；无分隔符返回整串。
String getFileName(const String& path) {
    const size_t pos = path.find_last_of("/\\");
    return (pos == String::npos) ? path : path.substr(pos + 1);
}

/// 当前可执行文件路径（Windows 用 GetModuleFileNameA）。
String getCurrentExecutablePath() {
#if defined(_WIN32)
    char buf[MAX_PATH];
    const DWORD n = GetModuleFileNameA(nullptr, buf, MAX_PATH);
    return String(buf, buf + n);
#else
    char buf[PATH_MAX];
    const ssize_t n = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
    if (n <= 0) return String();
    buf[n] = '\0';
    return String(buf);
#endif
}

/// 列出目录内全部 *.dll 并以 ';' 连接（TPA 列表格式）。
String listAssemblyFiles(const String& dir) {
    String result;
    bool any = false;
#if defined(_WIN32)
    const String pattern = dir + "\\*.dll";
    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(pattern.c_str(), &fd);
    if (h != INVALID_HANDLE_VALUE) {
        do {
            if (any) result += ";";
            result += dir + "\\" + fd.cFileName;
            any = true;
        } while (FindNextFileA(h, &fd));
        FindClose(h);
    }
#else
    (void)dir;   // POSIX：依赖 CoreCLR 自身的 DOTNET_ROOT 探测
#endif
    return result;
}

/// 程序集名（文件名去扩展名）——coreclr_create_delegate 用。
String assemblyNameFromPath(const String& path) {
    String file = getFileName(path);
    const size_t dot = file.rfind('.');
    if (dot != String::npos) file = file.substr(0, dot);
    return file;
}

/// 解析 "path/Assembly.dll|Full.Class.Name"（或使用默认程序集的裸类名）
/// 为 程序集路径 + 类名。平移自 M7T1 Scene.cpp 的 parseScriptName。
void parseScriptName(const String& scriptName, String& outAssembly, String& outClass) {
    const size_t sep = scriptName.find('|');
    if (sep != String::npos) {
        outAssembly = scriptName.substr(0, sep);
        outClass    = scriptName.substr(sep + 1);
    } else {
        outAssembly = String();   // 由调用方结合默认程序集处理
        outClass    = scriptName;
    }
}

} // namespace

// =====================================================================
// 生命周期
// =====================================================================

ScriptSystem::~ScriptSystem() {
    Shutdown();
}

bool ScriptSystem::Init(const String& runtimeConfig) {
    if (isInitialized_) return true;

#if defined(_WIN32)
    const char* kRuntimeLib = "coreclr.dll";
#else
    const char* kRuntimeLib = "libcoreclr.so";
#endif

#if defined(_WIN32)
    runtimeLib_ = static_cast<void*>(LoadLibraryA(kRuntimeLib));
#else
    runtimeLib_ = dlopen(kRuntimeLib, RTLD_NOW | RTLD_LOCAL);
#endif
    if (!runtimeLib_) {
        std::fprintf(stderr,
                     "[ScriptSystem] 未找到 .NET 运行时（'%s'），脚本已禁用"
                     "（引擎继续运行）。请安装 .NET SDK/运行时，或将自包含"
                     "发布产物放在可执行文件旁。\n", kRuntimeLib);
        return false;
    }

#if defined(_WIN32)
    coreclrInitialize_ = reinterpret_cast<Detail::FnCoreCLRInitialize>(
        reinterpret_cast<void*>(GetProcAddress(
            static_cast<HMODULE>(runtimeLib_), "coreclr_initialize")));
    coreclrCreateDelegate_ = reinterpret_cast<Detail::FnCoreCLRCreateDelegate>(
        reinterpret_cast<void*>(GetProcAddress(
            static_cast<HMODULE>(runtimeLib_), "coreclr_create_delegate")));
    coreclrShutdown_ = reinterpret_cast<Detail::FnCoreCLRShutdown>(
        reinterpret_cast<void*>(GetProcAddress(
            static_cast<HMODULE>(runtimeLib_), "coreclr_shutdown_2")));
#else
    coreclrInitialize_ = reinterpret_cast<Detail::FnCoreCLRInitialize>(
        dlsym(runtimeLib_, "coreclr_initialize"));
    coreclrCreateDelegate_ = reinterpret_cast<Detail::FnCoreCLRCreateDelegate>(
        dlsym(runtimeLib_, "coreclr_create_delegate"));
    coreclrShutdown_ = reinterpret_cast<Detail::FnCoreCLRShutdown>(
        dlsym(runtimeLib_, "coreclr_shutdown_2"));
#endif

    if (!coreclrInitialize_ || !coreclrCreateDelegate_ || !coreclrShutdown_) {
        std::fprintf(stderr,
                     "[ScriptSystem] '%s' 存在但缺少宿主入口点。\n", kRuntimeLib);
        // 自清理（M7T1 原版在此泄漏句柄）：不留半初始化状态
        releaseRuntime();
        return false;
    }

    // 从可执行文件目录构建宿主属性：自包含发布（游戏 dll + 运行时 dll 同
    // 目录）开箱即用；框架依赖型应用应传入 runtimeconfig.json。
    const String exePath = getCurrentExecutablePath();
    String appDir = getDirectory(exePath);
    if (!runtimeConfig.empty()) {
        appDir = getDirectory(runtimeConfig);
    }

    const String tpaList = listAssemblyFiles(appDir);

    const char* propertyKeys[2];
    const char* propertyValues[2];
    int propertyCount = 0;

    propertyKeys[propertyCount]   = "TRUSTED_PLATFORM_ASSEMBLIES";
    propertyValues[propertyCount] = tpaList.c_str();
    propertyCount++;

    propertyKeys[propertyCount]   = "APP_PATHS";
    propertyValues[propertyCount] = appDir.c_str();
    propertyCount++;

    const int hr = coreclrInitialize_(exePath.c_str(), "Mutant7ScriptDomain",
                                      propertyCount, propertyKeys, propertyValues,
                                      &hostHandle_, &domainId_);
    if (hr != 0) {
        std::fprintf(stderr,
                     "[ScriptSystem] coreclr_initialize 失败（hr=0x%08X）。"
                     "请确认游戏程序集与运行时 DLL 位于可执行文件旁，或传入"
                     "有效的 runtimeconfig.json。\n", static_cast<u32>(hr));
        hostHandle_ = nullptr;
        // 自清理（M7T1 原版在此泄漏句柄）：不留半初始化状态
        releaseRuntime();
        return false;
    }

    isInitialized_ = true;
    std::fprintf(stdout, "[ScriptSystem] CoreCLR 运行时已启动（domain %u）\n",
                 domainId_);
    return true;
}

void ScriptSystem::releaseRuntime() {
    if (runtimeLib_) {
#if defined(_WIN32)
        FreeLibrary(static_cast<HMODULE>(runtimeLib_));
#else
        dlclose(runtimeLib_);
#endif
    }
    runtimeLib_            = nullptr;
    coreclrInitialize_     = nullptr;
    coreclrCreateDelegate_ = nullptr;
    coreclrShutdown_       = nullptr;
}

void ScriptSystem::Shutdown() {
    if (!hostHandle_) {
        // 从未启动 / Init 中途失败：只清记录与（可能残留的）运行时库句柄
        loadedScripts_.clear();
        isInitialized_ = false;
        releaseRuntime();
        return;
    }

    // 逐个调托管 Unload。注意不能经 UnloadScript()——它会 erase
    // loadedScripts_，在 range-for 中是迭代器失效（M7T1 原版的隐患，
    // 此处改为直接分派）。
    for (auto& script : loadedScripts_) {
        if (script.isValid && script.objectHandle) {
            Detail::AssemblyBridge* bridge = getBridge(script.assemblyPath);
            if (bridge && bridge->unload) {
                bridge->unload(script.objectHandle);
            }
        }
    }
    loadedScripts_.clear();

    int exitCode = 0;
    coreclrShutdown_(hostHandle_, domainId_, &exitCode);
    hostHandle_ = nullptr;
    domainId_   = 0;
    bridges_.clear();
    releaseRuntime();

    isInitialized_ = false;
    std::fprintf(stdout, "[ScriptSystem] 已关停（CoreCLR 退出码 %d）\n", exitCode);
}

void ScriptSystem::SetDefaultAssembly(const String& assemblyPath) {
    defaultAssembly_ = assemblyPath;
}

const String& ScriptSystem::GetDefaultAssembly() const {
    return defaultAssembly_;
}

// =====================================================================
// 脚本加载与生命周期分派
// =====================================================================

Detail::AssemblyBridge* ScriptSystem::getBridge(const String& assemblyPath) {
    if (!hostHandle_) return nullptr;

    const String name = assemblyNameFromPath(assemblyPath);
    auto it = bridges_.find(name);
    if (it != bridges_.end()) return &it->second;

    Detail::AssemblyBridge bridge;
    struct Entry { const char* method; void** target; };
    Entry entries[] = {
        { "Load",      reinterpret_cast<void**>(&bridge.load) },
        { "Unload",    reinterpret_cast<void**>(&bridge.unload) },
        { "OnCreate",  reinterpret_cast<void**>(&bridge.onCreate) },
        { "OnUpdate",  reinterpret_cast<void**>(&bridge.onUpdate) },
        { "OnDestroy", reinterpret_cast<void**>(&bridge.onDestroy) },
    };

    for (const auto& e : entries) {
        void* fn = nullptr;
        const int hr = coreclrCreateDelegate_(hostHandle_, domainId_,
                                              name.c_str(), kHostTypeName,
                                              e.method, &fn);
        if (hr != 0 || !fn) {
            std::fprintf(stderr,
                         "[ScriptSystem] create_delegate(%s, %s.%s) 失败"
                         "（hr=0x%08X）。程序集是否导出 Mutant7.ScriptHost "
                         "契约？\n", name.c_str(), kHostTypeName, e.method,
                         static_cast<u32>(hr));
            return nullptr;
        }
        *e.target = fn;
    }

    return &bridges_.emplace(name, bridge).first->second;
}

ScriptInstance ScriptSystem::LoadScript(const String& assemblyPath, const String& className) {
    ScriptInstance instance;
    instance.assemblyPath = assemblyPath;
    instance.className    = className;

    if (!isInitialized_ || !hostHandle_) {
        std::fprintf(stderr,
                     "[ScriptSystem] LoadScript('%s') 已忽略——运行时未运行\n",
                     assemblyPath.c_str());
        return instance;
    }

    Detail::AssemblyBridge* bridge = getBridge(assemblyPath);
    if (!bridge || !bridge->load) return instance;

    void* handle = bridge->load(assemblyPath.c_str(), className.c_str());
    if (!handle) {
        std::fprintf(stderr,
                     "[ScriptSystem] 托管 Load() 对 %s::%s 返回 null\n",
                     assemblyPath.c_str(), className.c_str());
        return instance;
    }

    instance.objectHandle = handle;
    instance.isValid      = true;
    loadedScripts_.push_back(instance);
    std::fprintf(stdout, "[ScriptSystem] 脚本已加载：%s::%s\n",
                 assemblyPath.c_str(), className.c_str());
    return instance;
}

void ScriptSystem::UnloadScript(const ScriptInstance& instance) {
    auto it = std::find_if(loadedScripts_.begin(), loadedScripts_.end(),
        [&](const ScriptInstance& s) {
            return s.assemblyPath == instance.assemblyPath &&
                   s.className == instance.className;
        });
    if (it == loadedScripts_.end()) return;

    if (it->isValid && it->objectHandle) {
        Detail::AssemblyBridge* bridge = getBridge(it->assemblyPath);
        if (bridge && bridge->unload) {
            bridge->unload(it->objectHandle);
        }
    }
    std::fprintf(stdout, "[ScriptSystem] 脚本已卸载：%s::%s\n",
                 it->assemblyPath.c_str(), it->className.c_str());
    loadedScripts_.erase(it);
}

bool ScriptSystem::CallOnCreate(const ScriptInstance& instance) {
    if (!instance.isValid || !instance.objectHandle) return false;
    Detail::AssemblyBridge* bridge = getBridge(instance.assemblyPath);
    return bridge && bridge->onCreate &&
           bridge->onCreate(instance.objectHandle);
}

bool ScriptSystem::CallOnUpdate(const ScriptInstance& instance, f32 deltaTime) {
    if (!instance.isValid || !instance.objectHandle) return false;
    Detail::AssemblyBridge* bridge = getBridge(instance.assemblyPath);
    return bridge && bridge->onUpdate &&
           bridge->onUpdate(instance.objectHandle, deltaTime);
}

bool ScriptSystem::CallOnDestroy(const ScriptInstance& instance) {
    if (!instance.isValid || !instance.objectHandle) return false;
    Detail::AssemblyBridge* bridge = getBridge(instance.assemblyPath);
    return bridge && bridge->onDestroy &&
           bridge->onDestroy(instance.objectHandle);
}

void ScriptSystem::ReloadAll() {
    if (!isInitialized_) return;
    std::fprintf(stdout, "[ScriptSystem] 触发脚本热重载\n");

    // 记住已加载集合 → 重启运行时 → 逐个重载 + OnCreate（流程照搬 M7T1）。
    const std::vector<ScriptInstance> previous = loadedScripts_;
    Shutdown();
    if (!Init()) {
        // 运行时重启失败：组件持有的旧句柄已失效，卸下绑定防误用
        if (world_) {
            world_->ForEach<ScriptComp>([&](ECS::Entity /*e*/, ScriptComp& sc) {
                if (!sc.loaded || !sc.instanceData) return;
                delete static_cast<ScriptInstance*>(sc.instanceData);
                sc.instanceData = nullptr;
                sc.loaded       = false;
            });
        }
        return;
    }

    if (world_) {
        // M7N 适配：ScriptComp 持有旧实例指针，旧托管句柄已随 Shutdown
        // 失效，须按组件内的（程序集, 类名）重新加载并替换指针。
        world_->ForEach<ScriptComp>([&](ECS::Entity /*e*/, ScriptComp& sc) {
            if (!sc.loaded || !sc.instanceData) return;
            auto* old = static_cast<ScriptInstance*>(sc.instanceData);

            ScriptInstance fresh = LoadScript(old->assemblyPath, old->className);
            delete old;
            if (!fresh.isValid) {
                // 重载失败：卸下组件（数据保留，待下次 OnSceneCreate 重试）
                sc.instanceData = nullptr;
                sc.loaded       = false;
                return;
            }
            sc.instanceData = new ScriptInstance(fresh);
            CallOnCreate(fresh);
        });
    } else {
        // 未绑定 world：按 M7T1 流程恢复
        for (const auto& s : previous) {
            ScriptInstance reloaded = LoadScript(s.assemblyPath, s.className);
            if (reloaded.isValid) CallOnCreate(reloaded);
        }
    }
}

// =====================================================================
// ECS 集成
// =====================================================================

void ScriptSystem::Attach(ECS::World& world) {
    world_ = &world;
    // C 桥全局锚点（架构约定「无 static 可变状态」的唯一例外）：
    // 唯一写入点就是这里。
    g_scriptWorld = &world;
}

void ScriptSystem::OnSceneCreate(ECS::World& world) {
    world_ = &world;

    world.ForEach<ScriptComp>([&](ECS::Entity /*e*/, ScriptComp& sc) {
        if (!sc.enabled || sc.loaded || sc.scriptName.empty()) return;

        // 运行时未启动：静默跳过（引擎可无 .NET 运行，同 M7T1）
        if (!IsInitialized()) return;

        String assembly, className;
        parseScriptName(sc.scriptName, assembly, className);

        if (assembly.empty()) {
            // 裸类名：落到默认程序集
            assembly = defaultAssembly_;
        }

        if (assembly.empty()) {
            std::fprintf(stderr,
                         "[ScriptSystem] 脚本 '%s' 未指定程序集且未设置默认"
                         "程序集（SetDefaultAssembly），已跳过\n",
                         sc.scriptName.c_str());
            return;
        }

        ScriptInstance instance = LoadScript(assembly, className);
        if (!instance.isValid) return;

        sc.instanceData = new ScriptInstance(instance);
        sc.loaded       = true;
        CallOnCreate(*static_cast<ScriptInstance*>(sc.instanceData));
    });
}

void ScriptSystem::OnSceneUpdate(f32 dt) {
    if (!world_) return;

    world_->ForEach<ScriptComp>([&](ECS::Entity /*e*/, ScriptComp& sc) {
        if (sc.enabled && sc.loaded && sc.instanceData) {
            CallOnUpdate(*static_cast<ScriptInstance*>(sc.instanceData), dt);
        }
    });
}

void ScriptSystem::OnSceneDestroy() {
    if (!world_) return;

    world_->ForEach<ScriptComp>([&](ECS::Entity /*e*/, ScriptComp& sc) {
        if (!sc.loaded || !sc.instanceData) return;

        auto* stored = static_cast<ScriptInstance*>(sc.instanceData);
        CallOnDestroy(*stored);
        UnloadScript(*stored);
        delete stored;
        sc.instanceData = nullptr;
        sc.loaded       = false;
    });
}

} // namespace M7N::Scripting
