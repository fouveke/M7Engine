/**
 * @file World.cpp
 * @brief World 非模板部分实现：实体池、层级、级联销毁。
 */
#include "M7N/ECS/World.hpp"

namespace M7N::ECS {

void World::growTo(u32 index) {
    if (index < static_cast<u32>(records_.size())) return;
    size_t newSize = static_cast<size_t>(index) + 1;
    records_.resize(newSize);
    names_.resize(newSize, "Entity");
    parents_.resize(newSize, kNullEntity);
    children_.resize(newSize);
}

Entity World::CreateEntity(const String& name) {
    u32 index;
    if (!freeList_.empty()) {
        index = freeList_.back();
        freeList_.pop_back();
        // generation 已在销毁时自增，直接复用
    } else {
        index = static_cast<u32>(records_.size());
        growTo(index);
    }

    records_[index].alive = true;
    names_[index]         = name;
    parents_[index]       = kNullEntity;
    children_[index].clear();
    aliveCount_++;

    return Entity{ index, records_[index].generation };
}

void World::DestroyEntity(Entity e) {
    if (!IsAlive(e)) return;

    // 1) 级联销毁子树（先拷贝列表，销毁中会修改 children_）
    auto kids = children_[e.index];
    for (Entity c : kids) {
        DestroyEntity(c);
    }

    // 2) 摘除全部组件
    for (auto& storage : storages_) {
        if (storage) storage->OnEntityDestroyed(e);
    }

    // 3) 从父级子列表摘除
    Entity parent = parents_[e.index];
    if (parent.IsValid()) {
        auto& siblings = children_[parent.index];
        for (size_t i = 0; i < siblings.size(); i++) {
            if (siblings[i] == e) {
                siblings.erase(siblings.begin() + static_cast<i64>(i));
                break;
            }
        }
    }

    // 4) 释放槽位：generation 自增使全部旧句柄失效
    records_[e.index].alive = false;
    records_[e.index].generation++;
    names_[e.index].clear();
    parents_[e.index] = kNullEntity;
    children_[e.index].clear();
    freeList_.push_back(e.index);
    aliveCount_--;
}

bool World::IsAlive(Entity e) const {
    if (e.index >= records_.size()) return false;
    const Record& r = records_[e.index];
    return r.alive && r.generation == e.generation;
}

const String& World::GetName(Entity e) const {
    static const String kEmpty = "";
    if (!IsAlive(e)) return kEmpty;
    return names_[e.index];
}

void World::SetName(Entity e, const String& name) {
    if (!IsAlive(e)) return;
    names_[e.index] = name;
}

bool World::SetParent(Entity child, Entity parent) {
    if (!IsAlive(child)) return false;

    // 摘除为根
    if (!parent.IsValid()) {
        Entity old = parents_[child.index];
        if (old.IsValid()) {
            auto& siblings = children_[old.index];
            for (size_t i = 0; i < siblings.size(); i++) {
                if (siblings[i] == child) {
                    siblings.erase(siblings.begin() + static_cast<i64>(i));
                    break;
                }
            }
        }
        parents_[child.index] = kNullEntity;
        return true;
    }

    if (!IsAlive(parent)) return false;
    if (parent == child) return false;                 // 自引用
    if (IsAncestorOf(child, parent)) return false;     // 会成环

    // 从旧父级摘除
    Entity old = parents_[child.index];
    if (old.IsValid() && old != parent) {
        auto& siblings = children_[old.index];
        for (size_t i = 0; i < siblings.size(); i++) {
            if (siblings[i] == child) {
                siblings.erase(siblings.begin() + static_cast<i64>(i));
                break;
            }
        }
    }

    parents_[child.index] = parent;
    auto& kids = children_[parent.index];
    bool exists = false;
    for (Entity k : kids) {
        if (k == child) { exists = true; break; }
    }
    if (!exists) kids.push_back(child);
    return true;
}

Entity World::GetParent(Entity e) const {
    if (!IsAlive(e)) return kNullEntity;
    return parents_[e.index];
}

const std::vector<Entity>& World::GetChildren(Entity e) const {
    static const std::vector<Entity> kEmpty;
    if (!IsAlive(e)) return kEmpty;
    return children_[e.index];
}

bool World::IsAncestorOf(Entity ancestor, Entity e) const {
    if (!ancestor.IsValid()) return false;
    if (e.index >= parents_.size()) return false;
    Entity cur = e;
    // 沿父链上溯（最深 = 实体总数，必有尽头）
    for (u32 guard = 0; guard <= records_.size(); guard++) {
        Entity p = parents_[cur.index];
        if (!p.IsValid()) return false;
        if (p == ancestor) return true;
        cur = p;
    }
    return false; // 理论不可达（环已被 SetParent 拒绝）
}

void World::Clear() {
    // 倒序销毁，保证父先于子时级联逻辑安全
    for (u32 i = static_cast<u32>(records_.size()); i-- > 0;) {
        if (records_[i].alive) {
            DestroyEntity(Entity{ i, records_[i].generation });
        }
    }
}

} // namespace M7N::ECS
