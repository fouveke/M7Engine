/**
 * @file Input.cpp
 * @brief 输入状态与动作映射实现。
 */
#include "M7N/Core/Input.hpp"

#include <algorithm>

namespace M7N {

namespace {
u32 keySlot(Key key) {
    const i32 v = static_cast<i32>(key);
    return (v >= 0 && v < static_cast<i32>(Input::kKeySlots)) ? static_cast<u32>(v) : Input::kKeySlots;
}
u32 mouseSlot(MouseButton button) {
    const i32 v = static_cast<i32>(button);
    return (v >= 0 && v < static_cast<i32>(Input::kMouseSlots)) ? static_cast<u32>(v) : Input::kMouseSlots;
}
} // namespace

void Input::OnKey(i32 key, bool down) {
    if (key < 0 || key >= static_cast<i32>(kKeySlots)) return;
    const u32 slot = static_cast<u32>(key);
    if (down) {
        if (!keyDown_[slot]) keyPressed_[slot] = 1;
        keyDown_[slot] = 1;
    } else {
        if (keyDown_[slot]) keyReleased_[slot] = 1;
        keyDown_[slot] = 0;
    }
}

void Input::OnMouseButton(i32 button, bool down) {
    if (button < 0 || button >= static_cast<i32>(kMouseSlots)) return;
    const u32 slot = static_cast<u32>(button);
    if (down) {
        if (!mouseDown_[slot]) mousePressed_[slot] = 1;
        mouseDown_[slot] = 1;
    } else {
        if (mouseDown_[slot]) mouseReleased_[slot] = 1;
        mouseDown_[slot] = 0;
    }
}

void Input::OnMouseMove(f32 x, f32 y) {
    if (hasMousePosition_) {
        mouseDelta_.x += x - mousePosition_.x;
        mouseDelta_.y += y - mousePosition_.y;
    }
    mousePosition_ = Vec2(x, y);
    hasMousePosition_ = true;
}

void Input::OnMouseScroll(f32 dx, f32 dy) {
    scrollDelta_.x += dx;
    scrollDelta_.y += dy;
}

void Input::OnFocusLost() {
    for (u32 i = 0; i < kKeySlots; ++i) {
        if (keyDown_[i]) {
            keyDown_[i] = 0;
            keyReleased_[i] = 1;
        }
    }
    for (u32 i = 0; i < kMouseSlots; ++i) {
        if (mouseDown_[i]) {
            mouseDown_[i] = 0;
            mouseReleased_[i] = 1;
        }
    }
}

void Input::NewFrame() {
    std::fill(std::begin(keyPressed_), std::end(keyPressed_), 0);
    std::fill(std::begin(keyReleased_), std::end(keyReleased_), 0);
    std::fill(std::begin(mousePressed_), std::end(mousePressed_), 0);
    std::fill(std::begin(mouseReleased_), std::end(mouseReleased_), 0);
    mouseDelta_ = Vec2(0.0f);
    scrollDelta_ = Vec2(0.0f);
}

bool Input::IsKeyDown(Key key) const { return keyDown(keySlot(key)); }
bool Input::IsKeyPressed(Key key) const { return keyPressed(keySlot(key)); }
bool Input::IsKeyReleased(Key key) const { return keyReleased(keySlot(key)); }

bool Input::IsMouseDown(MouseButton button) const {
    const u32 slot = mouseSlot(button);
    return slot < kMouseSlots && mouseDown_[slot] != 0;
}
bool Input::IsMousePressed(MouseButton button) const {
    const u32 slot = mouseSlot(button);
    return slot < kMouseSlots && mousePressed_[slot] != 0;
}
bool Input::IsMouseReleased(MouseButton button) const {
    const u32 slot = mouseSlot(button);
    return slot < kMouseSlots && mouseReleased_[slot] != 0;
}

void Input::MapAction(const String& action, Key key) {
    actions_[action].push_back(KeyBinding::FromKey(key));
}

void Input::MapAction(const String& action, MouseButton button) {
    actions_[action].push_back(KeyBinding::FromMouse(button));
}

void Input::MapAxis(const String& axis, Key negative, Key positive) {
    axes_[axis] = { negative, positive };
}

void Input::ClearMappings() {
    actions_.clear();
    axes_.clear();
}

bool Input::bindingDown(const KeyBinding& b) const {
    if (b.mouse != MouseButton::None) return IsMouseDown(b.mouse);
    return IsKeyDown(b.key);
}

bool Input::bindingPressed(const KeyBinding& b) const {
    if (b.mouse != MouseButton::None) return IsMousePressed(b.mouse);
    return IsKeyPressed(b.key);
}

bool Input::bindingReleased(const KeyBinding& b) const {
    if (b.mouse != MouseButton::None) return IsMouseReleased(b.mouse);
    return IsKeyReleased(b.key);
}

bool Input::IsActionDown(const String& action) const {
    auto it = actions_.find(action);
    if (it == actions_.end()) return false;
    for (const KeyBinding& b : it->second) {
        if (bindingDown(b)) return true;
    }
    return false;
}

bool Input::IsActionPressed(const String& action) const {
    auto it = actions_.find(action);
    if (it == actions_.end()) return false;
    for (const KeyBinding& b : it->second) {
        if (bindingPressed(b)) return true;
    }
    return false;
}

bool Input::IsActionReleased(const String& action) const {
    auto it = actions_.find(action);
    if (it == actions_.end()) return false;
    for (const KeyBinding& b : it->second) {
        if (bindingReleased(b)) return true;
    }
    return false;
}

f32 Input::GetAxis(const String& axis) const {
    auto it = axes_.find(axis);
    if (it == axes_.end()) return 0.0f;
    const f32 negative = IsKeyDown(it->second.first) ? 1.0f : 0.0f;
    const f32 positive = IsKeyDown(it->second.second) ? 1.0f : 0.0f;
    return positive - negative;
}

} // namespace M7N
