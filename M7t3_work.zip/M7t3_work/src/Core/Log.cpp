/**
 * @file Log.cpp
 * @brief 分级日志实现（互斥锁序列化，低开销格式化）。
 */
#include "M7N/Core/Log.hpp"

#include <atomic>
#include <chrono>
#include <cstdio>
#include <ctime>
#include <mutex>

namespace M7N {

namespace {

std::atomic<LogLevel> g_level{ LogLevel::Info };
std::mutex g_mutex;
Log::Sink g_sink = nullptr;
void* g_sinkUser = nullptr;

const char* levelTag(LogLevel level) {
    switch (level) {
        case LogLevel::Trace: return "TRACE";
        case LogLevel::Debug: return "DEBUG";
        case LogLevel::Info:  return "INFO ";
        case LogLevel::Warn:  return "WARN ";
        case LogLevel::Error: return "ERROR";
        case LogLevel::Fatal: return "FATAL";
        default:              return "OFF  ";
    }
}

} // namespace

void Log::SetLevel(LogLevel level) { g_level.store(level, std::memory_order_relaxed); }

LogLevel Log::GetLevel() { return g_level.load(std::memory_order_relaxed); }

void Log::SetSink(Sink sink, void* user) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_sink = sink;
    g_sinkUser = user;
}

void Log::Write(LogLevel level, const char* category, const char* fmt, ...) {
    if (level < g_level.load(std::memory_order_relaxed)) return;
    if (!fmt) return;
    va_list args;
    va_start(args, fmt);
    VWrite(level, category, fmt, args);
    va_end(args);
}

void Log::VWrite(LogLevel level, const char* category, const char* fmt, va_list args) {
    char message[2048];
    std::vsnprintf(message, sizeof(message), fmt, args);

    const auto now = std::chrono::system_clock::now();
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                        now.time_since_epoch()).count() % 1000;
    std::time_t seconds = std::chrono::system_clock::to_time_t(now);
    std::tm tmBuf{};
#if defined(_WIN32)
    localtime_s(&tmBuf, &seconds);
#else
    localtime_r(&seconds, &tmBuf);
#endif

    char line[2304];
    std::snprintf(line, sizeof(line), "[%02d:%02d:%02d.%03d] [%s] [%s] %s\n",
                  tmBuf.tm_hour, tmBuf.tm_min, tmBuf.tm_sec,
                  static_cast<int>(ms), levelTag(level),
                  category ? category : "M7N", message);

    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_sink) {
        g_sink(level, line, g_sinkUser);
        return;
    }
    std::FILE* out = (level >= LogLevel::Warn) ? stderr : stdout;
    std::fputs(line, out);
    std::fflush(out);
}

} // namespace M7N
