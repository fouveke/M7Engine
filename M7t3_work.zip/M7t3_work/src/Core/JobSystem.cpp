/**
 * @file JobSystem.cpp
 * @brief 工作线程池实现：单活动任务 + 纪元唤醒 + 原子区间领取。
 */
#include "M7N/Core/JobSystem.hpp"
#include "M7N/Core/Log.hpp"

#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <vector>

namespace M7N {

namespace {
thread_local bool t_isWorker = false;
}

struct JobSystem::Impl {
    std::vector<std::thread> workers;
    std::mutex mutex;
    std::condition_variable wake;
    std::condition_variable done;

    const std::function<void(u32)>* fn = nullptr;
    u32 count = 0;
    u32 grain = 1;
    std::atomic<u32> next{ 0 };
    u32 finishedWorkers = 0;
    u64 epoch = 0;
    bool stop = false;

    void runRange() {
        if (!fn) return;
        const u32 g = grain > 0 ? grain : 1;
        for (;;) {
            const u32 begin = next.fetch_add(g, std::memory_order_relaxed);
            if (begin >= count) return;
            const u32 end = (begin + g < count) ? begin + g : count;
            for (u32 i = begin; i < end; ++i) (*fn)(i);
        }
    }

    void workerLoop() {
        t_isWorker = true;
        u64 seenEpoch = 0;
        for (;;) {
            {
                std::unique_lock<std::mutex> lock(mutex);
                wake.wait(lock, [&] { return stop || epoch != seenEpoch; });
                if (stop) return;
                seenEpoch = epoch;
            }

            runRange();

            {
                std::lock_guard<std::mutex> lock(mutex);
                finishedWorkers++;
                if (finishedWorkers >= workers.size()) done.notify_all();
            }
        }
    }
};

JobSystem::JobSystem(u32 workerCount) : impl_(CreateScope<Impl>()) {
    u32 hw = std::thread::hardware_concurrency();
    if (hw == 0) hw = 2;
    if (workerCount == 0) workerCount = (hw > 1) ? hw - 1 : 0;
    // 上限保护：避免超大核数机器创建过多线程
    if (workerCount > 64) workerCount = 64;

    impl_->workers.reserve(workerCount);
    for (u32 i = 0; i < workerCount; ++i) {
        impl_->workers.emplace_back([this] { impl_->workerLoop(); });
    }
    M7N_LOG_DEBUG("Jobs", "pool started: %u workers", workerCount);
}

JobSystem::~JobSystem() {
    {
        std::lock_guard<std::mutex> lock(impl_->mutex);
        impl_->stop = true;
    }
    impl_->wake.notify_all();
    for (auto& t : impl_->workers) {
        if (t.joinable()) t.join();
    }
}

u32 JobSystem::WorkerCount() const {
    return static_cast<u32>(impl_->workers.size());
}

bool JobSystem::IsWorkerThread() { return t_isWorker; }

void JobSystem::ParallelFor(u32 count, u32 grain, const std::function<void(u32)>& fn) {
    if (count == 0 || !fn) return;
    if (grain == 0) grain = 1;

    // 串行路径：无工作线程 / 工作量过小 / 嵌套调用
    if (impl_->workers.empty() || t_isWorker || count < grain * 2) {
        for (u32 i = 0; i < count; ++i) fn(i);
        return;
    }

    {
        std::unique_lock<std::mutex> lock(impl_->mutex);
        // API 约定同一时刻只有一个活动 ParallelFor；若被并发调用则串行退避。
        if (impl_->fn != nullptr) {
            lock.unlock();
            for (u32 i = 0; i < count; ++i) fn(i);
            return;
        }
        impl_->fn = &fn;
        impl_->count = count;
        impl_->grain = grain;
        impl_->next.store(0, std::memory_order_relaxed);
        impl_->finishedWorkers = 0;
        ++impl_->epoch;
    }
    impl_->wake.notify_all();

    // 主线程参与执行
    impl_->runRange();

    {
        std::unique_lock<std::mutex> lock(impl_->mutex);
        impl_->done.wait(lock, [&] {
            return impl_->finishedWorkers >= impl_->workers.size();
        });
        impl_->fn = nullptr;
        impl_->count = 0;
    }
}

} // namespace M7N
