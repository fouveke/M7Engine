/**
 * @file TransformSystem.cpp
 * @brief 世界矩阵缓存实现（根子树并行）。
 */
#include "M7N/Scene/TransformSystem.hpp"

#include <vector>

namespace M7N::Scene {

namespace {

void computeSubtree(ECS::World& world, ECS::Entity e, const Mat4& parent) {
    Transform* tf = world.GetComponent<Transform>(e);
    if (!tf) return;
    WorldTransform* wt = world.GetComponent<WorldTransform>(e);
    if (!wt) return;

    wt->matrix = parent * tf->GetLocalMatrix();
    for (ECS::Entity child : world.GetChildren(e)) {
        computeSubtree(world, child, wt->matrix);
    }
}

} // namespace

void TransformSystem::OnUpdate(ECS::World& world, JobSystem* jobs) {
    // 1) 补建缓存组件（结构修改只能串行）
    std::vector<ECS::Entity> roots;
    std::vector<ECS::Entity> stale;

    std::vector<ECS::Entity> transformEntities;
    world.ForEach<Transform>([&](ECS::Entity e, Transform&) {
        transformEntities.push_back(e);
    });
    for (ECS::Entity e : transformEntities) {
        if (!world.HasComponent<WorldTransform>(e)) {
            world.AddComponent<WorldTransform>(e);
        }
        ECS::Entity parent = world.GetParent(e);
        if (!parent.IsValid() || !world.HasComponent<Transform>(parent)) {
            roots.push_back(e);
        }
    }

    // 2) 清理失去 Transform 的缓存（例如运行时移除组件）
    world.ForEach<WorldTransform>([&](ECS::Entity e, WorldTransform&) {
        if (!world.HasComponent<Transform>(e)) stale.push_back(e);
    });
    for (ECS::Entity e : stale) world.RemoveComponent<WorldTransform>(e);

    // 3) 计算矩阵（根子树独立，可并行）
    lastRootCount_ = static_cast<u32>(roots.size());
    if (jobs && jobs->WorkerCount() > 0 && roots.size() > 1) {
        jobs->ParallelFor(static_cast<u32>(roots.size()), 1,
                          [&](u32 i) { computeSubtree(world, roots[i], Mat4(1.0f)); });
    } else {
        for (ECS::Entity root : roots) computeSubtree(world, root, Mat4(1.0f));
    }
}

Mat4 TransformSystem::GetWorldMatrix(const ECS::World& world, ECS::Entity e) {
    const WorldTransform* wt = world.GetComponent<WorldTransform>(e);
    if (wt) return wt->matrix;
    return ComputeWorldMatrix(world, e);
}

} // namespace M7N::Scene
