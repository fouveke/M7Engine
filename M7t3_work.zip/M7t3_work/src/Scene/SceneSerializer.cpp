/**
 * @file SceneSerializer.cpp
 * @brief 反射属性 <-> JSON 的具体转换与文件 IO。
 */
#include "M7N/Scene/SceneSerializer.hpp"

#include <cstring>

namespace M7N::Scene {

using Json = nlohmann::json;

void SceneSerializer::serializeProps(const Reflect::TypeInfo& info, const void* base,
                                     Json& out) {
    const u8* p = static_cast<const u8*>(base);
    for (u32 i = 0; i < info.propCount; i++) {
        const Reflect::PropertyInfo& prop = info.props[i];
        switch (prop.type) {
            case Reflect::PropType::Float: {
                f32 v;
                std::memcpy(&v, p + prop.offset, sizeof(f32));
                out[prop.name] = v;
                break;
            }
            case Reflect::PropType::Int32: {
                i32 v;
                std::memcpy(&v, p + prop.offset, sizeof(i32));
                out[prop.name] = v;
                break;
            }
            case Reflect::PropType::Bool: {
                bool v;
                std::memcpy(&v, p + prop.offset, sizeof(bool));
                out[prop.name] = v;
                break;
            }
            case Reflect::PropType::String: {
                const auto* s = reinterpret_cast<const String*>(p + prop.offset);
                out[prop.name] = *s;
                break;
            }
            case Reflect::PropType::Vec2: {
                const auto* v = reinterpret_cast<const Vec2*>(p + prop.offset);
                out[prop.name] = { v->x, v->y };
                break;
            }
            case Reflect::PropType::Vec3: {
                const auto* v = reinterpret_cast<const Vec3*>(p + prop.offset);
                out[prop.name] = { v->x, v->y, v->z };
                break;
            }
            case Reflect::PropType::Vec4: {
                const auto* v = reinterpret_cast<const Vec4*>(p + prop.offset);
                out[prop.name] = { v->x, v->y, v->z, v->w };
                break;
            }
            case Reflect::PropType::Quat: {
                const auto* q = reinterpret_cast<const Quat*>(p + prop.offset);
                out[prop.name] = { q->x, q->y, q->z, q->w };
                break;
            }
            case Reflect::PropType::Int32Array: {
                const auto* arr = reinterpret_cast<const std::vector<i32>*>(p + prop.offset);
                out[prop.name] = *arr;
                break;
            }
        }
    }
}

void SceneSerializer::applyProps(const Reflect::TypeInfo& info, void* base,
                                 const Json& in) {
    u8* p = static_cast<u8*>(base);
    for (u32 i = 0; i < info.propCount; i++) {
        const Reflect::PropertyInfo& prop = info.props[i];
        if (!in.contains(prop.name)) continue;
        const Json& val = in[prop.name];

        switch (prop.type) {
            case Reflect::PropType::Float: {
                f32 v = val.get<f32>();
                std::memcpy(p + prop.offset, &v, sizeof(f32));
                break;
            }
            case Reflect::PropType::Int32: {
                i32 v = val.get<i32>();
                std::memcpy(p + prop.offset, &v, sizeof(i32));
                break;
            }
            case Reflect::PropType::Bool: {
                bool v = val.get<bool>();
                std::memcpy(p + prop.offset, &v, sizeof(bool));
                break;
            }
            case Reflect::PropType::String: {
                *reinterpret_cast<String*>(p + prop.offset) = val.get<String>();
                break;
            }
            case Reflect::PropType::Vec2: {
                Vec2 v(val.at(0).get<f32>(), val.at(1).get<f32>());
                *reinterpret_cast<Vec2*>(p + prop.offset) = v;
                break;
            }
            case Reflect::PropType::Vec3: {
                Vec3 v(val.at(0).get<f32>(), val.at(1).get<f32>(), val.at(2).get<f32>());
                *reinterpret_cast<Vec3*>(p + prop.offset) = v;
                break;
            }
            case Reflect::PropType::Vec4: {
                Vec4 v(val.at(0).get<f32>(), val.at(1).get<f32>(),
                       val.at(2).get<f32>(), val.at(3).get<f32>());
                *reinterpret_cast<Vec4*>(p + prop.offset) = v;
                break;
            }
            case Reflect::PropType::Quat: {
                Quat q(val.at(0).get<f32>(), val.at(1).get<f32>(),
                       val.at(2).get<f32>(), val.at(3).get<f32>());
                *reinterpret_cast<Quat*>(p + prop.offset) = q;
                break;
            }
            case Reflect::PropType::Int32Array: {
                *reinterpret_cast<std::vector<i32>*>(p + prop.offset) =
                    val.get<std::vector<i32>>();
                break;
            }
        }
    }
}

bool SceneSerializer::writeJson(const Json& doc, const String& path) {
    std::ofstream file(path);
    if (!file.is_open()) return false;
    file << doc.dump(2);
    return true;
}

bool SceneSerializer::readJson(Json& doc, const String& path) {
    std::ifstream file(path);
    if (!file.is_open()) return false;
    try {
        file >> doc;
    } catch (const std::exception&) {
        return false;
    }
    return true;
}

} // namespace M7N::Scene
