/**
 * @file Components.cpp
 * @brief 系统函数：世界矩阵计算（父链上溯）。
 */
#include "M7N/Scene/Components.hpp"

namespace M7N::Scene {

Mat4 ComputeWorldMatrix(const ECS::World& world, ECS::Entity e) {
    // 未存活实体返回单位阵
    if (!const_cast<ECS::World&>(world).IsAlive(e)) return Mat4(1.0f);

    Mat4 worldMatrix = Mat4(1.0f);
    ECS::Entity cur = e;

    // 从自身沿父链上溯，逐级左乘父级本地矩阵
    for (u32 guard = 0; guard < 1024; guard++) {   // 深度保险丝
        const Transform* t = const_cast<ECS::World&>(world).GetComponent<Transform>(cur);
        if (t) {
            worldMatrix = t->GetLocalMatrix() * worldMatrix;
        }
        ECS::Entity parent = const_cast<ECS::World&>(world).GetParent(cur);
        if (!parent.IsValid()) break;
        cur = parent;
    }
    return worldMatrix;
}

} // namespace M7N::Scene
