/**
 * @file Camera.cpp
 * @brief 相机视图构建实现。
 */
#include "M7N/Scene/Camera.hpp"

#include <cmath>

namespace M7N::Scene {

CameraView BuildCameraView(const ECS::World& world, ECS::Entity cameraEntity,
                           f32 aspect) {
    CameraView view;
    view.proj = glm::perspective(glm::radians(view.fovYDeg),
                                 aspect > 0.0001f ? aspect : 1.0f,
                                 view.nearZ, view.farZ);

    const CameraComp* camera = world.GetComponent<CameraComp>(cameraEntity);
    if (camera) {
        view.fovYDeg = camera->fovYDeg;
        view.nearZ = camera->nearZ;
        view.farZ = camera->farZ;
        view.proj = glm::perspective(glm::radians(view.fovYDeg),
                                     aspect > 0.0001f ? aspect : 1.0f,
                                     view.nearZ, view.farZ);
    }

    const Transform* transform = world.GetComponent<Transform>(cameraEntity);
    if (transform) {
        const Mat4 m = ComputeWorldMatrix(world, cameraEntity);
        view.position = Vec3(m.m[12], m.m[13], m.m[14]);

        Vec3 right(m.m[0], m.m[1], m.m[2]);
        Vec3 up(m.m[4], m.m[5], m.m[6]);
        Vec3 backward(m.m[8], m.m[9], m.m[10]);
        if (glm::length(right) > 1e-5f) right = glm::normalize(right);
        if (glm::length(up) > 1e-5f) up = glm::normalize(up);
        if (glm::length(backward) > 1e-5f) backward = glm::normalize(backward);
        view.forward = -backward;
        view.up = up;
        view.view = glm::lookAt(view.position, view.position + view.forward, up);
    } else {
        view.view = glm::lookAt(Vec3(0.0f), Vec3(0.0f, 0.0f, -1.0f),
                                Vec3(0.0f, 1.0f, 0.0f));
    }

    view.viewProj = view.proj * view.view;
    return view;
}

ECS::Entity FindPrimaryCamera(const ECS::World& world) {
    ECS::Entity first = ECS::kNullEntity;
    ECS::Entity primary = ECS::kNullEntity;
    world.ForEach<CameraComp>([&](ECS::Entity e, CameraComp& camera) {
        if (!first.IsValid()) first = e;
        if (camera.primary && !primary.IsValid()) primary = e;
    });
    return primary.IsValid() ? primary : first;
}

} // namespace M7N::Scene
