/**
 * @file GLDevice.cpp
 * @brief GL 3.3 core / GLES3 兼容后端。
 *
 * 实现要点：
 *   - 全部 GL 调用限制在 GLES3 子集（无桌面专属入口），
 *     移动端原生 GLES3 上下文可直接复用本文件
 *   - 单一全局 VAO：BindVertexBuffer 时按当前管线的顶点布局
 *     重新下发 glVertexAttribPointer（GL 3.3 语义，捕获当前 ARRAY_BUFFER）
 *   - uniform 位置按 (program, name) 缓存，帧内零重复查询
 *   - 句柄 = 槽位 index + 1；销毁置 0，不复用（当前规模下足够）
 *   - 帧缓冲（M7N-G1）：Scene/HDR/DepthOnly 三模式；
 *     DepthOnly 深度附件 border=1（视锥外受光，阴影约定）
 */
#include "M7N/RHI/IRenderDevice.hpp"

#include <glad/glad.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <unordered_set>

namespace M7N::RHI {

namespace {

// ---------------------------------------------------------------------
// 内部资源记录
// ---------------------------------------------------------------------

struct GLBuffer {
    GLuint id = 0;
    GLenum target = GL_ARRAY_BUFFER;
    u32 size = 0;
};

struct GLTexture {
    GLuint id = 0;
};

struct GLShader {
    GLuint program = 0;
    /// uniform 名哈希 -> location 缓存（每程序一份）。
    /// 用哈希而不是 std::string 做键：回放时每条 SetUniform 都要查一次，
    /// 用字符串键等于每帧上万次小堆分配（实测这是渲染提交耗时的大头之一）。
    std::unordered_map<u64, GLint> locCache;
    /// 源码中声明为 int/bool 的 uniform 名集合：
    /// glUniform1f 设 int uniform 会静默失败(值不生效)，下发前按此表选 API。
    std::unordered_set<std::string> intUniforms;
    /// 上面那批 uniform 解析出的 location（回放时按 location 判断，免去字符串查找）
    std::unordered_set<GLint> intLocs;
};

struct GLPipeline {
    GLuint program = 0;
    PipelineDesc desc;
};

/// 帧缓冲记录：附件纹理自持，销毁时一并回收。
struct GLFramebuffer {
    GLuint fbo = 0;
    GLuint colorTex = 0;      // DepthOnly 模式为 0
    GLuint depthTex = 0;      // 可采样（阴影 PCF 用）
    u32 width = 0;
    u32 height = 0;
    FramebufferMode mode = FramebufferMode::Scene;
};

/// 编译单个着色器阶段。失败返回 0 并打印日志。
GLuint compileStage(GLenum stage, const char* src) {
    GLuint sh = glCreateShader(stage);
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    GLint ok = 0;
    glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetShaderInfoLog(sh, sizeof(log), nullptr, log);
        std::fprintf(stderr, "[GLDevice] shader compile failed:\n%s\n", log);
        glDeleteShader(sh);
        return 0;
    }
    return sh;
}

} // namespace

// ---------------------------------------------------------------------
// GLDevice
// ---------------------------------------------------------------------

class GLDevice final : public IRenderDevice {
public:
    bool Init() {
        glGenVertexArrays(1, &vao_);
        glBindVertexArray(vao_);
        // 引擎约定：CCW 正面、剔除背面
        glFrontFace(GL_CCW);
        glCullFace(GL_BACK);
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);

        GLint maxTex = 0;
        glGetIntegerv(0x0D33 /*GL_MAX_TEXTURE_SIZE*/, &maxTex);
        caps_.maxTextureSize = (maxTex > 0) ? static_cast<u32>(maxTex) : 4096u;

        GLfloat maxAniso = 1.0f;
        glGetFloatv(0x84FF /*GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT*/, &maxAniso);
        // 没有 EXT_texture_filter_anisotropic 时该查询会置 GL_INVALID_ENUM。
        if (glGetError() != GL_NO_ERROR) maxAniso = 1.0f;
        caps_.maxAnisotropy = (maxAniso > 1.0f) ? maxAniso : 1.0f;

        const char* version = reinterpret_cast<const char*>(glGetString(GL_VERSION));
        caps_.gles = version && std::strstr(version, "OpenGL ES") != nullptr;

        // 半浮点颜色附件探针：老 Intel / GLES 可能需要整条管线回退到 RGBA8。
        GLuint probeTex = 0, probeFbo = 0;
        glGenTextures(1, &probeTex);
        glBindTexture(GL_TEXTURE_2D, probeTex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, 4, 4, 0,
                     GL_RGBA, GL_HALF_FLOAT, nullptr);
        glGenFramebuffers(1, &probeFbo);
        glBindFramebuffer(GL_FRAMEBUFFER, probeFbo);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                               GL_TEXTURE_2D, probeTex, 0);
        caps_.halfFloatRenderTargets =
            glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glDeleteFramebuffers(1, &probeFbo);
        glDeleteTextures(1, &probeTex);
        return true;
    }

    const DeviceCaps& GetCapabilities() const override { return caps_; }

    // --- 资源创建 ---

    BufferHandle CreateBuffer(const BufferDesc& desc) override {
        GLBuffer b;
        b.target = (desc.usage == BufferUsage::Index) ? GL_ELEMENT_ARRAY_BUFFER
                                                      : GL_ARRAY_BUFFER;
        b.size = desc.size;
        glGenBuffers(1, &b.id);
        glBindBuffer(b.target, b.id);
        glBufferData(b.target, desc.size, desc.data,
                     desc.dynamic ? GL_DYNAMIC_DRAW : GL_STATIC_DRAW);
        buffers_.push_back(b);
        return BufferHandle{ static_cast<u32>(buffers_.size()) };
    }

    TextureHandle CreateTexture(const TextureDesc& desc) override {
        if (desc.width == 0 || desc.height == 0) return {};
        if (desc.width > caps_.maxTextureSize || desc.height > caps_.maxTextureSize) {
            std::fprintf(stderr,
                         "[GLDevice] texture exceeds max size: %ux%u (max %u)\n",
                         desc.width, desc.height, caps_.maxTextureSize);
            return {};
        }
        GLenum internal = GL_RGBA8, format = GL_RGBA, type = GL_UNSIGNED_BYTE;
        switch (desc.format) {
            case Format::RGB8:    internal = GL_RGB8;    format = GL_RGB;  break;
            case Format::RGBA8:   internal = GL_RGBA8;   format = GL_RGBA; break;
            case Format::RGBA16F: internal = GL_RGBA16F; format = GL_RGBA;
                                  type = GL_HALF_FLOAT;  break;
            case Format::Depth24: internal = GL_DEPTH_COMPONENT24;
                                  format = GL_DEPTH_COMPONENT; type = GL_FLOAT; break;
        }
        // 颜色贴图：sRGB 内部格式，采样时自动转线性（否则整体发灰、颜色发白）
        if (desc.srgb) {
            if (internal == GL_RGBA8) internal = GL_SRGB8_ALPHA8;
            else if (internal == GL_RGB8) internal = GL_SRGB8;
        }

        GLTexture t;
        glGenTextures(1, &t.id);
        glBindTexture(GL_TEXTURE_2D, t.id);
        // 非 4 字节对齐宽度（如 RGB8 奇数宽）避免行错位
        // （glad 子集未定义 GL_UNPACK_ALIGNMENT，直接给枚举值 0x0CF5）
        glPixelStorei(0x0CF5, 1);
        glTexImage2D(GL_TEXTURE_2D, 0, internal, desc.width, desc.height, 0,
                     format, type, desc.pixels);

        // mipmap 链（纹理平铺/远景必需；深度附件不生成）
        const bool canMip = desc.mipmaps && desc.format != Format::Depth24;
        const GLint filterGL = (desc.filter == TextureFilter::Nearest)
                                   ? GL_NEAREST : GL_LINEAR;
        if (canMip) {
            glGenerateMipmap(GL_TEXTURE_2D);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
                            (desc.filter == TextureFilter::Nearest)
                                ? GL_NEAREST_MIPMAP_NEAREST
                                : GL_LINEAR_MIPMAP_LINEAR);
        } else {
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filterGL);
        }
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filterGL);

        // 采样环绕模式（地形 Repeat，UI/贴图边界 ClampToEdge）
        GLint wrapGL = GL_CLAMP_TO_EDGE;
        switch (desc.wrap) {
            case SamplerWrap::Repeat:        wrapGL = GL_REPEAT; break;
            case SamplerWrap::ClampToBorder: wrapGL = GL_CLAMP_TO_BORDER; break;
            case SamplerWrap::ClampToEdge:
            default:                         wrapGL = GL_CLAMP_TO_EDGE; break;
        }
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapGL);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapGL);

        // 各向异性过滤（驱动上报上限；不可用则静默跳过）
        if (desc.anisotropy && canMip) {
            const GLfloat level = std::min(caps_.maxAnisotropy, 8.0f);
            if (level > 1.0f) {
                glTexParameterf(GL_TEXTURE_2D,
                                0x84FE /*GL_TEXTURE_MAX_ANISOTROPY_EXT*/, level);
            }
        }

        textures_.push_back(t);
        return TextureHandle{ static_cast<u32>(textures_.size()) };
    }

    ShaderHandle CreateShader(const ShaderDesc& desc) override {
        if (!desc.vert || !desc.frag) return {};

        std::string vsSrc, fsSrc;
        prepareShaderSource(desc.vert, vsSrc);
        prepareShaderSource(desc.frag, fsSrc);

        GLuint vs = compileStage(GL_VERTEX_SHADER, vsSrc.c_str());
        if (!vs) return {};
        GLuint fs = compileStage(GL_FRAGMENT_SHADER, fsSrc.c_str());
        if (!fs) { glDeleteShader(vs); return {}; }

        GLuint program = glCreateProgram();
        glAttachShader(program, vs);
        glAttachShader(program, fs);
        glLinkProgram(program);
        glDeleteShader(vs);
        glDeleteShader(fs);

        GLint ok = 0;
        glGetProgramiv(program, GL_LINK_STATUS, &ok);
        if (!ok) {
            char log[1024];
            glGetProgramInfoLog(program, sizeof(log), nullptr, log);
            std::fprintf(stderr, "[GLDevice] program link failed:\n%s\n", log);
            glDeleteProgram(program);
            return {};
        }

        GLShader sh;
        sh.program = program;
        scanIntUniforms(vsSrc.c_str(), sh.intUniforms);
        scanIntUniforms(fsSrc.c_str(), sh.intUniforms);
        // 一次性把 int uniform 的名字解析成 location：回放时只比对 location，不再查字符串。
        for (const std::string& name : sh.intUniforms) {
            const GLint loc = glGetUniformLocation(program, name.c_str());
            if (loc >= 0) sh.intLocs.insert(loc);
        }
        shaders_.push_back(std::move(sh));
        return ShaderHandle{ static_cast<u32>(shaders_.size()) };
    }

    PipelineHandle CreatePipeline(const PipelineDesc& desc) override {
        if (!desc.shader.IsValid() ||
            desc.shader.id > shaders_.size() ||
            shaders_[desc.shader.id - 1].program == 0) {
            return {};
        }
        GLPipeline p;
        p.program = shaders_[desc.shader.id - 1].program;
        p.desc = desc;
        pipelines_.push_back(std::move(p));
        return PipelineHandle{ static_cast<u32>(pipelines_.size()) };
    }

    FramebufferHandle CreateFramebuffer(const FramebufferDesc& desc) override {
        GLFramebuffer fb;
        fb.width = desc.width;
        fb.height = desc.height;
        fb.mode = desc.mode;

        glGenFramebuffers(1, &fb.fbo);
        glBindFramebuffer(GL_FRAMEBUFFER, fb.fbo);

        if (desc.mode == FramebufferMode::DepthOnly) {
            // 阴影贴图：仅深度写入。
            // 注意：GL 要求颜色读取缓冲有效，否则帧缓冲不完整、绘制被静默丢弃；
            // glad 精简集未提供 glReadBuffer，故挂一个颜色附件并把绘制缓冲设为 NONE。
            glGenTextures(1, &fb.colorTex);
            glBindTexture(GL_TEXTURE_2D, fb.colorTex);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8,
                         static_cast<GLsizei>(desc.width),
                         static_cast<GLsizei>(desc.height),
                         0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                                   GL_TEXTURE_2D, fb.colorTex, 0);
            glDrawBuffers(0, nullptr);   // 不写颜色，只写深度（GL 3.3 / GLES3）

            glGenTextures(1, &fb.depthTex);
            glBindTexture(GL_TEXTURE_2D, fb.depthTex);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24,
                         static_cast<GLsizei>(desc.width),
                         static_cast<GLsizei>(desc.height),
                         0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            // GLES3.0 没有 CLAMP_TO_BORDER：用 CLAMP_TO_EDGE + 着色器边界判定。
            const GLint wrap = caps_.gles ? GL_CLAMP_TO_EDGE : GL_CLAMP_TO_BORDER;
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrap);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrap);
            // 硬件 PCF：采样时由纹理单元完成深度比较 + 双线性过滤（GL 3.3 / GLES3）。
            glTexParameteri(GL_TEXTURE_2D, 0x884C /*TEXTURE_COMPARE_MODE*/,
                            0x884E /*COMPARE_REF_TO_TEXTURE*/);
            glTexParameteri(GL_TEXTURE_2D, 0x884D /*TEXTURE_COMPARE_FUNC*/,
                            0x0203 /*GL_LEQUAL*/);
            // 视锥外区域深度 = 1（受光），既有阴影约定。
            if (!caps_.gles) {
                const f32 border[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
                glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, border);
            }
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                                   GL_TEXTURE_2D, fb.depthTex, 0);

        } else {
            // 场景 / HDR：颜色纹理 + 深度附件。
            // 半浮点不可渲染时自动回退 RGBA8（颜色被截断，但管线不中断）。
            const bool hdr = (desc.mode == FramebufferMode::HDR) &&
                             caps_.halfFloatRenderTargets;
            const GLenum internal = hdr ? GL_RGBA16F : GL_RGBA8;
            const GLenum pixType  = hdr ? GL_HALF_FLOAT : GL_UNSIGNED_BYTE;

            glGenTextures(1, &fb.colorTex);
            glBindTexture(GL_TEXTURE_2D, fb.colorTex);
            glTexImage2D(GL_TEXTURE_2D, 0, internal,
                         static_cast<GLsizei>(desc.width),
                         static_cast<GLsizei>(desc.height),
                         0, GL_RGBA, pixType, nullptr);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                                   GL_TEXTURE_2D, fb.colorTex, 0);

            glGenTextures(1, &fb.depthTex);
            glBindTexture(GL_TEXTURE_2D, fb.depthTex);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24,
                         static_cast<GLsizei>(desc.width),
                         static_cast<GLsizei>(desc.height),
                         0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                                   GL_TEXTURE_2D, fb.depthTex, 0);
        }

        const GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
        if (status != GL_FRAMEBUFFER_COMPLETE) {
            std::fprintf(stderr, "[GLDevice] framebuffer incomplete: 0x%04X\n", status);
            glDeleteFramebuffers(1, &fb.fbo);
            if (fb.colorTex) glDeleteTextures(1, &fb.colorTex);
            if (fb.depthTex) glDeleteTextures(1, &fb.depthTex);
            glBindFramebuffer(GL_FRAMEBUFFER, 0);
            return {};
        }

        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        framebuffers_.push_back(fb);
        return FramebufferHandle{ static_cast<u32>(framebuffers_.size()) };
    }

    // --- 更新 / 销毁 ---

    void UpdateBuffer(BufferHandle h, const void* data, u32 size, u32 offset) override {
        GLBuffer* b = findBuffer(h);
        if (!b || offset + size > b->size) return;
        glBindBuffer(b->target, b->id);
        glBufferSubData(b->target, offset, size, data);
    }

    void DestroyBuffer(BufferHandle h) override {
        GLBuffer* b = findBuffer(h);
        if (!b) return;
        glDeleteBuffers(1, &b->id);
        *b = GLBuffer{};
        if (currentVertexBuffer_.id == h.id) {
            currentVertexBuffer_ = {};
            layoutVBO_ = {};
        }
        if (currentIndexBuffer_.id == h.id) currentIndexBuffer_ = {};
    }

    void DestroyTexture(TextureHandle h) override {
        if (!h.IsValid() || h.id > textures_.size()) return;
        GLTexture& t = textures_[h.id - 1];
        if (t.id) glDeleteTextures(1, &t.id);
        t = GLTexture{};
    }

    void DestroyShader(ShaderHandle h) override {
        if (!h.IsValid() || h.id > shaders_.size()) return;
        GLShader& s = shaders_[h.id - 1];
        if (s.program) glDeleteProgram(s.program);
        s = GLShader{};
    }

    void DestroyPipeline(PipelineHandle h) override {
        if (!h.IsValid() || h.id > pipelines_.size()) return;
        pipelines_[h.id - 1] = GLPipeline{};
        if (currentPipeline_.id == h.id || boundPipeline_ == &pipelines_[h.id - 1]) {
            boundPipeline_ = nullptr;
            boundShaderIdx_ = 0;
            currentPipeline_ = {};
            layoutPipeline_ = {};
        }
    }

    void DestroyFramebuffer(FramebufferHandle h) override {
        if (!h.IsValid() || h.id > framebuffers_.size()) return;
        GLFramebuffer& fb = framebuffers_[h.id - 1];
        if (!fb.fbo) return;
        glDeleteFramebuffers(1, &fb.fbo);
        if (fb.colorTex) glDeleteTextures(1, &fb.colorTex);
        if (fb.depthTex) glDeleteTextures(1, &fb.depthTex);
        fb = GLFramebuffer{};
    }

    TextureHandle GetFramebufferDepthTexture(FramebufferHandle h) override {
        if (!h.IsValid() || h.id > framebuffers_.size()) return {};
        GLFramebuffer& fb = framebuffers_[h.id - 1];
        if (!fb.fbo || !fb.depthTex) return {};
        // GL 后端内部编码：高位 1 标记"裸 GL 纹理名"（绕过 textures_ 表），
        // BindTexture 据此直通绑定。跨后端时由各后端自定义编码。
        // 阴影遮罩从 HDR 场景深度重建世界坐标，因此 Scene/HDR 也要暴露深度附件。
        return TextureHandle{ 0x80000000u | fb.depthTex };
    }

    TextureHandle GetFramebufferColorTexture(FramebufferHandle h) override {
        if (!h.IsValid() || h.id > framebuffers_.size()) return {};
        GLFramebuffer& fb = framebuffers_[h.id - 1];
        if (!fb.fbo || fb.mode == FramebufferMode::DepthOnly || !fb.colorTex) return {};
        // 同上：裸 GL 名直通编码。
        return TextureHandle{ 0x80000000u | fb.colorTex };
    }

    bool GetFramebufferSize(FramebufferHandle h, u32& outW, u32& outH) override {
        if (!h.IsValid() || h.id > framebuffers_.size()) return false;
        GLFramebuffer& fb = framebuffers_[h.id - 1];
        if (!fb.fbo) return false;
        outW = fb.width;
        outH = fb.height;
        return true;
    }

    // --- 帧调度 ---

    void BeginFrame() override {
        glBindVertexArray(vao_);
        // 帧首恢复深度写掩码：后处理管线 depthWrite=false 会把掩码留在 FALSE，
        // 而 glClear(GL_DEPTH_BUFFER_BIT) 受掩码影响会被静默忽略 —— 阴影图/HDR 深度
        // 若不清空，太阳转动时影子会一帧帧叠加，形成"绕物体一圈圈"的残留。
        glDepthMask(GL_TRUE);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        // 帧首清空状态缓存：下一帧第一次 Bind 必须真正下发 GL 状态。
        boundPipeline_ = nullptr;
        boundShaderIdx_ = 0;
        currentPipeline_ = {};
        currentVertexBuffer_ = {};
        currentIndexBuffer_ = {};
        layoutPipeline_ = {};
        layoutVBO_ = {};
        pendingSkinBuffer_ = 0;
    }

    void Submit(CommandList& cmd) override {
        // 绘制之外的路径（创建/上传纹理）也会改绑定，逐帧重置纹理槽缓存最省心。
        for (GLuint& t : boundTex_) t = 0;
        for (const Command& c : cmd.Commands()) {
            switch (c.type) {
                case CmdType::Clear: {
                    glClearColor(c.color[0], c.color[1], c.color[2], c.color[3]);
                    GLbitfield mask = GL_COLOR_BUFFER_BIT;
                    if (c.clearDepth) {
                        // 深度写掩码为 FALSE 时 glClear 不会清深度（GL 规范行为），先强制打开
                        glDepthMask(GL_TRUE);
                        glClearDepthf(1.0f);
                        mask |= GL_DEPTH_BUFFER_BIT;
                    }
                    glClear(mask);
                    break;
                }

                case CmdType::SetViewport:
                    glViewport(c.viewport[0], c.viewport[1],
                               c.viewport[2], c.viewport[3]);
                    break;

                case CmdType::BindFramebuffer: {
                    if (!c.framebuffer.IsValid()) {
                        glBindFramebuffer(GL_FRAMEBUFFER, 0);
                        break;
                    }
                    if (c.framebuffer.id <= framebuffers_.size()) {
                        GLFramebuffer& fb = framebuffers_[c.framebuffer.id - 1];
                        if (fb.fbo) {
                            glBindFramebuffer(GL_FRAMEBUFFER, fb.fbo);
                            // 视口跟随渲染目标尺寸（Clear 前必须正确）。
                            glViewport(0, 0, static_cast<GLsizei>(fb.width),
                                       static_cast<GLsizei>(fb.height));
                        }
                    }
                    break;
                }

                case CmdType::BindPipeline: {
                    // 同一管线连续绑定：程序/深度/剔除/混合状态都没变，整段跳过。
                    if (boundPipeline_ && currentPipeline_.id == c.pipeline.id) break;
                    const GLPipeline* p = findPipeline(c.pipeline);
                    if (!p) break;
                    glUseProgram(p->program);
                    if (p->desc.depthTest) glEnable(GL_DEPTH_TEST);
                    else glDisable(GL_DEPTH_TEST);
                    glDepthMask(p->desc.depthWrite ? GL_TRUE : GL_FALSE);
                    glColorMask(p->desc.colorWrite ? GL_TRUE : GL_FALSE,
                                p->desc.colorWrite ? GL_TRUE : GL_FALSE,
                                p->desc.colorWrite ? GL_TRUE : GL_FALSE,
                                p->desc.colorWrite ? GL_TRUE : GL_FALSE);
                    if (p->desc.cull) glEnable(GL_CULL_FACE);
                    else glDisable(GL_CULL_FACE);
                    // 阴影 pass 用正面剔除：只写背面深度，彻底避免自阴影摩尔纹
                    glCullFace(p->desc.cullFront ? GL_FRONT : GL_BACK);
                    if (p->desc.blend) {
                        glEnable(GL_BLEND);
                        if (p->desc.blendMode == BlendMode::Additive) {
                            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
                        } else {
                            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
                        }
                    } else {
                        glDisable(GL_BLEND);
                    }
                    boundPipeline_ = p;
                    boundShaderIdx_ = findShaderIndex(p->program);
                    currentPipeline_ = c.pipeline;
                    break;
                }

                case CmdType::BindVertexBuffer: {
                    const GLBuffer* b = findBuffer(c.buffer);
                    if (!b || b->target != GL_ARRAY_BUFFER) break;
                    const bool bindVBO = (currentVertexBuffer_.id != c.buffer.id);
                    if (bindVBO) {
                        glBindBuffer(GL_ARRAY_BUFFER, b->id);
                        currentVertexBuffer_ = c.buffer;
                    }
                    // 属性指针只在「换了顶点缓冲 / 换了管线 / 有待补发的蒙皮缓冲」时重新下发。
                    // 连续绘制同一网格（排序后大量出现）可以整段跳过 glVertexAttribPointer。
                    if (boundPipeline_) {
                        const bool layoutStale = bindVBO ||
                            layoutPipeline_.id != currentPipeline_.id ||
                            layoutVBO_.id != c.buffer.id ||
                            pendingSkinBuffer_ != 0;
                        if (layoutStale) {
                            applyLayout(boundPipeline_->desc.layout);
                            layoutPipeline_ = currentPipeline_;
                            layoutVBO_ = c.buffer;
                        }
                    }
                    // 蒙皮补发：皮肤缓冲上 3/4 指针，随后恢复顶点 ARRAY_BUFFER
                    if (pendingSkinBuffer_ != 0) {
                        const GLBuffer* sb = findBuffer(BufferHandle{ pendingSkinBuffer_ });
                        if (sb) {
                            glBindBuffer(GL_ARRAY_BUFFER, sb->id);
                            glEnableVertexAttribArray(3);
                            glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, 32,
                                                  reinterpret_cast<const void*>(0));
                            glVertexAttribDivisor(3, 0);
                            glEnableVertexAttribArray(4);
                            glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, 32,
                                                  reinterpret_cast<const void*>(16));
                            glVertexAttribDivisor(4, 0);
                            glBindBuffer(GL_ARRAY_BUFFER, b->id);
                        }
                        pendingSkinBuffer_ = 0;
                    }
                    break;
                }

                case CmdType::BindIndexBuffer: {
                    if (currentIndexBuffer_.id == c.buffer.id) break;
                    const GLBuffer* b = findBuffer(c.buffer);
                    if (!b || b->target != GL_ELEMENT_ARRAY_BUFFER) break;
                    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, b->id);
                    currentIndexBuffer_ = c.buffer;
                    break;
                }

                case CmdType::BindSkinBuffer: {
                    const GLBuffer* b = findBuffer(c.buffer);
                    if (!b || b->target != GL_ARRAY_BUFFER) break;
                    // 记录皮肤缓冲句柄；真正下发 3/4 属性指针推迟到
                    // BindVertexBuffer 的 applyLayout 之后（它会关闭未用槽），
                    // 补发时绑定本缓冲再恢复 ARRAY_BUFFER 到顶点缓冲。
                    pendingSkinBuffer_ = c.buffer.id;
                    break;
                }

                case CmdType::BindInstanceBuffer: {
                    const GLBuffer* b = findBuffer(c.buffer);
                    if (!b || b->target != GL_ARRAY_BUFFER) break;
                    const GLBuffer* vb = findBuffer(currentVertexBuffer_);
                    glBindBuffer(GL_ARRAY_BUFFER, b->id);
                    for (u32 i = 0; i < 4; i++) {
                        glEnableVertexAttribArray(6 + i);
                        glVertexAttribPointer(6 + i, 4, GL_FLOAT, GL_FALSE, 64,
                                              reinterpret_cast<const void*>(
                                                  static_cast<size_t>(i) * 16));
                        glVertexAttribDivisor(6 + i, 1);
                    }
                    glBindBuffer(GL_ARRAY_BUFFER, vb ? vb->id : 0);
                    break;
                }

                case CmdType::SetMat4ArrayUniform: {
                    if (!boundPipeline_) break;
                    GLShader& sh = shaders_[boundShaderIdx_];
                    GLint loc = uniformLocation(sh, c.name);
                    if (loc < 0) break;
                    // 矩阵池按命令 offset/count 引用（扁平 16 f32/矩阵）
                    const f32* pool = cmd.MatrixPool();
                    if (!pool) break;
                    glUniformMatrix4fv(loc, static_cast<GLsizei>(c.count), GL_FALSE,
                                       pool + static_cast<size_t>(c.offset) * 16);
                    break;
                }

                case CmdType::SetUniform: {
                    if (!boundPipeline_) break;
                    GLShader& sh = shaders_[boundShaderIdx_];
                    GLint loc = uniformLocation(sh, c.name);
                    if (loc < 0) break;
                    if (c.isMatrix && c.floatCount == 16) {
                        glUniformMatrix4fv(loc, 1, GL_FALSE, c.values);
                    } else switch (c.floatCount) {
                        case 1: {
                            // int/bool uniform 必须用 glUniform1i，否则 GL 静默忽略
                            if (sh.intLocs.count(loc) != 0) {
                                glUniform1i(loc, static_cast<GLint>(c.values[0]));
                            } else {
                                glUniform1f(loc, c.values[0]);
                            }
                            break;
                        }
                        case 2: glUniform2f(loc, c.values[0], c.values[1]); break;
                        case 3: glUniform3f(loc, c.values[0], c.values[1], c.values[2]); break;
                        case 4: glUniform4f(loc, c.values[0], c.values[1], c.values[2], c.values[3]); break;
                    }
                    break;
                }

                case CmdType::BindTexture: {
                    if (!boundPipeline_) break;
                    u32 texId = c.buffer.id;   // 纹理句柄借用字段
                    // GL 后端内部编码：高位 1 = 裸 GL 纹理名（帧缓冲深度附件直通）。
                    if (texId & 0x80000000u) {
                        const GLuint raw = texId & 0x7FFFFFFFu;
                        if (c.slot < 8 && boundTex_[c.slot] != raw) {
                            glActiveTexture(GL_TEXTURE0 + c.slot);
                            glBindTexture(GL_TEXTURE_2D, raw);
                            boundTex_[c.slot] = raw;
                        }
                        GLShader& sh = shaders_[boundShaderIdx_];
                        GLint loc = uniformLocation(sh, c.name);
                        if (loc >= 0) glUniform1i(loc, static_cast<GLint>(c.slot));
                        break;
                    }
                    if (!texId || texId > textures_.size()) break;
                    const GLuint glTex = textures_[texId - 1].id;
                    if (c.slot < 8 && boundTex_[c.slot] != glTex) {
                        glActiveTexture(GL_TEXTURE0 + c.slot);
                        glBindTexture(GL_TEXTURE_2D, glTex);
                        boundTex_[c.slot] = glTex;
                    }
                    GLShader& sh = shaders_[boundShaderIdx_];
                    GLint loc = uniformLocation(sh, c.name);
                    if (loc >= 0) glUniform1i(loc, static_cast<GLint>(c.slot));
                    break;
                }

                case CmdType::UpdateBuffer: {
                    GLBuffer* b = findBuffer(c.buffer);
                    const u8* blob = cmd.Blob();
                    if (!b || !blob || c.dataSize == 0) break;
                    if (c.dataOffset + c.dataSize > b->size) break;
                    glBindBuffer(b->target, b->id);
                    glBufferSubData(b->target, c.dataOffset, c.dataSize,
                                    blob + c.offset);
                    break;
                }

                case CmdType::UpdateTexture: {
                    const u32 texId = c.buffer.id;
                    const u8* blob = cmd.Blob();
                    if (!blob || c.dataSize == 0) break;
                    if (!texId || texId > textures_.size()) break;
                    const GLuint glTex = textures_[texId - 1].id;
                    if (!glTex) break;
                    glBindTexture(GL_TEXTURE_2D, glTex);
                    glPixelStorei(0x0CF5, 1);
                    glTexSubImage2D(
                        GL_TEXTURE_2D, 0, c.viewport[0], c.viewport[1],
                        static_cast<GLsizei>(c.viewport[2]),
                        static_cast<GLsizei>(c.viewport[3]),
                        GL_RGBA, GL_UNSIGNED_BYTE, blob + c.offset);
                    // 更新绑定发生在当前 active 纹理单元上，槽位缓存已不可信。
                    for (GLuint& bound : boundTex_) bound = 0;
                    break;
                }

                case CmdType::Draw:
                    glDrawArrays(GL_TRIANGLES, static_cast<GLint>(c.offset),
                                 static_cast<GLsizei>(c.count));
                    break;

                case CmdType::DrawIndexed: {
                    glDrawElements(GL_TRIANGLES, static_cast<GLsizei>(c.count),
                                   GL_UNSIGNED_INT,
                                   reinterpret_cast<const void*>(
                                       static_cast<size_t>(c.offset) * sizeof(u32)));
                    break;
                }

                case CmdType::DrawIndexedInstanced: {
                    glDrawElementsInstanced(
                        GL_TRIANGLES, static_cast<GLsizei>(c.count),
                        GL_UNSIGNED_INT,
                        reinterpret_cast<const void*>(
                            static_cast<size_t>(c.offset) * sizeof(u32)),
                        static_cast<GLsizei>(c.instanceCount));
                    break;
                }
            }
        }
    }

private:
    /// GLES3 上下文：把桌面 #version 330 着色器改写成 #version 300 es。
    void prepareShaderSource(const char* src, std::string& out) {
        if (!src) { out.clear(); return; }
        out.assign(src);
        if (!caps_.gles) return;
        static constexpr const char* kCoreHeader = "#version 330 core";
        static constexpr const char* kPlainHeader = "#version 330";
        static constexpr const char* kESHeader =
            "#version 300 es\nprecision highp float;\nprecision highp int;\n";
        const size_t coreLen = std::strlen(kCoreHeader);
        const size_t plainLen = std::strlen(kPlainHeader);
        if (out.compare(0, coreLen, kCoreHeader) == 0) {
            out.replace(0, coreLen, kESHeader);
        } else if (out.compare(0, plainLen, kPlainHeader) == 0) {
            out.replace(0, plainLen, kESHeader);
        }
    }

    GLBuffer* findBuffer(BufferHandle h) {
        if (!h.IsValid() || h.id > buffers_.size()) return nullptr;
        GLBuffer& b = buffers_[h.id - 1];
        return b.id ? &b : nullptr;
    }

    const GLPipeline* findPipeline(PipelineHandle h) {
        if (!h.IsValid() || h.id > pipelines_.size()) return nullptr;
        const GLPipeline& p = pipelines_[h.id - 1];
        return p.program ? &p : nullptr;
    }

    /// 由 GL program 反查 shader 槽位（管线持有 program 引用）。
    u32 findShaderIndex(GLuint program) {
        for (size_t i = 0; i < shaders_.size(); i++) {
            if (shaders_[i].program == program) return static_cast<u32>(i);
        }
        return 0;
    }

    /// FNV-1a：uniform 名（≤31 字节）的轻量哈希，替代 std::string 键。
    static u64 nameHash(const char* s) {
        u64 h = 1469598103934665603ull;
        while (*s) { h ^= static_cast<u8>(*s++); h *= 1099511628211ull; }
        return h;
    }

    GLint uniformLocation(GLShader& sh, const char* name) {
        const u64 h = nameHash(name);
        auto it = sh.locCache.find(h);
        if (it != sh.locCache.end()) return it->second;
        GLint loc = glGetUniformLocation(sh.program, name);
        sh.locCache.emplace(h, loc);
        return loc;
    }

    /// 从 GLSL 源码扫描 "uniform int/bool <name>"（glad 无 glGetActiveUniform，
    /// 故用源码内省确定整数型 uniform，供 SetFloat 选择 glUniform1i / glUniform1f）。
    void scanIntUniforms(const char* src, std::unordered_set<std::string>& out) {
        if (!src) return;
        const char* keys[2] = { "uniform int", "uniform bool" };
        for (const char* key : keys) {
            const char* p = src;
            while ((p = std::strstr(p, key)) != nullptr) {
                p += std::strlen(key);
                while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
                const char* start = p;
                while (*p && (std::isalnum(static_cast<unsigned char>(*p)) || *p == '_')) p++;
                if (p > start) out.insert(std::string(start, static_cast<size_t>(p - start)));
            }
        }
    }

    /// 下发顶点属性指针（含实例化 divisor），并关闭本管线未使用的 0..11 槽。
    void applyLayout(const std::vector<VertexAttrib>& layout) {
        bool used[12] = {};
        for (const VertexAttrib& a : layout) {
            if (a.location >= 12) continue;
            glEnableVertexAttribArray(a.location);
            glVertexAttribPointer(a.location, a.size, GL_FLOAT,
                                  a.normalized ? GL_TRUE : GL_FALSE,
                                  a.stride,
                                  reinterpret_cast<const void*>(
                                      static_cast<size_t>(a.offset)));
            glVertexAttribDivisor(a.location, a.divisor);
            used[a.location] = true;
        }
        for (u32 i = 0; i < 12; i++) {
            if (!used[i]) glDisableVertexAttribArray(i);
        }
    }

    GLuint vao_ = 0;
    DeviceCaps caps_;
    const GLPipeline* boundPipeline_ = nullptr;   // Submit 期间有效
    PipelineHandle currentPipeline_{};             // 当前程序状态（连续同管线可跳过）
    BufferHandle   currentVertexBuffer_{};
    BufferHandle   currentIndexBuffer_{};
    PipelineHandle layoutPipeline_{};              // 属性指针当前对应的管线
    BufferHandle   layoutVBO_{};                   // 属性指针当前对应的顶点缓冲
    /// 当前管线的 shader 下标：绑定管线时算一次，回放 uniform 时直接用，
    /// 免得每条 uniform 都线性扫一遍 shaders_。
    u32 boundShaderIdx_ = 0;
    u32 pendingSkinBuffer_ = 0;                   // 待补发 3/4 属性的皮肤缓冲
    /// 各纹理槽当前绑定的 GL 纹理（同一纹理连续绑定直接跳过）
    GLuint boundTex_[8] = {};

    std::vector<GLBuffer>   buffers_;
    std::vector<GLTexture>  textures_;
    std::vector<GLShader>   shaders_;
    std::vector<GLPipeline> pipelines_;
    std::vector<GLFramebuffer> framebuffers_;
};

Ref<IRenderDevice> CreateGLDevice() {
    auto device = CreateRef<GLDevice>();
    if (!device->Init()) return nullptr;
    return device;
}

} // namespace M7N::RHI
