/**
 * @file PhysicsSystem.cpp
 * @brief 物理系统实现：ECS <-> PhysicsWorld 桥接 + Transform 写回。
 *
 * 数据流（每帧）：
 *   SyncPending（新增/移除对账） -> PhysicsWorld::Step（模拟）
 *   -> 把 body.position / body.orientation 写回 Scene::Transform
 *
 * 写回约定：M7N 的 Transform 只有 position / rotation(欧拉) / scale
 * 三个字段，没有四元数字段；因此朝向用 glm::eulerAngles() 转成
 * 欧拉角后写入 rotation 字段（弧度，pitch/yaw/roll 语义与
 * Scene::Components.hpp 的 Transform::GetLocalMatrix 一致）。
 */
#include "M7N/Physics/PhysicsSystem.hpp"
#include "M7N/Scene/Components.hpp"

namespace M7N::Physics {

// =====================================================================
// 注册
// =====================================================================

u32 PhysicsSystem::RegisterBody(ECS::Entity e, const RigidBodyComp& rb) {
    // 形状：无 ColliderComp 时默认 Box
    const ColliderComp* col = ecs_->GetComponent<ColliderComp>(e);
    CollisionShape shape = CollisionShape::Box;
    if (col) {
        switch (col->shape) {
            case ColliderShape::Sphere:  shape = CollisionShape::Sphere;  break;
            case ColliderShape::Capsule: shape = CollisionShape::Capsule; break;
            case ColliderShape::Box:
            default:                     shape = CollisionShape::Box;     break;
        }
    }

    u32 bodyId = world_.AddRigidBody(e, shape, rb.mass);
    RigidBody* body = world_.GetBody(bodyId);
    if (!body) return 0;

    // RigidBodyComp 参数（invMass 按 mass 重算，防止两者不一致）
    body->invMass        = (rb.mass > 0.0f) ? 1.0f / rb.mass : 0.0f;
    body->restitution    = rb.restitution;
    body->friction       = rb.friction;
    body->useGravity     = rb.useGravity;
    body->isKinematic    = rb.isKinematic;
    body->freezeRotation = rb.freezeRotation;
    body->angularDamping = rb.angularDamping;
    body->velocity        = rb.velocity;
    body->angularVelocity = rb.angularVelocity;
    body->torque          = rb.torque;
    body->orientation     = rb.orientation;

    // ColliderComp 尺寸
    if (col) {
        body->halfExtents = col->halfExtents;
        body->radius      = col->radius;
        body->halfHeight  = col->halfHeight;
    }

    // Transform.position 为初始位置
    const Scene::Transform* tf = ecs_->GetComponent<Scene::Transform>(e);
    if (tf) body->position = tf->position;

    entityToBody_[static_cast<size_t>(e.index)] = bodyId;
    return bodyId;
}

// =====================================================================
// 绑定与同步
// =====================================================================

void PhysicsSystem::Attach(ECS::World& ecs) {
    ecs_ = &ecs;
    entityToBody_.clear();
    world_.Init(world_.GetGravity());   // 清空内部世界，保留当前重力设置
    SyncPending();                      // 全量注册
}

void PhysicsSystem::SyncPending() {
    if (!ecs_) return;

    // 1) 移除失效刚体（实体销毁 / 组件被摘除 / bodyId 失效）
    for (auto it = entityToBody_.begin(); it != entityToBody_.end(); ) {
        RigidBody* body = world_.GetBody(it->second);
        const bool alive = (body != nullptr) &&
                           ecs_->HasComponent<RigidBodyComp>(body->entity);
        if (!alive) {
            if (body) world_.RemoveRigidBody(it->second);
            it = entityToBody_.erase(it);
        } else {
            ++it;
        }
    }

    // 2) 注册新增刚体
    ecs_->ForEach<RigidBodyComp>([&](ECS::Entity e, RigidBodyComp& rb) {
        auto it = entityToBody_.find(static_cast<size_t>(e.index));
        if (it != entityToBody_.end()) {
            RigidBody* body = world_.GetBody(it->second);
            if (body && body->entity.generation == e.generation) {
                return;   // 已注册
            }
            // 同 index 换代残留（旧实体销毁后新实体复用了 index）：先移除旧的
            world_.RemoveRigidBody(it->second);
            entityToBody_.erase(it);
        }
        RegisterBody(e, rb);
    });
}

// =====================================================================
// 帧步进
// =====================================================================

void PhysicsSystem::Step(f32 dt) {
    if (!ecs_) return;

    SyncPending();   // 帧前增量同步（新增/移除对账）
    world_.Step(dt);

    // 把模拟结果写回 Transform（M7N Transform 只有欧拉 rotation 字段，
    // 故用 glm::eulerAngles 把物理朝向转成欧拉角）
    for (const auto& kv : entityToBody_) {
        RigidBody* body = world_.GetBody(kv.second);
        if (!body) continue;

        Scene::Transform* tf = ecs_->GetComponent<Scene::Transform>(body->entity);
        if (!tf) continue;

        tf->position = body->position;
        tf->rotation = glm::eulerAngles(body->orientation);
    }
}

// =====================================================================
// 射线检测
// =====================================================================

bool PhysicsSystem::Raycast(const Vec3& origin, const Vec3& dir, f32 maxDist,
                            ECS::Entity& outEntity, f32& outDist, Vec3& outNormal) {
    RaycastHit hit;
    if (!world_.Raycast(origin, dir, maxDist, hit)) return false;

    outEntity = hit.entity;
    outDist   = hit.distance;
    outNormal = hit.normal;
    return true;
}

std::vector<ECS::Entity> PhysicsSystem::OverlapSphere(const Vec3& center, f32 radius) {
    std::vector<ECS::Entity> out;
    world_.OverlapSphere(center, radius, out);
    return out;
}

std::vector<ECS::Entity> PhysicsSystem::OverlapBox(const AABB& box) {
    std::vector<ECS::Entity> out;
    world_.OverlapBox(box, out);
    return out;
}

} // namespace M7N::Physics
