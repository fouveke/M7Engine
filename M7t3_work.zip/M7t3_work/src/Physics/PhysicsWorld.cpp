/**
 * @file PhysicsWorld.cpp
 * @brief 物理模拟世界实现（自 M7T1 PhysicsWorld.cpp 平移）。
 *
 * 窄相派发（全部六对）：
 *   Sphere  - Sphere   : 精确中心距测试
 *   Sphere  - Box      : 精确"点到盒最近点"测试（非 AABB 近似）
 *   Capsule - Sphere   : 轴段最近点 -> 球测试
 *   Capsule - Capsule  : 线段-线段最近点对 -> 球对测试
 *   Capsule - Box      : 沿胶囊轴采样最近点（12 个采样点；法线
 *                        质量近似但稳定）
 *   Box     - Box      : AABB 重叠 + 最小平移向量（MTV）
 *
 * 旋转：力矩按对角惯量张量近似（由形状推导）积分角速度；
 * 朝向为四元数，按标准 0.5 * (omega x q) * dt 格式积分。
 *
 * 平移说明（M7N-4A）：
 *   - namespace Mutant7 -> M7N::Physics
 *   - void* entity 句柄 -> M7N::ECS::Entity（按 index + generation 比较）
 *   - Math::X 数学调用 -> glm::X（M7N Types 直接暴露 glm）
 *   - 去掉 M7_LOG_PHYSICS 日志调用（M7N 侧暂无日志层）
 */
#include "M7N/Physics/PhysicsWorld.hpp"

#include <algorithm>
#include <cmath>
#include <cmath>
#include <limits>

namespace M7N::Physics {

void PhysicsWorld::Init(const Vec3& gravity) {
    gravity_ = gravity;
    bodies_.clear();
    accumulator_ = 0.0f;
}

void PhysicsWorld::Step(f32 deltaTime) {
    if (bodies_.empty()) return;

    // 固定步长模式：累加器步进；否则直接用 deltaTime
    if (fixedTimestep_ > 0.0f) {
        accumulator_ += deltaTime;
        // 钳制累加器，避免长时间停顿后的死亡螺旋
        if (accumulator_ > fixedTimestep_ * 8.0f) accumulator_ = fixedTimestep_ * 8.0f;
        while (accumulator_ >= fixedTimestep_) {
            integrateBodies(fixedTimestep_);
            detectAndResolveCollisions();
            accumulator_ -= fixedTimestep_;
        }
    } else {
        integrateBodies(deltaTime);
        detectAndResolveCollisions();
    }
}

// =====================================================================
// 积分
// =====================================================================

/// 对角惯量张量（按形状推导，返回各轴的 1/I）。
static Vec3 invInertiaDiag(const RigidBody& b) {
    if (b.mass <= 0.0f) return Vec3(0.0f);
    f32 m = b.mass;
    Vec3 I(0.0f);
    switch (b.shape) {
        case CollisionShape::Sphere:
            I = Vec3(0.4f * m * b.radius * b.radius);  // 2/5 m r^2
            break;
        case CollisionShape::Capsule: {
            // 主体按实心圆柱近似
            f32 r = b.radius;
            f32 h = b.halfHeight;
            f32 iAxis = 0.5f * m * r * r;                          // 绕局部 Y
            f32 iPerp = m * (3.0f * r * r + 4.0f * h * h) / 12.0f; // 绕 X/Z
            I = Vec3(iPerp, iAxis, iPerp);
            break;
        }
        case CollisionShape::Box:
        case CollisionShape::Mesh:
        default: {
            f32 ex = 2.0f * b.halfExtents.x, ey = 2.0f * b.halfExtents.y, ez = 2.0f * b.halfExtents.z;
            I = Vec3(m * (ey * ey + ez * ez) / 12.0f,
                     m * (ex * ex + ez * ez) / 12.0f,
                     m * (ex * ex + ey * ey) / 12.0f);
            break;
        }
    }
    return Vec3(
        I.x > 0.0001f ? 1.0f / I.x : 0.0f,
        I.y > 0.0001f ? 1.0f / I.y : 0.0f,
        I.z > 0.0001f ? 1.0f / I.z : 0.0f);
}

void PhysicsWorld::integrateBodies(f32 dt) {
    for (auto& body : bodies_) {
        if (body.isStatic || body.isKinematic) {
            body.force = Vec3(0.0f);
            body.torque = Vec3(0.0f);
            continue;
        }

        // 重力
        if (body.useGravity && gravityEnabled_) {
            body.velocity += gravity_ * dt;
        }

        // 累积力 / 力矩
        body.velocity += body.force * body.invMass * dt;

        if (!body.freezeRotation) {
            Vec3 invI = invInertiaDiag(body);
            body.angularVelocity += Vec3(body.torque.x * invI.x,
                                         body.torque.y * invI.y,
                                         body.torque.z * invI.z) * dt;
            // 角阻尼
            f32 damp = 1.0f / (1.0f + body.angularDamping * dt);
            body.angularVelocity *= damp;
        }
        body.force = Vec3(0.0f);
        body.torque = Vec3(0.0f);

        // 位置积分（半隐式欧拉）
        body.position += body.velocity * dt;

        // 朝向积分：q' = q + 0.5 * (w x q) * dt，随后归一化。
        // 本库四元数为 (x,y,z,w) 布局（见 glm.hpp 自定义 quat）。
        f32 wLen = glm::length(body.angularVelocity);
        if (!body.freezeRotation && wLen > 0.00001f) {
            const Quat& q = body.orientation;
            Vec3 w = body.angularVelocity;
            // omegaQuat = (w, 0)，(x,y,z,w) 布局
            Quat dq(
                0.5f * ( w.x * q.w + w.y * q.z - w.z * q.y),
                0.5f * (-w.x * q.z + w.y * q.w + w.z * q.x),
                0.5f * ( w.x * q.y - w.y * q.x + w.z * q.w),
                0.5f * (-w.x * q.x - w.y * q.y - w.z * q.z)
            );
            Quat nq(q.x + dq.x * dt, q.y + dq.y * dt, q.z + dq.z * dt, q.w + dq.w * dt);
            f32 len = std::sqrt(nq.x * nq.x + nq.y * nq.y + nq.z * nq.z + nq.w * nq.w);
            if (len > 0.00001f) {
                body.orientation = Quat(nq.x / len, nq.y / len, nq.z / len, nq.w / len);
            }
        }
    }
}

// =====================================================================
// 窄相辅助
// =====================================================================

namespace {

/// 点到 AABB 的最近点。
inline Vec3 closestPointOnAABB(const Vec3& p, const AABB& box) {
    return Vec3(
        glm::clamp(p.x, box.min.x, box.max.x),
        glm::clamp(p.y, box.min.y, box.max.y),
        glm::clamp(p.z, box.min.z, box.max.z));
}

/// 点 p 到线段 [a1,a2] 的最近点，可选返回 t 在 [0,1]。
inline Vec3 closestPointOnSegment(const Vec3& a1, const Vec3& a2, const Vec3& p, f32* outT = nullptr) {
    Vec3 ab = a2 - a1;
    f32 lenSq = glm::dot(ab, ab);
    f32 t = (lenSq > 0.0000001f) ? glm::dot(p - a1, ab) / lenSq : 0.0f;
    t = glm::clamp(t, 0.0f, 1.0f);
    if (outT) *outT = t;
    return a1 + ab * t;
}

/// 两线段间的最近点对（钳制迭代解）。
inline void closestPointsSegmentSegment(const Vec3& p1, const Vec3& q1,
                                        const Vec3& p2, const Vec3& q2,
                                        Vec3& outC1, Vec3& outC2) {
    Vec3 d1 = q1 - p1;
    Vec3 d2 = q2 - p2;
    Vec3 r  = p1 - p2;

    f32 a = glm::dot(d1, d1);
    f32 e = glm::dot(d2, d2);
    f32 f = glm::dot(d2, r);

    f32 s, t;
    if (a <= 0.0000001f && e <= 0.0000001f) {
        outC1 = p1; outC2 = p2; return;
    }
    if (a <= 0.0000001f) {
        s = 0.0f;
        t = glm::clamp(f / e, 0.0f, 1.0f);
    } else {
        f32 c = glm::dot(d1, r);
        if (e <= 0.0000001f) {
            t = 0.0f;
            s = glm::clamp(-c / a, 0.0f, 1.0f);
        } else {
            f32 b = glm::dot(d1, d2);
            f32 denom = a * e - b * b;
            s = (denom > 0.0000001f) ? glm::clamp((b * f - c * e) / denom, 0.0f, 1.0f) : 0.0f;
            t = (b * s + f) / e;
            if (t < 0.0f) {
                t = 0.0f;
                s = glm::clamp(-c / a, 0.0f, 1.0f);
            } else if (t > 1.0f) {
                t = 1.0f;
                s = glm::clamp((b - c) / a, 0.0f, 1.0f);
            }
        }
    }
    outC1 = p1 + d1 * s;
    outC2 = p2 + d2 * t;
}

} // namespace

// =====================================================================
// 碰撞检测 + 解算
// =====================================================================

void PhysicsWorld::detectAndResolveCollisions() {
    for (size_t i = 0; i < bodies_.size(); i++) {
        for (size_t j = i + 1; j < bodies_.size(); j++) {
            auto& a = bodies_[i];
            auto& b = bodies_[j];

            if (a.isStatic && b.isStatic) continue;
            if (a.isKinematic && b.isKinematic) continue;

            // 粗相：AABB 重叠（胶囊 AABB 跟随其朝向）
            if (!checkAABBCollision(a.GetAABB(), b.GetAABB())) continue;

            // 派发前统一 A/B 排序（Sphere < Capsule < Box）
            auto rank = [](CollisionShape s) -> int {
                if (s == CollisionShape::Sphere) return 0;
                if (s == CollisionShape::Capsule) return 1;
                return 2;
            };
            RigidBody& bodyA = (rank(a.shape) <= rank(b.shape)) ? a : b;
            RigidBody& bodyB = (rank(a.shape) <= rank(b.shape)) ? b : a;

            Vec3 normal(0.0f, 1.0f, 0.0f);
            f32 depth = 0.0f;
            Vec3 contact(0.0f);
            bool hit = false;

            if (bodyA.shape == CollisionShape::Sphere) {
                if (bodyB.shape == CollisionShape::Sphere) {
                    // --- 球 vs 球（精确）---
                    hit = checkSphereCollision(bodyA.position, bodyA.radius,
                                               bodyB.position, bodyB.radius,
                                               normal, depth);
                    contact = bodyA.position + normal * bodyA.radius;
                } else if (bodyB.shape == CollisionShape::Capsule) {
                    // --- 球 vs 胶囊：轴上最近点 -> 球 ---
                    Vec3 top, bot;
                    bodyB.GetCapsuleSegment(top, bot);
                    Vec3 cp = closestPointOnSegment(bot, top, bodyA.position);
                    hit = checkSphereCollision(cp, bodyB.radius,
                                               bodyA.position, bodyA.radius,
                                               normal, depth);
                    // normal 当前指向 cp -> 球心；翻转为 A -> B
                    normal = -normal;
                    contact = cp + normal * bodyB.radius;
                } else {
                    // --- 球 vs 盒（精确最近点；非 AABB 近似）---
                    AABB box = bodyB.GetAABB();
                    Vec3 closest = closestPointOnAABB(bodyA.position, box);
                    Vec3 diff = bodyA.position - closest;
                    f32 distSq = glm::dot(diff, diff);
                    if (distSq < bodyA.radius * bodyA.radius) {
                        hit = true;
                        if (distSq > 0.0000001f) {
                            f32 dist = std::sqrt(distSq);
                            normal = diff / dist;                     // A(球) -> B(盒)
                            depth = bodyA.radius - dist;
                            contact = closest;
                        } else {
                            // 球心在盒内：沿最小穿透轴推出
                            Vec3 center = box.GetCenter();
                            Vec3 ext = box.GetExtents();
                            Vec3 d = bodyA.position - center;
                            f32 dx = ext.x - std::abs(d.x);
                            f32 dy = ext.y - std::abs(d.y);
                            f32 dz = ext.z - std::abs(d.z);
                            if (dx <= dy && dx <= dz) {
                                normal = Vec3(d.x > 0 ? 1.0f : -1.0f, 0.0f, 0.0f);
                                depth = dx + bodyA.radius;
                            } else if (dy <= dz) {
                                normal = Vec3(0.0f, d.y > 0 ? 1.0f : -1.0f, 0.0f);
                                depth = dy + bodyA.radius;
                            } else {
                                normal = Vec3(0.0f, 0.0f, d.z > 0 ? 1.0f : -1.0f);
                                depth = dz + bodyA.radius;
                            }
                            contact = bodyA.position;
                        }
                    }
                }
            } else if (bodyA.shape == CollisionShape::Capsule) {
                if (bodyB.shape == CollisionShape::Capsule) {
                    // --- 胶囊 vs 胶囊（线段-线段最近点对）---
                    Vec3 aTop, aBot, bTop, bBot;
                    bodyA.GetCapsuleSegment(aTop, aBot);
                    bodyB.GetCapsuleSegment(bTop, bBot);
                    Vec3 c1, c2;
                    closestPointsSegmentSegment(aBot, aTop, bBot, bTop, c1, c2);
                    Vec3 diff = c2 - c1;
                    f32 distSq = glm::dot(diff, diff);
                    f32 rSum = bodyA.radius + bodyB.radius;
                    if (distSq < rSum * rSum) {
                        hit = true;
                        f32 dist = std::sqrt(distSq);
                        if (dist > 0.0000001f) {
                            normal = diff / dist;                 // A -> B
                            depth = rSum - dist;
                        } else {
                            normal = Vec3(0.0f, 1.0f, 0.0f);
                            depth = rSum;
                        }
                        contact = c1 + normal * bodyA.radius;
                    }
                } else {
                    // --- 胶囊 vs 盒：沿轴采样最近点。
                    // 12 个采样点相对常见胶囊高度的误差很小，且分支轻。
                    Vec3 top, bot;
                    bodyA.GetCapsuleSegment(top, bot);
                    AABB box = bodyB.GetAABB();

                    constexpr i32 kSamples = 12;
                    f32 bestDistSq = std::numeric_limits<f32>::max();
                    Vec3 bestOnAxis(0.0f), bestOnBox(0.0f);
                    for (i32 s = 0; s <= kSamples; s++) {
                        f32 t = static_cast<f32>(s) / static_cast<f32>(kSamples);
                        Vec3 axisP = bot + (top - bot) * t;
                        Vec3 boxP = closestPointOnAABB(axisP, box);
                        f32 dSq = glm::dot(axisP - boxP, axisP - boxP);
                        if (dSq < bestDistSq) {
                            bestDistSq = dSq;
                            bestOnAxis = axisP;
                            bestOnBox = boxP;
                        }
                    }
                    f32 rSum = bodyA.radius;
                    if (bestDistSq < rSum * rSum) {
                        hit = true;
                        f32 dist = std::sqrt(bestDistSq);
                        if (dist > 0.0000001f) {
                            normal = (bestOnBox - bestOnAxis) / dist;  // A(胶囊) -> B(盒)
                            depth = rSum - dist;
                            contact = bestOnBox;
                        } else {
                            // 轴点在盒内：退化为盒 MTV
                            Vec3 center = box.GetCenter();
                            Vec3 ext = box.GetExtents();
                            Vec3 d = bestOnAxis - center;
                            f32 dx = ext.x - std::abs(d.x);
                            f32 dy = ext.y - std::abs(d.y);
                            f32 dz = ext.z - std::abs(d.z);
                            if (dx <= dy && dx <= dz) {
                                normal = Vec3(d.x > 0 ? 1.0f : -1.0f, 0.0f, 0.0f);
                                depth = dx + rSum;
                            } else if (dy <= dz) {
                                normal = Vec3(0.0f, d.y > 0 ? 1.0f : -1.0f, 0.0f);
                                depth = dy + rSum;
                            } else {
                                normal = Vec3(0.0f, 0.0f, d.z > 0 ? 1.0f : -1.0f);
                                depth = dz + rSum;
                            }
                            contact = bestOnAxis;
                        }
                    }
                }
            } else {
                // --- 盒 vs 盒：AABB MTV ---
                AABB boxA = bodyA.GetAABB();
                AABB boxB = bodyB.GetAABB();
                Vec3 overlap;
                overlap.x = std::min(boxA.max.x, boxB.max.x) - std::max(boxA.min.x, boxB.min.x);
                overlap.y = std::min(boxA.max.y, boxB.max.y) - std::max(boxA.min.y, boxB.min.y);
                overlap.z = std::min(boxA.max.z, boxB.max.z) - std::max(boxA.min.z, boxB.min.z);

                Vec3 n(0.0f);
                f32 d = overlap.x;
                if (overlap.y < d) { d = overlap.y; n = Vec3(0, 1, 0); }
                else if (overlap.x <= overlap.z) { d = overlap.x; n = Vec3(1, 0, 0); }
                else { d = overlap.z; n = Vec3(0, 0, 1); }

                Vec3 dir = boxB.GetCenter() - boxA.GetCenter();
                if (glm::dot(n, dir) < 0.0f) n = -n;

                normal = n;   // A -> B
                depth = d;
                hit = d > 0.0f;
                contact = (boxA.GetCenter() + boxB.GetCenter()) * 0.5f;
            }

            if (hit && depth > 0.0f) {
                resolveCollision(bodyA, bodyB, normal, depth, contact);
            }
        }
    }
}

bool PhysicsWorld::checkAABBCollision(const AABB& a, const AABB& b) {
    return a.min.x <= b.max.x && a.max.x >= b.min.x &&
           a.min.y <= b.max.y && a.max.y >= b.min.y &&
           a.min.z <= b.max.z && a.max.z >= b.min.z;
}

bool PhysicsWorld::checkSphereCollision(const Vec3& posA, f32 radA,
                                        const Vec3& posB, f32 radB,
                                        Vec3& outNormal, f32& outDepth) {
    Vec3 diff = posB - posA;
    f32 distSq = glm::dot(diff, diff);
    f32 radiusSum = radA + radB;

    if (distSq >= radiusSum * radiusSum) return false;

    f32 dist = std::sqrt(distSq);
    if (dist > 0.0001f) {
        outNormal = diff / dist;
    } else {
        outNormal = Vec3(0.0f, 1.0f, 0.0f);
    }
    outDepth = radiusSum - dist;
    return true;
}

void PhysicsWorld::resolveCollision(RigidBody& a, RigidBody& b,
                                     const Vec3& normal, f32 depth,
                                     const Vec3& contactPoint) {
    // normal 指向：从 A 到 B
    f32 totalInvMass = a.invMass + b.invMass;
    if (totalInvMass <= 0.0f) return;  // 双方均为静态

    // --- 位置修正（Baumgarte；slop 避免抖动）---
    constexpr f32 kCorrectionPercent = 0.8f;
    constexpr f32 kSlop = 0.001f;
    f32 magnitude = std::max(depth - kSlop, 0.0f) * kCorrectionPercent;
    Vec3 correction = normal * (magnitude / totalInvMass);
    if (!a.isStatic) a.position -= correction * a.invMass;
    if (!b.isStatic) b.position += correction * b.invMass;

    // --- 速度解算（冲量法，含角速度项）---
    Vec3 rA = contactPoint - a.position;
    Vec3 rB = contactPoint - b.position;
    Vec3 relVel = (b.velocity + glm::cross(b.angularVelocity, rB)) -
                  (a.velocity + glm::cross(a.angularVelocity, rA));
    f32 velAlongNormal = glm::dot(relVel, normal);

    // 仅在两物体相互接近时解算
    if (velAlongNormal > 0.0f) return;

    // 弹性系数（取两者较小值）
    f32 e = std::min(a.restitution, b.restitution);

    // 有效质量含角速度贡献（对角惯量近似）
    Vec3 invIA = (a.freezeRotation || a.isStatic) ? Vec3(0.0f) : invInertiaDiag(a);
    Vec3 invIB = (b.freezeRotation || b.isStatic) ? Vec3(0.0f) : invInertiaDiag(b);

    Vec3 angA = glm::cross(invIA * glm::cross(rA, normal), rA);
    Vec3 angB = glm::cross(invIB * glm::cross(rB, normal), rB);
    f32 angTerm = glm::dot(angA + angB, normal);

    f32 denom = totalInvMass + angTerm;
    if (denom < 0.0000001f) denom = totalInvMass > 0.0f ? totalInvMass : 0.0000001f;

    // 冲量标量
    f32 j = -(1.0f + e) * velAlongNormal / denom;

    // 施加冲量
    Vec3 impulse = normal * j;
    if (!a.isStatic) {
        a.velocity -= impulse * a.invMass;
        if (!a.freezeRotation)
            a.angularVelocity -= invIA * glm::cross(rA, impulse);
    }
    if (!b.isStatic) {
        b.velocity += impulse * b.invMass;
        if (!b.freezeRotation)
            b.angularVelocity += invIB * glm::cross(rB, impulse);
    }

    // --- 摩擦（简化库仑摩擦，切向冲量）---
    Vec3 relVel2 = (b.velocity + glm::cross(b.angularVelocity, rB)) -
                   (a.velocity + glm::cross(a.angularVelocity, rA));
    Vec3 tangent = relVel2 - normal * glm::dot(relVel2, normal);
    f32 tangentLen = glm::length(tangent);
    if (tangentLen > 0.0001f) {
        tangent = tangent / tangentLen;

        Vec3 tangA = glm::cross(invIA * glm::cross(rA, tangent), rA);
        Vec3 tangB = glm::cross(invIB * glm::cross(rB, tangent), rB);
        f32 tangDenom = totalInvMass + glm::dot(tangA + tangB, tangent);
        if (tangDenom < 0.0000001f) tangDenom = totalInvMass > 0.0f ? totalInvMass : 0.0000001f;

        f32 jt = -glm::dot(relVel2, tangent) / tangDenom;
        f32 mu = std::sqrt(a.friction * b.friction);

        // 钳制：动摩擦冲量幅值 vs j * mu
        Vec3 frictionImpulse = (std::abs(jt) < j * mu)
            ? tangent * jt
            : tangent * (-j * mu);   // jt > 0 的方向已由 jt 符号处理

        if (!a.isStatic) {
            a.velocity -= frictionImpulse * a.invMass;
            if (!a.freezeRotation)
                a.angularVelocity -= invIA * glm::cross(rA, frictionImpulse);
        }
        if (!b.isStatic) {
            b.velocity += frictionImpulse * b.invMass;
            if (!b.freezeRotation)
                b.angularVelocity += invIB * glm::cross(rB, frictionImpulse);
        }
    }
}

// =====================================================================
// 射线检测
// =====================================================================

bool PhysicsWorld::Raycast(const Vec3& origin, const Vec3& direction,
                           f32 maxDist, RaycastHit& hit) {
    hit.hit = false;
    hit.distance = maxDist;

    Vec3 dir = glm::normalize(direction);
    if (glm::length(dir) < 0.0001f) return false;

    for (const auto& body : bodies_) {
        AABB box = body.GetAABB();
        f32 dist = 0.0f;
        bool rayHit = false;

        if (body.shape == CollisionShape::Sphere) {
            rayHit = raycastSphere(origin, dir, body.position, body.radius, dist);
        } else if (body.shape == CollisionShape::Capsule) {
            rayHit = raycastCapsule(origin, dir, body, dist);
        } else {
            rayHit = raycastAABB(origin, dir, box, dist);
        }

        if (rayHit && dist >= 0.0f && dist < hit.distance) {
            hit.hit = true;
            hit.distance = dist;
            hit.point = origin + dir * dist;
            hit.entity = body.entity;
            hit.bodyId = body.id;

            // 计算法线
            if (body.shape == CollisionShape::Sphere) {
                hit.normal = glm::normalize(hit.point - body.position);
            } else if (body.shape == CollisionShape::Capsule) {
                Vec3 top, bot;
                body.GetCapsuleSegment(top, bot);
                Vec3 cp = closestPointOnSegment(bot, top, hit.point);
                hit.normal = glm::normalize(hit.point - cp);
            } else {
                // 找命中面
                Vec3 center = box.GetCenter();
                Vec3 local = hit.point - center;
                Vec3 ext = box.GetExtents();
                Vec3 normalized = Vec3(
                    ext.x > 0.0001f ? local.x / ext.x : 0.0f,
                    ext.y > 0.0001f ? local.y / ext.y : 0.0f,
                    ext.z > 0.0001f ? local.z / ext.z : 0.0f
                );
                f32 ax = std::abs(normalized.x);
                f32 ay = std::abs(normalized.y);
                f32 az = std::abs(normalized.z);
                if (ax >= ay && ax >= az) {
                    hit.normal = Vec3(normalized.x > 0 ? 1.0f : -1.0f, 0, 0);
                } else if (ay >= az) {
                    hit.normal = Vec3(0, normalized.y > 0 ? 1.0f : -1.0f, 0);
                } else {
                    hit.normal = Vec3(0, 0, normalized.z > 0 ? 1.0f : -1.0f);
                }
            }
        }
    }

    return hit.hit;
}

bool PhysicsWorld::raycastAABB(const Vec3& origin, const Vec3& dir,
                                const AABB& box, f32& outDist) {
    // Slab 法
    f32 tmin = -std::numeric_limits<f32>::infinity();
    f32 tmax = std::numeric_limits<f32>::infinity();

    for (int i = 0; i < 3; i++) {
        f32 o = (i == 0) ? origin.x : (i == 1) ? origin.y : origin.z;
        f32 d = (i == 0) ? dir.x : (i == 1) ? dir.y : dir.z;
        f32 bmin = (i == 0) ? box.min.x : (i == 1) ? box.min.y : box.min.z;
        f32 bmax = (i == 0) ? box.max.x : (i == 1) ? box.max.y : box.max.z;

        if (std::abs(d) < 0.0001f) {
            if (o < bmin || o > bmax) return false;
        } else {
            f32 t1 = (bmin - o) / d;
            f32 t2 = (bmax - o) / d;
            if (t1 > t2) std::swap(t1, t2);
            tmin = std::max(tmin, t1);
            tmax = std::min(tmax, t2);
            if (tmin > tmax) return false;
        }
    }

    if (tmin < 0.0f) {
        outDist = tmax;  // 起点在盒内
        return tmax >= 0.0f;
    }
    outDist = tmin;
    return true;
}

bool PhysicsWorld::raycastSphere(const Vec3& origin, const Vec3& dir,
                                  const Vec3& center, f32 radius, f32& outDist) {
    Vec3 oc = origin - center;
    f32 a = glm::dot(dir, dir);
    f32 b = 2.0f * glm::dot(oc, dir);
    f32 c = glm::dot(oc, oc) - radius * radius;
    f32 discriminant = b * b - 4.0f * a * c;

    if (discriminant < 0.0f) return false;

    f32 sqrtD = std::sqrt(discriminant);
    f32 t1 = (-b - sqrtD) / (2.0f * a);
    f32 t2 = (-b + sqrtD) / (2.0f * a);

    if (t1 >= 0.0f) {
        outDist = t1;
        return true;
    }
    if (t2 >= 0.0f) {
        outDist = t2;
        return true;
    }
    return false;
}

bool PhysicsWorld::raycastCapsule(const Vec3& origin, const Vec3& dir,
                                  const RigidBody& body, f32& outDist) {
    // 精确射线 vs 圆柱-球帽解较重；改为采样轴并在两端球心及最近轴点
    // 测试球体，对常见游戏胶囊的扫掠体精度足够。
    Vec3 top, bot;
    body.GetCapsuleSegment(top, bot);

    // 先测两端球（精确）
    f32 dTop, dBot;
    bool hitTop = raycastSphere(origin, dir, top, body.radius, dTop);
    bool hitBot = raycastSphere(origin, dir, bot, body.radius, dBot);
    if (hitTop || hitBot) {
        if (hitTop && (!hitBot || dTop < dBot)) { outDist = dTop; return true; }
        if (hitBot) { outDist = dBot; return true; }
    }

    // 射线到轴的最近点：二分迭代几步
    f32 lo = 0.0f, hi = 1.0f;
    Vec3 axis = top - bot;
    auto rayPointAt = [&](f32 t) {
        // 射线上距某轴点最近的点
        return closestPointOnSegment(origin, origin + dir * 1000.0f, bot + axis * t);
    };
    for (i32 it = 0; it < 8; it++) {
        f32 m1 = lo + (hi - lo) / 3.0f;
        f32 m2 = hi - (hi - lo) / 3.0f;
        f32 d1 = glm::length(rayPointAt(m1) - (bot + axis * m1));
        f32 d2 = glm::length(rayPointAt(m2) - (bot + axis * m2));
        if (d1 < d2) hi = m2; else lo = m1;
    }
    f32 tMid = (lo + hi) * 0.5f;
    Vec3 midPoint = bot + axis * tMid;
    return raycastSphere(origin, dir, midPoint, body.radius, outDist);
}

// =====================================================================
// 刚体管理
// =====================================================================

u32 PhysicsWorld::AddRigidBody(ECS::Entity entity, CollisionShape shape, f32 mass) {
    RigidBody body;
    body.id = nextBodyId_++;
    body.entity = entity;
    body.shape = shape;
    body.mass = mass;
    body.invMass = (mass > 0.0f) ? 1.0f / mass : 0.0f;
    body.isStatic = (mass <= 0.0f);

    bodies_.push_back(body);
    return body.id;
}

void PhysicsWorld::RemoveRigidBody(ECS::Entity entity) {
    bodies_.erase(
        std::remove_if(bodies_.begin(), bodies_.end(),
            [entity](const RigidBody& b) {
                return b.entity.index == entity.index &&
                       b.entity.generation == entity.generation;
            }),
        bodies_.end());
}

void PhysicsWorld::RemoveRigidBody(u32 bodyId) {
    bodies_.erase(
        std::remove_if(bodies_.begin(), bodies_.end(),
            [bodyId](const RigidBody& b) { return b.id == bodyId; }),
        bodies_.end());
}

RigidBody* PhysicsWorld::GetBody(u32 bodyId) {
    for (auto& body : bodies_) {
        if (body.id == bodyId) return &body;
    }
    return nullptr;
}

RigidBody* PhysicsWorld::GetBodyByEntity(ECS::Entity entity) {
    for (auto& body : bodies_) {
        if (body.entity.index == entity.index &&
            body.entity.generation == entity.generation) return &body;
    }
    return nullptr;
}

void PhysicsWorld::OverlapSphere(const Vec3& center, f32 radius,
                                 std::vector<ECS::Entity>& out) const {
    out.clear();
    if (radius <= 0.0f) return;
    const f32 radiusSq = radius * radius;

    for (const RigidBody& body : bodies_) {
        const AABB box = body.GetAABB();
        const f32 cx = std::fmax(box.min.x, std::fmin(center.x, box.max.x));
        const f32 cy = std::fmax(box.min.y, std::fmin(center.y, box.max.y));
        const f32 cz = std::fmax(box.min.z, std::fmin(center.z, box.max.z));
        const f32 dx = center.x - cx;
        const f32 dy = center.y - cy;
        const f32 dz = center.z - cz;
        if (dx * dx + dy * dy + dz * dz <= radiusSq) {
            out.push_back(body.entity);
        }
    }
}

void PhysicsWorld::OverlapBox(const AABB& box, std::vector<ECS::Entity>& out) const {
    out.clear();
    for (const RigidBody& body : bodies_) {
        const AABB other = body.GetAABB();
        const bool overlap = !(other.min.x > box.max.x || other.max.x < box.min.x ||
                               other.min.y > box.max.y || other.max.y < box.min.y ||
                               other.min.z > box.max.z || other.max.z < box.min.z);
        if (overlap) out.push_back(body.entity);
    }
}

} // namespace M7N::Physics
