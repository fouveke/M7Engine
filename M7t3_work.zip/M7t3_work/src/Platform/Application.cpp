/**
 * @file Application.cpp
 * @brief 桌面应用外壳实现（GLFW + glad + RHI 设备 + BMP 截图）。
 */
#include "M7N/Platform/Application.hpp"
#include "M7N/Core/Log.hpp"

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <cstdio>
#include <vector>

namespace M7N {

namespace {

void glfwErrorCallback(int code, const char* description) {
    M7N_LOG_ERROR("GLFW", "error %d: %s", code, description ? description : "?");
}

Application* appOf(GLFWwindow* window) {
    return static_cast<Application*>(glfwGetWindowUserPointer(window));
}

void onKey(GLFWwindow* window, int key, int scancode, int action, int mods) {
    (void)scancode; (void)mods;
    Application* app = appOf(window);
    if (!app) return;
    if (action == GLFW_PRESS) app->GetInput().OnKey(key, true);
    else if (action == GLFW_RELEASE) app->GetInput().OnKey(key, false);
}

void onMouseButton(GLFWwindow* window, int button, int action, int mods) {
    (void)mods;
    Application* app = appOf(window);
    if (!app) return;
    if (action == GLFW_PRESS) app->GetInput().OnMouseButton(button, true);
    else if (action == GLFW_RELEASE) app->GetInput().OnMouseButton(button, false);
}

void onCursorPos(GLFWwindow* window, double x, double y) {
    Application* app = appOf(window);
    if (app) app->GetInput().OnMouseMove(static_cast<f32>(x), static_cast<f32>(y));
}

void onScroll(GLFWwindow* window, double dx, double dy) {
    Application* app = appOf(window);
    if (app) app->GetInput().OnMouseScroll(static_cast<f32>(dx), static_cast<f32>(dy));
}

void onFocus(GLFWwindow* window, int focused) {
    Application* app = appOf(window);
    if (app && !focused) app->GetInput().OnFocusLost();
}

} // namespace

Application::Application() = default;

Application::~Application() { Shutdown(); }

bool Application::Init(const AppConfig& config) {
    config_ = config;

    glfwSetErrorCallback(glfwErrorCallback);
    if (!glfwInit()) {
        M7N_LOG_ERROR("App", "glfwInit failed");
        return false;
    }

    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_VISIBLE, config_.visible ? GLFW_TRUE : GLFW_FALSE);
    glfwWindowHint(GLFW_RESIZABLE, config_.resizable ? GLFW_TRUE : GLFW_FALSE);

    window_ = glfwCreateWindow(static_cast<int>(config_.width),
                               static_cast<int>(config_.height),
                               config_.title.c_str(), nullptr, nullptr);
    if (!window_) {
        M7N_LOG_ERROR("App", "window creation failed");
        glfwTerminate();
        return false;
    }

    glfwMakeContextCurrent(window_);
    glfwSwapInterval(config_.vsync ? 1 : 0);

    if (!gladLoadGLLoader(reinterpret_cast<GLADloadproc>(glfwGetProcAddress))) {
        M7N_LOG_ERROR("App", "gladLoadGLLoader failed");
        return false;
    }

    glfwSetWindowUserPointer(window_, this);

    device_ = RHI::CreateGLDevice();
    if (!device_) {
        M7N_LOG_ERROR("App", "RHI device creation failed");
        return false;
    }

    i32 initialW = 0, initialH = 0;
    glfwGetFramebufferSize(window_, &initialW, &initialH);
    width_ = initialW > 0 ? static_cast<u32>(initialW) : config_.width;
    height_ = initialH > 0 ? static_cast<u32>(initialH) : config_.height;

    installCallbacks(window_);
    M7N_LOG_INFO("App", "started %ux%u \"%s\"", width_, height_, config_.title.c_str());
    return true;
}

void Application::installCallbacks(GLFWwindow* window) {
    glfwSetKeyCallback(window, onKey);
    glfwSetMouseButtonCallback(window, onMouseButton);
    glfwSetCursorPosCallback(window, onCursorPos);
    glfwSetScrollCallback(window, onScroll);
    glfwSetWindowFocusCallback(window, onFocus);
}

int Application::Run(u32 maxFrames) {
    if (!window_ || !device_) return 1;
    if (!started_) {
        if (!OnStartup()) {
            M7N_LOG_ERROR("App", "OnStartup failed");
            return 1;
        }
        started_ = true;
        OnResize(width_, height_);
    }

    FixedStepAccumulator fixed(config_.fixedStep, config_.maxFixedSteps);

    u32 frame = 0;
    while (!glfwWindowShouldClose(window_)) {
        // NewFrame 必须早于事件轮询，否则本帧 pressed 边缘会被清掉
        input_.NewFrame();
        glfwPollEvents();

        i32 fbW = 0, fbH = 0;
        glfwGetFramebufferSize(window_, &fbW, &fbH);
        if (fbW > 0 && fbH > 0 &&
            (static_cast<u32>(fbW) != width_ || static_cast<u32>(fbH) != height_)) {
            width_ = static_cast<u32>(fbW);
            height_ = static_cast<u32>(fbH);
            OnResize(width_, height_);
        }

        f32 dt = timer_.Tick();
        // 防止调试器断点后一帧巨大步长（固定步长有自身保护）
        if (dt > 0.25f) dt = 0.25f;

        if (config_.fixedStep > 0.0f) {
            fixed.Advance(dt, [this](f32 step) { OnFixedUpdate(step); });
        }
        OnUpdate(dt);
        OnRender(dt);

        if (!pendingScreenshot_.empty()) {
            captureToBmp(pendingScreenshot_);
            pendingScreenshot_.clear();
        }

        glfwSwapBuffers(window_);
        ++frame;
        if (maxFrames > 0 && frame >= maxFrames) break;
    }
    return 0;
}

void Application::RequestQuit() {
    if (window_) glfwSetWindowShouldClose(window_, GLFW_TRUE);
}

void Application::RequestScreenshot(const String& path) { pendingScreenshot_ = path; }

bool Application::SaveScreenshot(const String& path) { return captureToBmp(path); }

bool Application::captureToBmp(const String& path) {
    if (!window_) return false;

    i32 w = 0, h = 0;
    glfwGetFramebufferSize(window_, &w, &h);
    if (w <= 0 || h <= 0) return false;

    std::vector<u8> rgba(static_cast<size_t>(w) * static_cast<size_t>(h) * 4);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    // 双缓冲默认后备缓冲即读取源（GL_BACK），无需 glReadBuffer
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, rgba.data());

    const u32 rowBytes = static_cast<u32>(w) * 3u;
    const u32 padded = (rowBytes + 3u) & ~3u;
    const u32 imageSize = padded * static_cast<u32>(h);
    const u32 fileSize = 54u + imageSize;

    std::FILE* file = std::fopen(path.c_str(), "wb");
    if (!file) {
        M7N_LOG_ERROR("App", "screenshot: cannot open %s", path.c_str());
        return false;
    }

    u8 header[54] = {};
    header[0] = 'B'; header[1] = 'M';
    auto put32 = [&](u32 offset, u32 value) {
        header[offset + 0] = static_cast<u8>(value & 0xFF);
        header[offset + 1] = static_cast<u8>((value >> 8) & 0xFF);
        header[offset + 2] = static_cast<u8>((value >> 16) & 0xFF);
        header[offset + 3] = static_cast<u8>((value >> 24) & 0xFF);
    };
    put32(2, fileSize);
    put32(10, 54);
    put32(14, 40);
    put32(18, static_cast<u32>(w));
    put32(22, static_cast<u32>(h));
    header[26] = 1;   // planes
    header[28] = 24;  // bpp
    put32(34, imageSize);
    put32(38, 2835);  // 72 DPI
    put32(42, 2835);

    std::fwrite(header, 1, sizeof(header), file);

    // BMP 行序为自下而上，与 glReadPixels 一致；RGBA -> BGR。
    std::vector<u8> row(padded, 0);
    for (i32 y = 0; y < h; ++y) {
        const u8* src = rgba.data() + static_cast<size_t>(y) * static_cast<size_t>(w) * 4;
        for (i32 x = 0; x < w; ++x) {
            row[static_cast<size_t>(x) * 3 + 0] = src[static_cast<size_t>(x) * 4 + 2];
            row[static_cast<size_t>(x) * 3 + 1] = src[static_cast<size_t>(x) * 4 + 1];
            row[static_cast<size_t>(x) * 3 + 2] = src[static_cast<size_t>(x) * 4 + 0];
        }
        std::fwrite(row.data(), 1, padded, file);
    }
    std::fclose(file);
    M7N_LOG_INFO("App", "screenshot saved: %s (%dx%d)", path.c_str(), w, h);
    return true;
}

f64 Application::GetTime() const {
    return window_ ? glfwGetTime() : 0.0;
}

void Application::SetTitle(const String& title) {
    if (window_) glfwSetWindowTitle(window_, title.c_str());
}

void Application::SetVsync(bool enabled) {
    if (window_) glfwSwapInterval(enabled ? 1 : 0);
}

void Application::Shutdown() {
    if (shutdown_) return;
    shutdown_ = true;

    if (window_) glfwMakeContextCurrent(window_);
    if (started_) {
        OnShutdown();
        started_ = false;
    }
    device_.reset();
    if (window_) {
        glfwDestroyWindow(window_);
        window_ = nullptr;
        glfwTerminate();
    }
}

} // namespace M7N
