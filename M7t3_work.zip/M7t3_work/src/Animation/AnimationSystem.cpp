/**
 * @file AnimationSystem.cpp
 * @brief 动画系统实现：四元数插值采样 + 姿态级联 + 调色板。
 *
 * 四元数 slerp 自 M7T1 Animation.cpp 平移（自包含实现，避免精简
 * glm 的版本差异）；调色板 = global(j) * inverseBind(j)，与
 * M7T1 验证过的蒙皮矩阵约定一致。
 */
#include "M7N/Animation/AnimationSystem.hpp"

#include <algorithm>
#include <cmath>

namespace M7N::Animation {

namespace {

/// 四元数球面插值（自包含；近共线时退化为归一化 lerp）。
/// 本库四元数为 (x,y,z,w) 布局（见 glm.hpp 自定义 quat）。
Quat quatSlerp(const Quat& a, const Quat& b, f32 t) {
    f32 cosTheta = a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w;
    Quat bb = b;
    if (cosTheta < 0.0f) {
        bb = Quat(-b.x, -b.y, -b.z, -b.w);
        cosTheta = -cosTheta;
    }
    if (cosTheta > 0.9995f) {
        Quat r(a.x + t * (bb.x - a.x),
               a.y + t * (bb.y - a.y),
               a.z + t * (bb.z - a.z),
               a.w + t * (bb.w - a.w));
        return glm::normalize(r);
    }
    const f32 theta = std::acos(cosTheta);
    const f32 sinTheta = std::sin(theta);
    const f32 wa = std::sin((1.0f - t) * theta) / sinTheta;
    const f32 wb = std::sin(t * theta) / sinTheta;
    return Quat(wa * a.x + wb * bb.x,
                wa * a.y + wb * bb.y,
                wa * a.z + wb * bb.z,
                wa * a.w + wb * bb.w);
}

/// TRS 组合为矩阵（T * R * S）。
Mat4 composeTRS(const Vec3& t, const Quat& r, const Vec3& s) {
    return glm::translate(Mat4(1.0f), t) * glm::mat4_cast(r) * glm::scale(Mat4(1.0f), s);
}

/// 找时间 t 落入的关键帧区间上界索引。
u32 findKey(const std::vector<f32>& times, f32 t) {
    const u32 n = static_cast<u32>(times.size());
    if (n == 0) return 0;
    for (u32 i = 1; i < n; i++) {
        if (t < times[i]) return i;
    }
    return n - 1;
}

} // namespace

// =====================================================================
// 初始化
// =====================================================================

void AnimationSystem::InitSkeletonFromAsset(const Asset::SkinData& skin,
                                            SkeletonComp& outSkeleton) {
    const size_t count = skin.joints.size();
    outSkeleton.parents.resize(count);
    outSkeleton.inverseBinds.resize(count);
    outSkeleton.restPoses.resize(count);

    for (size_t i = 0; i < count; i++) {
        const Asset::JointData& j = skin.joints[i];
        outSkeleton.parents[i] = j.parent;
        outSkeleton.inverseBinds[i] = j.inverseBind;
        outSkeleton.restPoses[i] = JointPose{ j.restTranslation, j.restRotation, j.restScale };
    }
    outSkeleton.rootMatrix = skin.rootMatrix;   // 骨架根矩阵（见 SkinData 注释）
    outSkeleton.ResetToRest();
    outSkeleton.palette.assign(count, Mat4(1.0f));
}

void AnimationSystem::InitAnimatorFromAsset(
        const std::vector<Asset::AnimationClip>& clips,
        AnimatorComp& outAnimator) {
    outAnimator.clips.clear();
    outAnimator.durations.clear();
    outAnimator.activeClip = -1;
    outAnimator.playing = false;
    outAnimator.time = 0.0f;

    outAnimator.clips.reserve(clips.size());
    outAnimator.durations.reserve(clips.size());
    for (const Asset::AnimationClip& c : clips) {
        outAnimator.clips.push_back(c.channels);
        outAnimator.durations.push_back(c.duration);
    }
}

// =====================================================================
// 调色板
// =====================================================================

void AnimationSystem::ComputePalette(SkeletonComp& skeleton) {
    const u32 count = skeleton.JointCount();
    if (count == 0) return;

    // 全局矩阵（列主序：globals[i] = globals[parent] * local，父变换左乘）。
    // 【不能】假设 joints 数组父在前子在后 —— glTF 规范没这个保证，
    // Quaternius 的士兵模型就不是（Hips 排第 3，它的子孙排在它前面）。
    // 单趟扫描会拿未解算的父节点当单位阵用，整棵树的级联全错，
    // 表现为"模型整体消失"（顶点被扔到无穷远）。所以按拓扑序反复求解。
    static thread_local std::vector<Mat4> globals;
    static thread_local std::vector<u8>   resolved;
    globals.assign(count, Mat4(1.0f));
    resolved.assign(count, 0);

    u32 remaining = count;
    while (remaining > 0) {
        const u32 before = remaining;
        for (u32 i = 0; i < count; i++) {
            if (resolved[i]) continue;
            const i32 parent = skeleton.parents[i];
            if (parent >= 0 && !resolved[static_cast<u32>(parent)]) continue;
            const JointPose& p = skeleton.localPoses[i];
            const Mat4 local = composeTRS(p.translation, p.rotation, p.scale);
            globals[i] = (parent >= 0)
                ? globals[static_cast<u32>(parent)] * local : local;
            resolved[i] = 1;
            remaining--;
        }
        if (remaining == before) break;   // 有环（非法骨骼数据）：剩余按单位阵处理
    }

    if (skeleton.palette.size() != count) skeleton.palette.resize(count);
    // 骨架根矩阵乘在最外层：蒙皮顶点生活在骨架根的局部空间（Mixamo 是
    // 厘米+Z-up），由它统一换算到世界空间。无缩放/旋转的模型它是单位阵。
    const Mat4 rootMat = skeleton.rootMatrix;
    for (u32 i = 0; i < count; i++) {
        skeleton.palette[i] = rootMat * globals[i] * skeleton.inverseBinds[i];
    }
}

// =====================================================================
// 帧更新
// =====================================================================

void AnimationSystem::Evaluate(ECS::Entity e, ECS::World& world, f32 dt) {
    AnimatorComp* animator = world.GetComponent<AnimatorComp>(e);
    SkeletonComp* skeleton = world.GetComponent<SkeletonComp>(e);
    if (!animator || !skeleton) return;
    if (!animator->playing || animator->activeClip < 0) {
        ComputePalette(*skeleton);
        return;
    }

    // --- 时间推进 ---
    animator->time += dt * animator->speed;
    const f32 duration = animator->Duration();
    if (duration > 0.0f) {
        if (animator->looping) {
            animator->time = std::fmod(animator->time, duration);
        } else if (animator->time >= duration) {
            animator->time = duration;
            animator->playing = false;   // 播完停在末帧
        }
    }

    // --- 采样通道写姿态 ---
    const u32 clipIndex = static_cast<u32>(animator->activeClip);
    if (clipIndex >= animator->clips.size()) return;
    skeleton->ResetToRest();   // 无通道关节保持绑定姿态

    const f32 t = animator->time;
    for (const Asset::AnimChannel& ch : animator->clips[clipIndex]) {
        if (ch.jointIndex >= skeleton->JointCount()) continue;
        if (ch.times.empty()) continue;

        JointPose& pose = skeleton->localPoses[ch.jointIndex];
        const u32 hi = findKey(ch.times, t);
        const u32 lo = (hi > 0) ? hi - 1 : 0;

        if (hi == 0 || ch.interp == Asset::AnimInterp::Step || hi == lo) {
            // 首帧前钳制 / 阶跃插值
            if (ch.path == Asset::AnimPath::Rotation) {
                if (!ch.quatKeys.empty()) pose.rotation = ch.quatKeys[lo];
            } else if (!ch.vecKeys.empty()) {
                if (ch.path == Asset::AnimPath::Translation) pose.translation = ch.vecKeys[lo];
                else pose.scale = ch.vecKeys[lo];
            }
            continue;
        }

        const f32 span = ch.times[hi] - ch.times[lo];
        f32 u = (span > 0.0001f) ? (t - ch.times[lo]) / span : 0.0f;
        u = std::clamp(u, 0.0f, 1.0f);

        if (ch.path == Asset::AnimPath::Rotation) {
            if (ch.quatKeys.size() > hi) {
                pose.rotation = quatSlerp(ch.quatKeys[lo], ch.quatKeys[hi], u);
            }
        } else if (ch.vecKeys.size() > hi) {
            const Vec3 v = glm::mix(ch.vecKeys[lo], ch.vecKeys[hi], u);
            if (ch.path == Asset::AnimPath::Translation) pose.translation = v;
            else pose.scale = v;
        }
    }

    ComputePalette(*skeleton);
}

void AnimationSystem::OnUpdate(ECS::World& world, f32 dt) {
    world.ForEach<AnimatorComp, SkeletonComp>(
        [&](ECS::Entity e, AnimatorComp&, SkeletonComp&) {
            Evaluate(e, world, dt);
        });
}

} // namespace M7N::Animation
