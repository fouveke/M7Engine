/**
 * @file Animation2D.cpp
 * @brief 精灵帧动画推进与 UV 同步。
 */
#include "M7N/2D/Animation2D.hpp"
#include "M7N/2D/Math2D.hpp"

#include <algorithm>
#include <cmath>

namespace M7N::Dim2 {

namespace {

void writeUv(const SpriteAnimatorComp& anim, SpriteComp& sprite) {
    if (anim.columns <= 0 || anim.rows <= 0) return;
    u32 frame = static_cast<u32>(std::max(anim.ResolveFrame(), 0));
    const u32 total = static_cast<u32>(anim.columns) * static_cast<u32>(anim.rows);
    if (total > 0) frame %= total;
    sprite.uv = FrameUV(frame, static_cast<u32>(anim.columns),
                        static_cast<u32>(anim.rows));
}

} // namespace

void SpriteAnimatorSystem::OnUpdate(ECS::World& world, f32 dt) {
    world.ForEach<SpriteAnimatorComp, SpriteComp>(
        [&](ECS::Entity, SpriteAnimatorComp& anim, SpriteComp& sprite) {
            if (!anim.playing || anim.frameCount <= 1 || anim.fps <= 0.0f || dt <= 0.0f) {
                writeUv(anim, sprite);
                return;
            }

            const f32 frameDuration = 1.0f / (anim.fps * std::max(anim.speed, 0.01f));
            anim.time += dt;

            // 大 dt 下限制最大推进帧数，避免死循环
            i32 steps = static_cast<i32>(anim.time / frameDuration);
            if (steps <= 0) return;
            anim.time -= static_cast<f32>(steps) * frameDuration;
            steps = std::min(steps, std::max(anim.frameCount * 4, 8));

            for (i32 i = 0; i < steps; ++i) {
                if (anim.pingPong) {
                    anim.currentFrame += anim.direction;
                    if (anim.currentFrame >= anim.frameCount - 1) {
                        anim.currentFrame = anim.frameCount - 1;
                        if (anim.loop) anim.direction = -1;
                        else { anim.playing = false; break; }
                    } else if (anim.currentFrame <= 0) {
                        anim.currentFrame = 0;
                        if (anim.loop) anim.direction = 1;
                        else { anim.playing = false; break; }
                    }
                } else {
                    anim.currentFrame++;
                    if (anim.currentFrame >= anim.frameCount) {
                        if (anim.loop) anim.currentFrame = 0;
                        else {
                            anim.currentFrame = anim.frameCount - 1;
                            anim.playing = false;
                            break;
                        }
                    }
                }
            }

            writeUv(anim, sprite);
        });
}

} // namespace M7N::2D
