/**
 * @file Renderer2D.cpp
 * @brief 2D 批渲染器实现：排序 -> 剔除 -> 批次录制 -> 命令流提交。
 */
#include "M7N/2D/Renderer2D.hpp"
#include "M7N/Core/Log.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <limits>
#include <utility>

namespace M7N::Dim2 {

using M7N::Scene::ComputeWorldMatrix;
using M7N::Scene::Transform;
using M7N::Scene::TransformSystem;

// =====================================================================
// 相机
// =====================================================================

Mat4 Camera2D::ViewProjection() const {
    // view = R(-rot) * T(-pos)
    Mat4 view = glm::rotate(Mat4(1.0f), -rotation, Vec3(0.0f, 0.0f, 1.0f));
    view = glm::translate(view, Vec3(-position.x, -position.y, 0.0f));
    const f32 halfH = orthoHeight * 0.5f;
    const f32 halfW = halfH * (aspect > 0.0001f ? aspect : 1.0f);
    const Mat4 proj = glm::ortho(-halfW, halfW, -halfH, halfH, nearZ, farZ);
    return proj * view;
}

Rect2D Camera2D::WorldBounds() const {
    const f32 halfH = orthoHeight * 0.5f;
    const f32 halfW = halfH * (aspect > 0.0001f ? aspect : 1.0f);

    // 视图逆变换：T(pos) * R(rot)
    Mat4 invView = glm::translate(Mat4(1.0f), Vec3(position.x, position.y, 0.0f));
    invView = glm::rotate(invView, rotation, Vec3(0.0f, 0.0f, 1.0f));

    Rect2D bounds;
    bounds.min = Vec2(std::numeric_limits<f32>::max(), std::numeric_limits<f32>::max());
    bounds.max = Vec2(std::numeric_limits<f32>::lowest(), std::numeric_limits<f32>::lowest());
    const Vec2 corners[4] = {
        Vec2(-halfW, -halfH), Vec2(halfW, -halfH),
        Vec2(halfW, halfH), Vec2(-halfW, halfH),
    };
    for (const Vec2& c : corners) {
        const Vec2 w = TransformPoint(invView, c);
        bounds.min.x = std::min(bounds.min.x, w.x);
        bounds.min.y = std::min(bounds.min.y, w.y);
        bounds.max.x = std::max(bounds.max.x, w.x);
        bounds.max.y = std::max(bounds.max.y, w.y);
    }
    return bounds;
}

Vec2 Camera2D::WorldToScreen(const Vec2& world, const Vec2& viewport) const {
    const f32 halfH = orthoHeight * 0.5f;
    const f32 halfW = halfH * (aspect > 0.0001f ? aspect : 1.0f);
    const Vec2 d = world - position;
    const f32 c = std::cos(-rotation);
    const f32 s = std::sin(-rotation);
    const Vec2 viewPt(c * d.x - s * d.y, s * d.x + c * d.y);
    const f32 ndcX = (viewPt.x / halfW) * 0.5f + 0.5f;
    const f32 ndcY = (viewPt.y / halfH) * 0.5f + 0.5f;
    return Vec2(ndcX * viewport.x, (1.0f - ndcY) * viewport.y);
}

Vec2 Camera2D::ScreenToWorld(const Vec2& screen, const Vec2& viewport) const {
    const f32 halfH = orthoHeight * 0.5f;
    const f32 halfW = halfH * (aspect > 0.0001f ? aspect : 1.0f);
    const f32 ndcX = (viewport.x > 0.0001f) ? (screen.x / viewport.x) * 2.0f - 1.0f : 0.0f;
    const f32 ndcY = (viewport.y > 0.0001f) ? 1.0f - (screen.y / viewport.y) * 2.0f : 0.0f;
    const Vec2 viewPt(ndcX * halfW, ndcY * halfH);
    const f32 c = std::cos(rotation);
    const f32 s = std::sin(rotation);
    return position + Vec2(c * viewPt.x - s * viewPt.y,
                           s * viewPt.x + c * viewPt.y);
}

Camera2D MakeCamera2D(const ECS::World& world, ECS::Entity cameraEntity,
                      f32 aspect) {
    Camera2D camera;
    camera.aspect = aspect > 0.0001f ? aspect : 1.0f;

    const Camera2DComp* comp = world.GetComponent<Camera2DComp>(cameraEntity);
    const Transform* tf = world.GetComponent<Transform>(cameraEntity);
    if (comp) {
        camera.orthoHeight = comp->orthoHeight;
        camera.nearZ = comp->nearZ;
        camera.farZ = comp->farZ;
        camera.clearColor = comp->clearColor;
        camera.clear = comp->clearScreen;
    }
    if (tf) {
        const Mat4 m = ComputeWorldMatrix(world, cameraEntity);
        camera.position = Vec2(m.m[12], m.m[13]);
        camera.rotation = std::atan2(m.m[1], m.m[0]);
        const f32 scaleY = std::sqrt(m.m[4] * m.m[4] + m.m[5] * m.m[5]);
        if (scaleY > 0.0001f) camera.orthoHeight /= scaleY;
    }
    return camera;
}

ECS::Entity FindPrimaryCamera2D(const ECS::World& world) {
    ECS::Entity fallback = ECS::kNullEntity;
    ECS::Entity result = ECS::kNullEntity;
    world.ForEach<Camera2DComp>([&](ECS::Entity e, Camera2DComp& cam) {
        if (!fallback.IsValid()) fallback = e;
        if (cam.primary && !result.IsValid()) result = e;
    });
    return result.IsValid() ? result : fallback;
}

// =====================================================================
// 生命周期
// =====================================================================

namespace {

constexpr const char* kSpriteVert = R"(
#version 330 core
layout(location = 0) in vec2 a_Position;
layout(location = 1) in vec2 a_TexCoord;
layout(location = 2) in vec4 a_Color;
uniform mat4 u_ViewProjection;
out vec2 v_TexCoord;
out vec4 v_Color;
void main() {
    v_TexCoord = a_TexCoord;
    v_Color = a_Color;
    gl_Position = u_ViewProjection * vec4(a_Position, 0.0, 1.0);
}
)";

constexpr const char* kSpriteFrag = R"(
#version 330 core
in vec2 v_TexCoord;
in vec4 v_Color;
uniform sampler2D u_Texture;
out vec4 FragColor;
void main() {
    vec4 texel = texture(u_Texture, v_TexCoord);
    vec4 color = texel * v_Color;
    if (color.a < 0.003) discard;
    FragColor = color;
}
)";

constexpr u32 kFloatsPerVertex = 8;              // pos2 + uv2 + rgba4
constexpr u32 kVertexStrideBytes = kFloatsPerVertex * sizeof(f32);

} // namespace

Renderer2D::Renderer2D(RHI::IRenderDevice& device, Asset::AssetManager& assets)
    : device_(device), assets_(assets) {}

Renderer2D::~Renderer2D() { Shutdown(); }

bool Renderer2D::Init(u32 maxQuadsPerBatch) {
    maxQuads_ = maxQuadsPerBatch > 0 ? maxQuadsPerBatch : 1;

    shader_ = device_.CreateShader({ kSpriteVert, kSpriteFrag });
    if (!shader_.IsValid()) {
        M7N_LOG_ERROR("2D", "sprite shader creation failed");
        return false;
    }

    RHI::PipelineDesc desc;
    desc.shader = shader_;
    desc.layout = {
        { 0, 2, kVertexStrideBytes, 0, false },
        { 1, 2, kVertexStrideBytes, 8, false },
        { 2, 4, kVertexStrideBytes, 16, false },
    };
    desc.depthTest = false;
    desc.depthWrite = false;
    desc.cull = false;
    desc.blend = true;
    desc.blendMode = RHI::BlendMode::Alpha;
    alphaPipeline_ = device_.CreatePipeline(desc);

    desc.blendMode = RHI::BlendMode::Additive;
    additivePipeline_ = device_.CreatePipeline(desc);
    if (!alphaPipeline_.IsValid() || !additivePipeline_.IsValid()) {
        M7N_LOG_ERROR("2D", "sprite pipeline creation failed");
        return false;
    }

    // 动态顶点缓冲（每批上传实际数据）
    RHI::BufferDesc vb;
    vb.size = maxQuads_ * 4u * kVertexStrideBytes;
    vb.usage = RHI::BufferUsage::Vertex;
    vb.dynamic = true;
    vbo_ = device_.CreateBuffer(vb);
    if (!vbo_.IsValid()) return false;

    // 静态四边形索引（0,1,2, 0,2,3）重复
    std::vector<u32> indices;
    indices.resize(static_cast<size_t>(maxQuads_) * 6);
    for (u32 q = 0; q < maxQuads_; ++q) {
        const u32 base = q * 4;
        u32* dst = &indices[static_cast<size_t>(q) * 6];
        dst[0] = base + 0; dst[1] = base + 1; dst[2] = base + 2;
        dst[3] = base + 0; dst[4] = base + 2; dst[5] = base + 3;
    }
    RHI::BufferDesc ib;
    ib.data = indices.data();
    ib.size = static_cast<u32>(indices.size() * sizeof(u32));
    ib.usage = RHI::BufferUsage::Index;
    ibo_ = device_.CreateBuffer(ib);
    if (!ibo_.IsValid()) return false;

    // 1x1 白纹理（纯色矩形/调试线）
    const u8 white[4] = { 255, 255, 255, 255 };
    RHI::TextureDesc tex;
    tex.width = 1;
    tex.height = 1;
    tex.format = RHI::Format::RGBA8;
    tex.pixels = white;
    tex.filter = RHI::TextureFilter::Nearest;
    whiteTexture_ = device_.CreateTexture(tex);

    items_.reserve(1024);
    batchVertices_.reserve(static_cast<size_t>(maxQuads_) * 4);

    M7N_LOG_INFO("2D", "renderer ready: max %u quads/batch", maxQuads_);
    return whiteTexture_.IsValid();
}

void Renderer2D::Shutdown() {
    if (whiteTexture_.IsValid()) { device_.DestroyTexture(whiteTexture_); whiteTexture_ = {}; }
    if (ibo_.IsValid()) { device_.DestroyBuffer(ibo_); ibo_ = {}; }
    if (vbo_.IsValid()) { device_.DestroyBuffer(vbo_); vbo_ = {}; }
    if (alphaPipeline_.IsValid()) { device_.DestroyPipeline(alphaPipeline_); alphaPipeline_ = {}; }
    if (additivePipeline_.IsValid()) { device_.DestroyPipeline(additivePipeline_); additivePipeline_ = {}; }
    if (shader_.IsValid()) { device_.DestroyShader(shader_); shader_ = {}; }
}

void Renderer2D::OnResize(u32 width, u32 height) {
    viewportW_ = width > 0 ? width : 1;
    viewportH_ = height > 0 ? height : 1;
}

// =====================================================================
// 帧
// =====================================================================

void Renderer2D::BeginScene(const Camera2D& camera) {
    camera_ = camera;
    viewProj_ = camera_.ViewProjection();
    cameraBounds_ = camera_.WorldBounds();

    inScene_ = true;
    sequence_ = 0;
    items_.clear();
    stats_ = Renderer2DStats{};
    batchQuads_ = 0;
    batchTexture_ = {};
    batchBlend_ = 0;
    batchVertices_.clear();

    cmd_.Reset();
    cmd_.BindFramebuffer({});
    cmd_.SetViewport(0, 0, static_cast<i32>(viewportW_), static_cast<i32>(viewportH_));
    if (camera_.clear) {
        cmd_.Clear(camera_.clearColor.x, camera_.clearColor.y,
                   camera_.clearColor.z, camera_.clearColor.w, true);
    }
}

void Renderer2D::RenderFrame(ECS::World& world, const Camera2D& camera,
                              f32 dtSeconds) {
    BeginScene(camera);
    Submit(world, dtSeconds);
    EndScene();
}

void Renderer2D::RenderFrameAuto(ECS::World& world, f32 dtSeconds) {
    transformSystem_.OnUpdate(world);
    const ECS::Entity camEntity = FindPrimaryCamera2D(world);
    const Camera2D camera = MakeCamera2D(world, camEntity, GetAspectSafe());
    RenderFrame(world, camera, dtSeconds);
}

// =====================================================================
// 收集
// =====================================================================

void Renderer2D::Submit(ECS::World& world, f32 dtSeconds) {
    if (!inScene_) return;

    if (dtSeconds > 0.0f) SpriteAnimatorSystem::OnUpdate(world, dtSeconds);
    transformSystem_.OnUpdate(world);

    collectTilemaps(world);   // 先收集；排序会保证层次
    collectSprites(world);
}

void Renderer2D::collectSprites(ECS::World& world) {
    world.ForEach<Transform, SpriteComp>(
        [&](ECS::Entity e, Transform&, SpriteComp& sprite) {
            if (!sprite.visible) return;

            Asset::TextureInfo info;
            const bool hasTexture = !sprite.texture.empty() &&
                                    assets_.GetTextureInfo(sprite.texture, info,
                                                           sprite.pixelArt);
            if (!sprite.texture.empty() && !hasTexture) return;   // 纹理加载失败

            Vec2 size = sprite.size;
            if (hasTexture) {
                const f32 ppu = sprite.pixelsPerUnit > 0.0001f ? sprite.pixelsPerUnit : 100.0f;
                const f32 texW = static_cast<f32>(info.width) / ppu;
                const f32 texH = static_cast<f32>(info.height) / ppu;
                if (size.x <= 0.0f && size.y <= 0.0f) {
                    size = Vec2(texW, texH);
                } else if (size.x <= 0.0f) {
                    size.x = (texH > 0.0001f) ? size.y * (texW / texH) : size.y;
                } else if (size.y <= 0.0f) {
                    size.y = (texW > 0.0001f) ? size.x * (texH / texW) : size.x;
                }
            } else {
                if (size.x <= 0.0f && size.y <= 0.0f) size = Vec2(1.0f);
                else if (size.x <= 0.0f) size.x = size.y;
                else if (size.y <= 0.0f) size.y = size.x;
            }

            const f32 x0 = -sprite.pivot.x * size.x;
            const f32 y0 = -sprite.pivot.y * size.y;
            const f32 x1 = x0 + size.x;
            const f32 y1 = y0 + size.y;

            const Mat4 worldM = TransformSystem::GetWorldMatrix(world, e);
            Vec2 corners[4] = {
                TransformPoint(worldM, Vec2(x0, y0)),
                TransformPoint(worldM, Vec2(x1, y0)),
                TransformPoint(worldM, Vec2(x1, y1)),
                TransformPoint(worldM, Vec2(x0, y1)),
            };

            Rect2D aabb = Rect2D::FromCenterSize(corners[0], Vec2(0.0f));
            aabb = UnionRect(aabb, Rect2D::FromCenterSize(corners[1], Vec2(0.0f)));
            aabb = UnionRect(aabb, Rect2D::FromCenterSize(corners[2], Vec2(0.0f)));
            aabb = UnionRect(aabb, Rect2D::FromCenterSize(corners[3], Vec2(0.0f)));

            stats_.sprites++;
            if (!aabb.Intersects(cameraBounds_)) {
                stats_.culled++;
                return;
            }

            RHI::TextureHandle texture = hasTexture ? info.handle : whiteTexture_;
            Vec4 uv = sprite.uv;
            if (sprite.flipX) std::swap(uv.x, uv.z);
            if (sprite.flipY) std::swap(uv.y, uv.w);

            pushItem(texture, sprite.layer, sprite.order, sprite.blendMode,
                     corners, uv, sprite.color);
        });
}

void Renderer2D::collectTilemaps(ECS::World& world) {
    world.ForEach<Transform, TilemapComp>(
        [&](ECS::Entity e, Transform&, TilemapComp& map) {
            if (!map.visible || map.columns <= 0 || map.rows <= 0 ||
                map.tileWorldSize <= 0.0f) {
                return;
            }
            Asset::TextureInfo info;
            if (map.texture.empty() ||
                !assets_.GetTextureInfo(map.texture, info, map.pixelArt)) {
                return;
            }

            const Mat4 worldM = TransformSystem::GetWorldMatrix(world, e);
            const Rect2D local = Rect2D{
                map.origin,
                Vec2(map.origin.x + static_cast<f32>(map.columns) * map.tileWorldSize,
                     map.origin.y + static_cast<f32>(map.rows) * map.tileWorldSize),
            };
            if (!TransformRectToAABB(worldM, local).Intersects(cameraBounds_)) {
                stats_.culled += static_cast<u32>(map.columns * map.rows);
                return;
            }

            const u32 atlasCols = static_cast<u32>(map.atlasColumns > 0 ? map.atlasColumns : 1);
            const u32 atlasRows = static_cast<u32>(map.atlasRows > 0 ? map.atlasRows : 1);
            const size_t tileCount = static_cast<size_t>(map.columns) *
                                     static_cast<size_t>(map.rows);

            for (i32 y = 0; y < map.rows; ++y) {
                for (i32 x = 0; x < map.columns; ++x) {
                    const size_t index = static_cast<size_t>(y) *
                                         static_cast<size_t>(map.columns) +
                                         static_cast<size_t>(x);
                    if (index >= map.tiles.size()) continue;
                    const i32 tile = map.tiles[index];
                    if (tile < 0) continue;

                    const f32 px = map.origin.x + static_cast<f32>(x) * map.tileWorldSize;
                    const f32 py = map.origin.y + static_cast<f32>(y) * map.tileWorldSize;
                    const f32 px1 = px + map.tileWorldSize;
                    const f32 py1 = py + map.tileWorldSize;

                    Vec2 corners[4] = {
                        TransformPoint(worldM, Vec2(px, py)),
                        TransformPoint(worldM, Vec2(px1, py)),
                        TransformPoint(worldM, Vec2(px1, py1)),
                        TransformPoint(worldM, Vec2(px, py1)),
                    };

                    // 单瓦片剔除（旋转地图用角点 AABB，保守但正确）
                    Rect2D tileAabb = Rect2D::FromCenterSize(corners[0], Vec2(0.0f));
                    tileAabb = UnionRect(tileAabb, Rect2D::FromCenterSize(corners[1], Vec2(0.0f)));
                    tileAabb = UnionRect(tileAabb, Rect2D::FromCenterSize(corners[2], Vec2(0.0f)));
                    tileAabb = UnionRect(tileAabb, Rect2D::FromCenterSize(corners[3], Vec2(0.0f)));
                    if (!tileAabb.Intersects(cameraBounds_)) {
                        stats_.culled++;
                        continue;
                    }

                    const Vec4 uv = FrameUV(static_cast<u32>(tile), atlasCols, atlasRows);
                    pushItem(info.handle, map.layer, map.order, 0, corners, uv, map.tint);
                    stats_.tiles++;
                }
            }
            (void)tileCount;
        });
}

// =====================================================================
// 批次
// =====================================================================

void Renderer2D::pushItem(RHI::TextureHandle texture, i32 layer, i32 order,
                          i32 blend, const Vec2 corners[4], const Vec4& uv,
                          const Vec4& color) {
    DrawItem item;
    item.texture = texture;
    item.layer = layer;
    item.order = order;
    item.blend = blend;
    for (u32 i = 0; i < 4; ++i) item.corners[i] = corners[i];
    item.uv = uv;
    item.color = color;
    item.sequence = sequence_++;
    items_.push_back(item);
}

RHI::PipelineHandle Renderer2D::pipelineFor(i32 blend) const {
    return (blend == static_cast<i32>(SpriteBlendMode::Additive))
               ? additivePipeline_ : alphaPipeline_;
}

void Renderer2D::flushBatch() {
    if (!batchTexture_.IsValid() || batchQuads_ == 0) {
        batchQuads_ = 0;
        batchVertices_.clear();
        batchTexture_ = {};
        batchBlend_ = 0;
        return;
    }

    cmd_.BindPipeline(pipelineFor(batchBlend_));
    cmd_.SetMat4("u_ViewProjection", viewProj_);
    cmd_.UpdateBuffer(vbo_, batchVertices_.data(),
                      static_cast<u32>(batchVertices_.size() * sizeof(Vertex)));
    cmd_.BindVertexBuffer(vbo_);
    cmd_.BindIndexBuffer(ibo_);
    cmd_.BindTexture("u_Texture", 0, batchTexture_);
    cmd_.DrawIndexed(batchQuads_ * 6, 0);

    stats_.drawCalls++;
    stats_.batches++;
    stats_.quads += batchQuads_;

    batchQuads_ = 0;
    batchVertices_.clear();
    batchTexture_ = {};
    batchBlend_ = 0;
}

void Renderer2D::EndScene() {
    if (!inScene_) return;

    std::stable_sort(items_.begin(), items_.end(),
                     [](const DrawItem& a, const DrawItem& b) {
                         if (a.layer != b.layer) return a.layer < b.layer;
                         if (a.order != b.order) return a.order < b.order;
                         if (a.blend != b.blend) return a.blend < b.blend;
                         if (a.texture.id != b.texture.id) return a.texture.id < b.texture.id;
                         return a.sequence < b.sequence;
                     });

    for (const DrawItem& item : items_) {
        const bool textureChanged = !batchTexture_.IsValid() ||
                                    item.texture.id != batchTexture_.id;
        const bool blendChanged = item.blend != batchBlend_;
        if ((textureChanged || blendChanged || batchQuads_ >= maxQuads_) &&
            batchQuads_ > 0) {
            flushBatch();
        }
        if (!batchTexture_.IsValid()) {
            batchTexture_ = item.texture;
            batchBlend_ = item.blend;
        }

        const f32 u0 = item.uv.x, v0 = item.uv.y;
        const f32 u1 = item.uv.z, v1 = item.uv.w;
        const Vec4& c = item.color;

        auto addVertex = [&](const Vec2& p, f32 u, f32 v) {
            Vertex vert;
            vert.x = p.x; vert.y = p.y;
            vert.u = u;   vert.v = v;
            vert.r = c.x; vert.g = c.y; vert.b = c.z; vert.a = c.w;
            batchVertices_.push_back(vert);
        };
        addVertex(item.corners[0], u0, v0);
        addVertex(item.corners[1], u1, v0);
        addVertex(item.corners[2], u1, v1);
        addVertex(item.corners[3], u0, v1);
        batchQuads_++;
    }
    flushBatch();

    device_.BeginFrame();
    device_.Submit(cmd_);
    inScene_ = false;
}

// =====================================================================
// 调试绘制
// =====================================================================

void Renderer2D::DrawRect(const Vec2& center, const Vec2& size, f32 rotation,
                          const Vec4& color) {
    if (!inScene_) return;
    const f32 c = std::cos(rotation);
    const f32 s = std::sin(rotation);
    const f32 hx = size.x * 0.5f;
    const f32 hy = size.y * 0.5f;
    auto rotate = [&](f32 x, f32 y) {
        return Vec2(center.x + c * x - s * y, center.y + s * x + c * y);
    };
    Vec2 corners[4] = {
        rotate(-hx, -hy), rotate(hx, -hy), rotate(hx, hy), rotate(-hx, hy),
    };
    pushItem(whiteTexture_, 10000, 0, 0, corners,
             Vec4(0.0f, 0.0f, 1.0f, 1.0f), color);
}

void Renderer2D::DrawRectOutline(const Vec2& center, const Vec2& size, f32 rotation,
                                 f32 thickness, const Vec4& color) {
    const f32 c = std::cos(rotation);
    const f32 s = std::sin(rotation);
    const f32 hx = size.x * 0.5f;
    const f32 hy = size.y * 0.5f;
    auto rotate = [&](f32 x, f32 y) {
        return Vec2(center.x + c * x - s * y, center.y + s * x + c * y);
    };
    const Vec2 corners[4] = {
        rotate(-hx, -hy), rotate(hx, -hy), rotate(hx, hy), rotate(-hx, hy),
    };
    for (i32 i = 0; i < 4; ++i) {
        DrawLine(corners[i], corners[(i + 1) % 4], thickness, color);
    }
}

void Renderer2D::DrawLine(const Vec2& a, const Vec2& b, f32 thickness,
                          const Vec4& color) {
    if (!inScene_) return;
    Vec2 dir = b - a;
    const f32 len = std::sqrt(dir.x * dir.x + dir.y * dir.y);
    if (len < 0.0001f) return;
    dir = dir / len;
    const Vec2 normal(-dir.y, dir.x);
    const Vec2 half = normal * (thickness * 0.5f);
    Vec2 corners[4] = { a + half, b + half, b - half, a - half };
    pushItem(whiteTexture_, 10000, 0, 0, corners,
             Vec4(0.0f, 0.0f, 1.0f, 1.0f), color);
}

} // namespace M7N::2D
