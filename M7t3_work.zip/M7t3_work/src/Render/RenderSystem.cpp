/**
 * @file RenderSystem.cpp
 * @brief 前向渲染系统实现：三 pass 命令流（阴影 / PBR 场景 / ACES 后处理）。
 *
 * 着色器均内嵌（与 M7T1 验证过的实现同源）：
 *   - PBR：Cook-Torrance（GGX + Smith + Schlick），metallic/roughness 工作流
 *   - 阴影：depth-only 顶点变换（光空间矩阵）
 *   - 后处理：全屏三角（gl_VertID）+ Narkowicz ACES + gamma + 晴角
 */
#include "M7N/Render/RenderSystem.hpp"
#include "M7N/Scene/Components.hpp"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <utility>
#include <vector>

namespace M7N::Render {

using namespace M7N::RHI;
using namespace M7N::Scene;

// =====================================================================
// 内嵌着色器
// =====================================================================

namespace {

/// 程序化细节法线贴图的注册名（AssetManager 纹理缓存键）。
constexpr const char* kDetailNormalTexName = "__m7n_detail_normal";

/// 屏幕分块光照的块边长（与 PBR 片元着色器里的 /32 保持一致）。
constexpr u32 kLightTileSize = 32;

/// 生成可平铺的"机加工金属"细节法线图。
///
/// 为什么需要它：Blender 直出的硬表面模型（如 M4A1.glb）经常只有
/// POSITION/NORMAL，**没有 UV 也没有贴图**。这种模型无论材质参数怎么调，
/// 大块平面在光照下都是一片光滑的灰——这就是"白模"观感的根源。
/// 三平面采样不需要 UV，用一张程序化噪声法线就能把平面打散。
///
/// 做法：周期性值噪声叠三个倍频得到高度场，再用环形中央差分求梯度，
/// 编码成切线空间法线（+Z 为主轴）。周期取 8/16/32 且整除纹理尺寸，
/// 保证首尾相接、平铺无缝。
void MakeDetailNormalTexture(std::vector<u8>& out, u32 size) {
    out.assign(static_cast<size_t>(size) * size * 4, 0);
    const u32 N = size;

    auto hash = [](u32 x, u32 y) {
        u32 h = x * 374761393u + y * 668265263u;
        h = (h ^ (h >> 13)) * 1274126177u;
        return static_cast<f32>((h ^ (h >> 16)) & 0xFFFFu) / 65535.0f;
    };

    std::vector<f32> height(static_cast<size_t>(N) * N, 0.0f);
    // 倍频选取：周期必须是 N 的约数才能无缝平铺。低频（8/16）会形成大块斑，
    // 那是"粗糙水泥"而不是"机加工金属"——所以砍掉低频，主能量放在中高频。
    const u32 periods[4] = { 16u, 32u, 64u, 128u };
    const f32 amps[4]    = { 0.50f, 0.45f, 0.32f, 0.18f };

    for (int o = 0; o < 4; o++) {
        const u32 P    = periods[o];
        if (P > N) continue;
        const u32 cell = N / P;                      // 每个格点占多少像素
        for (u32 y = 0; y < N; y++) {
            for (u32 x = 0; x < N; x++) {
                const f32 fx = static_cast<f32>(x) / static_cast<f32>(cell);
                const f32 fy = static_cast<f32>(y) / static_cast<f32>(cell);
                const u32 x0 = static_cast<u32>(fx) % P;
                const u32 y0 = static_cast<u32>(fy) % P;
                const u32 x1 = (x0 + 1) % P;
                const u32 y1 = (y0 + 1) % P;
                f32 tx = fx - std::floor(fx);
                f32 ty = fy - std::floor(fy);
                tx = tx * tx * (3.0f - 2.0f * tx);   // smoothstep，避免格点棱线
                ty = ty * ty * (3.0f - 2.0f * ty);
                const f32 v00 = hash(x0, y0), v10 = hash(x1, y0);
                const f32 v01 = hash(x0, y1), v11 = hash(x1, y1);
                const f32 v = (v00 * (1.0f - tx) + v10 * tx) * (1.0f - ty)
                            + (v01 * (1.0f - tx) + v11 * tx) * ty;
                height[static_cast<size_t>(y) * N + x] += v * amps[o];
            }
        }
    }

    // 高度场 -> 法线（环形差分，保证平铺接缝处连续）
    constexpr f32 kGrad = 3.0f;
    for (u32 y = 0; y < N; y++) {
        for (u32 x = 0; x < N; x++) {
            const u32 xl = (x + N - 1) % N, xr = (x + 1) % N;
            const u32 yd = (y + N - 1) % N, yu = (y + 1) % N;
            const f32 hL = height[static_cast<size_t>(y) * N + xl];
            const f32 hR = height[static_cast<size_t>(y) * N + xr];
            const f32 hD = height[static_cast<size_t>(yd) * N + x];
            const f32 hU = height[static_cast<size_t>(yu) * N + x];
            f32 nx = (hL - hR) * kGrad;
            f32 ny = (hD - hU) * kGrad;
            f32 nz = 1.0f;
            const f32 inv = 1.0f / std::sqrt(nx * nx + ny * ny + nz * nz);
            nx *= inv; ny *= inv; nz *= inv;
            const size_t i = (static_cast<size_t>(y) * N + x) * 4;
            out[i + 0] = static_cast<u8>((nx * 0.5f + 0.5f) * 255.0f + 0.5f);
            out[i + 1] = static_cast<u8>((ny * 0.5f + 0.5f) * 255.0f + 0.5f);
            out[i + 2] = static_cast<u8>((nz * 0.5f + 0.5f) * 255.0f + 0.5f);
            out[i + 3] = 255u;
        }
    }
}

/// Cook-Torrance PBR（自 M7T1 pbr.frag 平移，光照约定一致）。
/// 顶点含蒙皮路径：u_Skinning=1 时按调色板变换（静态管线不声明 3/4 槽）。
constexpr const char* kPbrVertSkinned = R"(#version 330 core
layout(location = 0) in vec3 a_Position;
layout(location = 1) in vec3 a_Normal;
layout(location = 2) in vec2 a_TexCoord;
layout(location = 3) in vec4 a_JointIdxBits;   // floatBitsToInt 还原关节索引
layout(location = 4) in vec4 a_JointWeights;
layout(location = 5) in vec2 a_LightmapUV;

uniform mat4 u_Model;
uniform mat4 u_ViewProj;
uniform mat4 u_LightSpaceMatrix;
uniform mat4 u_BoneMatrices[64];

out vec3 v_FragPos;
out vec3 v_Normal;
out vec2 v_TexCoord;
out vec2 v_LightmapUV;
out vec4 v_FragPosLightSpace;
out vec3 v_ObjPos;
out vec3 v_ObjNormal;

void main() {
    // 4 骨骼线性混合蒙皮矩阵
    ivec4 joints = ivec4(floatBitsToInt(a_JointIdxBits.x),
                         floatBitsToInt(a_JointIdxBits.y),
                         floatBitsToInt(a_JointIdxBits.z),
                         floatBitsToInt(a_JointIdxBits.w));
    mat4 skin =
        a_JointWeights.x * u_BoneMatrices[joints.x] +
        a_JointWeights.y * u_BoneMatrices[joints.y] +
        a_JointWeights.z * u_BoneMatrices[joints.z] +
        a_JointWeights.w * u_BoneMatrices[joints.w];

    mat4 world = u_Model * skin;
    vec4 worldPos = world * vec4(a_Position, 1.0);
    v_FragPos  = worldPos.xyz;
    v_Normal   = mat3(transpose(inverse(world))) * a_Normal;
    v_TexCoord = a_TexCoord;
    v_LightmapUV = a_LightmapUV;
    v_ObjPos    = a_Position;
    v_ObjNormal = a_Normal;
    v_FragPosLightSpace = u_LightSpaceMatrix * worldPos;
    gl_Position = u_ViewProj * worldPos;
}
)";

constexpr const char* kPbrVert = R"(#version 330 core
layout(location = 0) in vec3 a_Position;   // AssetManager 交错布局：40 字节/顶点
layout(location = 1) in vec3 a_Normal;
layout(location = 2) in vec2 a_TexCoord;
layout(location = 5) in vec2 a_LightmapUV;

uniform mat4 u_Model;
uniform mat4 u_ViewProj;
uniform mat4 u_LightSpaceMatrix;

out vec3 v_FragPos;
out vec3 v_Normal;
out vec2 v_TexCoord;
out vec2 v_LightmapUV;
out vec4 v_FragPosLightSpace;
out vec3 v_ObjPos;      // 物体空间坐标：三平面细节法线用（无 UV 模型的救命稻草）
out vec3 v_ObjNormal;   // 物体空间法线：给三平面选主投影轴

void main() {
    vec4 worldPos = u_Model * vec4(a_Position, 1.0);
    v_FragPos  = worldPos.xyz;
    v_Normal   = mat3(transpose(inverse(u_Model))) * a_Normal;
    v_TexCoord = a_TexCoord;
    v_LightmapUV = a_LightmapUV;
    v_ObjPos    = a_Position;
    v_ObjNormal = a_Normal;
    v_FragPosLightSpace = u_LightSpaceMatrix * worldPos;
    gl_Position = u_ViewProj * worldPos;
}
)";

/// 实例化 PBR 顶点着色器：模型矩阵来自 location 6..9（每实例 4 个 vec4）。
constexpr const char* kPbrVertInstanced = R"(#version 330 core
layout(location = 0) in vec3 a_Position;
layout(location = 1) in vec3 a_Normal;
layout(location = 2) in vec2 a_TexCoord;
layout(location = 5) in vec2 a_LightmapUV;
layout(location = 6) in vec4 a_Inst0;
layout(location = 7) in vec4 a_Inst1;
layout(location = 8) in vec4 a_Inst2;
layout(location = 9) in vec4 a_Inst3;

uniform mat4 u_ViewProj;
uniform mat4 u_LightSpaceMatrix;

out vec3 v_FragPos;
out vec3 v_Normal;
out vec2 v_TexCoord;
out vec2 v_LightmapUV;
out vec4 v_FragPosLightSpace;
out vec3 v_ObjPos;
out vec3 v_ObjNormal;

void main() {
    mat4 model = mat4(a_Inst0, a_Inst1, a_Inst2, a_Inst3);
    vec4 worldPos = model * vec4(a_Position, 1.0);
    v_FragPos  = worldPos.xyz;
    v_Normal   = mat3(transpose(inverse(model))) * a_Normal;
    v_TexCoord = a_TexCoord;
    v_LightmapUV = a_LightmapUV;
    v_ObjPos    = a_Position;
    v_ObjNormal = a_Normal;
    v_FragPosLightSpace = u_LightSpaceMatrix * worldPos;
    gl_Position = u_ViewProj * worldPos;
}
)";

/// Cook-Torrance PBR（自 M7T1 pbr.frag 平移，光照约定一致）。
constexpr const char* kPbrFrag = R"(#version 330

in vec3 v_FragPos;
in vec3 v_Normal;
in vec2 v_TexCoord;
in vec2 v_LightmapUV;   // BSP 烘焙光图坐标（图集 UV）
in vec4 v_FragPosLightSpace;
in vec3 v_ObjPos;       // 物体空间坐标：三平面细节法线用（无 UV 模型的救命稻草）
in vec3 v_ObjNormal;    // 物体空间法线：给三平面选主投影轴

uniform vec3 u_CameraPos;
uniform mat4 u_LightSpaceMatrix;   // 阴影采样用（片元里重算法线偏移后的光空间坐标）

// 材质
uniform vec4  u_BaseColor ;
uniform float u_Metallic  ;
uniform float u_Roughness ;
uniform int   u_UseBaseMap ;
uniform float u_AlphaCutoff ;     // >0 时按 alpha 裁剪（草叶/铁网这类卡片贴图）
uniform sampler2D u_BaseMap;      // slot 0

// 法线贴图 / 金属粗糙度 / 自发光
uniform int       u_UseNormalMap ;
uniform sampler2D u_NormalMap;    // slot 2
uniform int       u_UseMRMap ;
uniform sampler2D u_MRMap;        // slot 3（G=roughness, B=metallic, R=AO）
uniform vec3      u_Emissive ;
uniform int       u_UseEmissiveMap ;
uniform sampler2D u_EmissiveMap;  // slot 4

// 烘焙光图（BSP）：替代太阳/环境光的漫反射，动态光只作为补光。
// 采样点数已到 AMD 驱动的 9 处上限，后续不要再加 texture()。
uniform int       u_UseLightmap ;
uniform sampler2D u_Lightmap;      // slot 6
uniform float     u_LightmapStrength ;
uniform int       u_LightmapDebug ;   // 1 = 只输出光图（调 UV/亮度用）

// UV 平铺（箱体每面 UV 0..1，按实体尺寸放大避免拉伸）
uniform vec2      u_UvScale ;
// 法线强度（0 = 关闭，1 = 原始强度）
uniform float     u_NormalStrength ;

// 三平面细节法线：给**没有 UV**的模型加程序化微凹凸。
// 注意：GLSL 330 core 不允许 uniform 初始化器（`uniform float x = 0.0;` 非法），
// 默认值一律由 C++ 侧 SetFloat 显式下发，否则 AMD 驱动会回退到 #version 110。
uniform int       u_UseDetailNormal ;
uniform sampler2D u_DetailNormal;    // slot 5（程序化噪声法线，可平铺）
uniform float     u_DetailScale ;    // 每米重复次数
uniform float     u_DetailStrength ; // 法线强度（0 = 关闭）
uniform float     u_DetailRoughJitter ; // 用同一张噪声抖动粗糙度

// 环境光（半球，廉价 IBL）
uniform vec3 u_AmbientSky    ;
uniform vec3 u_AmbientGround ;

// 方向光
uniform int   u_DirLightEnabled ;
uniform vec3  u_DirLightDir;
uniform vec3  u_DirLightColor;
uniform float u_DirLightIntensity;

// 点光（最多 32）
uniform int u_PointLightCount ;
struct PointLightData {
    vec3  position;
    vec3  color;
    float intensity;
    float range;
};
uniform PointLightData u_PointLights[32];

// 聚光灯（手电/探照灯）：锥形 + 距离衰减，动态光源
uniform int u_SpotLightCount ;
struct SpotLightData {
    vec3  position;
    vec3  direction;
    vec3  color;
    float intensity;
    float range;
    float innerCos;
    float outerCos;
};
uniform SpotLightData u_SpotLights[8];

// 屏幕分块光照：每块 32×32 像素，RGBA8 两个 texel 存最多 8 盏灯
// （按屏幕距离保留最强的 8 盏）。0 = 无，1..32 = 点光下标+1，33..40 = 聚光下标+1。
uniform int       u_LightGridEnabled ;
uniform int       u_CheapDynamicLights ;
uniform int       u_DynamicLightFullCount ;
uniform sampler2D u_LightGrid;
uniform vec2      u_LightGridTiles;   // (tilesX, tilesY)

// 阴影
uniform int          u_ShadowEnabled ;
uniform int          u_ShadowMaskEnabled ;
uniform sampler2DShadow u_ShadowMap;    // slot 1（硬件深度比较 + 双线性 PCF）
uniform sampler2D    u_ShadowMask;      // slot 1（半分辨率遮罩；优先于逐像素采样）
uniform vec2         u_RenderSize;      // HDR 目标像素尺寸

out vec4 FragColor;

const float PI = 3.14159265359;

float distributionGGX(vec3 N, vec3 H, float roughness) {
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.0);
    float denom = (NdotH * NdotH * (a2 - 1.0) + 1.0);
    return a2 / (PI * denom * denom + 0.0001);
}
float geometrySchlickGGX(float NdotV, float roughness) {
    float r = roughness + 1.0;
    float k = (r * r) / 8.0;
    return NdotV / (NdotV * (1.0 - k) + k);
}
float geometrySmith(vec3 N, vec3 V, vec3 L, float roughness) {
    return geometrySchlickGGX(max(dot(N, V), 0.0), roughness)
         * geometrySchlickGGX(max(dot(N, L), 0.0), roughness);
}
vec3 fresnelSchlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(1.0 - cosTheta, 5.0);
}

/// 硬件 PCF 软阴影：2×2 采样点，每个点由纹理单元做 2×2 比较过滤，
/// 等价于 3×3 texel 的双线性软边；比 9 次手写深度采样便宜得多。
/// 关键：斜率缩放偏移 + 法线偏移，消除大平面上低角度光照产生的自遮挡摩尔纹。
float shadowFactor(vec3 N, vec3 L) {
    if (u_ShadowMaskEnabled == 1) {
        return texture(u_ShadowMask, gl_FragCoord.xy / u_RenderSize).r;
    }
    if (u_ShadowEnabled == 0) return 1.0;

    // 法线偏移：沿表面法线抬起采样点（1cm），配合正面剔除后仅需极小偏移
    vec3 offsetPos = v_FragPos + N * 0.01;
    vec4 lsPos = u_LightSpaceMatrix * vec4(offsetPos, 1.0);
    vec3 proj = lsPos.xyz / lsPos.w;
    proj = proj * 0.5 + 0.5;
    // 视锥外受光。桌面用 border 颜色也能做到，这里统一显式判定，
    // 让 GLES3（无 CLAMP_TO_BORDER）走同一套逻辑。
    if (proj.z > 1.0 || proj.x < 0.0 || proj.x > 1.0 ||
        proj.y < 0.0 || proj.y > 1.0) {
        return 1.0;
    }

    // 斜率缩放偏移：掠射角越大偏移越大（正面剔除后可用较小值，避免阴影脱离物体）
    float ndl = clamp(dot(N, L), 0.0, 1.0);
    float bias = max(0.0006 * (1.0 - ndl), 0.00008);

    vec2 texel = 1.0 / vec2(textureSize(u_ShadowMap, 0));
    float z = proj.z - bias;
    float shadow = texture(u_ShadowMap, vec3(proj.xy + texel * vec2( 0.5,  0.5), z));
    shadow += texture(u_ShadowMap, vec3(proj.xy + texel * vec2(-0.5, -0.5), z));
    return shadow * 0.5;
}

vec3 evalLight(vec3 L, vec3 radiance, vec3 N, vec3 V, vec3 albedo,
               float metallic, float roughness) {
    vec3 H  = normalize(V + L);
    vec3 F0 = mix(vec3(0.04), albedo, metallic);

    float NDF = distributionGGX(N, H, roughness);
    float G   = geometrySmith(N, V, L, roughness);
    vec3  F   = fresnelSchlick(max(dot(H, V), 0.0), F0);

    vec3  numerator   = NDF * G * F;
    float denominator = 4.0 * max(dot(N, V), 0.0) * max(dot(N, L), 0.0) + 0.0001;
    vec3  specular    = numerator / denominator;

    vec3  kD    = (vec3(1.0) - F) * (1.0 - metallic);
    float NdotL = max(dot(N, L), 0.0);
    return (kD * albedo / PI + specular) * radiance * NdotL;
}

/// 动态光用的轻量 BRDF：Lambert 漫反射 + Blinn-Phong 高光。
/// 方向光（太阳）仍然走完整 Cook-Torrance，主高光不受影响；
/// 附近路灯/枪口光只需要"有金属感"的近似，省下每像素多次 GGX。
vec3 evalLightCheap(vec3 L, vec3 radiance, vec3 N, vec3 V, vec3 albedo,
                    float metallic, float roughness) {
    float NdotL = max(dot(N, L), 0.0);
    if (NdotL <= 0.0) return vec3(0.0);
    vec3 H = normalize(V + L);
    float NdotH = max(dot(N, H), 0.0);
    float specPower = mix(220.0, 6.0, roughness * roughness);
    float spec = pow(NdotH, specPower) * mix(0.04, 0.55, metallic);
    vec3 diffuse = albedo * (1.0 - metallic) * (1.0 / PI);
    return (diffuse + vec3(spec)) * radiance * NdotL;
}

vec3 evalDynamic(vec3 L, vec3 radiance, vec3 N, vec3 V, vec3 albedo,
                 float metallic, float roughness) {
    return (u_CheapDynamicLights == 1)
        ? evalLightCheap(L, radiance, N, V, albedo, metallic, roughness)
        : evalLight(L, radiance, N, V, albedo, metallic, roughness);
}

/// 光照网格里按强度排序后的第 slot 盏：前 N 盏完整 PBR，其余走轻量 BRDF。
/// 这样近处最强的灯保留金属高光细节，远处次要灯只负责照度，省下大量 GGX。
vec3 evalDynamicSlot(int slot, vec3 L, vec3 radiance, vec3 N, vec3 V,
                     vec3 albedo, float metallic, float roughness) {
    if (u_CheapDynamicLights == 0 || slot < u_DynamicLightFullCount) {
        return evalLight(L, radiance, N, V, albedo, metallic, roughness);
    }
    return evalLightCheap(L, radiance, N, V, albedo, metallic, roughness);
}

void main() {
    vec2 uv = v_TexCoord * u_UvScale;

    // 光图只采样一次（AMD 驱动对片元 texture() 数量有上限）。
    vec3 lmSample = vec3(1.0);
    if (u_UseLightmap == 1) lmSample = texture(u_Lightmap, v_LightmapUV).rgb;
    if (u_LightmapDebug == 1) {
        FragColor = vec4(lmSample * 4.0, 1.0);
        return;
    }

    // 反照率（常量 * 可选纹理）；贴图 A 通道参与最终 alpha（弹孔/火光的软边）
    vec3 albedo = u_BaseColor.rgb;
    float texAlpha = 1.0;
    if (u_UseBaseMap == 1) {
        vec4 base = texture(u_BaseMap, uv);
        albedo *= base.rgb;
        texAlpha = base.a;
    }
    // alpha 裁剪：低于阈值的片元直接丢，草叶/铁网/窗棂才不会糊成一块不透明板。
    // 不透明材质使用 M7N_OPAQUE 变体（不声明 discard）→ 驱动可以开启 early-z。
#ifndef M7N_OPAQUE
    if (u_AlphaCutoff > 0.0 && u_BaseColor.a * texAlpha < u_AlphaCutoff) discard;
#endif

    vec3 N = normalize(v_Normal);

    // 法线贴图：无顶点切线，用屏幕导数构造 TBN（cotangent frame）
    if (u_UseNormalMap == 1) {
        vec3 dp1 = dFdx(v_FragPos);
        vec3 dp2 = dFdy(v_FragPos);
        vec2 duv1 = dFdx(uv);
        vec2 duv2 = dFdy(uv);
        vec3 dp2perp = cross(dp2, N);
        vec3 dp1perp = cross(N, dp1);
        vec3 T = dp2perp * duv1.x + dp1perp * duv2.x;
        vec3 B = dp2perp * duv1.y + dp1perp * duv2.y;
        float invmax = inversesqrt(max(dot(T, T), dot(B, B)) + 1e-8);
        mat3 TBN = mat3(T * invmax, B * invmax, N);
        vec3 nTex = texture(u_NormalMap, uv).xyz * 2.0 - 1.0;
        nTex.xy *= u_NormalStrength;     // 法线强度（地面等大面积可调低，避免掠射角条纹）
        N = normalize(TBN * nTex);
    }

    // 三平面（triplanar）细节法线：完全不需要 UV。
    // 按物体空间法线的主轴做权重混合，采样噪声法线图三次。
    // 这是给"只有 POSITION + NORMAL 的 GLB"加表面质感的唯一可行手段。
    float detailNoise = 0.5;
    if (u_UseDetailNormal == 1 && u_DetailStrength > 0.0) {
        vec3 an = abs(normalize(v_ObjNormal));
        vec3 w  = an / max(an.x + an.y + an.z, 1e-4);
        vec3 p  = v_ObjPos * u_DetailScale;
        vec3 dx = texture(u_DetailNormal, p.zy).xyz * 2.0 - 1.0;
        vec3 dy = texture(u_DetailNormal, p.xz).xyz * 2.0 - 1.0;
        vec3 dz = texture(u_DetailNormal, p.xy).xyz * 2.0 - 1.0;
        detailNoise = dx.x * 0.5 + 0.5;      // 顺手留一份噪声给粗糙度抖动用
        vec3 d  = dx * w.x + dy * w.y + dz * w.z;
        // 投影掉沿 N 的分量：只保留切线方向扰动，避免整体法线被拉偏
        d -= N * dot(d, N);
        N = normalize(N + d * u_DetailStrength);
    }

    vec3 V = normalize(u_CameraPos - v_FragPos);
    float roughness = clamp(u_Roughness, 0.045, 1.0);
    float metallic  = clamp(u_Metallic, 0.0, 1.0);

    // 金属粗糙度贴图（G=roughness, B=metallic）
    if (u_UseMRMap == 1) {
        vec3 mr = texture(u_MRMap, uv).rgb;
        roughness = clamp(roughness * max(mr.g, 0.02), 0.045, 1.0);
        metallic  = clamp(metallic * mr.b, 0.0, 1.0);
    }

    float NdotV = max(dot(N, V), 0.0);

    // 粗糙度抖动：PBR 金属感的关键不是法线起伏，而是**粗糙度沿表面变化**——
    // 均匀粗糙度只会得到一块塑料似的大片高光，抖动后高光才会碎成金属反光。
    // 这里复用三平面已采样的噪声（detailNoise），不再额外采样，省一次 texture()。
    if (u_DetailRoughJitter > 0.0) {
        float jitter = 1.0 - u_DetailRoughJitter * (1.0 - detailNoise);
        roughness = clamp(roughness * jitter, 0.045, 1.0);
    }

    // 半球环境光 + 金属 Fake IBL 反射
    vec3 LDir = normalize(-u_DirLightDir);
    float hemi = N.y * 0.5 + 0.5;
    vec3 diffuseAmb = mix(u_AmbientGround, u_AmbientSky, hemi) * albedo;
    vec3 R = reflect(-V, N);
    float rHemi = clamp(R.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 envDirCol = mix(u_AmbientGround, u_AmbientSky, rHemi);
    vec3 envAvg = (u_AmbientGround + u_AmbientSky) * 0.5;
    vec3 envColor = mix(envDirCol, envAvg, roughness * roughness);
    // 环境里的"太阳"：反射方向扫过光源时给一个高光斑。
    // 金属没有漫反射，只有这个才能让它读起来像金属而不是磨砂塑料。
    // 指数随粗糙度下降 → 光滑金属得到锐利小点，粗糙金属得到一片柔和亮区。
    if (u_DirLightEnabled == 1) {
        float sunDot = max(dot(R, LDir), 0.0);
        float sunExp = mix(320.0, 6.0, roughness * roughness);
        envColor += u_DirLightColor * pow(sunDot, sunExp) * (u_DirLightIntensity * 0.35);
    }
    vec3 F0 = mix(vec3(0.04), albedo, metallic);
    vec3 F = fresnelSchlick(NdotV, F0);
    vec3 kD = (vec3(1.0) - F) * (1.0 - metallic);
    vec3 ambient = kD * diffuseAmb + F * envColor * 1.6;

    // 动态光单独累计：光图模式（BSP）下烘焙光已经包含太阳/环境，动态光只做补光。
    vec3 dynamicLights = vec3(0.0);
    // 阴影只在方向光真正贡献时采样（背光面 / 光图模式直接跳过）。
    if (u_DirLightEnabled == 1 && u_UseLightmap == 0) {
        float ndl = dot(N, LDir);
        if (ndl > 0.0) {
            float shadow = shadowFactor(N, LDir);
            vec3 radiance = u_DirLightColor * u_DirLightIntensity * shadow;
            dynamicLights += evalLight(LDir, radiance, N, V, albedo, metallic, roughness);
        }
    }

    if (u_LightGridEnabled == 1) {
        // 只遍历本屏幕块记录的最强 8 盏灯，而不是全局 40 盏。
        // RGBA8 texelFetch 返回 0..1 归一化值，先还原成字节再解码下标。
        ivec2 tile = ivec2(gl_FragCoord.xy) / 32;
        tile = clamp(tile, ivec2(0), ivec2(u_LightGridTiles) - 1);
        for (int t = 0; t < 2; t++) {
            vec4 refs = texelFetch(u_LightGrid, ivec2(tile.x * 2 + t, tile.y), 0);
            for (int k = 0; k < 4; k++) {
                float ref = refs[k];
                int refByte = int(ref * 255.0 + 0.5);
                if (refByte <= 0) continue;
                int idx = refByte - 1;
                if (idx < 32) {
                    if (idx >= u_PointLightCount) continue;
                    PointLightData pl = u_PointLights[idx];
                    vec3 toLight = pl.position - v_FragPos;
                    float dist = length(toLight);
                    if (dist >= pl.range) continue;
                    vec3 L = toLight / dist;
                    float att = pow(clamp(1.0 - dist / pl.range, 0.0, 1.0), 2.0);
                    vec3 radiance = pl.color * pl.intensity * att;
                    dynamicLights += evalDynamicSlot(idx, L, radiance, N, V,
                                                     albedo, metallic, roughness);
                } else {
                    int si = idx - 32;
                    if (si >= u_SpotLightCount) continue;
                    SpotLightData sl = u_SpotLights[si];
                    vec3 toLight = sl.position - v_FragPos;
                    float dist = length(toLight);
                    if (dist >= sl.range) continue;
                    vec3 L = toLight / dist;
                    float cosAngle = dot(normalize(-L), normalize(sl.direction));
                    float cone = smoothstep(sl.outerCos, sl.innerCos, cosAngle);
                    if (cone <= 0.0) continue;
                    float att = pow(clamp(1.0 - dist / sl.range, 0.0, 1.0), 2.0) * cone;
                    vec3 radiance = sl.color * sl.intensity * att;
                    dynamicLights += evalDynamicSlot(idx, L, radiance, N, V,
                                                     albedo, metallic, roughness);
                }
            }
        }
    } else {
        for (int i = 0; i < u_PointLightCount; i++) {
            vec3 toLight = u_PointLights[i].position - v_FragPos;
            float dist = length(toLight);
            if (dist >= u_PointLights[i].range) continue;
            vec3 L = toLight / dist;
            float att = pow(clamp(1.0 - dist / u_PointLights[i].range, 0.0, 1.0), 2.0);
            vec3 radiance = u_PointLights[i].color * u_PointLights[i].intensity * att;
            dynamicLights += evalDynamicSlot(i, L, radiance, N, V,
                                             albedo, metallic, roughness);
        }

        // 聚光灯（手电/探照灯）
        for (int i = 0; i < u_SpotLightCount; i++) {
            vec3 toLight = u_SpotLights[i].position - v_FragPos;
            float dist = length(toLight);
            if (dist >= u_SpotLights[i].range) continue;
            vec3 L = toLight / dist;
            // 锥形衰减：光源看向片元的方向与光源朝向夹角
            float cosAngle = dot(normalize(-L), normalize(u_SpotLights[i].direction));
            float cone = smoothstep(u_SpotLights[i].outerCos, u_SpotLights[i].innerCos, cosAngle);
            if (cone <= 0.0) continue;
            float att = pow(clamp(1.0 - dist / u_SpotLights[i].range, 0.0, 1.0), 2.0) * cone;
            vec3 radiance = u_SpotLights[i].color * u_SpotLights[i].intensity * att;
            dynamicLights += evalDynamicSlot(32 + i, L, radiance, N, V,
                                             albedo, metallic, roughness);
        }
    }

    // 自发光（灯头/贴图）
    vec3 emissive = u_Emissive;
    if (u_UseEmissiveMap == 1) emissive *= texture(u_EmissiveMap, uv).rgb;

    // 光图模式：烘焙光提供漫反射，保留少量动态光作为手电/枪口/近灯的补光。
    vec3 color = ambient + dynamicLights;
    if (u_UseLightmap == 1) {
        vec3 baked = lmSample * u_LightmapStrength;
        color = albedo * baked
              + ambient * 0.22
              + dynamicLights * 0.65
              + emissive;
    } else {
        color += emissive;
    }

    FragColor = vec4(color, u_BaseColor.a * texAlpha);
}
)";

/// 阴影 depth-only（蒙皮变体：调色板变换后再投影）。
constexpr const char* kShadowVertSkinned = R"(#version 330 core
layout(location = 0) in vec3 a_Position;
layout(location = 3) in vec4 a_JointIdxBits;
layout(location = 4) in vec4 a_JointWeights;
uniform mat4 u_LightSpaceMatrix;
uniform mat4 u_Model;
uniform mat4 u_BoneMatrices[64];
void main() {
    ivec4 joints = ivec4(floatBitsToInt(a_JointIdxBits.x),
                         floatBitsToInt(a_JointIdxBits.y),
                         floatBitsToInt(a_JointIdxBits.z),
                         floatBitsToInt(a_JointIdxBits.w));
    mat4 skin =
        a_JointWeights.x * u_BoneMatrices[joints.x] +
        a_JointWeights.y * u_BoneMatrices[joints.y] +
        a_JointWeights.z * u_BoneMatrices[joints.z] +
        a_JointWeights.w * u_BoneMatrices[joints.w];
    gl_Position = u_LightSpaceMatrix * u_Model * skin * vec4(a_Position, 1.0);
}
)";

/// 阴影 depth-only（静态）。
constexpr const char* kShadowVert = R"(#version 330 core
layout(location = 0) in vec3 a_Position;
uniform mat4 u_LightSpaceMatrix;
uniform mat4 u_Model;
void main() {
    gl_Position = u_LightSpaceMatrix * u_Model * vec4(a_Position, 1.0);
}
)";

/// 阴影 depth-only（实例化）。
constexpr const char* kShadowVertInstanced = R"(#version 330 core
layout(location = 0) in vec3 a_Position;
layout(location = 6) in vec4 a_Inst0;
layout(location = 7) in vec4 a_Inst1;
layout(location = 8) in vec4 a_Inst2;
layout(location = 9) in vec4 a_Inst3;
uniform mat4 u_LightSpaceMatrix;
void main() {
    mat4 model = mat4(a_Inst0, a_Inst1, a_Inst2, a_Inst3);
    gl_Position = u_LightSpaceMatrix * model * vec4(a_Position, 1.0);
}
)";

/// 深度预通道（静态）：与 PBR 顶点着色器保持完全相同的矩阵运算顺序，
/// 否则同像素两次算出的深度可能差 1 ULP，LEQUAL 会漏掉片元。
constexpr const char* kDepthVert = R"(#version 330 core
layout(location = 0) in vec3 a_Position;
uniform mat4 u_ViewProj;
uniform mat4 u_Model;
void main() {
    vec4 worldPos = u_Model * vec4(a_Position, 1.0);
    gl_Position = u_ViewProj * worldPos;
}
)";

constexpr const char* kDepthVertSkinned = R"(#version 330 core
layout(location = 0) in vec3 a_Position;
layout(location = 3) in vec4 a_JointIdxBits;
layout(location = 4) in vec4 a_JointWeights;
uniform mat4 u_ViewProj;
uniform mat4 u_Model;
uniform mat4 u_BoneMatrices[64];
void main() {
    ivec4 joints = ivec4(floatBitsToInt(a_JointIdxBits.x),
                         floatBitsToInt(a_JointIdxBits.y),
                         floatBitsToInt(a_JointIdxBits.z),
                         floatBitsToInt(a_JointIdxBits.w));
    mat4 skin =
        a_JointWeights.x * u_BoneMatrices[joints.x] +
        a_JointWeights.y * u_BoneMatrices[joints.y] +
        a_JointWeights.z * u_BoneMatrices[joints.z] +
        a_JointWeights.w * u_BoneMatrices[joints.w];
    mat4 world = u_Model * skin;
    vec4 worldPos = world * vec4(a_Position, 1.0);
    gl_Position = u_ViewProj * worldPos;
}
)";

constexpr const char* kDepthVertInstanced = R"(#version 330 core
layout(location = 0) in vec3 a_Position;
layout(location = 6) in vec4 a_Inst0;
layout(location = 7) in vec4 a_Inst1;
layout(location = 8) in vec4 a_Inst2;
layout(location = 9) in vec4 a_Inst3;
uniform mat4 u_ViewProj;
void main() {
    mat4 model = mat4(a_Inst0, a_Inst1, a_Inst2, a_Inst3);
    vec4 worldPos = model * vec4(a_Position, 1.0);
    gl_Position = u_ViewProj * worldPos;
}
)";

constexpr const char* kDepthFrag = R"(#version 330 core
void main() {}
)";

/// 半分辨率阴影遮罩：从场景深度重建世界坐标与法线，写入硬件 PCF 阴影因子。
/// PBR 片元随后只采样一次遮罩（线性放大），避免每像素 4 次阴影采样。
constexpr const char* kShadowMaskFrag = R"(#version 330 core
in vec2 v_UV;
uniform sampler2D u_SceneDepth;
uniform sampler2DShadow u_ShadowMap;
uniform mat4 u_LightSpaceMatrix;
uniform vec3 u_CameraPos;
uniform vec3 u_CameraRight;
uniform vec3 u_CameraUp;
uniform vec3 u_CameraForward;
uniform vec2 u_TanHalfFov;
uniform vec2 u_NearFar;
uniform vec3 u_DirLightDir;
out vec4 FragColor;

float shadowFactor(vec3 worldPos, vec3 N, vec3 L) {
    vec3 offsetPos = worldPos + N * 0.01;
    vec4 lsPos = u_LightSpaceMatrix * vec4(offsetPos, 1.0);
    vec3 proj = lsPos.xyz / lsPos.w;
    proj = proj * 0.5 + 0.5;
    if (proj.z > 1.0 || proj.x < 0.0 || proj.x > 1.0 ||
        proj.y < 0.0 || proj.y > 1.0) {
        return 1.0;
    }
    float ndl = clamp(dot(N, L), 0.0, 1.0);
    float bias = max(0.0006 * (1.0 - ndl), 0.00008);
    vec2 texel = 1.0 / vec2(textureSize(u_ShadowMap, 0));
    float z = proj.z - bias;
    float shadow = 0.0;
    shadow += texture(u_ShadowMap, vec3(proj.xy + texel * vec2(-0.5, -0.5), z));
    shadow += texture(u_ShadowMap, vec3(proj.xy + texel * vec2( 0.5, -0.5), z));
    shadow += texture(u_ShadowMap, vec3(proj.xy + texel * vec2(-0.5,  0.5), z));
    shadow += texture(u_ShadowMap, vec3(proj.xy + texel * vec2( 0.5,  0.5), z));
    return shadow * 0.25;
}

void main() {
    float depth = texture(u_SceneDepth, v_UV).r;
    if (depth >= 0.99999) {
        FragColor = vec4(1.0);
        return;
    }
    vec2 ndc = v_UV * 2.0 - 1.0;
    float zNdc = depth * 2.0 - 1.0;
    float viewDepth = (2.0 * u_NearFar.x * u_NearFar.y) /
        (u_NearFar.y + u_NearFar.x - zNdc * (u_NearFar.y - u_NearFar.x));
    vec3 worldPos = u_CameraPos +
        (u_CameraRight * (ndc.x * u_TanHalfFov.x) +
         u_CameraUp * (ndc.y * u_TanHalfFov.y) +
         u_CameraForward) * viewDepth;

    vec3 V = normalize(u_CameraPos - worldPos);
    vec3 N = normalize(cross(dFdx(worldPos), dFdy(worldPos)));
    if (dot(N, V) < 0.0) N = -N;
    vec3 L = normalize(-u_DirLightDir);
    FragColor = vec4(shadowFactor(worldPos, N, L), 1.0, 1.0, 1.0);
}
)";
constexpr const char* kShadowFrag = R"(#version 330 core
void main() { /* 深度自动写入，无颜色输出 */ }
)";

/// 后处理：全屏三角 + ACES + gamma + 晴角。
constexpr const char* kPostVert = R"(#version 330 core
out vec2 v_UV;
void main() {
    // gl_VertID 技巧：3 顶点覆盖全屏，无需顶点缓冲
    vec2 pos = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
    v_UV = pos;
    gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);
}
)";
/// 泛光链：预过滤（4 tap 降采样 + 阈值）与可分离高斯模糊（5 tap）。
constexpr const char* kBloomFrag = R"(#version 330 core
in vec2 v_UV;
uniform sampler2D u_Src;
uniform vec2 u_Direction;     // (1,0) / (0,1)
uniform float u_Threshold;
uniform int u_Prefilter;
out vec4 FragColor;

vec3 tap(vec2 uv) { return texture(u_Src, uv).rgb; }

void main() {
    vec2 texel = 1.0 / vec2(textureSize(u_Src, 0));

    if (u_Prefilter == 1) {
        // 4 tap 盒式降采样：把 HDR 缩到 1/4 分辨率，同时保留亮点颜色。
        vec3 c = tap(v_UV + texel * vec2(-0.5, -0.5)) +
                 tap(v_UV + texel * vec2( 0.5, -0.5)) +
                 tap(v_UV + texel * vec2(-0.5,  0.5)) +
                 tap(v_UV + texel * vec2( 0.5,  0.5));
        c *= 0.25;
        float br = max(c.r, max(c.g, c.b));
        float contrib = smoothstep(u_Threshold, u_Threshold + 0.6, br);
        FragColor = vec4(c * contrib, 1.0);
        return;
    }

    // 5 tap 可分离高斯（1/4 分辨率上约 ±8px 全分辨率光晕）。
    const float w0 = 0.2941176;
    const float w1 = 0.2352941;
    const float w2 = 0.1176471;
    vec2 o1 = u_Direction * texel * 1.0;
    vec2 o2 = u_Direction * texel * 2.0;
    vec3 c = tap(v_UV) * w0;
    c += (tap(v_UV + o1) + tap(v_UV - o1)) * w1;
    c += (tap(v_UV + o2) + tap(v_UV - o2)) * w2;
    FragColor = vec4(c, 1.0);
}
)";

constexpr const char* kPostFrag = R"(#version 330 core
in vec2 v_UV;
uniform sampler2D u_HdrColor;    // slot 0：HDR 场景颜色
uniform sampler2D u_BloomTex;    // slot 1：已模糊的泛光图
uniform float u_Exposure;
uniform float u_Vignette;
uniform float u_Gamma;
uniform float u_Bloom;
out vec4 FragColor;

/// Narkowicz ACES 近似。
vec3 acesToneMap(vec3 x) {
    const float a = 2.51, b = 0.03, c = 2.43, d = 0.59, e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

void main() {
    vec3 hdr = texture(u_HdrColor, v_UV).rgb;
    // 泛光链已经在低分辨率完成模糊，这里只做一次纹理采样。
    if (u_Bloom > 0.0) {
        hdr += texture(u_BloomTex, v_UV).rgb * u_Bloom;
    }

    hdr *= u_Exposure;
    vec3 mapped = acesToneMap(hdr);
    if (u_Vignette > 0.0) {
        vec2 center = v_UV - 0.5;
        float v = 1.0 - dot(center, center) * u_Vignette * 2.0;
        mapped *= clamp(v, 0.0, 1.0);
    }
    vec3 corrected = pow(max(mapped, vec3(0.0)), vec3(1.0 / u_Gamma));
    FragColor = vec4(corrected, 1.0);
}
)";

} // namespace

// =====================================================================
// 生命周期
// =====================================================================

RenderSystem::RenderSystem(IRenderDevice& device, Asset::AssetManager& assets)
    : device_(device), assets_(assets) {}

bool RenderSystem::Init(u32 viewportWidth, u32 viewportHeight) {
    viewportW_ = viewportWidth > 0 ? viewportWidth : 1;
    viewportH_ = viewportHeight > 0 ? viewportHeight : 1;

    if (!createPipelines()) return false;

    // 程序化细节法线（一次性生成 256²，供无 UV 模型的三平面微凹凸使用）
    {
        std::vector<u8> pixels;
        MakeDetailNormalTexture(pixels, 256);
        assets_.RegisterProceduralTexture(kDetailNormalTexName, 256, 256,
                                          pixels.data(), /*repeat=*/true,
                                          /*mipmaps=*/true, /*srgb=*/false);
        detailNormalTex_ = assets_.GetOrCreateTexture(kDetailNormalTexName, /*srgb=*/false);
    }

    // HDR 场景帧缓冲（按 renderScale 降分辨率；后处理再放大到窗口）
    const f32 scale = std::clamp(config_.renderScale, 0.5f, 1.0f);
    FramebufferDesc hdr;
    hdr.width = std::max(1u, static_cast<u32>(static_cast<f32>(viewportW_) * scale));
    hdr.height = std::max(1u, static_cast<u32>(static_cast<f32>(viewportH_) * scale));
    hdr.mode = FramebufferMode::HDR;
    renderW_ = hdr.width;
    renderH_ = hdr.height;
    hdrFB_ = device_.CreateFramebuffer(hdr);
    if (!hdrFB_.IsValid()) return false;

    // 阴影贴图（DepthOnly）
    FramebufferDesc shadow;
    const u32 maxTex = device_.GetCapabilities().maxTextureSize;
    const u32 shadowSize = std::max(1u, std::min(config_.shadowMapSize, maxTex));
    shadow.width = shadowSize;
    shadow.height = shadowSize;
    shadow.mode = FramebufferMode::DepthOnly;
    shadowFB_ = device_.CreateFramebuffer(shadow);

    createBloomTargets(hdr.width, hdr.height);
    createLightGridTexture();
    createShadowMaskTarget(renderW_, renderH_);
    return true;
}

bool RenderSystem::createShadowMaskTarget(u32 width, u32 height) {
    if (shadowMaskFB_.IsValid()) device_.DestroyFramebuffer(shadowMaskFB_);
    shadowMaskFB_ = {};
    FramebufferDesc desc;
    desc.width = std::max(1u, width / 2);
    desc.height = std::max(1u, height / 2);
    desc.mode = FramebufferMode::HDR;
    shadowMaskFB_ = device_.CreateFramebuffer(desc);
    return shadowMaskFB_.IsValid();
}

bool RenderSystem::createBloomTargets(u32 width, u32 height) {
    for (auto& fb : bloomFB_) {
        if (fb.IsValid()) device_.DestroyFramebuffer(fb);
        fb = {};
    }
    const u32 bloomDiv = std::clamp(config_.bloomDownscale, 2u, 8u);
    bloomW_ = std::max(1u, width / bloomDiv);
    bloomH_ = std::max(1u, height / bloomDiv);

    FramebufferDesc desc;
    desc.width = bloomW_;
    desc.height = bloomH_;
    desc.mode = FramebufferMode::HDR;
    bloomFB_[0] = device_.CreateFramebuffer(desc);
    bloomFB_[1] = device_.CreateFramebuffer(desc);
    if (!bloomFB_[0].IsValid() || !bloomFB_[1].IsValid()) {
        for (auto& fb : bloomFB_) {
            if (fb.IsValid()) device_.DestroyFramebuffer(fb);
            fb = {};
        }
        return false;
    }
    return true;
}

bool RenderSystem::createPipelines() {
    // 不透明变体：在 #version 之后插入 #define，去掉片元里的 discard。
    std::string opaqueFrag = kPbrFrag;
    const size_t versionEnd = opaqueFrag.find('\n');
    if (versionEnd != std::string::npos) {
        opaqueFrag.insert(versionEnd + 1, "#define M7N_OPAQUE 1\n");
    }
    pbrShader_ = device_.CreateShader({ kPbrVert, kPbrFrag });
    pbrSkinShader_ = device_.CreateShader({ kPbrVertSkinned, kPbrFrag });
    pbrInstShader_ = device_.CreateShader({ kPbrVertInstanced, kPbrFrag });
    pbrOpaqueShader_ = device_.CreateShader({ kPbrVert, opaqueFrag.c_str() });
    pbrSkinOpaqueShader_ = device_.CreateShader({ kPbrVertSkinned, opaqueFrag.c_str() });
    pbrInstOpaqueShader_ = device_.CreateShader({ kPbrVertInstanced, opaqueFrag.c_str() });
    shadowShader_ = device_.CreateShader({ kShadowVert, kShadowFrag });
    shadowSkinShader_ = device_.CreateShader({ kShadowVertSkinned, kShadowFrag });
    shadowInstShader_ = device_.CreateShader({ kShadowVertInstanced, kShadowFrag });
    depthShader_ = device_.CreateShader({ kDepthVert, kDepthFrag });
    depthSkinShader_ = device_.CreateShader({ kDepthVertSkinned, kDepthFrag });
    depthInstShader_ = device_.CreateShader({ kDepthVertInstanced, kDepthFrag });
    shadowMaskShader_ = device_.CreateShader({ kPostVert, kShadowMaskFrag });
    bloomShader_ = device_.CreateShader({ kPostVert, kBloomFrag });
    postShader_ = device_.CreateShader({ kPostVert, kPostFrag });
    if (!pbrShader_.IsValid() || !pbrSkinShader_.IsValid() ||
        !pbrInstShader_.IsValid() || !pbrOpaqueShader_.IsValid() ||
        !pbrSkinOpaqueShader_.IsValid() || !pbrInstOpaqueShader_.IsValid() ||
        !shadowShader_.IsValid() || !shadowSkinShader_.IsValid() ||
        !shadowInstShader_.IsValid() ||
        !depthShader_.IsValid() || !depthSkinShader_.IsValid() ||
        !depthInstShader_.IsValid() || !shadowMaskShader_.IsValid() ||
        !bloomShader_.IsValid() || !postShader_.IsValid()) {
        return false;
    }

    // PBR 静态：pos3 + normal3 + uv2 + lightmapUV2 交错（AssetManager 约定，40 字节）
    PipelineDesc pbr;
    pbr.shader = pbrShader_;
    pbr.layout = {
        { 0, 3, 40,  0, false },
        { 1, 3, 40, 12, false },
        { 2, 2, 40, 24, false },
        { 5, 2, 40, 32, false },
    };
    pbrPipeline_ = device_.CreatePipeline(pbr);

    // PBR 蒙皮：同基础布局（3/4 槽由 BindSkinBuffer 命令补发，
    // 不进 PipelineDesc —— 皮肤属性在独立缓冲）
    PipelineDesc pbrSkin = pbr;
    pbrSkin.shader = pbrSkinShader_;
    pbrSkinPipeline_ = device_.CreatePipeline(pbrSkin);

    // PBR 实例化：顶点属性 + 每实例 mat4（location 6..9，divisor=1）
    PipelineDesc pbrInst = pbr;
    pbrInst.shader = pbrInstShader_;
    pbrInst.layout = {
        { 0, 3, 40,  0, false, 0 },
        { 1, 3, 40, 12, false, 0 },
        { 2, 2, 40, 24, false, 0 },
        { 5, 2, 40, 32, false, 0 },
        { 6, 4, 64,  0, false, 1 },
        { 7, 4, 64, 16, false, 1 },
        { 8, 4, 64, 32, false, 1 },
        { 9, 4, 64, 48, false, 1 },
    };
    pbrInstPipeline_ = device_.CreatePipeline(pbrInst);

    // 深度预通道之后的颜色 pass：深度测试照常，深度值不再重复写。
    // 使用无 discard 的不透明变体，让 early-z 可以把被遮挡片元整段跳过。
    PipelineDesc pbrNoDepth = pbr;
    pbrNoDepth.shader = pbrOpaqueShader_;
    pbrNoDepth.depthWrite = false;
    pbrNoDepthPipeline_ = device_.CreatePipeline(pbrNoDepth);

    PipelineDesc pbrSkinNoDepth = pbrSkin;
    pbrSkinNoDepth.shader = pbrSkinOpaqueShader_;
    pbrSkinNoDepth.depthWrite = false;
    pbrSkinNoDepthPipeline_ = device_.CreatePipeline(pbrSkinNoDepth);

    PipelineDesc pbrInstNoDepth = pbrInst;
    pbrInstNoDepth.shader = pbrInstOpaqueShader_;
    pbrInstNoDepth.depthWrite = false;
    pbrInstNoDepthPipeline_ = device_.CreatePipeline(pbrInstNoDepth);

    // alpha 混合变体：弹孔贴片 / 枪口火光等"贴片"材质。
    // 不写深度（避免遮挡后面的半透明片），仍做深度测试（被墙挡住时不画）。
    PipelineDesc pbrBlend = pbr;
    pbrBlend.blend = true;
    pbrBlend.depthWrite = false;
    pbrBlendPipeline_ = device_.CreatePipeline(pbrBlend);

    PipelineDesc pbrBlendSkin = pbrBlend;
    pbrBlendSkin.shader = pbrSkinShader_;
    pbrBlendSkinPipeline_ = device_.CreatePipeline(pbrBlendSkin);

    // 阴影：仅位置；正面剔除（只写背面深度）——消除平面上低角度光照的自阴影摩尔纹
    PipelineDesc shadow;
    shadow.shader = shadowShader_;
    shadow.layout = { { 0, 3, 40, 0, false } };
    shadow.cull = true;
    shadow.cullFront = false;   // 单面地形用正面剔除会漏掉地面，保持背面剔除
    shadowPipeline_ = device_.CreatePipeline(shadow);

    // 阴影蒙皮变体（3/4 槽同由 BindSkinBuffer 补发）
    PipelineDesc shadowSkin = shadow;
    shadowSkin.shader = shadowSkinShader_;
    shadowSkinPipeline_ = device_.CreatePipeline(shadowSkin);

    // 阴影实例化：位置 + 每实例 mat4
    PipelineDesc shadowInst;
    shadowInst.shader = shadowInstShader_;
    shadowInst.layout = {
        { 0, 3, 40, 0, false, 0 },
        { 6, 4, 64,  0, false, 1 },
        { 7, 4, 64, 16, false, 1 },
        { 8, 4, 64, 32, false, 1 },
        { 9, 4, 64, 48, false, 1 },
    };
    shadowInst.cull = true;
    shadowInst.cullFront = false;
    shadowInstPipeline_ = device_.CreatePipeline(shadowInst);

    // 深度预通道：只写深度，不写颜色
    PipelineDesc depth;
    depth.shader = depthShader_;
    depth.layout = { { 0, 3, 40, 0, false, 0 } };
    depth.colorWrite = false;
    depthPipeline_ = device_.CreatePipeline(depth);

    PipelineDesc depthInst = depth;
    depthInst.shader = depthInstShader_;
    depthInst.layout = {
        { 0, 3, 40, 0, false, 0 },
        { 6, 4, 64,  0, false, 1 },
        { 7, 4, 64, 16, false, 1 },
        { 8, 4, 64, 32, false, 1 },
        { 9, 4, 64, 48, false, 1 },
    };
    depthInstPipeline_ = device_.CreatePipeline(depthInst);

    PipelineDesc depthSkin = depth;
    depthSkin.shader = depthSkinShader_;
    depthSkinPipeline_ = device_.CreatePipeline(depthSkin);

    // 阴影遮罩：全屏三角、无深度、无剔除
    PipelineDesc shadowMask;
    shadowMask.shader = shadowMaskShader_;
    shadowMask.depthTest = false;
    shadowMask.depthWrite = false;
    shadowMask.cull = false;
    shadowMaskPipeline_ = device_.CreatePipeline(shadowMask);

    // 泛光链：全屏三角、无深度、无剔除
    PipelineDesc bloom;
    bloom.shader = bloomShader_;
    bloom.depthTest = false;
    bloom.depthWrite = false;
    bloom.cull = false;
    bloomPipeline_ = device_.CreatePipeline(bloom);

    // 后处理：无顶点输入，关深度
    PipelineDesc post;
    post.shader = postShader_;
    post.depthTest = false;
    post.depthWrite = false;
    post.cull = false;
    postPipeline_ = device_.CreatePipeline(post);

    return pbrPipeline_.IsValid() && pbrSkinPipeline_.IsValid() &&
           pbrInstPipeline_.IsValid() &&
           pbrNoDepthPipeline_.IsValid() && pbrSkinNoDepthPipeline_.IsValid() &&
           pbrInstNoDepthPipeline_.IsValid() &&
           pbrBlendPipeline_.IsValid() && pbrBlendSkinPipeline_.IsValid() &&
           shadowPipeline_.IsValid() && shadowSkinPipeline_.IsValid() &&
           shadowInstPipeline_.IsValid() &&
           depthPipeline_.IsValid() && depthInstPipeline_.IsValid() &&
           depthSkinPipeline_.IsValid() && shadowMaskPipeline_.IsValid() &&
           bloomPipeline_.IsValid() && postPipeline_.IsValid();
}

void RenderSystem::Shutdown() {
    if (hdrFB_.IsValid())    device_.DestroyFramebuffer(hdrFB_);
    if (shadowFB_.IsValid()) device_.DestroyFramebuffer(shadowFB_);
    if (pbrPipeline_.IsValid())    device_.DestroyPipeline(pbrPipeline_);
    if (pbrInstPipeline_.IsValid()) device_.DestroyPipeline(pbrInstPipeline_);
    if (pbrNoDepthPipeline_.IsValid()) device_.DestroyPipeline(pbrNoDepthPipeline_);
    if (pbrSkinNoDepthPipeline_.IsValid()) device_.DestroyPipeline(pbrSkinNoDepthPipeline_);
    if (pbrInstNoDepthPipeline_.IsValid()) device_.DestroyPipeline(pbrInstNoDepthPipeline_);
    if (pbrSkinPipeline_.IsValid()) device_.DestroyPipeline(pbrSkinPipeline_);
    if (pbrBlendPipeline_.IsValid()) device_.DestroyPipeline(pbrBlendPipeline_);
    if (pbrBlendSkinPipeline_.IsValid()) device_.DestroyPipeline(pbrBlendSkinPipeline_);
    if (shadowPipeline_.IsValid()) device_.DestroyPipeline(shadowPipeline_);
    if (shadowInstPipeline_.IsValid()) device_.DestroyPipeline(shadowInstPipeline_);
    if (depthPipeline_.IsValid()) device_.DestroyPipeline(depthPipeline_);
    if (depthInstPipeline_.IsValid()) device_.DestroyPipeline(depthInstPipeline_);
    if (depthSkinPipeline_.IsValid()) device_.DestroyPipeline(depthSkinPipeline_);
    if (shadowMaskPipeline_.IsValid()) device_.DestroyPipeline(shadowMaskPipeline_);
    if (bloomPipeline_.IsValid()) device_.DestroyPipeline(bloomPipeline_);
    if (postPipeline_.IsValid())   device_.DestroyPipeline(postPipeline_);
    if (pbrShader_.IsValid())    device_.DestroyShader(pbrShader_);
    if (pbrInstShader_.IsValid()) device_.DestroyShader(pbrInstShader_);
    if (pbrOpaqueShader_.IsValid()) device_.DestroyShader(pbrOpaqueShader_);
    if (pbrSkinOpaqueShader_.IsValid()) device_.DestroyShader(pbrSkinOpaqueShader_);
    if (pbrInstOpaqueShader_.IsValid()) device_.DestroyShader(pbrInstOpaqueShader_);
    if (shadowShader_.IsValid()) device_.DestroyShader(shadowShader_);
    if (shadowInstShader_.IsValid()) device_.DestroyShader(shadowInstShader_);
    if (depthShader_.IsValid()) device_.DestroyShader(depthShader_);
    if (depthSkinShader_.IsValid()) device_.DestroyShader(depthSkinShader_);
    if (depthInstShader_.IsValid()) device_.DestroyShader(depthInstShader_);
    if (shadowMaskShader_.IsValid()) device_.DestroyShader(shadowMaskShader_);
    if (bloomShader_.IsValid()) device_.DestroyShader(bloomShader_);
    if (postShader_.IsValid())   device_.DestroyShader(postShader_);
    for (auto& fb : bloomFB_) {
        if (fb.IsValid()) device_.DestroyFramebuffer(fb);
        fb = {};
    }
    if (shadowMaskFB_.IsValid()) device_.DestroyFramebuffer(shadowMaskFB_);
    shadowMaskFB_ = {};
    for (RHI::BufferHandle h : instBuffers_) {
        if (h.IsValid()) device_.DestroyBuffer(h);
    }
    for (RHI::BufferHandle h : shadowInstBuffers_) {
        if (h.IsValid()) device_.DestroyBuffer(h);
    }
    instBuffers_.clear();
    instBufferCaps_.clear();
    shadowInstBuffers_.clear();
    shadowInstBufferCaps_.clear();
    if (lightGridTex_.IsValid()) device_.DestroyTexture(lightGridTex_);
    lightGridTex_ = {};
    hdrFB_ = {};
    shadowFB_ = {};
}

void RenderSystem::OnResize(u32 width, u32 height) {
    if (width == 0 || height == 0) return;
    if (width == viewportW_ && height == viewportH_) return;
    viewportW_ = width;
    viewportH_ = height;
    if (hdrFB_.IsValid()) device_.DestroyFramebuffer(hdrFB_);
    const f32 scale = std::clamp(config_.renderScale, 0.5f, 1.0f);
    FramebufferDesc hdr;
    hdr.width = std::max(1u, static_cast<u32>(static_cast<f32>(width) * scale));
    hdr.height = std::max(1u, static_cast<u32>(static_cast<f32>(height) * scale));
    hdr.mode = FramebufferMode::HDR;
    renderW_ = hdr.width;
    renderH_ = hdr.height;
    hdrFB_ = device_.CreateFramebuffer(hdr);
    createBloomTargets(hdr.width, hdr.height);
    createLightGridTexture();
    createShadowMaskTarget(renderW_, renderH_);
}

void RenderSystem::createLightGridTexture() {
    if (lightGridTex_.IsValid()) device_.DestroyTexture(lightGridTex_);
    lightGridTex_ = {};
    lightGridTilesX_ = (renderW_ + kLightTileSize - 1) / kLightTileSize;
    lightGridTilesY_ = (renderH_ + kLightTileSize - 1) / kLightTileSize;
    if (lightGridTilesX_ == 0 || lightGridTilesY_ == 0) return;

    RHI::TextureDesc desc;
    desc.width = lightGridTilesX_ * 2;
    desc.height = lightGridTilesY_;
    desc.format = RHI::Format::RGBA8;
    desc.filter = RHI::TextureFilter::Nearest;
    desc.wrap = RHI::SamplerWrap::ClampToEdge;
    desc.mipmaps = false;
    desc.srgb = false;
    lightGridTex_ = device_.CreateTexture(desc);
}

void RenderSystem::buildLightGrid() {
    lightGridActive_ = false;
    stats_.lightOverflows = 0;
    if (!config_.lightGrid || !lightGridTex_.IsValid() ||
        lightGridTilesX_ == 0 || lightGridTilesY_ == 0) {
        return;
    }
    if (pointLights_.empty() && spotLights_.empty()) return;

    struct Tile {
        u8 refs[8];
        f32 scores[8];
        u8 count;
    };
    std::vector<Tile> tiles(static_cast<size_t>(lightGridTilesX_) * lightGridTilesY_);
    for (Tile& tile : tiles) {
        tile.count = 0;
        std::memset(tile.refs, 0, sizeof(tile.refs));
        std::memset(tile.scores, 0, sizeof(tile.scores));
    }

    const f32 focal = (static_cast<f32>(renderH_) * 0.5f) / std::tan(fovY_ * 0.5f);
    const i32 tilesX = static_cast<i32>(lightGridTilesX_);
    const i32 tilesY = static_cast<i32>(lightGridTilesY_);
    const f32 tileSize = static_cast<f32>(kLightTileSize);

    auto addLight = [&](const Vec3& pos, f32 range, f32 intensity, u8 ref) {
        i32 x0 = 0, y0 = 0, x1 = tilesX - 1, y1 = tilesY - 1;
        f32 sx = 0.0f, sy = 0.0f;
        bool globalLight = false;
        const Vec4 viewPos = viewMatrix_ * Vec4(pos.x, pos.y, pos.z, 1.0f);
        const f32 viewDepth = -viewPos.z;
        if (viewDepth <= nearZ_) {
            // 光源在相机后方：只有相机本身处在光源范围内才保守地投到所有块。
            const Vec3 d = pos - cameraPos_;
            if (glm::dot(d, d) > range * range) return;
            globalLight = true;
        } else if (viewDepth <= range) {
            // 相机在光源球内：该灯可能照亮画面任意方向，保守地投到所有块。
            globalLight = true;
        } else {
            const Vec4 clip = projMatrix_ * viewPos;
            if (clip.w <= 1e-6f) return;
            sx = (clip.x / clip.w * 0.5f + 0.5f) * static_cast<f32>(renderW_);
            sy = (clip.y / clip.w * 0.5f + 0.5f) * static_cast<f32>(renderH_);
            // 透视投影下球体的精确屏幕半径（分母用 sqrt(depth² - range²)）。
            const f32 denom = std::sqrt(std::max(
                viewDepth * viewDepth - range * range, 1e-4f));
            const f32 rPix = range * focal / denom * 1.1f;
            if (sx + rPix < 0.0f || sx - rPix > static_cast<f32>(renderW_) ||
                sy + rPix < 0.0f || sy - rPix > static_cast<f32>(renderH_)) {
                return;
            }
            x0 = static_cast<i32>(std::floor((sx - rPix) / tileSize));
            x1 = static_cast<i32>(std::floor((sx + rPix) / tileSize));
            y0 = static_cast<i32>(std::floor((sy - rPix) / tileSize));
            y1 = static_cast<i32>(std::floor((sy + rPix) / tileSize));
            x0 = std::max(0, std::min(x0, tilesX - 1));
            x1 = std::max(0, std::min(x1, tilesX - 1));
            y0 = std::max(0, std::min(y0, tilesY - 1));
            y1 = std::max(0, std::min(y1, tilesY - 1));
        }
        for (i32 ty = y0; ty <= y1; ++ty) {
            for (i32 tx = x0; tx <= x1; ++tx) {
                Tile& tile = tiles[static_cast<size_t>(ty) * tilesX + tx];
                f32 score = intensity;
                if (!globalLight) {
                    // 越靠近屏幕块中心、强度越高，越值得保留。
                    const f32 cx = (static_cast<f32>(tx) + 0.5f) * tileSize;
                    const f32 cy = (static_cast<f32>(ty) + 0.5f) * tileSize;
                    const f32 dx = sx - cx;
                    const f32 dy = sy - cy;
                    score = intensity / (1.0f + dx * dx + dy * dy);
                }
                if (tile.count < 8) {
                    tile.refs[tile.count] = ref;
                    tile.scores[tile.count] = score;
                    ++tile.count;
                } else {
                    u32 weakest = 0;
                    for (u32 k = 1; k < 8; ++k) {
                        if (tile.scores[k] < tile.scores[weakest]) weakest = k;
                    }
                    if (score > tile.scores[weakest]) {
                        tile.refs[weakest] = ref;
                        tile.scores[weakest] = score;
                    } else {
                        ++stats_.lightOverflows;
                    }
                }
            }
        }
    };

    for (u32 i = 0; i < pointLights_.size(); ++i) {
        addLight(pointLights_[i].position, pointLights_[i].range,
                 pointLights_[i].intensity, static_cast<u8>(i + 1));
    }
    for (u32 i = 0; i < spotLights_.size(); ++i) {
        addLight(spotLights_[i].position, spotLights_[i].range,
                 spotLights_[i].intensity, static_cast<u8>(32 + i + 1));
    }

    // 每块按强度从高到低排序：着色器用前 N 盏走完整 PBR，其余走轻量 BRDF。
    for (Tile& tile : tiles) {
        for (u32 a = 1; a < tile.count; ++a) {
            const u8 ref = tile.refs[a];
            const f32 score = tile.scores[a];
            i32 b = static_cast<i32>(a) - 1;
            while (b >= 0 && tile.scores[b] < score) {
                tile.refs[b + 1] = tile.refs[b];
                tile.scores[b + 1] = tile.scores[b];
                --b;
            }
            tile.refs[b + 1] = ref;
            tile.scores[b + 1] = score;
        }
    }

    const u32 texW = lightGridTilesX_ * 2;
    std::vector<u8> data(static_cast<size_t>(texW) * lightGridTilesY_ * 4, 0);
    for (u32 ty = 0; ty < lightGridTilesY_; ++ty) {
        for (u32 tx = 0; tx < lightGridTilesX_; ++tx) {
            const Tile& tile =
                tiles[static_cast<size_t>(ty) * lightGridTilesX_ + tx];
            for (u32 k = 0; k < 8; ++k) {
                const u32 texelX = tx * 2 + (k >= 4 ? 1 : 0);
                const size_t index =
                    (static_cast<size_t>(ty) * texW + texelX) * 4 + (k % 4);
                data[index] = tile.refs[k];
            }
        }
    }

    cmd_.UpdateTexture(lightGridTex_, 0, 0, texW, lightGridTilesY_,
                       data.data(), static_cast<u32>(data.size()));
    lightGridActive_ = true;
}

// =====================================================================
// 帧级状态
// =====================================================================

void RenderSystem::SetCamera(const Vec3& eye, const Vec3& target,
                             f32 fovYDeg, f32 aspect, f32 nearZ, f32 farZ) {
    viewMatrix_ = glm::lookAt(eye, target, Vec3(0.0f, 1.0f, 0.0f));
    projMatrix_ = glm::perspective(glm::radians(fovYDeg), aspect, nearZ, farZ);
    cameraPos_ = eye;
    fovY_ = glm::radians(fovYDeg);
    aspect_ = aspect;
    nearZ_ = nearZ;
    farZ_ = farZ;
}

void RenderSystem::SetDirectionalLight(const DirectionalLight& light) {
    dirLight_ = light;
    dirLightEnabled_ = true;
}

void RenderSystem::AddPointLight(const PointLight& light) {
    if (pointLights_.size() < kMaxPointLights) pointLights_.push_back(light);
}

void RenderSystem::AddSpotLight(const SpotLight& light) {
    if (spotLights_.size() < kMaxSpotLights) spotLights_.push_back(light);
}

void RenderSystem::ClearLights() {
    pointLights_.clear();
    spotLights_.clear();
    dirLightEnabled_ = false;
}

// =====================================================================
// Pass 录制
// =====================================================================

namespace {

/// 视锥（6 个平面，已归一化），用于静态盒体的粗剔除。
struct ViewFrustum {
    f32 p[6][4];
};

ViewFrustum MakeViewFrustum(const Mat4& m) {
    ViewFrustum f{};
    auto e = [&](int col, int row) { return m.at(col, row); };
    // 行主序取出 4 行（列主序存储：at(col,row)）
    f32 rows[4][4];
    for (int r = 0; r < 4; r++)
        for (int c = 0; c < 4; c++)
            rows[r][c] = e(c, r);

    auto setPlane = [&](int i, int rA, f32 s) {
        f32 len2 = 0.0f;
        for (int c = 0; c < 4; c++) {
            f.p[i][c] = rows[3][c] + s * rows[rA][c];
            if (c < 3) len2 += f.p[i][c] * f.p[i][c];
        }
        const f32 inv = 1.0f / std::sqrt(std::max(len2, 1e-8f));
        for (int c = 0; c < 4; c++) f.p[i][c] *= inv;
    };
    setPlane(0, 0,  1.0f);   // left
    setPlane(1, 0, -1.0f);   // right
    setPlane(2, 1,  1.0f);   // bottom
    setPlane(3, 1, -1.0f);   // top
    setPlane(4, 2,  1.0f);   // near
    setPlane(5, 2, -1.0f);   // far
    return f;
}

/// AABB 是否完全在视锥外（真 = 可跳过）。
bool AabbOutside(const ViewFrustum& f, const Vec3& c, const Vec3& h) {
    for (int i = 0; i < 6; i++) {
        const f32 px = (f.p[i][0] >= 0.0f) ? c.x + h.x : c.x - h.x;
        const f32 py = (f.p[i][1] >= 0.0f) ? c.y + h.y : c.y - h.y;
        const f32 pz = (f.p[i][2] >= 0.0f) ? c.z + h.z : c.z - h.z;
        if (f.p[i][0] * px + f.p[i][1] * py + f.p[i][2] * pz + f.p[i][3] < 0.0f)
            return true;
    }
    return false;
}

// --- 材质/设置哈希：只用于分组与缓存失效判断，不参与渲染逻辑 ---

constexpr u64 kHashSeed = 1469598103934665603ull;
constexpr u64 kHashPrime = 1099511628211ull;

u64 HashU32(u64 h, u32 v) {
    h ^= v;
    return h * kHashPrime;
}

u64 HashF32(u64 h, f32 v) {
    u32 bits = 0;
    std::memcpy(&bits, &v, sizeof(bits));
    return HashU32(h, bits);
}

u64 HashString(u64 h, const String& s) {
    for (unsigned char c : s) {
        h ^= c;
        h *= kHashPrime;
    }
    return h;
}

} // namespace

Mat4 RenderSystem::computeLightSpaceMatrix(const Vec3& lightDir, const Vec3& center) const {
    Vec3 dir = glm::normalize(lightDir);
    if (glm::length(dir) < 0.5f) dir = Vec3(0.0f, -1.0f, 0.0f);
    Vec3 up = std::fabs(dir.y) > 0.999f ? Vec3(1.0f, 0.0f, 0.0f) : Vec3(0.0f, 1.0f, 0.0f);

    const f32 r = config_.shadowRadius;
    Vec3 eye = center - dir * r * 2.0f;
    Mat4 view = glm::lookAt(eye, center, up);
    Mat4 proj = glm::ortho(-r, r, -r, r, 0.1f, r * 4.0f);
    return proj * view;
}

RenderSystem::CachedDraw* RenderSystem::getCachedDraw(
    ECS::Entity entity, const Scene::MeshRef& meshRef) {
    if (entity.index >= drawCache_.size()) drawCache_.resize(entity.index + 1);

    // 只哈希会影响资产解析的字段。字符串很短，1800 个实体约几十微秒；
    // 相比每帧 4~6 次资产表查找 + 纹理键拼接，这是数量级的下降。
    u64 settings = kHashSeed;
    settings = HashString(settings, meshRef.path);
    settings = HashU32(settings, meshRef.submesh);
    settings = HashString(settings, meshRef.texturePath);
    settings = HashString(settings, meshRef.normalPath);
    settings = HashString(settings, meshRef.ormPath);
    settings = HashString(settings, meshRef.emissivePath);
    settings = HashString(settings, meshRef.lightmapPath);
    settings = HashF32(settings, meshRef.lightmapStrength);
    settings = HashF32(settings, meshRef.uvScale.x);
    settings = HashF32(settings, meshRef.uvScale.y);
    settings = HashF32(settings, meshRef.normalStrength);
    settings = HashF32(settings, meshRef.detailNormalScale);
    settings = HashF32(settings, meshRef.detailNormalStrength);
    settings = HashF32(settings, meshRef.detailRoughJitter);
    settings = HashF32(settings, meshRef.baseColor.x);
    settings = HashF32(settings, meshRef.baseColor.y);
    settings = HashF32(settings, meshRef.baseColor.z);
    settings = HashF32(settings, meshRef.baseColor.w);
    settings = HashF32(settings, meshRef.metallic);
    settings = HashF32(settings, meshRef.roughness);
    settings = HashF32(settings, meshRef.emissive.x);
    settings = HashF32(settings, meshRef.emissive.y);
    settings = HashF32(settings, meshRef.emissive.z);
    settings = HashU32(settings, meshRef.useAssetColors ? 1u : 0u);
    settings = HashU32(settings, meshRef.useAssetPbr ? 1u : 0u);

    auto& slot = drawCache_[entity.index];
    if (slot && slot->generation == entity.generation &&
        slot->settingsHash == settings) {
        return slot.get();
    }

    auto cached = std::make_unique<CachedDraw>();
    cached->path = meshRef.path;
    cached->settingsHash = settings;
    cached->generation = entity.generation;
    cached->gpu = assets_.GetGPUMesh(meshRef.path);
    if (!cached->gpu.vbo.IsValid() || !cached->gpu.ibo.IsValid()) {
        slot = std::move(cached);
        return nullptr;
    }
    cached->skinned = cached->gpu.skinned;

    const Asset::ModelData* model = assets_.GetModelData(meshRef.path);
    const RHI::TextureHandle lightmapTex = meshRef.lightmapPath.empty()
        ? RHI::TextureHandle{}
        : assets_.GetOrCreateTexture(meshRef.lightmapPath, /*srgb=*/false);

    auto resolveMaterial = [&](const Asset::ModelMaterial* mat) {
        MaterialState m;
        m.baseColor = meshRef.baseColor;
        f32 metallic = meshRef.metallic;
        f32 roughness = meshRef.roughness;
        if (mat && meshRef.useAssetColors) {
            m.baseColor = Vec4(m.baseColor.x * mat->baseColor.x,
                               m.baseColor.y * mat->baseColor.y,
                               m.baseColor.z * mat->baseColor.z,
                               m.baseColor.w * mat->baseColor.w);
        }
        if (mat && meshRef.useAssetPbr) {
            metallic *= mat->metallic;
            roughness *= mat->roughness;
        }
        m.metallic = metallic;
        m.roughness = roughness;
        m.alphaCutoff = mat ? mat->alphaCutoff : 0.0f;

        auto tex = [&](const String& overridePath, const String& assetPath,
                       bool srgb) -> RHI::TextureHandle {
            const String& path = overridePath.empty() ? assetPath : overridePath;
            return path.empty() ? RHI::TextureHandle{}
                                : assets_.GetOrCreateTexture(path, srgb);
        };
        m.baseTex = tex(meshRef.texturePath,
                        mat ? mat->texturePath : String(), true);
        m.normalTex = tex(meshRef.normalPath,
                          mat ? mat->normalPath : String(), false);
        m.ormTex = tex(meshRef.ormPath,
                       mat ? mat->metallicRoughnessPath : String(), false);
        m.emissiveTex = tex(meshRef.emissivePath,
                            mat ? mat->emissivePath : String(), true);

        m.emissive = meshRef.emissive;
        if (m.emissive.x <= 0.0f && m.emissive.y <= 0.0f &&
            m.emissive.z <= 0.0f && mat) {
            m.emissive = mat->emissiveFactor;
        }
        m.uvScale = meshRef.uvScale;
        m.normalStrength = meshRef.normalStrength;
        m.detailScale = meshRef.detailNormalScale;
        m.detailStrength = meshRef.detailNormalStrength;
        m.detailRoughJitter = meshRef.detailRoughJitter;
        m.useDetail = meshRef.detailNormalStrength > 0.0f ||
                      meshRef.detailRoughJitter > 0.0f;
        m.lightmapTex = lightmapTex;
        m.lightmapStrength = meshRef.lightmapStrength;

        u64 key = kHashSeed;
        key = HashU32(key, m.baseTex.id);
        key = HashU32(key, m.normalTex.id);
        key = HashU32(key, m.ormTex.id);
        key = HashU32(key, m.emissiveTex.id);
        key = HashU32(key, m.lightmapTex.id);
        key = HashF32(key, m.baseColor.x);
        key = HashF32(key, m.baseColor.y);
        key = HashF32(key, m.baseColor.z);
        key = HashF32(key, m.baseColor.w);
        key = HashF32(key, m.metallic);
        key = HashF32(key, m.roughness);
        key = HashF32(key, m.alphaCutoff);
        key = HashF32(key, m.emissive.x);
        key = HashF32(key, m.emissive.y);
        key = HashF32(key, m.emissive.z);
        key = HashF32(key, m.uvScale.x);
        key = HashF32(key, m.uvScale.y);
        key = HashF32(key, m.normalStrength);
        key = HashF32(key, m.detailScale);
        key = HashF32(key, m.detailStrength);
        key = HashF32(key, m.detailRoughJitter);
        key = HashF32(key, m.lightmapStrength);
        key = HashU32(key, m.useDetail ? 1u : 0u);
        m.key = key;
        return m;
    };

    if (model && model->mesh.submeshes.size() > 1) {
        const u32 count = static_cast<u32>(model->mesh.submeshes.size());
        cached->subs.reserve(count);
        for (u32 i = 0; i < count; ++i) {
            const Asset::ModelMaterial* mat = nullptr;
            if (i < model->submeshMaterials.size()) {
                const i32 mi = model->submeshMaterials[i];
                if (mi >= 0 && static_cast<u32>(mi) < model->materials.size()) {
                    mat = &model->materials[static_cast<u32>(mi)];
                }
            }
            CachedSub sub;
            sub.indexOffset = model->mesh.submeshes[i].indexOffset;
            sub.indexCount = model->mesh.submeshes[i].indexCount;
            sub.mat = resolveMaterial(mat);
            cached->subs.push_back(std::move(sub));
        }
    } else {
        CachedSub sub;
        if (model && !model->mesh.submeshes.empty()) {
            sub.indexOffset = model->mesh.submeshes[0].indexOffset;
            sub.indexCount = model->mesh.submeshes[0].indexCount;
        } else {
            sub.indexOffset = 0;
            sub.indexCount = cached->gpu.indexCount;
        }
        const Asset::ModelMaterial* mat =
            (model && !model->materials.empty()) ? &model->materials[0] : nullptr;
        sub.mat = resolveMaterial(mat);
        cached->subs.push_back(std::move(sub));
    }

    slot = std::move(cached);
    return slot.get();
}

void RenderSystem::prepareDraws(ECS::World& world, bool doShadow) {
    auto now = [] {
        return std::chrono::duration<double, std::milli>(
                   std::chrono::steady_clock::now().time_since_epoch())
            .count();
    };
    const double tCollect0 = now();
    opaqueStatic_.clear();
    opaqueSkinned_.clear();
    blendStatic_.clear();
    blendSkinned_.clear();
    shadowStatic_.clear();
    shadowSkinned_.clear();
    opaqueHasCutout_ = false;

    // 资产卸载/新增会让缓存里的句柄失效，版本变化时整表重建。
    if (cachedAssetRevision_ != assets_.Revision()) {
        drawCache_.clear();
        cachedAssetRevision_ = assets_.Revision();
    }

    const Mat4 vp = projMatrix_ * viewMatrix_;
    const ViewFrustum sceneVF = MakeViewFrustum(vp);
    Math::Frustum sceneGF;
    sceneGF.FromViewProjection(vp);

    ViewFrustum lightVF{};
    Math::Frustum lightGF;
    if (doShadow) {
        lightVF = MakeViewFrustum(lightSpaceMatrix_);
        lightGF.FromViewProjection(lightSpaceMatrix_);
    }

    auto outside = [&](const Scene::MeshRef& mr, const Transform& tr,
                       bool haveAabb, const Vec3& worldMin, const Vec3& worldMax,
                       const ViewFrustum& vf, const Math::Frustum& gf) {
        if (mr.path == "bf_box" &&
            AabbOutside(vf, tr.position, tr.scale * 0.75f)) {
            return true;
        }
        if (mr.frustumCull &&
            AabbOutside(vf, mr.cullCenter, mr.cullExtent)) {
            return true;
        }
        if (haveAabb && !gf.IntersectsAABB(worldMin, worldMax)) return true;
        return false;
    };

    auto transformEqual = [](const Transform& a, const Transform& b) {
        return a.position.x == b.position.x && a.position.y == b.position.y &&
               a.position.z == b.position.z && a.rotation.x == b.rotation.x &&
               a.rotation.y == b.rotation.y && a.rotation.z == b.rotation.z &&
               a.scale.x == b.scale.x && a.scale.y == b.scale.y &&
               a.scale.z == b.scale.z;
    };

    world.ForEach<Transform, MeshRef>(
        [&](ECS::Entity e, Transform& tr, MeshRef& meshRef) {
            if (!meshRef.visible) return;
            CachedDraw* cached = getCachedDraw(e, meshRef);
            if (!cached || cached->subs.empty()) return;

            const ECS::Entity parent = world.GetParent(e);
            Mat4 worldM;
            if (!parent.IsValid() && cached->hasTransform &&
                cached->lastParentIndex == ECS::kInvalidIndex &&
                transformEqual(tr, cached->lastTransform)) {
                worldM = cached->lastWorld;   // 静止根实体：矩阵跨帧复用
            } else {
                worldM = Scene::TransformSystem::GetWorldMatrix(world, e);
                cached->lastTransform = tr;
                cached->lastWorld = worldM;
                cached->hasTransform = true;
                cached->lastParentIndex =
                    parent.IsValid() ? parent.index : ECS::kInvalidIndex;
                cached->hasBounds = false;
            }

            bool haveAabb = false;
            Vec3 aabbMin, aabbMax;
            if (config_.frustumCulling && !cached->skinned) {
                if (!cached->hasBounds) {
                    Math::TransformAABB(worldM, cached->gpu.boundsMin,
                                        cached->gpu.boundsMax,
                                        cached->worldMin, cached->worldMax);
                    cached->hasBounds = true;
                }
                aabbMin = cached->worldMin;
                aabbMax = cached->worldMax;
                haveAabb = true;
            }

            const Animation::SkeletonComp* skeleton = nullptr;
            bool skinned = false;
            if (cached->skinned) {
                skeleton = world.GetComponent<Animation::SkeletonComp>(e);
                skinned = skeleton && !skeleton->palette.empty();
                if (!skinned) skeleton = nullptr;
            }

            const Vec3 pos(worldM.m[12], worldM.m[13], worldM.m[14]);
            const Vec3 delta = pos - cameraPos_;
            const f32 depth = glm::dot(delta, delta);

            if (!outside(meshRef, tr, haveAabb, aabbMin, aabbMax,
                         sceneVF, sceneGF)) {
                stats_.meshes++;
                for (const CachedSub& sub : cached->subs) {
                    DrawItem item;
                    item.entity = e;
                    item.world = worldM;
                    item.cached = cached;
                    item.sub = &sub;
                    item.skeleton = skeleton;
                    item.depth = depth;
                    if (meshRef.alphaBlend) {
                        (skinned ? blendSkinned_ : blendStatic_).push_back(item);
                    } else {
                        if (sub.mat.alphaCutoff > 0.0f) opaqueHasCutout_ = true;
                        (skinned ? opaqueSkinned_ : opaqueStatic_).push_back(item);
                    }
                }
            } else {
                stats_.culled++;
            }

            // 阴影剔除与场景剔除独立：被相机剔除的物体仍可能把影子投进画面。
            if (doShadow && meshRef.castShadow &&
                !outside(meshRef, tr, haveAabb, aabbMin, aabbMax,
                         lightVF, lightGF)) {
                ShadowItem item;
                item.entity = e;
                item.world = worldM;
                item.cached = cached;
                item.skeleton = skeleton;
                item.depth = depth;
                (skinned ? shadowSkinned_ : shadowStatic_).push_back(item);
            }
        });

    stats_.cpuCollectMs = static_cast<f32>(now() - tCollect0);
    const double tSort0 = now();

    // 不透明：材质优先（同材质只下发一次），同材质内按网格聚合，再按距离前到后。
    auto opaqueLess = [](const DrawItem& a, const DrawItem& b) {
        if (a.sub->mat.key != b.sub->mat.key) {
            return a.sub->mat.key < b.sub->mat.key;
        }
        if (a.cached->gpu.vbo.id != b.cached->gpu.vbo.id) {
            return a.cached->gpu.vbo.id < b.cached->gpu.vbo.id;
        }
        if (a.sub->indexOffset != b.sub->indexOffset) {
            return a.sub->indexOffset < b.sub->indexOffset;
        }
        if (a.sub->indexCount != b.sub->indexCount) {
            return a.sub->indexCount < b.sub->indexCount;
        }
        return a.depth < b.depth;
    };
    std::sort(opaqueStatic_.begin(), opaqueStatic_.end(), opaqueLess);
    std::sort(opaqueSkinned_.begin(), opaqueSkinned_.end(), opaqueLess);

    // 半透明：远到近，保证混合顺序正确。
    auto blendLess = [](const DrawItem& a, const DrawItem& b) {
        if (a.depth != b.depth) return a.depth > b.depth;
        return a.sub->mat.key < b.sub->mat.key;
    };
    std::sort(blendStatic_.begin(), blendStatic_.end(), blendLess);
    std::sort(blendSkinned_.begin(), blendSkinned_.end(), blendLess);

    // 阴影不关心顺序，按顶点缓冲聚合减少绑定切换。
    auto shadowLess = [](const ShadowItem& a, const ShadowItem& b) {
        if (a.cached->gpu.vbo.id != b.cached->gpu.vbo.id) {
            return a.cached->gpu.vbo.id < b.cached->gpu.vbo.id;
        }
        return a.depth < b.depth;
    };
    std::sort(shadowStatic_.begin(), shadowStatic_.end(), shadowLess);
    std::sort(shadowSkinned_.begin(), shadowSkinned_.end(), shadowLess);

    stats_.cpuSortMs = static_cast<f32>(now() - tSort0);
    const double tBatch0 = now();
    buildInstanceBatches();
    stats_.cpuBatchMs = static_cast<f32>(now() - tBatch0);

    cachedAssetRevision_ = assets_.Revision();
}

void RenderSystem::applyMaterial(const MaterialState& mat) {
    cmd_.SetVec4("u_BaseColor", mat.baseColor);
    cmd_.SetFloat("u_Metallic", mat.metallic);
    cmd_.SetFloat("u_Roughness", mat.roughness);
    cmd_.SetFloat("u_AlphaCutoff", mat.alphaCutoff);

    cmd_.SetFloat("u_UseBaseMap", mat.baseTex.IsValid() ? 1.0f : 0.0f);
    if (mat.baseTex.IsValid()) cmd_.BindTexture("u_BaseMap", 0, mat.baseTex);

    cmd_.SetFloat("u_UseNormalMap", mat.normalTex.IsValid() ? 1.0f : 0.0f);
    if (mat.normalTex.IsValid()) cmd_.BindTexture("u_NormalMap", 2, mat.normalTex);

    cmd_.SetFloat("u_UseMRMap", mat.ormTex.IsValid() ? 1.0f : 0.0f);
    if (mat.ormTex.IsValid()) cmd_.BindTexture("u_MRMap", 3, mat.ormTex);

    cmd_.SetVec3("u_Emissive", mat.emissive);
    cmd_.SetFloat("u_UseEmissiveMap",
                  mat.emissiveTex.IsValid() ? 1.0f : 0.0f);
    if (mat.emissiveTex.IsValid()) {
        cmd_.BindTexture("u_EmissiveMap", 4, mat.emissiveTex);
    }

    cmd_.SetVec2("u_UvScale", mat.uvScale);
    cmd_.SetFloat("u_NormalStrength", mat.normalStrength);
    cmd_.SetFloat("u_UseDetailNormal", mat.useDetail ? 1.0f : 0.0f);
    cmd_.SetFloat("u_DetailScale", mat.detailScale);
    cmd_.SetFloat("u_DetailStrength", mat.detailStrength);
    cmd_.SetFloat("u_DetailRoughJitter", mat.detailRoughJitter);
    if (mat.useDetail && detailNormalTex_.IsValid()) {
        cmd_.BindTexture("u_DetailNormal", 5, detailNormalTex_);
    }

    cmd_.SetFloat("u_UseLightmap", mat.lightmapTex.IsValid() ? 1.0f : 0.0f);
    cmd_.SetFloat("u_LightmapStrength", mat.lightmapStrength);
    if (mat.lightmapTex.IsValid()) {
        cmd_.BindTexture("u_Lightmap", 6, mat.lightmapTex);
    }
}

void RenderSystem::drawItems(const std::vector<DrawItem>& items, bool skinned) {
    u64 lastMaterial = 0;
    bool haveMaterial = false;
    for (const DrawItem& item : items) {
        if (!haveMaterial || item.sub->mat.key != lastMaterial) {
            applyMaterial(item.sub->mat);
            lastMaterial = item.sub->mat.key;
            haveMaterial = true;
            stats_.batches++;
        }
        // 皮肤缓冲必须先于顶点缓冲下发：BindSkinBuffer 只是登记句柄，
        // 真正的 3/4 槽属性指针在 BindVertexBuffer 的处理分支里补发。
        if (skinned && item.skeleton) {
            cmd_.SetMat4Array("u_BoneMatrices", item.skeleton->palette.data(),
                              static_cast<u32>(item.skeleton->palette.size()));
            cmd_.BindSkinBuffer(item.cached->gpu.skin);
        }
        cmd_.BindVertexBuffer(item.cached->gpu.vbo);
        cmd_.BindIndexBuffer(item.cached->gpu.ibo);
        cmd_.SetMat4("u_Model", item.world);
        cmd_.DrawIndexed(item.sub->indexCount, item.sub->indexOffset);
        stats_.sceneDraws++;
    }
}

RHI::BufferHandle RenderSystem::ensureInstanceBuffer(
    std::vector<RHI::BufferHandle>& buffers, std::vector<u32>& capacities,
    u32 index, const std::vector<Mat4>& models) {
    if (index >= buffers.size()) {
        buffers.resize(index + 1);
        capacities.resize(index + 1, 0);
    }
    const u32 count = static_cast<u32>(models.size());
    if (count == 0) return {};
    const u32 bytes = count * static_cast<u32>(sizeof(Mat4));
    if (!buffers[index].IsValid() || capacities[index] < count) {
        if (buffers[index].IsValid()) device_.DestroyBuffer(buffers[index]);
        RHI::BufferDesc desc;
        desc.size = bytes;
        desc.usage = RHI::BufferUsage::Vertex;
        desc.dynamic = true;
        buffers[index] = device_.CreateBuffer(desc);
        capacities[index] = count;
    }
    if (buffers[index].IsValid()) {
        cmd_.UpdateBuffer(buffers[index], models.data(), bytes);
    }
    return buffers[index];
}

void RenderSystem::buildInstanceBatches() {
    opaqueInst_.clear();
    shadowInst_.clear();

    // 4 个以下合并成实例化反而多一次间接寻址，保留普通 draw。
    constexpr size_t kMinInstances = 4;

    auto sameDraw = [](const DrawItem& a, const DrawItem& b) {
        return a.sub->mat.key == b.sub->mat.key &&
               a.cached->gpu.vbo.id == b.cached->gpu.vbo.id &&
               a.sub->indexOffset == b.sub->indexOffset &&
               a.sub->indexCount == b.sub->indexCount;
    };

    std::vector<DrawItem> individuals;
    individuals.reserve(opaqueStatic_.size());
    size_t i = 0;
    while (i < opaqueStatic_.size()) {
        size_t j = i + 1;
        while (j < opaqueStatic_.size() &&
               sameDraw(opaqueStatic_[i], opaqueStatic_[j])) {
            ++j;
        }
        const size_t count = j - i;
        if (count >= kMinInstances) {
            InstancedBatch batch;
            batch.cached = opaqueStatic_[i].cached;
            batch.sub = opaqueStatic_[i].sub;
            batch.materialKey = opaqueStatic_[i].sub->mat.key;
            batch.models.reserve(count);
            f64 depthSum = 0.0;
            for (size_t k = i; k < j; ++k) {
                batch.models.push_back(opaqueStatic_[k].world);
                depthSum += static_cast<f64>(opaqueStatic_[k].depth);
            }
            batch.depth = static_cast<f32>(depthSum / static_cast<f64>(count));
            opaqueInst_.push_back(std::move(batch));
        } else {
            individuals.insert(individuals.end(),
                               opaqueStatic_.begin() + static_cast<i64>(i),
                               opaqueStatic_.begin() + static_cast<i64>(j));
        }
        i = j;
    }
    opaqueStatic_.swap(individuals);

    std::vector<ShadowItem> shadowIndividuals;
    shadowIndividuals.reserve(shadowStatic_.size());
    i = 0;
    while (i < shadowStatic_.size()) {
        const u32 vboId = shadowStatic_[i].cached->gpu.vbo.id;
        size_t j = i + 1;
        while (j < shadowStatic_.size() &&
               shadowStatic_[j].cached->gpu.vbo.id == vboId) {
            ++j;
        }
        const size_t count = j - i;
        if (count >= kMinInstances) {
            ShadowInstancedBatch batch;
            batch.cached = shadowStatic_[i].cached;
            batch.models.reserve(count);
            for (size_t k = i; k < j; ++k) {
                batch.models.push_back(shadowStatic_[k].world);
            }
            shadowInst_.push_back(std::move(batch));
        } else {
            shadowIndividuals.insert(
                shadowIndividuals.end(),
                shadowStatic_.begin() + static_cast<i64>(i),
                shadowStatic_.begin() + static_cast<i64>(j));
        }
        i = j;
    }
    shadowStatic_.swap(shadowIndividuals);
}

void RenderSystem::prepareInstanceBuffers() {
    opaqueInstHandles_.resize(opaqueInst_.size());
    for (u32 i = 0; i < opaqueInst_.size(); ++i) {
        opaqueInstHandles_[i] = ensureInstanceBuffer(
            instBuffers_, instBufferCaps_, i, opaqueInst_[i].models);
    }
}

void RenderSystem::recordDepthPrepass() {
    if (!config_.depthPrepass) return;
    const Mat4 vp = projMatrix_ * viewMatrix_;

    if (!opaqueInst_.empty()) {
        cmd_.BindPipeline(depthInstPipeline_);
        cmd_.SetMat4("u_ViewProj", vp);
        for (u32 i = 0; i < opaqueInst_.size(); ++i) {
            const InstancedBatch& batch = opaqueInst_[i];
            if (batch.sub->mat.alphaCutoff > 0.0f) continue;
            const RHI::BufferHandle instances =
                (i < opaqueInstHandles_.size()) ? opaqueInstHandles_[i]
                                                : RHI::BufferHandle{};
            if (!instances.IsValid()) continue;
            cmd_.BindVertexBuffer(batch.cached->gpu.vbo);
            cmd_.BindIndexBuffer(batch.cached->gpu.ibo);
            cmd_.BindInstanceBuffer(instances);
            cmd_.DrawIndexedInstanced(batch.sub->indexCount,
                                      static_cast<u32>(batch.models.size()),
                                      batch.sub->indexOffset);
            stats_.prepassDraws++;
        }
    }

    if (!opaqueStatic_.empty()) {
        cmd_.BindPipeline(depthPipeline_);
        cmd_.SetMat4("u_ViewProj", vp);
        for (const DrawItem& item : opaqueStatic_) {
            if (item.sub->mat.alphaCutoff > 0.0f) continue;
            cmd_.BindVertexBuffer(item.cached->gpu.vbo);
            cmd_.BindIndexBuffer(item.cached->gpu.ibo);
            cmd_.SetMat4("u_Model", item.world);
            cmd_.DrawIndexed(item.sub->indexCount, item.sub->indexOffset);
            stats_.prepassDraws++;
        }
    }

    if (!opaqueSkinned_.empty()) {
        cmd_.BindPipeline(depthSkinPipeline_);
        cmd_.SetMat4("u_ViewProj", vp);
        for (const DrawItem& item : opaqueSkinned_) {
            if (item.sub->mat.alphaCutoff > 0.0f || !item.skeleton) continue;
            cmd_.SetMat4Array("u_BoneMatrices", item.skeleton->palette.data(),
                              static_cast<u32>(item.skeleton->palette.size()));
            cmd_.BindSkinBuffer(item.cached->gpu.skin);
            cmd_.BindVertexBuffer(item.cached->gpu.vbo);
            cmd_.BindIndexBuffer(item.cached->gpu.ibo);
            cmd_.SetMat4("u_Model", item.world);
            cmd_.DrawIndexed(item.sub->indexCount, item.sub->indexOffset);
            stats_.prepassDraws++;
        }
    }
}

void RenderSystem::recordShadowMaskPass() {
    if (!shadowMaskFB_.IsValid() || !hdrFB_.IsValid() || !shadowFB_.IsValid()) {
        return;
    }

    cmd_.BindPipeline(shadowMaskPipeline_);
    cmd_.BindFramebuffer(shadowMaskFB_);

    // 相机基向量：从 view 矩阵的三行取出（world→view 的旋转转置）。
    const Mat4& v = viewMatrix_;
    const Vec3 right(v.m[0], v.m[4], v.m[8]);
    const Vec3 up(v.m[1], v.m[5], v.m[9]);
    const Vec3 forward(-v.m[2], -v.m[6], -v.m[10]);
    const f32 tanY = std::tan(fovY_ * 0.5f);

    cmd_.SetMat4("u_LightSpaceMatrix", lightSpaceMatrix_);
    cmd_.SetVec3("u_CameraPos", cameraPos_);
    cmd_.SetVec3("u_CameraRight", right);
    cmd_.SetVec3("u_CameraUp", up);
    cmd_.SetVec3("u_CameraForward", forward);
    cmd_.SetVec2("u_TanHalfFov", Vec2(tanY * aspect_, tanY));
    cmd_.SetVec2("u_NearFar", Vec2(nearZ_, farZ_));
    cmd_.SetVec3("u_DirLightDir", glm::normalize(dirLight_.direction));
    cmd_.BindTexture("u_SceneDepth", 0,
                     device_.GetFramebufferDepthTexture(hdrFB_));
    cmd_.BindTexture("u_ShadowMap", 1,
                     device_.GetFramebufferDepthTexture(shadowFB_));
    cmd_.Draw(3, 0);
}

void RenderSystem::drawInstancedOpaque() {
    u64 lastMaterial = 0;
    bool haveMaterial = false;
    for (u32 i = 0; i < opaqueInst_.size(); ++i) {
        const InstancedBatch& batch = opaqueInst_[i];
        if (!haveMaterial || batch.materialKey != lastMaterial) {
            applyMaterial(batch.sub->mat);
            lastMaterial = batch.materialKey;
            haveMaterial = true;
            stats_.batches++;
        }
        const RHI::BufferHandle instances =
            (i < opaqueInstHandles_.size()) ? opaqueInstHandles_[i]
                                            : RHI::BufferHandle{};
        if (!instances.IsValid()) continue;
        cmd_.BindVertexBuffer(batch.cached->gpu.vbo);
        cmd_.BindIndexBuffer(batch.cached->gpu.ibo);
        cmd_.BindInstanceBuffer(instances);
        cmd_.DrawIndexedInstanced(batch.sub->indexCount,
                                  static_cast<u32>(batch.models.size()),
                                  batch.sub->indexOffset);
        stats_.sceneDraws++;
    }
}

void RenderSystem::drawInstancedShadow() {
    if (shadowInst_.empty()) return;
    cmd_.BindPipeline(shadowInstPipeline_);
    cmd_.SetMat4("u_LightSpaceMatrix", lightSpaceMatrix_);
    for (u32 i = 0; i < shadowInst_.size(); ++i) {
        const ShadowInstancedBatch& batch = shadowInst_[i];
        RHI::BufferHandle instances = ensureInstanceBuffer(
            shadowInstBuffers_, shadowInstBufferCaps_, i, batch.models);
        if (!instances.IsValid()) continue;
        cmd_.BindVertexBuffer(batch.cached->gpu.vbo);
        cmd_.BindIndexBuffer(batch.cached->gpu.ibo);
        cmd_.BindInstanceBuffer(instances);
        cmd_.DrawIndexedInstanced(batch.cached->gpu.indexCount,
                                  static_cast<u32>(batch.models.size()));
        stats_.shadowDraws++;
    }
}

void RenderSystem::recordShadowPass() {
    cmd_.BindFramebuffer(shadowFB_);
    cmd_.Clear(1.0f, 1.0f, 1.0f, 1.0f, true);

    drawInstancedShadow();

    if (!shadowStatic_.empty()) {
        cmd_.BindPipeline(shadowPipeline_);
        cmd_.SetMat4("u_LightSpaceMatrix", lightSpaceMatrix_);
        for (const ShadowItem& item : shadowStatic_) {
            cmd_.BindVertexBuffer(item.cached->gpu.vbo);
            cmd_.BindIndexBuffer(item.cached->gpu.ibo);
            cmd_.SetMat4("u_Model", item.world);
            cmd_.DrawIndexed(item.cached->gpu.indexCount);
            stats_.shadowDraws++;
        }
    }

    if (!shadowSkinned_.empty()) {
        cmd_.BindPipeline(shadowSkinPipeline_);
        cmd_.SetMat4("u_LightSpaceMatrix", lightSpaceMatrix_);
        for (const ShadowItem& item : shadowSkinned_) {
            if (!item.skeleton) continue;
            cmd_.SetMat4Array("u_BoneMatrices", item.skeleton->palette.data(),
                              static_cast<u32>(item.skeleton->palette.size()));
            cmd_.BindSkinBuffer(item.cached->gpu.skin);
            cmd_.BindVertexBuffer(item.cached->gpu.vbo);
            cmd_.BindIndexBuffer(item.cached->gpu.ibo);
            cmd_.SetMat4("u_Model", item.world);
            cmd_.DrawIndexed(item.cached->gpu.indexCount);
            stats_.shadowDraws++;
        }
    }
}

void RenderSystem::setSceneGlobals() {
        cmd_.SetMat4("u_ViewProj", projMatrix_ * viewMatrix_);
        cmd_.SetMat4("u_LightSpaceMatrix", lightSpaceMatrix_);
        cmd_.SetVec3("u_CameraPos", cameraPos_);
        cmd_.SetVec3("u_AmbientSky", config_.ambientSky);
        cmd_.SetVec3("u_AmbientGround", config_.ambientGround);
        cmd_.SetFloat("u_LightmapDebug", config_.lightmapDebug ? 1.0f : 0.0f);
        cmd_.SetFloat("u_CheapDynamicLights",
                      config_.cheapDynamicLights ? 1.0f : 0.0f);
        cmd_.SetFloat("u_DynamicLightFullCount",
                      static_cast<f32>(config_.dynamicLightFullCount));

        if (dirLightEnabled_) {
            cmd_.SetFloat("u_DirLightEnabled", 1.0f);
            cmd_.SetVec3("u_DirLightDir", glm::normalize(dirLight_.direction));
            cmd_.SetVec3("u_DirLightColor", dirLight_.color);
            cmd_.SetFloat("u_DirLightIntensity", dirLight_.intensity);
        } else {
            cmd_.SetFloat("u_DirLightEnabled", 0.0f);
        }

        cmd_.SetFloat("u_PointLightCount", static_cast<f32>(pointLights_.size()));
        for (u32 i = 0; i < pointLights_.size(); i++) {
            char name[40];
            std::snprintf(name, sizeof(name), "u_PointLights[%u].position", i);
            cmd_.SetVec3(name, pointLights_[i].position);
            std::snprintf(name, sizeof(name), "u_PointLights[%u].color", i);
            cmd_.SetVec3(name, pointLights_[i].color);
            std::snprintf(name, sizeof(name), "u_PointLights[%u].intensity", i);
            cmd_.SetFloat(name, pointLights_[i].intensity);
            std::snprintf(name, sizeof(name), "u_PointLights[%u].range", i);
            cmd_.SetFloat(name, pointLights_[i].range);
        }

        const bool wantShadow = dirLightEnabled_ && dirLight_.castShadows &&
                                shadowFB_.IsValid();
        const bool shadowOn = wantShadow && shadowValid_;
        const bool maskOn = shadowOn && shadowMaskActive_ &&
                            shadowMaskFB_.IsValid();
        cmd_.SetFloat("u_ShadowEnabled", shadowOn ? 1.0f : 0.0f);
        cmd_.SetFloat("u_ShadowMaskEnabled", maskOn ? 1.0f : 0.0f);
        cmd_.SetVec2("u_RenderSize", Vec2(static_cast<f32>(renderW_),
                                          static_cast<f32>(renderH_)));
        if (maskOn) {
            cmd_.BindTexture("u_ShadowMask", 1,
                             device_.GetFramebufferColorTexture(shadowMaskFB_));
        } else if (shadowOn) {
            cmd_.BindTexture("u_ShadowMap", 1,
                             device_.GetFramebufferDepthTexture(shadowFB_));
        }

        cmd_.SetFloat("u_SpotLightCount", static_cast<f32>(spotLights_.size()));
        for (u32 i = 0; i < spotLights_.size(); i++) {
            char name[44];
            std::snprintf(name, sizeof(name), "u_SpotLights[%u].position", i);
            cmd_.SetVec3(name, spotLights_[i].position);
            std::snprintf(name, sizeof(name), "u_SpotLights[%u].direction", i);
            cmd_.SetVec3(name, glm::normalize(spotLights_[i].direction));
            std::snprintf(name, sizeof(name), "u_SpotLights[%u].color", i);
            cmd_.SetVec3(name, spotLights_[i].color);
            std::snprintf(name, sizeof(name), "u_SpotLights[%u].intensity", i);
            cmd_.SetFloat(name, spotLights_[i].intensity);
            std::snprintf(name, sizeof(name), "u_SpotLights[%u].range", i);
            cmd_.SetFloat(name, spotLights_[i].range);
            std::snprintf(name, sizeof(name), "u_SpotLights[%u].innerCos", i);
            cmd_.SetFloat(name, spotLights_[i].innerCos);
            std::snprintf(name, sizeof(name), "u_SpotLights[%u].outerCos", i);
            cmd_.SetFloat(name, spotLights_[i].outerCos);
        }

        const bool gridOn = lightGridActive_ && lightGridTex_.IsValid();
        cmd_.SetFloat("u_LightGridEnabled", gridOn ? 1.0f : 0.0f);
        if (gridOn) {
            cmd_.SetVec2("u_LightGridTiles",
                         Vec2(static_cast<f32>(lightGridTilesX_),
                              static_cast<f32>(lightGridTilesY_)));
            cmd_.BindTexture("u_LightGrid", 7, lightGridTex_);
        }
}

void RenderSystem::recordScenePass() {
    cmd_.BindFramebuffer(hdrFB_);
    cmd_.Clear(config_.skyColor.x, config_.skyColor.y, config_.skyColor.z, 1.0f, true);

    prepareInstanceBuffers();
    // 有 alpha 裁剪材质时颜色 pass 必须保留 discard/写深度，
    // 深度预通道无法转化为 early-z，直接省掉这一趟。
    const bool usePrepass = config_.depthPrepass && !opaqueHasCutout_;
    if (usePrepass) recordDepthPrepass();

    const bool wantShadow = dirLightEnabled_ && dirLight_.castShadows &&
                            shadowValid_ && shadowFB_.IsValid();
    shadowMaskActive_ = config_.shadowMask && usePrepass && wantShadow &&
                        shadowMaskFB_.IsValid();
    if (shadowMaskActive_) {
        recordShadowMaskPass();
        cmd_.BindFramebuffer(hdrFB_);   // 遮罩写完，回到场景颜色目标
    }

    auto drawList = [&](RHI::PipelineHandle pipe,
                        const std::vector<DrawItem>& items, bool skinned) {
        if (items.empty()) return;
        cmd_.BindPipeline(pipe);
        setSceneGlobals();
        drawItems(items, skinned);
    };

    const bool noDepthWrite = usePrepass;

    if (!opaqueInst_.empty()) {
        cmd_.BindPipeline(noDepthWrite ? pbrInstNoDepthPipeline_
                                       : pbrInstPipeline_);
        setSceneGlobals();
        drawInstancedOpaque();
    }

    drawList(noDepthWrite ? pbrNoDepthPipeline_ : pbrPipeline_,
             opaqueStatic_, false);
    drawList(noDepthWrite ? pbrSkinNoDepthPipeline_ : pbrSkinPipeline_,
             opaqueSkinned_, true);
    drawList(pbrBlendPipeline_,  blendStatic_,   false);
    drawList(pbrBlendSkinPipeline_, blendSkinned_, true);
}

void RenderSystem::recordBloomPass() {
    if (config_.bloomStrength <= 0.0f) return;
    if (!hdrFB_.IsValid() || !bloomFB_[0].IsValid() || !bloomFB_[1].IsValid()) return;

    cmd_.BindPipeline(bloomPipeline_);

    // 1) HDR → 1/4 泛光图：4 tap 降采样 + 阈值
    cmd_.BindFramebuffer(bloomFB_[0]);
    cmd_.SetFloat("u_Prefilter", 1.0f);
    cmd_.SetFloat("u_Threshold", 0.8f);
    cmd_.SetVec2("u_Direction", Vec2(1.0f, 0.0f));
    cmd_.BindTexture("u_Src", 0, device_.GetFramebufferColorTexture(hdrFB_));
    cmd_.Draw(3, 0);

    // 2) 横向高斯
    cmd_.BindFramebuffer(bloomFB_[1]);
    cmd_.SetFloat("u_Prefilter", 0.0f);
    cmd_.SetVec2("u_Direction", Vec2(1.0f, 0.0f));
    cmd_.BindTexture("u_Src", 0, device_.GetFramebufferColorTexture(bloomFB_[0]));
    cmd_.Draw(3, 0);

    // 3) 纵向高斯 → bloomFB_[0]
    cmd_.BindFramebuffer(bloomFB_[0]);
    cmd_.SetVec2("u_Direction", Vec2(0.0f, 1.0f));
    cmd_.BindTexture("u_Src", 0, device_.GetFramebufferColorTexture(bloomFB_[1]));
    cmd_.Draw(3, 0);
}

void RenderSystem::recordPostPass() {
    // 无效句柄 = 默认帧缓冲（后备缓冲）
    cmd_.BindFramebuffer(FramebufferHandle{});
    cmd_.SetViewport(0, 0, static_cast<i32>(viewportW_), static_cast<i32>(viewportH_));
    cmd_.Clear(0.0f, 0.0f, 0.0f, 1.0f, false);
    cmd_.BindPipeline(postPipeline_);
    cmd_.SetFloat("u_Exposure", config_.exposure);
    cmd_.SetFloat("u_Vignette", config_.vignette);
    cmd_.SetFloat("u_Gamma", config_.gamma);

    const bool bloomOn = config_.bloomStrength > 0.0f &&
                         bloomFB_[0].IsValid();
    cmd_.SetFloat("u_Bloom", bloomOn ? config_.bloomStrength : 0.0f);

    // 绑定 HDR 颜色附件（后端裸名直通编码，对称于阴影深度采样）
    cmd_.BindTexture("u_HdrColor", 0, device_.GetFramebufferColorTexture(hdrFB_));
    cmd_.BindTexture("u_BloomTex", 1,
                     bloomOn ? device_.GetFramebufferColorTexture(bloomFB_[0])
                             : device_.GetFramebufferColorTexture(hdrFB_));
    cmd_.Draw(3, 0);
}

void RenderSystem::RenderFrame(ECS::World& world, const Vec3& sceneCenter) {
    stats_ = RenderStats{};
    auto now = [] {
        return std::chrono::duration<double, std::milli>(
                   std::chrono::steady_clock::now().time_since_epoch())
            .count();
    };
    const double tTransform0 = now();
    transformSystem_.OnUpdate(world, jobs_);
    const double tTransform1 = now();

    // 阴影图按间隔重绘：静态场景/缓慢转动的太阳没有必要每帧重画。
    // 跳过时沿用上一次的光空间矩阵，保证场景采样与阴影图是同一套变换。
    const bool wantShadow = dirLightEnabled_ && dirLight_.castShadows &&
                            shadowFB_.IsValid();
    const u32 frameNo = shadowFrame_++;
    const u32 interval = config_.shadowUpdateInterval > 0
                             ? config_.shadowUpdateInterval : 1;
    const bool doShadow = wantShadow &&
        (!shadowValid_ || interval == 1 || (frameNo % interval) == 0);
    if (doShadow) {
        lightSpaceMatrix_ = computeLightSpaceMatrix(dirLight_.direction, sceneCenter);
    }

    const double tPrepare0 = now();
    prepareDraws(world, doShadow);
    stats_.lights = static_cast<u32>(pointLights_.size() + spotLights_.size());
    const double tPrepare1 = now();

    cmd_.Reset();
    buildLightGrid();
    if (doShadow) {
        recordShadowPass();
        shadowValid_ = true;
    } else if (!wantShadow) {
        shadowValid_ = false;
    }
    recordScenePass();
    recordBloomPass();
    recordPostPass();
    const double tRecord1 = now();

    device_.BeginFrame();
    device_.Submit(cmd_);
    const double tSubmit1 = now();

    stats_.cpuTransformMs = static_cast<f32>(tTransform1 - tTransform0);
    stats_.cpuPrepareMs = static_cast<f32>(tPrepare1 - tPrepare0);
    stats_.cpuRecordMs = static_cast<f32>(tRecord1 - tPrepare1);
    stats_.cpuSubmitMs = static_cast<f32>(tSubmit1 - tRecord1);
}

void RenderSystem::RenderFrameNoShadows(ECS::World& world) {
    stats_ = RenderStats{};
    transformSystem_.OnUpdate(world, jobs_);

    shadowValid_ = false;
    prepareDraws(world, /*doShadow=*/false);
    stats_.lights = static_cast<u32>(pointLights_.size() + spotLights_.size());

    cmd_.Reset();
    buildLightGrid();
    recordScenePass();
    recordBloomPass();
    recordPostPass();
    device_.BeginFrame();
    device_.Submit(cmd_);
}

} // namespace M7N::Render
