/**
 * @file GLTFLoader.cpp
 * @brief glTF 2.0（纯文本 .gltf）解析实现：平移自旧引擎 ModelLoader::LoadGLTF。
 *
 * 与旧版的对应关系：
 *   - base64 解码                  -> DecodeBase64（对外可见，供 AssetManager 解 data URI 纹理）
 *   - readAccessorF / readAccessorU32 -> 匿名空间平移（含 byteStride 交错布局）
 *   - decomposeTRS（Shepperd 法）  -> 匿名空间平移（skin 绑定姿态矩阵分解）
 *   - 节点层级 / skin joints / LINEAR-STEP 动画通道 -> 平移到 CPU 结构
 *   - 纹理不再直接加载：data URI 原样保留在材质 texturePath，由 AssetManager 解码上传
 */
#include "M7N/Asset/GLTFLoader.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <functional>
#include <iterator>
#include <unordered_map>

#include <nlohmann/json.hpp>
#include <glm/gtx/quaternion.hpp>   // mat4_cast / quat normalize（节点变换与绑定姿态）

namespace M7N::Asset {

namespace {

using Json = nlohmann::json;

/// glTF componentType 的字节大小。
u32 componentSize(u32 t) {
    switch (t) {
        case 5120: case 5121: return 1;  // i8 / u8
        case 5122: case 5123: return 2;  // i16 / u16
        case 5125: case 5126: return 4;  // u32 / f32
        default: return 0;
    }
}

/// glTF accessor type 字符串的分量数。
u32 typeCount(const String& t) {
    if (t == "SCALAR") return 1;
    if (t == "VEC2")   return 2;
    if (t == "VEC3")   return 3;
    if (t == "VEC4" || t == "MAT2") return 4;
    if (t == "MAT3")   return 9;
    if (t == "MAT4")   return 16;
    return 0;
}

/// 按分量类型读取一个标量为 f32。
f32 readComponent(const u8* base, u32 compType) {
    switch (compType) {
        case 5126: { f32 v; std::memcpy(&v, base, 4); return v; }
        case 5125: { u32 v; std::memcpy(&v, base, 4); return static_cast<f32>(v); }
        case 5123: { u16 v; std::memcpy(&v, base, 2); return static_cast<f32>(v); }
        case 5122: { i16 v; std::memcpy(&v, base, 2); return static_cast<f32>(v); }
        case 5121: return static_cast<f32>(*base);
        case 5120: return static_cast<f32>(static_cast<i8>(*base));
        default:   return 0.0f;
    }
}

/// 读 f32 访问器为平铺数组（整数分量提升为 f32；byteStride 交错布局生效）。
std::vector<f32> readAccessorF(const Json& doc,
                               const std::vector<std::vector<u8>>& buffers,
                               u32 accessorIndex) {
    std::vector<f32> out;
    const Json& accessors = doc["accessors"];
    if (accessorIndex >= accessors.size()) return out;

    const Json& acc = accessors[accessorIndex];
    if (!acc.contains("bufferView")) return out;

    const Json& views = doc["bufferViews"];
    u32 viewIndex = acc["bufferView"].get<u32>();
    if (viewIndex >= views.size()) return out;

    const Json& view = views[viewIndex];
    u32 bufIndex   = view.value("buffer", 0);
    u32 viewOffset = view.value("byteOffset", 0);
    u32 byteStride = view.value("byteStride", 0);

    u32 accOffset = acc.value("byteOffset", 0);
    u32 count      = acc.value("count", 0);
    u32 compType   = acc.value("componentType", 5126);
    u32 comps      = typeCount(acc.value("type", "SCALAR"));
    u32 compSz     = componentSize(compType);

    if (bufIndex >= buffers.size() || !count || !comps || !compSz) return out;
    const std::vector<u8>& buf = buffers[bufIndex];

    u32 elemSize = comps * compSz;
    if (byteStride == 0) byteStride = elemSize;
    if (viewOffset + accOffset + byteStride * (count - 1) + elemSize > buf.size()) {
        if (viewOffset + accOffset + count * elemSize > buf.size()) return out;
    }

    out.reserve(static_cast<size_t>(count) * comps);
    for (u32 e = 0; e < count; e++) {
        const u8* elem = buf.data() + viewOffset + accOffset + byteStride * e;
        for (u32 c = 0; c < comps; c++) {
            out.push_back(readComponent(elem + c * compSz, compType));
        }
    }
    return out;
}

/// 读索引/关节访问器为 u32（u8/u16/i16 提升）。
std::vector<u32> readAccessorU32(const Json& doc,
                                const std::vector<std::vector<u8>>& buffers,
                                u32 accessorIndex) {
    std::vector<f32> raw = readAccessorF(doc, buffers, accessorIndex);
    std::vector<u32> out;
    out.reserve(raw.size());
    for (f32 v : raw) out.push_back(static_cast<u32>(v));
    return out;
}

/// 4x4 矩阵的 3x3 代数余子式（= 逆转置 × det）：
/// 法线变换用它，非均匀缩放下也保持正确朝向（精简数学库无 inverse/transpose）。
void cofactor3(const Mat4& m, f32 out[9]) {
    f32 a[3][3];
    for (int c = 0; c < 3; c++)
        for (int r = 0; r < 3; r++)
            a[c][r] = m.at(c, r);
    // 列主序输入，按行列式定义展开
    out[0] = a[1][1] * a[2][2] - a[2][1] * a[1][2];
    out[1] = a[2][1] * a[0][2] - a[0][1] * a[2][2];
    out[2] = a[0][1] * a[1][2] - a[1][1] * a[0][2];
    out[3] = a[2][0] * a[1][2] - a[1][0] * a[2][2];
    out[4] = a[0][0] * a[2][2] - a[2][0] * a[0][2];
    out[5] = a[1][0] * a[0][2] - a[0][0] * a[1][2];
    out[6] = a[1][0] * a[2][1] - a[2][0] * a[1][1];
    out[7] = a[2][0] * a[0][1] - a[0][0] * a[2][1];
    out[8] = a[0][0] * a[1][1] - a[1][0] * a[0][1];
}

/// 余子式矩阵乘向量（行主序 9 元素）。
Vec3 mulCofactor(const f32 c[9], const Vec3& n) {
    return Vec3(c[0] * n.x + c[1] * n.y + c[2] * n.z,
                c[3] * n.x + c[4] * n.y + c[5] * n.z,
                c[6] * n.x + c[7] * n.y + c[8] * n.z);
}

/// 4x4 矩阵分解 TRS（假定旋转+缩放、无剪切；Shepperd 法提取四元数）。
void decomposeTRS(const Mat4& m, Vec3& t, Quat& r, Vec3& s) {
    t = Vec3(m.at(3, 0), m.at(3, 1), m.at(3, 2));
    Vec3 col0(m.at(0, 0), m.at(0, 1), m.at(0, 2));
    Vec3 col1(m.at(1, 0), m.at(1, 1), m.at(1, 2));
    Vec3 col2(m.at(2, 0), m.at(2, 1), m.at(2, 2));
    s = Vec3(glm::length(col0), glm::length(col1), glm::length(col2));

    // 镜像（负缩放）检测：低模手臂常用"镜像复制"建模，某个关节带负 scale，
    // 线性部分是"旋转×反射"（行列式 < 0）——那不是真旋转，直接提四元数会得到
    // 垃圾（实测某手臂关节往返误差 0.8）。对策：把反射吸收进 x 轴
    // （col0 取反、s.x 记成负），剩下的基就是真旋转，重组时 T*R*S 原样还原。
    if (glm::dot(col0, glm::cross(col1, col2)) < 0.0f) {
        col0 = -col0;
        s.x = -s.x;
    }

    // 零缩放保护，避免旋转基出现 NaN
    f32 sx = (std::fabs(s.x) > 0.00001f) ? std::fabs(s.x) : 1.0f;
    f32 sy = (std::fabs(s.y) > 0.00001f) ? std::fabs(s.y) : 1.0f;
    f32 sz = (std::fabs(s.z) > 0.00001f) ? std::fabs(s.z) : 1.0f;
    col0 = col0 / sx; col1 = col1 / sy; col2 = col2 / sz;

    // 从正交旋转基提取四元数（Shepperd 法）。
    // 列主序：col0=(R00,R10,R20)、col1=(R01,R11,R21)、col2=(R02,R12,R22)。
    // 标准公式：qw=√(1+trace)/2，qx=(R21-R12)/(4qw)，qy=(R02-R20)/(4qw)，qz=(R10-R01)/(4qw)。
    // 【历史坑】这里三个分量的分子曾全部写反（等于返回共轭四元数=逆旋转）。
    // 静态网格的节点几乎都是单位/180° 旋转，共轭恰好相同，所以一直没暴露；
    // 骨骼 rest pose 一用，整棵树的姿态就逐级错乱（实测某关节往返误差 1.7）。
    f32 trace = col0.x + col1.y + col2.z;
    if (trace > 0.0f) {
        f32 sq = std::sqrt(trace + 1.0f) * 2.0f;
        r = Quat((col1.z - col2.y) / sq, (col2.x - col0.z) / sq,
                 (col0.y - col1.x) / sq, 0.25f * sq);
    } else if (col0.x > col1.y && col0.x > col2.z) {
        f32 sq = std::sqrt(1.0f + col0.x - col1.y - col2.z) * 2.0f;
        r = Quat(0.25f * sq, (col1.x + col0.y) / sq,
                 (col2.x + col0.z) / sq, (col1.z - col2.y) / sq);
    } else if (col1.y > col2.z) {
        // R11 最大：qy=s/4，qx=(R01+R10)/s，qz=(R12+R21)/s，qw=(R02-R20)/s
        f32 sq = std::sqrt(1.0f + col1.y - col0.x - col2.z) * 2.0f;
        r = Quat((col1.x + col0.y) / sq, 0.25f * sq,
                 (col2.y + col1.z) / sq, (col2.x - col0.z) / sq);
    } else {
        // R22 最大：qz=s/4，qx=(R02+R20)/s，qy=(R12+R21)/s，qw=(R10-R01)/s
        f32 sq = std::sqrt(1.0f + col2.z - col0.x - col1.y) * 2.0f;
        r = Quat((col2.x + col0.z) / sq, (col2.y + col1.z) / sq,
                 0.25f * sq, (col0.y - col1.x) / sq);
    }
    r = glm::normalize(r);
}

/// TRS 矩阵求逆（精确，不要求正交）：inv(T*R*S) = S^-1 * R^-1 * T^-1。
/// 只对"平移*旋转*缩放"型矩阵成立 —— 节点世界矩阵正是这种。
/// 精简 glm 没有 mat4 求逆，而 glTF 骨骼的 rest pose 需要它（见皮肤段注释）。
Mat4 inverseTRS(const Mat4& m) {
    Vec3 t; Quat r; Vec3 sc;
    decomposeTRS(m, t, r, sc);
    Vec3 invS(1.0f, 1.0f, 1.0f);
    if (std::fabs(sc.x) > 1e-6f) invS.x = 1.0f / sc.x;
    if (std::fabs(sc.y) > 1e-6f) invS.y = 1.0f / sc.y;
    if (std::fabs(sc.z) > 1e-6f) invS.z = 1.0f / sc.z;
    const Quat ir(-r.x, -r.y, -r.z, r.w);   // 单位四元数的逆 = 共轭
    return glm::scale(Mat4(1.0f), invS) * glm::mat4_cast(ir)
         * glm::translate(Mat4(1.0f), -t);
}

/// 取文件所在目录（不含文件名，兼容 '/' 与 '\\' 分隔）。
String getDirectory(const String& filepath) {
    size_t pos = filepath.find_last_of("/\\");
    return (pos == String::npos) ? String() : filepath.substr(0, pos);
}

/// base64 编码（供 .glb 内嵌图片转 data URI，复用 AssetManager 的纹理上传路径）。
String encodeBase64(const u8* data, size_t size) {
    static const char* kChars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    String out;
    out.reserve((size + 2) / 3 * 4);
    for (size_t i = 0; i < size; i += 3) {
        const u32 b0 = data[i];
        const u32 b1 = (i + 1 < size) ? data[i + 1] : 0;
        const u32 b2 = (i + 2 < size) ? data[i + 2] : 0;
        const u32 triple = (b0 << 16) | (b1 << 8) | b2;
        out.push_back(kChars[(triple >> 18) & 0x3F]);
        out.push_back(kChars[(triple >> 12) & 0x3F]);
        out.push_back((i + 1 < size) ? kChars[(triple >> 6) & 0x3F] : '=');
        out.push_back((i + 2 < size) ? kChars[triple & 0x3F] : '=');
    }
    return out;
}

/// 解析 images[imageIndex] 的纹理来源路径：
/// data URI 原样返回（AssetManager 解码上传）；.glb bufferView 内嵌图片转为 data URI；
/// 外部文件拼接 .gltf/.glb 所在目录。
String resolveTexturePath(const Json& doc, u32 imageIndex, const String& baseDir,
                          const std::vector<std::vector<u8>>& buffers) {
    if (!doc.contains("images") || imageIndex >= doc["images"].size()) return "";
    const Json& img = doc["images"][imageIndex];

    // Blender 默认 .glb：图片以 bufferView 内嵌（无 uri）
    if (!img.contains("uri")) {
        if (!img.contains("bufferView") || !doc.contains("bufferViews")) return "";
        u32 viewIndex = img["bufferView"].get<u32>();
        if (viewIndex >= doc["bufferViews"].size()) return "";
        const Json& view = doc["bufferViews"][viewIndex];
        u32 bufIndex = view.value("buffer", 0);
        u32 offset   = view.value("byteOffset", 0);
        u32 length   = view.value("byteLength", 0);
        if (bufIndex >= buffers.size() || length == 0) return "";
        const std::vector<u8>& buf = buffers[bufIndex];
        if (offset + length > buf.size()) return "";
        return "data:application/octet-stream;base64," +
               encodeBase64(buf.data() + offset, length);
    }

    String uri = img["uri"].get<String>();
    if (uri.rfind("data:", 0) == 0) return uri;
    return baseDir.empty() ? uri : baseDir + "/" + uri;
}

} // namespace

bool DecodeBase64(const String& in, std::vector<u8>& out) {
    // 函数内 static const 表（架构约定允许；无全局可变状态）
    static const i32 kTable[256] = {
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, 62,-1,-1,-1, 63,52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-1,-1,
        -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14, 15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,
        -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40, 41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
        -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1, -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1
    };

    out.clear();
    i32 val = 0, valb = -8;
    for (char c : in) {
        i32 d = kTable[static_cast<u8>(c)];
        if (d == -1) continue;
        val = (val << 6) + d;
        valb += 6;
        if (valb >= 0) {
            out.push_back(static_cast<u8>((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return !out.empty();
}

bool GLTFLoader::Load(const String& filepath, ModelData& out) {
    out = ModelData{};   // 清空目标，允许重入

    // --- 读取整个文件（.gltf 文本 / .glb 二进制共用入口）---
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) return false;
    std::vector<u8> fileBytes((std::istreambuf_iterator<char>(file)),
                               std::istreambuf_iterator<char>());
    if (fileBytes.size() < 4) return false;

    // --- 容器识别：GLB 魔数 "glTF" = 0x46546C67（小端）---
    std::vector<u8> binChunk;
    std::string jsonText;
    const u32 magic = static_cast<u32>(fileBytes[0]) |
                      (static_cast<u32>(fileBytes[1]) << 8) |
                      (static_cast<u32>(fileBytes[2]) << 16) |
                      (static_cast<u32>(fileBytes[3]) << 24);

    if (magic == 0x46546C67u) {
        // GLB: header(12) + chunk 循环 { length, type, data }
        u32 cursor = 12;
        bool hasJson = false;
        while (cursor + 8 <= fileBytes.size()) {
            u32 chunkLen = 0, chunkType = 0;
            std::memcpy(&chunkLen, fileBytes.data() + cursor, 4);
            std::memcpy(&chunkType, fileBytes.data() + cursor + 4, 4);
            cursor += 8;
            if (cursor + chunkLen > fileBytes.size()) break;

            if (chunkType == 0x4E4F534Au) {            // "JSON"
                jsonText.assign(reinterpret_cast<const char*>(fileBytes.data() + cursor),
                                chunkLen);
                hasJson = true;
            } else if (chunkType == 0x004E4942u) {      // "BIN\0"
                binChunk.assign(fileBytes.begin() + cursor,
                                fileBytes.begin() + cursor + chunkLen);
            }
            cursor += chunkLen;
            // chunk 数据按 4 字节对齐
            cursor = (cursor + 3u) & ~3u;
        }
        if (!hasJson) return false;
    } else {
        jsonText.assign(fileBytes.begin(), fileBytes.end());
    }

    Json doc;
    try {
        doc = Json::parse(jsonText);
    } catch (const std::exception&) {
        return false;
    }

    const String baseDir = getDirectory(filepath);

    // --- 二进制缓冲（外部 .bin / base64 data URI / .glb BIN chunk）---
    std::vector<std::vector<u8>> buffers;
    if (doc.contains("buffers")) {
        for (const auto& b : doc["buffers"]) {
            std::vector<u8> data;
            if (b.contains("uri")) {
                String uri = b["uri"].get<String>();
                if (uri.rfind("data:", 0) == 0) {
                    size_t comma = uri.find(',');
                    if (comma != String::npos) {
                        DecodeBase64(uri.substr(comma + 1), data);
                    }
                } else {
                    String path = baseDir.empty() ? uri : baseDir + "/" + uri;
                    std::ifstream bin(path, std::ios::binary);
                    if (bin.is_open()) {
                        bin.seekg(0, std::ios::end);
                        std::streampos len = bin.tellg();
                        bin.seekg(0, std::ios::beg);
                        data.resize(static_cast<size_t>(len));
                        bin.read(reinterpret_cast<char*>(data.data()), len);
                    }
                }
            } else {
                data = binChunk;   // .glb：无 uri 的 buffer 即 BIN chunk
            }
            buffers.push_back(std::move(data));
        }
    }

    // --- 材质（baseColorFactor + baseColorTexture 路径）---
    if (doc.contains("materials")) {
        for (const auto& m : doc["materials"]) {
            ModelMaterial mat;
            mat.name = m.value("name", "material");
            if (m.contains("pbrMetallicRoughness")) {
                const Json& pbr = m["pbrMetallicRoughness"];
                if (pbr.contains("baseColorFactor")) {
                    const auto& c = pbr["baseColorFactor"];
                    mat.baseColor = Vec4(c[0].get<f32>(), c[1].get<f32>(),
                                          c[2].get<f32>(), c[3].get<f32>());
                }
                if (pbr.contains("baseColorTexture")) {
                    u32 texIndex = pbr["baseColorTexture"].value("index", 0);
                    if (doc.contains("textures") && texIndex < doc["textures"].size()) {
                        u32 imageIndex = doc["textures"][texIndex].value("source", 0);
                        mat.texturePath = resolveTexturePath(doc, imageIndex, baseDir, buffers);
                    }
                }
                // 金属度 / 粗糙度因子（glTF 缺省均为 1.0）。
                // 不解析这两个字段会让所有材质退化成同一组标量，
                // 橡胶握把和抛光钢看起来一模一样——"白模"的主要成因之一。
                mat.metallic  = pbr.value("metallicFactor",  1.0f);
                mat.roughness = pbr.value("roughnessFactor", 1.0f);
                // 金属粗糙度贴图（G=roughness, B=metallic）
                if (pbr.contains("metallicRoughnessTexture")) {
                    u32 texIndex = pbr["metallicRoughnessTexture"].value("index", 0);
                    if (doc.contains("textures") && texIndex < doc["textures"].size()) {
                        u32 imageIndex = doc["textures"][texIndex].value("source", 0);
                        mat.metallicRoughnessPath =
                            resolveTexturePath(doc, imageIndex, baseDir, buffers);
                    }
                }
            }
            // 透明模式：只有 MASK 映射成裁剪阈值。BLEND 需要真正的透明排序
            // pass（本引擎没有），硬切会把弹孔/火光这类软边贴图的渐变削成方块，
            // 所以宁可保持它现在的样子，也不要用裁剪去冒充。
            if (m.value("alphaMode", String("OPAQUE")) == "MASK") {
                mat.alphaCutoff = m.value("alphaCutoff", 0.5f);
            }
            // 法线贴图
            if (m.contains("normalTexture")) {
                u32 texIndex = m["normalTexture"].value("index", 0);
                if (doc.contains("textures") && texIndex < doc["textures"].size()) {
                    u32 imageIndex = doc["textures"][texIndex].value("source", 0);
                    mat.normalPath = resolveTexturePath(doc, imageIndex, baseDir, buffers);
                }
            }
            // 自发光（颜色 + 贴图）
            if (m.contains("emissiveFactor")) {
                const auto& e = m["emissiveFactor"];
                mat.emissiveFactor = Vec3(e[0].get<f32>(), e[1].get<f32>(), e[2].get<f32>());
            }
            if (m.contains("emissiveTexture")) {
                u32 texIndex = m["emissiveTexture"].value("index", 0);
                if (doc.contains("textures") && texIndex < doc["textures"].size()) {
                    u32 imageIndex = doc["textures"][texIndex].value("source", 0);
                    mat.emissivePath = resolveTexturePath(doc, imageIndex, baseDir, buffers);
                }
            }
            out.materials.push_back(std::move(mat));
        }
    }

    // --- 节点层级（TRS / matrix / children；供 skin 关节与动画目标解析）---
    struct NodeInfo {
        String name;
        Vec3 translation = Vec3(0.0f);
        Quat rotation    = Quat(0.0f, 0.0f, 0.0f, 1.0f);
        Vec3 scale       = Vec3(1.0f);
        Mat4 matrix      = Mat4(1.0f);
        bool hasMatrix   = false;
        i32 mesh         = -1;
        i32 skin         = -1;
        std::vector<u32> children;
    };
    std::vector<NodeInfo> nodes;
    if (doc.contains("nodes")) {
        for (const auto& n : doc["nodes"]) {
            NodeInfo info;
            info.name = n.value("name", "");
            if (n.contains("translation")) {
                const auto& t = n["translation"];
                info.translation = Vec3(t[0].get<f32>(), t[1].get<f32>(), t[2].get<f32>());
            }
            if (n.contains("rotation")) {
                const auto& r = n["rotation"];
                info.rotation = Quat(r[0].get<f32>(), r[1].get<f32>(),
                                    r[2].get<f32>(), r[3].get<f32>());
            }
            if (n.contains("scale")) {
                const auto& s = n["scale"];
                info.scale = Vec3(s[0].get<f32>(), s[1].get<f32>(), s[2].get<f32>());
            }
            if (n.contains("matrix")) {
                const auto& m = n["matrix"];
                Mat4 mat(1.0f);
                for (int c = 0; c < 4; c++)
                    for (int r = 0; r < 4; r++)
                        mat.at(c, r) = m[c * 4 + r].get<f32>();
                info.matrix = mat;
                info.hasMatrix = true;
            }
            info.mesh = n.value("mesh", -1);
            info.skin = n.value("skin", -1);
            if (n.contains("children")) {
                for (const auto& c : n["children"]) info.children.push_back(c.get<u32>());
            }
            nodes.push_back(info);
        }
    }

    std::vector<i32> parentOf(nodes.size(), -1);
    for (u32 p = 0; p < nodes.size(); p++) {
        for (u32 c : nodes[p].children) {
            if (c < parentOf.size()) parentOf[c] = static_cast<i32>(p);
        }
    }

    std::vector<Mat4> worldCache(nodes.size(), Mat4(1.0f));
    std::vector<bool> worldReady(nodes.size(), false);
    std::function<Mat4(u32)> worldOf = [&](u32 idx) -> Mat4 {
        if (worldReady[idx]) return worldCache[idx];
        const NodeInfo& n = nodes[idx];
        Mat4 local = n.hasMatrix
            ? n.matrix
            : glm::translate(Mat4(1.0f), n.translation) *
              glm::mat4_cast(n.rotation) *
              glm::scale(Mat4(1.0f), n.scale);
        i32 parent = parentOf[idx];
        worldCache[idx] = (parent >= 0) ? worldOf(static_cast<u32>(parent)) * local : local;
        worldReady[idx] = true;
        return worldCache[idx];
    };


    // --- 皮肤（首个 skin；glTF 实际每模型一个）---
    std::unordered_map<u32, u32> nodeToJoint;   // glTF 节点索引 -> 关节索引
    i32 skinIndex = -1;
    for (const auto& node : nodes) {
        if (node.skin >= 0) { skinIndex = node.skin; break; }
    }
    if (skinIndex >= 0 && doc.contains("skins") &&
        static_cast<u32>(skinIndex) < doc["skins"].size()) {
        const Json& skin = doc["skins"][static_cast<u32>(skinIndex)];
        if (skin.contains("joints")) {
            out.skeleton.name = skin.value("name", "skin");
            const auto& jointNodes = skin["joints"];

            // 先建 节点->关节 映射，父关节才能解析
            for (u32 i = 0; i < jointNodes.size(); i++) {
                nodeToJoint[jointNodes[i].get<u32>()] = i;
            }
            // 关节索引 -> 节点索引（绑定校验 / inverseBind 自愈回退用）
            std::vector<u32> jointNodeOf;
            jointNodeOf.reserve(jointNodes.size());

            // 骨架根矩阵：所有"父节点不是关节"的根关节，其父节点的世界变换。
            // glTF 的 skin.skeleton 字段各导出器填写不一，不可靠，自己从层级推导。
            // 蒙皮顶点生活在骨架根的局部空间（Mixamo 导出是 厘米+Z-up），
            // 这个矩阵负责把它换算到世界空间（等价 three.js 的 bindMatrix）。
            Mat4 skeletonRootMat(1.0f);
            {
                i32 rootParentNode = -1;
                bool consistent = true;
                for (u32 i = 0; i < jointNodes.size() && consistent; i++) {
                    const u32 jn = jointNodes[i].get<u32>();
                    if (jn >= nodes.size()) continue;
                    i32 pn = -1;
                    for (u32 p = 0; p < nodes.size(); p++)
                        for (u32 c : nodes[p].children)
                            if (c == jn) pn = static_cast<i32>(p);
                    if (pn < 0) { consistent = false; break; }   // 场景根，无父节点
                    if (nodeToJoint.count(static_cast<u32>(pn))) continue;
                    if (rootParentNode < 0) rootParentNode = pn;
                    else if (rootParentNode != pn) { consistent = false; }
                }
                if (consistent && rootParentNode >= 0)
                    skeletonRootMat = worldOf(static_cast<u32>(rootParentNode));
                out.skeleton.rootMatrix = skeletonRootMat;
            }

            std::vector<f32> invBinds;
            if (skin.contains("inverseBindMatrices")) {
                invBinds = readAccessorF(doc, buffers,
                                         skin["inverseBindMatrices"].get<u32>());
            }

            for (u32 i = 0; i < jointNodes.size(); i++) {
                u32 nodeIdx = jointNodes[i].get<u32>();
                if (nodeIdx >= nodes.size()) continue;   // 非法 joints 引用防御
                const NodeInfo& n = nodes[nodeIdx];

                JointData joint;
                joint.name = n.name;
                if (invBinds.size() >= (i + 1) * 16) {
                    // glTF 矩阵为列主序数组
                    for (int c = 0; c < 4; c++)
                        for (int r = 0; r < 4; r++)
                            joint.inverseBind.at(c, r) = invBinds[i * 16 + c * 4 + r];
                }

                // 父关节：最近的也是关节的祖先（nodes 不存父指针，扫 children 列表）
                i32 parentJointNode = -1;
                for (u32 p = 0; p < nodes.size(); p++) {
                    for (u32 c : nodes[p].children) {
                        if (c == nodeIdx) {
                            auto it = nodeToJoint.find(p);
                            if (it != nodeToJoint.end()) {
                                joint.parent = static_cast<i32>(it->second);
                                parentJointNode = static_cast<i32>(p);
                            }
                        }
                    }
                }

                // 绑定姿态 TRS。
                // 【关键】不能直接用节点自身的局部 TRS：关节和它的父关节之间
                // 可能隔着**非关节**节点（Quaternius 士兵的 Bone 上面就有
                // CharacterArmature/Scene/__fit 三层）。级联时这些中间变换会被
                // 跳过，而 inverseBind 里包含它们 → palette = global*inverseBind
                // 在绑定姿态下就不等于单位阵（实测偏差 1.41），动画一播整个模型
                // 飞出视锥。正确做法：rest = W_parent^-1 * W_self（世界矩阵相除），
                // 这样绑定姿态下级联结果恰好还原出 inverseBind 的逆，palette = I。
                const Mat4 Wself = worldOf(nodeIdx);
                // 根关节的 rest pose 用"骨架根的局部空间"（去掉非关节祖先），
                // 祖先变换改由 skeleton.rootMatrix 单独承担——否则动画通道
                // 驱动根关节时会把祖先变换顶掉（模型瞬间放大 100 倍并躺平）。
                Mat4 restLocal = inverseTRS(skeletonRootMat) * Wself;
                if (parentJointNode >= 0) {
                    restLocal = inverseTRS(worldOf(
                        static_cast<u32>(parentJointNode))) * Wself;
                }
                decomposeTRS(restLocal, joint.restTranslation,
                             joint.restRotation, joint.restScale);
                jointNodeOf.push_back(nodeIdx);
                out.skeleton.joints.push_back(std::move(joint));
            }

            // 【绑定自检】glTF 约定 inverseBind_j = inverse(关节全局矩阵)，
            // 因此"绑定姿态下 全局矩阵 × inverseBind ≈ 单位阵"必须成立。
            // 这里的"全局矩阵"用 **骨架根空间的级联结果**（与运行时
            // ComputePalette 同一套 rest pose 级联），保证校验、自愈、运行时
            // 三者用的是同一个约定。实测 Quaternius 士兵文件的
            // inverseBindMatrices 是坏的（首行 [0,0,0,1]，根本不是可逆矩阵），
            // 直接用会导致动画一播顶点飞出视锥。
            if (!jointNodeOf.empty() &&
                out.skeleton.joints.size() == jointNodeOf.size()) {
                // 用 rest pose 级联出绑定姿态的全局矩阵（骨架根空间）
                std::vector<Mat4> bindG(out.skeleton.joints.size(), Mat4(1.0f));
                {
                    std::vector<u8> done(out.skeleton.joints.size(), 0);
                    u32 remain = static_cast<u32>(out.skeleton.joints.size());
                    while (remain > 0) {
                        const u32 before = remain;
                        for (size_t i = 0; i < out.skeleton.joints.size(); i++) {
                            if (done[i]) continue;
                            const i32 pp = out.skeleton.joints[i].parent;
                            if (pp >= 0 && !done[static_cast<u32>(pp)]) continue;
                            const JointData& jd = out.skeleton.joints[i];
                            const Mat4 L = glm::translate(Mat4(1.0f), jd.restTranslation)
                                         * glm::mat4_cast(jd.restRotation)
                                         * glm::scale(Mat4(1.0f), jd.restScale);
                            bindG[i] = (pp >= 0)
                                ? bindG[static_cast<u32>(pp)] * L : L;
                            done[i] = 1; remain--;
                        }
                        if (remain == before) break;   // 环（非法数据）兜底
                    }
                }
                f32 bindDev = 0.0f;
                for (size_t i = 0; i < out.skeleton.joints.size(); i++) {
                    const Mat4 m = bindG[i] * out.skeleton.joints[i].inverseBind;
                    for (int c = 0; c < 4; c++)
                        for (int r = 0; r < 4; r++) {
                            const f32 want = (c == r) ? 1.0f : 0.0f;
                            bindDev = std::max(bindDev,
                                std::fabs(m.at(c, r) - want));
                        }
                }
                if (bindDev > 0.05f) {
                    std::printf("[GLTF] inverseBindMatrices 与骨架层级不符"
                                "（偏差 %.3f），改用 rest 级联矩阵求逆\n", bindDev);
                    for (size_t i = 0; i < out.skeleton.joints.size(); i++) {
                        out.skeleton.joints[i].inverseBind =
                            inverseTRS(bindG[i]);
                    }
                }
            }
        }
    }

    // --- 节点世界变换（烘焙进顶点：Blender 多物体场景保持各自位置/旋转/缩放）---
    // 网格实例：同一 mesh 被多个节点引用时各自烘焙一份世界变换（场景物件）
    struct MeshInstance {
        u32  mesh = 0;
        bool skinned = false;
        Mat4 world = Mat4(1.0f);
        i32  skin = -1;     ///< 该实例引用的 skin 索引（跨 skin 关节重映射用）
    };
    std::vector<MeshInstance> instances;
    for (u32 i = 0; i < nodes.size(); i++) {
        if (nodes[i].mesh < 0) continue;
        instances.push_back({ static_cast<u32>(nodes[i].mesh),
                              nodes[i].skin >= 0,
                              worldOf(i),
                              nodes[i].skin });
    }
    // 防御：无 nodes 引用的 .gltf（部分导出器）按单位矩阵逐个 mesh 导入
    if (instances.empty() && doc.contains("meshes")) {
        for (u32 m = 0; m < doc["meshes"].size(); m++) {
            instances.push_back({ m, false, Mat4(1.0f) });
        }
    }

    // --- 网格：所有实例的 primitive 合并进一份顶点/索引，子网格按 primitive 划分 ---
    MeshData& mesh = out.mesh;
    bool modelSkinned = false;
    for (const MeshInstance& inst : instances) {
        if (!doc.contains("meshes") || inst.mesh >= doc["meshes"].size()) continue;
        const Json& m = doc["meshes"][inst.mesh];
        if (!m.contains("primitives")) continue;

        // 蒙皮网格不做烘焙（绑定姿态由关节动画驱动，避免双重变换）
        const bool bake = !inst.skinned;
        f32 normalMat[9] = { 1,0,0, 0,1,0, 0,0,1 };
        if (bake) cofactor3(inst.world, normalMat);

        for (const auto& prim : m["primitives"]) {
            if (!prim.contains("attributes") ||
                !prim["attributes"].contains("POSITION")) continue;

            u32 posAcc = prim["attributes"]["POSITION"].get<u32>();
            std::vector<f32> positions = readAccessorF(doc, buffers, posAcc);
            if (positions.empty()) continue;
            u32 vertexCount = static_cast<u32>(positions.size() / 3);

            std::vector<f32> normals, uvs, weights;
            std::vector<u32> joints;
            if (prim["attributes"].contains("NORMAL")) {
                normals = readAccessorF(doc, buffers,
                                        prim["attributes"]["NORMAL"].get<u32>());
            }
            if (prim["attributes"].contains("TEXCOORD_0")) {
                uvs = readAccessorF(doc, buffers,
                                     prim["attributes"]["TEXCOORD_0"].get<u32>());
            }
            if (prim["attributes"].contains("JOINTS_0")) {
                joints = readAccessorU32(doc, buffers,
                                         prim["attributes"]["JOINTS_0"].get<u32>());
                // 跨 skin 重映射：一个 glTF 可以有多个 skin（Mixamo 的面甲就是
                // 独立 skin，只含 Neck/Head 两个关节）。它的 JOINTS_0 是**那个
                // skin 的局部索引**，而引擎只保留主 skin 的骨架——不映射的话
                // 面甲会挂到 Hips/Spine 上，位置整个错掉。
                if (inst.skin >= 0 && static_cast<u32>(inst.skin) != skinIndex &&
                    doc.contains("skins") &&
                    static_cast<u32>(inst.skin) < doc["skins"].size() &&
                    doc["skins"][static_cast<u32>(inst.skin)].contains("joints")) {
                    const auto& otherJoints =
                        doc["skins"][static_cast<u32>(inst.skin)]["joints"];
                    for (auto& jj : joints) {
                        if (jj < otherJoints.size()) {
                            const u32 jointNode = otherJoints[jj].get<u32>();
                            auto it = nodeToJoint.find(jointNode);
                            jj = (it != nodeToJoint.end()) ? it->second : 0u;
                        }
                    }
                }
                modelSkinned = true;
            }
            if (prim["attributes"].contains("WEIGHTS_0")) {
                weights = readAccessorF(doc, buffers,
                                        prim["attributes"]["WEIGHTS_0"].get<u32>());
            }

            u32 vertexBase = static_cast<u32>(mesh.positions.size());
            for (u32 v = 0; v < vertexCount; v++) {
                Vec3 pos(positions[v * 3], positions[v * 3 + 1], positions[v * 3 + 2]);
                Vec3 nrm = (normals.size() >= (v + 1) * 3)
                    ? Vec3(normals[v * 3], normals[v * 3 + 1], normals[v * 3 + 2])
                    : Vec3(0.0f, 1.0f, 0.0f);
                if (bake) {
                    const Vec4 worldPos = inst.world * Vec4(pos, 1.0f);
                    pos = Vec3(worldPos.x, worldPos.y, worldPos.z);
                    nrm = mulCofactor(normalMat, nrm);
                    const f32 len = glm::length(nrm);
                    if (len > 0.00001f) nrm = nrm / len;
                }
                mesh.positions.push_back(pos);
                mesh.normals.push_back(nrm);

                if (uvs.size() >= (v + 1) * 2) {
                    // glTF UV 原点在左上，OpenGL 纹理原点在左下：翻转 V
                    mesh.texCoords.emplace_back(uvs[v * 2], 1.0f - uvs[v * 2 + 1]);
                } else {
                    mesh.texCoords.emplace_back(0.0f, 0.0f);
                }
                // 蒙皮属性：缺失时补 0（保持平行数组对齐；仅蒙皮模型填充）
                if (modelSkinned) {
                    for (int k = 0; k < 4; k++) {
                        mesh.jointIndices.push_back(
                            (joints.size() > v * 4 + k)
                                ? static_cast<i32>(joints[v * 4 + k]) : 0);
                        mesh.jointWeights.push_back(
                            (weights.size() > v * 4 + k) ? weights[v * 4 + k] : 0.0f);
                    }
                }
            }

            u32 indexStart = static_cast<u32>(mesh.indices.size());
            if (prim.contains("indices")) {
                std::vector<u32> primIndices =
                    readAccessorU32(doc, buffers, prim["indices"].get<u32>());
                for (u32 idx : primIndices) mesh.indices.push_back(vertexBase + idx);
            } else {
                for (u32 v = 0; v < vertexCount; v++) mesh.indices.push_back(vertexBase + v);
            }

            SubMeshRange sub;
            sub.indexOffset = indexStart;
            sub.indexCount  = static_cast<u32>(mesh.indices.size()) - indexStart;

            i32 matIndex = prim.value("material", -1);
            if (matIndex < 0 ||
                static_cast<u32>(matIndex) >= out.materials.size()) {
                matIndex = -1;   // 无材质或越界 -> 消费方用默认色
            }
            out.submeshMaterials.push_back(matIndex);
            mesh.submeshes.push_back(sub);
        }
    }
    mesh.skinned = modelSkinned && !out.skeleton.joints.empty();

    if (mesh.positions.empty()) return false;   // 无几何数据

    // --- 动画（LINEAR/STEP；仅解析映射到关节的通道）---
    if (doc.contains("animations")) {
        for (const auto& a : doc["animations"]) {
            AnimationClip clip;
            clip.name = a.value("name", "animation");

            if (!a.contains("channels")) continue;
            for (const auto& ch : a["channels"]) {
                if (!ch.contains("target")) continue;
                const Json& target = ch["target"];
                u32 targetNode = target.value("node", 0xFFFFFFFFu);
                String path = target.value("path", "");

                auto jointIt = nodeToJoint.find(targetNode);
                if (targetNode == 0xFFFFFFFFu || jointIt == nodeToJoint.end()) continue;

                AnimChannel channel;
                channel.jointIndex = jointIt->second;
                if (path == "translation")      channel.path = AnimPath::Translation;
                else if (path == "rotation")    channel.path = AnimPath::Rotation;
                else if (path == "scale")       channel.path = AnimPath::Scale;
                else continue;   // weights（变形目标）不支持

                if (!ch.contains("sampler")) continue;
                u32 samplerIdx = ch["sampler"].get<u32>();
                if (!a.contains("samplers") || samplerIdx >= a["samplers"].size()) continue;
                const Json& smp = a["samplers"][samplerIdx];

                String interp = smp.value("interpolation", "LINEAR");
                channel.interp = (interp == "STEP") ? AnimInterp::Step : AnimInterp::Linear;
                // CUBICSPLINE 降级为 LINEAR：每关键帧为 [入切线, 值, 出切线]，取中间值
                const bool cubic = (interp == "CUBICSPLINE");

                std::vector<f32> times =
                    readAccessorF(doc, buffers, smp["input"].get<u32>());
                std::vector<f32> values =
                    readAccessorF(doc, buffers, smp["output"].get<u32>());
                if (times.empty() || values.empty()) continue;

                channel.times = times;
                u32 comps = static_cast<u32>(values.size() / times.size());
                const u32 stride = comps * (cubic ? 3u : 1u);
                const u32 valueOffset = cubic ? comps : 0u;
                if (channel.path == AnimPath::Rotation) {
                    for (u32 k = 0; k < times.size(); k++) {
                        u32 b = k * stride + valueOffset;
                        if (b + 3 < values.size()) {
                            channel.quatKeys.push_back(Quat(values[b], values[b + 1],
                                                            values[b + 2], values[b + 3]));
                        }
                    }
                } else {
                    for (u32 k = 0; k < times.size(); k++) {
                        u32 b = k * stride + valueOffset;
                        if (b + 2 < values.size()) {
                            channel.vecKeys.push_back(Vec3(values[b], values[b + 1],
                                                           values[b + 2]));
                        }
                    }
                }

                clip.duration = std::max(clip.duration, times.back());
                clip.channels.push_back(std::move(channel));
            }

            if (!clip.channels.empty()) {
                out.animations.push_back(std::move(clip));
            }
        }
    }

    return true;
}

} // namespace M7N::Asset
