/**
 * @file AssetManager.cpp
 * @brief 资产管理器实现：网格/纹理的 GPU 上传与缓存生命周期。
 *
 * STB_IMAGE_IMPLEMENTATION 仅放本编译单元（全引擎唯一 stb 实现体）；
 * 一切 GPU 资源经 RHI::IRenderDevice 创建/销毁，无直接 GL 调用。
 */
#include "M7N/Asset/AssetManager.hpp"
#include "M7N/Asset/GLTFLoader.hpp"

#include <cstring>
#include <limits>

// stb_image：仅本编译单元持有实现
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

namespace M7N::Asset {

namespace {

/// 交错步长（浮点数）：pos3 + normal3 + uv2 + lightmapUV2 = 10。
constexpr u32 kFloatsPerVertex = 10;
/// 交错步长（字节）：10 * 4 = 40。
constexpr u32 kVertexStrideBytes = kFloatsPerVertex * sizeof(f32);
/// data URI 前缀（内嵌纹理判定）。
constexpr const char* kDataURIPrefix = "data:";

} // namespace

AssetManager::AssetManager(RHI::IRenderDevice& device) : device_(device) {}

AssetManager::~AssetManager() {
    // 经 RHI 销毁全部缓存 GPU 资源（vbo/ibo/skin/texture）
    for (auto& [path, gpu] : meshes_) {
        (void)path;
        if (gpu.vbo.IsValid()) device_.DestroyBuffer(gpu.vbo);
        if (gpu.ibo.IsValid()) device_.DestroyBuffer(gpu.ibo);
        if (gpu.skin.IsValid()) device_.DestroyBuffer(gpu.skin);
    }
    for (TextureMap* map : { &texturesSrgb_, &texturesLinear_, &texturesNearest_ }) {
        for (auto& [key, info] : *map) {
            (void)key;
            if (info.handle.IsValid()) device_.DestroyTexture(info.handle);
        }
    }
}

bool AssetManager::uploadMesh(const String& name, ModelData model) {
    const MeshData& md = model.mesh;
    const u32 vertexCount = static_cast<u32>(md.positions.size());
    if (vertexCount == 0 || md.indices.empty()) return false;

    // --- 交错顶点数组：pos(3) + normal(3) + uv(2) + lightmapUV(2) = 10 浮点/顶点 ---
    // 布局约定：location0 pos / location1 normal / location2 uv / location5 lightmapUV，
    // stride 40 字节。三套 UV 数据都按需补零，非 BSP 网格的第二套 UV 全 0。
    std::vector<f32> vertices;
    vertices.reserve(static_cast<size_t>(vertexCount) * kFloatsPerVertex);
    for (u32 v = 0; v < vertexCount; v++) {
        const Vec3 pos = md.positions[v];
        const Vec3 nrm = (md.normals.size() > v) ? md.normals[v] : Vec3(0.0f, 1.0f, 0.0f);
        const Vec2 uv  = (md.texCoords.size() > v) ? md.texCoords[v] : Vec2(0.0f);
        const Vec2 lm  = (md.texCoords2.size() > v) ? md.texCoords2[v] : Vec2(0.0f);
        vertices.push_back(pos.x); vertices.push_back(pos.y); vertices.push_back(pos.z);
        vertices.push_back(nrm.x); vertices.push_back(nrm.y); vertices.push_back(nrm.z);
        vertices.push_back(uv.x);  vertices.push_back(uv.y);
        vertices.push_back(lm.x);  vertices.push_back(lm.y);
    }

    RHI::BufferDesc vbd;
    vbd.data = vertices.data();
    vbd.size = vertexCount * kVertexStrideBytes;
    vbd.usage = RHI::BufferUsage::Vertex;
    vbd.dynamic = false;
    RHI::BufferHandle vbo = device_.CreateBuffer(vbd);

    // --- 索引缓冲（u32 索引，与 RHI DrawIndexed 的 GL_UNSIGNED_INT 约定一致）---
    RHI::BufferDesc ibd;
    ibd.data = md.indices.data();
    ibd.size = static_cast<u32>(md.indices.size() * sizeof(u32));
    ibd.usage = RHI::BufferUsage::Index;
    ibd.dynamic = false;
    RHI::BufferHandle ibo = device_.CreateBuffer(ibd);

    // 半途失败回收，避免泄漏半套缓冲（下次调用重试）
    if (!vbo.IsValid() || !ibo.IsValid()) {
        if (vbo.IsValid()) device_.DestroyBuffer(vbo);
        if (ibo.IsValid()) device_.DestroyBuffer(ibo);
        return false;
    }

    GPUMesh gpu;
    gpu.vbo = vbo;
    gpu.ibo = ibo;
    gpu.indexCount = static_cast<u32>(md.indices.size());

    // 包围盒（视锥剔除）：一次线性扫描
    Vec3 bmin(std::numeric_limits<f32>::max());
    Vec3 bmax(std::numeric_limits<f32>::lowest());
    for (const Vec3& p : md.positions) {
        bmin.x = (p.x < bmin.x) ? p.x : bmin.x;
        bmin.y = (p.y < bmin.y) ? p.y : bmin.y;
        bmin.z = (p.z < bmin.z) ? p.z : bmin.z;
        bmax.x = (p.x > bmax.x) ? p.x : bmax.x;
        bmax.y = (p.y > bmax.y) ? p.y : bmax.y;
        bmax.z = (p.z > bmax.z) ? p.z : bmax.z;
    }
    gpu.boundsMin = bmin;
    gpu.boundsMax = bmax;
    model.boundsMin = bmin;
    model.boundsMax = bmax;

    // --- 蒙皮附加缓冲（location 3 / 4）---
    // 布局：关节索引 4×float（存的是整数的**位模式**，shader 用 floatBitsToInt 还原）
    //       + 权重 4×float，共 8 浮点 = 32 字节/顶点，与顶点缓冲同 stride。
    // 这里曾经是断链：渲染侧有完整的蒙皮管线和 shader，但上传侧从没建过这个缓冲，
    // 于是 gpu.skinned 永远 false —— 模型画出来停在绑定姿态（T-pose），
    // 而动画系统的调色板算得好好的，光看数值完全看不出问题。
    if (md.skinned &&
        md.jointIndices.size() == static_cast<size_t>(vertexCount) * 4 &&
        md.jointWeights.size() == static_cast<size_t>(vertexCount) * 4) {
        std::vector<f32> skinData(static_cast<size_t>(vertexCount) * 8);
        for (u32 v = 0; v < vertexCount; v++) {
            f32* dst = skinData.data() + static_cast<size_t>(v) * 8;
            for (int k = 0; k < 4; k++) {
                const i32 idx = md.jointIndices[static_cast<size_t>(v) * 4 + k];
                std::memcpy(&dst[k], &idx, sizeof(i32));   // 位模式塞进 float
                dst[4 + k] = md.jointWeights[static_cast<size_t>(v) * 4 + k];
            }
        }
        RHI::BufferDesc sbd;
        sbd.data = skinData.data();
        sbd.size = vertexCount * 32;
        sbd.usage = RHI::BufferUsage::Vertex;
        sbd.dynamic = false;
        RHI::BufferHandle skin = device_.CreateBuffer(sbd);
        if (skin.IsValid()) {
            gpu.skin = skin;
            gpu.skinned = true;
        }
    }

    models_[name] = std::move(model);
    meshes_[name] = gpu;
    revision_++;
    return true;
}

RHI::BufferHandle AssetManager::GetOrCreateMesh(const String& path) {
    auto it = meshes_.find(path);
    if (it != meshes_.end()) return it->second.vbo;   // 命中缓存

    // 解析 path -> ModelData（CPU）后上传缓存
    ModelData model;
    if (!GLTFLoader::Load(path, model)) return {};
    if (!uploadMesh(path, std::move(model))) return {};
    return meshes_[path].vbo;
}

bool AssetManager::RegisterProceduralMesh(const String& name, const MeshData& data) {
    if (meshes_.find(name) != meshes_.end()) return false;   // 同名已存在
    if (data.positions.empty() || data.indices.empty()) return false;

    ModelData model;
    model.mesh = data;   // 拷贝缓存（材质表可为空：MeshRef 材质字段生效）
    return uploadMesh(name, std::move(model));
}

GPUMesh AssetManager::GetGPUMesh(const String& path) {
    auto it = meshes_.find(path);
    if (it != meshes_.end()) return it->second;

    GetOrCreateMesh(path);   // 未加载时自动触发（失败则下方仍找不到）
    auto it2 = meshes_.find(path);
    return (it2 != meshes_.end()) ? it2->second : GPUMesh{};
}

const ModelData* AssetManager::GetModelData(const String& path) {
    auto it = models_.find(path);
    return (it != models_.end()) ? &it->second : nullptr;
}

RHI::TextureHandle AssetManager::loadTexture(const String& path, bool srgb, bool pixelArt) {
    TextureMap& map = textureMap(srgb, pixelArt);
    auto it = map.find(path);
    if (it != map.end()) return it->second.handle;   // 命中缓存

    int w = 0, h = 0, channels = 0;
    u8* pixels = nullptr;

    if (path.rfind(kDataURIPrefix, 0) == 0) {
        // 内嵌 data URI：data:image/xxx;base64,<载荷>
        size_t comma = path.find(',');
        if (comma == String::npos) return {};
        std::vector<u8> bytes;
        if (!DecodeBase64(path.substr(comma + 1), bytes)) return {};
        stbi_set_flip_vertically_on_load(1);
        pixels = stbi_load_from_memory(bytes.data(), static_cast<int>(bytes.size()),
                                       &w, &h, &channels, 4);
    } else {
        // 外部文件路径（相对 .gltf 目录解析后的结果）
        stbi_set_flip_vertically_on_load(1);
        pixels = stbi_load(path.c_str(), &w, &h, &channels, 4);
    }

    if (!pixels) return {};

    // 强制 4 通道解码 -> RGBA8 上传：数据布局与上传格式一致，避免越界读；
    // 翻转与 GLTFLoader 的 V 翻转（1 - v）配套，保证采样方向正确。
    RHI::TextureDesc desc;
    desc.width  = static_cast<u32>(w);
    desc.height = static_cast<u32>(h);
    desc.format = RHI::Format::RGBA8;
    desc.pixels = pixels;
    desc.filter = pixelArt ? RHI::TextureFilter::Nearest : RHI::TextureFilter::Linear;
    desc.wrap = RHI::SamplerWrap::Repeat;   // 平铺资产（地形/墙体/箱体）
    desc.mipmaps = !pixelArt;               // 像素美术不生成 mipmap（Nearest 保持锐利）
    desc.anisotropy = !pixelArt;
    desc.srgb = srgb;
    RHI::TextureHandle tex = device_.CreateTexture(desc);
    stbi_image_free(pixels);

    if (!tex.IsValid()) return {};
    map[path] = TextureInfo{ tex, static_cast<u32>(w), static_cast<u32>(h) };
    revision_++;
    return tex;
}

RHI::TextureHandle AssetManager::GetOrCreateTexture(const String& path, bool srgb) {
    return loadTexture(path, srgb, false);
}

bool AssetManager::GetTextureInfo(const String& path, TextureInfo& out, bool pixelArt) {
    const RHI::TextureHandle handle = loadTexture(path, /*srgb=*/false, pixelArt);
    if (!handle.IsValid()) return false;
    TextureMap& map = textureMap(false, pixelArt);
    auto it = map.find(path);
    if (it == map.end()) return false;
    out = it->second;
    return true;
}

bool AssetManager::RegisterTexture(const String& name, u32 width, u32 height,
                                   const void* rgbaPixels, bool pixelArt) {
    if (width == 0 || height == 0 || !rgbaPixels) return false;
    TextureMap& map = textureMap(false, pixelArt);
    if (map.find(name) != map.end()) return false;

    RHI::TextureDesc desc;
    desc.width = width;
    desc.height = height;
    desc.format = RHI::Format::RGBA8;
    desc.pixels = rgbaPixels;
    desc.filter = pixelArt ? RHI::TextureFilter::Nearest : RHI::TextureFilter::Linear;
    desc.wrap = RHI::SamplerWrap::ClampToEdge;
    RHI::TextureHandle tex = device_.CreateTexture(desc);
    if (!tex.IsValid()) return false;

    map[name] = TextureInfo{ tex, width, height };
    revision_++;
    return true;
}

bool AssetManager::RegisterProceduralTexture(const String& name, u32 width, u32 height,
                                             const u8* rgba, bool repeat, bool mipmaps,
                                             bool srgb) {
    if (name.empty() || width == 0 || height == 0) return false;
    TextureMap& map = textureMap(srgb, false);
    if (map.find(name) != map.end()) return false;   // 同名已存在

    // pixels 为空时补一张纯白 RGBA（1 像素亦可，尺寸按传入值）
    std::vector<u8> white;
    const u8* src = rgba;
    if (!src) {
        white.assign(static_cast<size_t>(width) * height * 4, 255);
        src = white.data();
    }

    RHI::TextureDesc desc;
    desc.width  = width;
    desc.height = height;
    desc.format = RHI::Format::RGBA8;
    desc.pixels = src;
    desc.wrap = repeat ? RHI::SamplerWrap::Repeat : RHI::SamplerWrap::ClampToEdge;
    desc.mipmaps = mipmaps;
    desc.anisotropy = mipmaps;
    desc.srgb = srgb;

    RHI::TextureHandle tex = device_.CreateTexture(desc);
    if (!tex.IsValid()) return false;
    map[name] = TextureInfo{ tex, width, height };
    revision_++;
    return true;
}

void AssetManager::Unload(const String& path) {
    auto it = meshes_.find(path);
    if (it != meshes_.end()) {
        if (it->second.vbo.IsValid()) device_.DestroyBuffer(it->second.vbo);
        if (it->second.ibo.IsValid()) device_.DestroyBuffer(it->second.ibo);
        if (it->second.skin.IsValid()) device_.DestroyBuffer(it->second.skin);
        meshes_.erase(it);
        revision_++;
    }
    models_.erase(path);
}

void AssetManager::ReleaseUnused() {
    // 引用计数简化版：不做自动回收，全部保留；
    // 需要释放时由调用方手动 Unload(path)。
}

} // namespace M7N::Asset
