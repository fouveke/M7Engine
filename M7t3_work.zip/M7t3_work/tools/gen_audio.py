#!/usr/bin/env python3
"""Last Light (末灯) procedural audio asset generator.

Everything is synthesized from noise/sines, so the game ships with
royalty-free audio. Output: game_assets/audio/*.wav (44.1 kHz, s16 stereo).
"""
import math
import os
import struct
import wave

import numpy as np

SR = 44100
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "game_assets", "audio")

rng = np.random.default_rng(20261106)


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------

def t_axis(seconds):
    return np.arange(int(SR * seconds), dtype=np.float64) / SR


def fade(x, seconds=0.01, in_out=True):
    n = int(SR * seconds)
    n = min(n, len(x) // 2)
    if n <= 0:
        return x
    ramp = np.linspace(0.0, 1.0, n)[:, None] if x.ndim == 2 else np.linspace(0.0, 1.0, n)
    if in_out:
        x[:n] *= ramp
        x[-n:] *= ramp[::-1]
    else:
        x[:n] *= ramp
    return x


def loopify(x, seconds=1.2):
    """Crossfade the tail into the head so the file loops seamlessly."""
    xf = int(SR * seconds)
    n = len(x) - xf
    out = x[:n].copy()
    ramp = np.linspace(0.0, 1.0, xf)[:, None]
    out[:xf] = x[:xf] * ramp + x[n:n + xf] * (1.0 - ramp)
    return out


def fft_filter(x, lo=None, hi=None, soft=0.25):
    """Smooth band filter using FFT (fine for offline sound design)."""
    mono = x.ndim == 1
    if mono:
        x = x[:, None]
    out = np.empty_like(x)
    freqs = np.fft.rfftfreq(x.shape[0], 1.0 / SR)
    mask = np.ones_like(freqs)
    if lo is not None:
        width = max(lo * soft, 20.0)
        mask *= 0.5 * (1.0 + np.tanh((freqs - lo) / width))
    if hi is not None:
        width = max(hi * soft, 20.0)
        mask *= 0.5 * (1.0 - np.tanh((freqs - hi) / width))
    for c in range(x.shape[1]):
        out[:, c] = np.fft.irfft(np.fft.rfft(x[:, c]) * mask, n=x.shape[0])
    return out[:, 0] if mono else out


def noise(seconds, lo=None, hi=None):
    x = rng.standard_normal(int(SR * seconds))
    return fft_filter(x, lo, hi)


def sine(freq, seconds, phase=0.0):
    return np.sin(2.0 * np.pi * freq * t_axis(seconds) + phase)


def env_exp(seconds, attack=0.005, decay=0.3):
    tt = t_axis(seconds)
    a = np.clip(tt / max(attack, 1e-4), 0.0, 1.0)
    return a * np.exp(-np.maximum(tt - attack, 0.0) / max(decay, 1e-4))


def env_ar(seconds, attack=0.02, release=0.3):
    tt = t_axis(seconds)
    a = np.clip(tt / max(attack, 1e-4), 0.0, 1.0)
    r = np.clip((seconds - tt) / max(release, 1e-4), 0.0, 1.0)
    return a * r


def place(buf, sound, at_sec):
    i = int(at_sec * SR)
    n = min(len(sound), len(buf) - i)
    if n > 0:
        buf[i:i + n] += sound[:n]
    return buf


def stereo(l, r=None, width=0.0):
    if r is None:
        r = l
    if l.ndim == 1:
        l = l[:, None]
    if r.ndim == 1:
        r = r[:, None]
    out = np.concatenate([l, r], axis=1)
    if width > 0.0:
        n = int(width * SR)
        if n > 0:
            out[n:, 1] = out[:-n, 1].copy()
    return out


def write(name, data, peak=0.72):
    os.makedirs(OUT, exist_ok=True)
    data = np.asarray(data, dtype=np.float64)
    if data.ndim == 1:
        data = stereo(data)
    m = float(np.max(np.abs(data)))
    if m > 0:
        data = data / m * peak
    pcm = np.clip(data, -1.0, 1.0)
    pcm = (pcm * 32767.0).astype(np.int16)
    path = os.path.join(OUT, name)
    with wave.open(path, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    print(f"  {name:22s} {len(pcm) / SR:6.2f}s  {os.path.getsize(path) / 1024:7.1f} KiB")


# ----------------------------------------------------------------------------
# loops
# ----------------------------------------------------------------------------

def amb_drone():
    dur, xf = 26.0, 1.5
    n = int((dur + xf) * SR)
    tt = np.arange(n) / SR
    lfo = 0.5 + 0.5 * np.sin(2 * np.pi * tt / 17.0 + 0.7)
    lfo2 = 0.5 + 0.5 * np.sin(2 * np.pi * tt / 11.0 + 2.1)
    low = noise(n / SR, 30, 180) * 0.05
    l = (0.12 * np.sin(2 * np.pi * 36.71 * tt) +
         0.075 * np.sin(2 * np.pi * 55.0 * tt + 0.3) +
         0.055 * np.sin(2 * np.pi * 55.37 * tt) +
         0.030 * np.sin(2 * np.pi * 73.42 * tt + 1.1) +
         0.020 * np.sin(2 * np.pi * 110.0 * tt + 2.2))
    l *= (0.72 + 0.28 * lfo)
    r = (0.12 * np.sin(2 * np.pi * 36.71 * tt + 0.15) +
         0.075 * np.sin(2 * np.pi * 55.0 * tt + 1.4) +
         0.055 * np.sin(2 * np.pi * 55.63 * tt) +
         0.030 * np.sin(2 * np.pi * 73.42 * tt + 2.6) +
         0.020 * np.sin(2 * np.pi * 110.0 * tt + 0.4))
    r *= (0.72 + 0.28 * lfo2)
    l += low[:n]
    r += np.roll(low, 913)[:n]
    data = np.stack([l, r], axis=1)
    write("amb_drone.wav", loopify(data, xf), 0.60)


def amb_wind():
    dur, xf = 22.0, 1.5
    n = int((dur + xf) * SR)
    tt = np.arange(n) / SR
    gust = 0.35 + 0.65 * (0.5 + 0.5 * np.sin(2 * np.pi * tt / 9.5 + 0.4))
    gust *= 0.75 + 0.25 * np.sin(2 * np.pi * tt / 3.7)
    l = noise(n / SR, 160, 1400) * gust
    r = noise(n / SR, 140, 1200) * np.roll(gust, 1103)
    whistle = 0.06 * np.sin(2 * np.pi * 520 * tt) * (0.5 + 0.5 * np.sin(2 * np.pi * tt / 7.0))
    l += whistle
    r += np.roll(whistle, 2205)
    data = np.stack([l, r], axis=1)
    write("amb_wind.wav", loopify(data, xf), 0.42)


def heartbeat():
    dur, xf = 1.6, 0.2
    buf = np.zeros((int((dur + xf) * SR), 2))
    for at, amp in ((0.02, 1.0), (0.40, 0.72), (0.78, 0.35)):
        n = int(0.28 * SR)
        tt = np.arange(n) / SR
        thump = (np.sin(2 * np.pi * (52 - 18 * tt / 0.28) * tt) *
                 np.exp(-tt / 0.055) * amp)
        click = noise(0.28, 40, 400) * np.exp(-tt / 0.02) * 0.25 * amp
        s = thump + click
        for c in range(2):
            place(buf[:, c], s, at)
    write("heartbeat.wav", loopify(fade(buf, 0.005), xf), 0.62)


def ghost_growl():
    dur, xf = 8.0, 1.0
    n = int((dur + xf) * SR)
    tt = np.arange(n) / SR
    fm = np.sin(2 * np.pi * 0.23 * tt) * 6.0
    base = (np.sin(2 * np.pi * 43.0 * tt + fm) +
            0.6 * np.sin(2 * np.pi * 57.5 * tt - fm * 0.7) +
            0.35 * np.sin(2 * np.pi * 86.0 * tt + 1.2))
    base *= 0.55 + 0.45 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.37 * tt + 2.0))
    breath = noise(n / SR, 120, 900) * (0.22 + 0.18 * np.sin(2 * np.pi * 0.61 * tt))
    growl = base * 0.55 + breath
    data = np.stack([growl, np.roll(growl, 331)], axis=1)
    write("ghost_growl.wav", loopify(data, xf), 0.58)


def chase_layer():
    dur, xf = 8.0, 1.0
    n = int((dur + xf) * SR)
    tt = np.arange(n) / SR
    pulse = np.zeros(n)
    for k in range(int(dur / 0.5) + 2):
        at = k * 0.5
        m = int(0.36 * SR)
        t2 = np.arange(m) / SR
        s = (np.sin(2 * np.pi * (48 - 10 * t2) * t2) *
             np.exp(-t2 / 0.09)) * (1.0 if k % 2 == 0 else 0.55)
        place(pulse, s, at)
    trem = 0.55 + 0.45 * np.sin(2 * np.pi * 6.0 * tt)
    hi = (np.sin(2 * np.pi * 220.0 * tt) * 0.10 +
          np.sin(2 * np.pi * 233.1 * tt) * 0.10 +
          np.sin(2 * np.pi * 311.1 * tt) * 0.06) * trem
    hi += noise(n / SR, 900, 3800) * 0.05 * trem
    low = noise(n / SR, 60, 300) * 0.10
    s = pulse * 0.55 + hi + low
    data = np.stack([s, np.roll(s, 507)], axis=1)
    write("chase.wav", loopify(data, xf), 0.62)


def light_buzz():
    dur, xf = 3.0, 0.4
    n = int((dur + xf) * SR)
    tt = np.arange(n) / SR
    buzz = (np.sin(2 * np.pi * 100 * tt) * 0.35 +
            np.sin(2 * np.pi * 200 * tt) * 0.22 +
            np.sin(2 * np.pi * 300 * tt) * 0.12)
    buzz *= 0.55 + 0.45 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.9 * tt))
    crackle = noise(n / SR, 1200, 6000) * np.where(
        rng.random(n) < 0.0015, 0.6, 0.0)
    s = buzz + crackle
    write("light_buzz.wav", loopify(stereo(s, np.roll(s, 77)), xf), 0.30)


# ----------------------------------------------------------------------------
# one-shots
# ----------------------------------------------------------------------------

def footstep(idx):
    dur = 0.36
    tt = t_axis(dur)
    noise_burst = noise(dur, 90, 2400) * env_exp(dur, 0.004, 0.055)
    body = np.sin(2 * np.pi * (72 + idx * 4) * tt) * env_exp(dur, 0.003, 0.07)
    tail = noise(dur, 300, 900) * env_exp(dur, 0.02, 0.11) * 0.20
    heel = noise(dur, 1800, 6000) * env_exp(dur, 0.001, 0.012) * 0.22
    s = noise_burst * (0.55 + 0.08 * idx) + body * 0.42 + tail + heel
    write(f"step_{idx + 1}.wav", stereo(s, np.roll(s, 31), 0.006), 0.52)


def ghost_step():
    dur = 0.6
    tt = t_axis(dur)
    s = (np.sin(2 * np.pi * 40 * tt) * env_exp(dur, 0.006, 0.13) * 0.8 +
         noise(dur, 45, 500) * env_exp(dur, 0.004, 0.09) * 0.6)
    write("ghost_step.wav", stereo(s, np.roll(s, 53)), 0.60)


def whisper(idx):
    dur = 3.4
    tt = t_axis(dur)
    # syllable envelope: random on/off segments with smooth edges
    env = np.zeros(len(tt))
    pos = 0.2
    while pos < dur - 0.3:
        length = float(rng.uniform(0.10, 0.26))
        start = int(pos * SR)
        stop = int((pos + length) * SR)
        a = np.hanning(max(stop - start, 2))
        env[start:stop] = np.maximum(env[start:stop], a[:max(stop - start, 0)])
        pos += length + float(rng.uniform(0.02, 0.12))
    src = noise(dur, 500 + idx * 120, 2600 + idx * 300)
    voiced = src * env
    s = voiced * 0.8 + np.sin(2 * np.pi * (180 + idx * 30) * tt) * env * 0.05
    write(f"whisper_{idx + 1}.wav", stereo(s, np.roll(s, 2600 + idx * 900)), 0.34)


def pickup(name, base=660.0):
    dur = 0.9
    tt = t_axis(dur)
    click = noise(dur, 1800, 9000) * env_exp(dur, 0.001, 0.02) * 0.5
    chime = (np.sin(2 * np.pi * base * tt) * 0.35 +
             np.sin(2 * np.pi * base * 1.5 * tt) * 0.18) * env_exp(dur, 0.002, 0.20)
    click2 = noise(dur, 400, 2400) * env_exp(dur, 0.002, 0.05) * 0.25
    s = click + chime + click2
    write(name, stereo(s, np.roll(s, 97)), 0.5)


def fuse_sound():
    dur = 1.5
    tt = t_axis(dur)
    clunk = (np.sin(2 * np.pi * 90 * tt) * env_exp(dur, 0.002, 0.08) +
             noise(dur, 80, 900) * env_exp(dur, 0.001, 0.05) * 0.7)
    hum = (np.sin(2 * np.pi * 120 * tt) + 0.4 * np.sin(2 * np.pi * 240 * tt))
    hum *= np.clip((tt - 0.18) / 0.15, 0, 1) * np.exp(-np.maximum(tt - 0.3, 0) / 0.55) * 0.25
    s = clunk + hum
    write("fuse_insert.wav", stereo(s, np.roll(s, 71)), 0.62)


def battery_sound():
    dur = 0.55
    tt = t_axis(dur)
    click = noise(dur, 1200, 7000) * env_exp(dur, 0.001, 0.02) * 0.6
    tone = np.sin(2 * np.pi * 880 * tt) * env_exp(dur, 0.005, 0.12) * 0.12
    s = click + tone
    write("battery.wav", stereo(s, np.roll(s, 53)), 0.45)


def power_on():
    dur = 4.0
    buf = np.zeros(int(dur * SR))
    tt = t_axis(dur)
    relay = (np.sin(2 * np.pi * 70 * tt) * env_exp(dur, 0.002, 0.09) +
             noise(dur, 60, 1200) * env_exp(dur, 0.001, 0.06) * 0.8)
    place(buf, relay, 0.0)
    hum = (np.sin(2 * np.pi * 60 * tt) * 0.22 +
           np.sin(2 * np.pi * 120 * tt) * 0.12 +
           np.sin(2 * np.pi * 180 * tt) * 0.07)
    ramp = np.clip((tt - 0.25) / 1.1, 0, 1) * np.clip((dur - tt) / 0.8, 0, 1)
    buf += hum * ramp
    for at in (0.15, 0.32, 0.45, 0.8, 1.35, 2.1):
        place(buf, noise(0.12, 1500, 8000) * env_exp(0.12, 0.001, 0.02) * 0.25, at)
    write("power_on.wav", stereo(buf, np.roll(buf, 441)), 0.68)


def door_locked():
    dur = 1.0
    buf = np.zeros(int(dur * SR))
    for at in (0.0, 0.11, 0.26, 0.41):
        rattle = noise(0.25, 300, 3500) * env_exp(0.25, 0.001, 0.05)
        ring = np.sin(2 * np.pi * 320 * t_axis(0.25)) * env_exp(0.25, 0.002, 0.12) * 0.15
        place(buf, rattle + ring, at)
    write("door_locked.wav", stereo(buf, np.roll(buf, 89)), 0.55)


def locker_sound():
    dur = 1.3
    tt = t_axis(dur)
    creak = np.sin(2 * np.pi * (320 - 120 * tt / dur) * tt) * env_exp(dur, 0.03, 0.35) * 0.35
    metal = noise(dur, 700, 4200) * env_exp(dur, 0.02, 0.22) * 0.35
    clank = np.sin(2 * np.pi * 140 * tt) * env_exp(dur, 0.001, 0.07) * 0.4
    s = creak + metal + clank
    write("locker.wav", stereo(s, np.roll(s, 157)), 0.55)


def apparition():
    dur = 2.8
    tt = t_axis(dur)
    swell = np.clip(tt / dur, 0, 1) ** 2
    shimmer = (np.sin(2 * np.pi * 740 * tt) * 0.08 +
               np.sin(2 * np.pi * 1105 * tt) * 0.05 +
               np.sin(2 * np.pi * 1480 * tt) * 0.03)
    breath = noise(dur, 200, 1800) * 0.22
    s = (shimmer + breath) * swell
    s += np.sin(2 * np.pi * 55 * tt) * swell * 0.2
    write("apparition.wav", stereo(s, np.roll(s, 3000)), 0.55)


def jumpscare():
    dur = 2.2
    tt = t_axis(dur)
    hit = (noise(dur, 120, 9000) * env_exp(dur, 0.001, 0.16) * 0.85 +
           np.sin(2 * np.pi * 70 * tt) * env_exp(dur, 0.001, 0.30) * 0.7)
    cluster = np.zeros_like(tt)
    for f in (110.0, 116.54, 155.56, 233.08):
        cluster += np.sin(2 * np.pi * f * tt) * 0.11
    cluster *= env_ar(dur, 0.004, 0.9)
    sub = np.sin(2 * np.pi * (85 - 55 * np.clip(tt / 0.9, 0, 1)) * tt) * env_exp(dur, 0.002, 0.5) * 0.45
    s = hit + cluster + sub
    write("jumpscare.wav", stereo(s, np.roll(s, 233)), 0.82)


def death_sound():
    dur = 6.0
    tt = t_axis(dur)
    drone = (np.sin(2 * np.pi * (48 - 20 * tt / dur) * tt) * 0.35 +
             np.sin(2 * np.pi * (72 - 28 * tt / dur) * tt) * 0.25)
    drone *= np.clip(tt / 1.2, 0, 1) * np.clip((dur - tt) / 2.2, 0, 1)
    breath = noise(dur, 90, 700) * 0.12 * np.clip((dur - tt) / 2.0, 0, 1)
    s = drone + breath
    write("death.wav", stereo(s, np.roll(s, 881)), 0.58)


def win_sound():
    dur = 8.0
    tt = t_axis(dur)
    env = np.clip(tt / 2.2, 0, 1) * np.clip((dur - tt) / 3.0, 0, 1)
    chord = (np.sin(2 * np.pi * 146.83 * tt) * 0.16 +
             np.sin(2 * np.pi * 220.0 * tt) * 0.13 +
             np.sin(2 * np.pi * 293.66 * tt) * 0.10 +
             np.sin(2 * np.pi * 369.99 * tt) * 0.07)
    shimmer = np.sin(2 * np.pi * 587.33 * tt) * 0.04 * (0.5 + 0.5 * np.sin(2 * np.pi * 0.4 * tt))
    s = (chord + shimmer) * env
    s += noise(dur, 300, 1800) * 0.05 * env
    write("win.wav", stereo(s, np.roll(s, 2205)), 0.55)


def distant_bang():
    dur = 3.0
    tt = t_axis(dur)
    hit = (np.sin(2 * np.pi * 55 * tt) * env_exp(dur, 0.003, 0.5) * 0.7 +
           noise(dur, 50, 1200) * env_exp(dur, 0.002, 0.35) * 0.5)
    ring = (np.sin(2 * np.pi * 190 * tt) + 0.6 * np.sin(2 * np.pi * 287 * tt)) * env_exp(dur, 0.01, 0.45) * 0.10
    s = hit + ring
    write("distant_bang.wav", stereo(s, np.roll(s, 497)), 0.5)


def main():
    print(f"generating audio -> {OUT}")
    amb_drone()
    amb_wind()
    heartbeat()
    ghost_growl()
    chase_layer()
    light_buzz()
    for i in range(3):
        footstep(i)
    ghost_step()
    for i in range(2):
        whisper(i)
    pickup("pickup.wav", 660.0)
    pickup("note.wav", 520.0)
    fuse_sound()
    battery_sound()
    power_on()
    door_locked()
    locker_sound()
    apparition()
    jumpscare()
    death_sound()
    win_sound()
    distant_bang()
    print("done")


if __name__ == "__main__":
    main()
