/**
 * @file RenderBench.cpp
 * @brief 渲染重负载基准：静态网格 + 多材质 + 纹理 + 点光/聚光 + 阴影 + HDR 泛光。
 *
 * 输出 CPU 提交耗时、整帧 GPU 完成耗时、draw call 与剔除统计。
 * 用法：
 *   RenderBench [--objects N] [--frames N] [--width W] [--height H]
 *               [--lights N] [--spots N] [--bloom 0|1] [--scale S] [--out FILE]
 *
 * 默认 1280x720 / 2400 网格 / 16 点光 + 4 聚光 / 120 帧。
 * 窗口隐藏、垂直同步关闭；每帧 glFinish 后再计时，便于前后版本直接对比。
 */
#include <M7N/Render/RenderSystem.hpp>
#include <M7N/Scene/Components.hpp>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "../examples/DemoScreenshot.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

using namespace M7N;
using namespace M7N::ECS;
using namespace M7N::Scene;
using namespace M7N::Render;
using namespace M7N::Asset;

namespace {

MeshData MakeSphere(f32 radius, u32 segments) {
    MeshData md;
    const u32 rings = segments;
    for (u32 r = 0; r <= rings; r++) {
        const f32 theta = 3.14159265f * r / rings;
        const f32 sinT = std::sin(theta), cosT = std::cos(theta);
        for (u32 s = 0; s <= segments; s++) {
            const f32 phi = 2.0f * 3.14159265f * s / segments;
            const Vec3 n(std::cos(phi) * sinT, cosT, std::sin(phi) * sinT);
            md.positions.push_back(n * radius);
            md.normals.push_back(n);
            md.texCoords.emplace_back(static_cast<f32>(s) / segments,
                                      static_cast<f32>(r) / rings);
        }
    }
    for (u32 r = 0; r < rings; r++) {
        for (u32 s = 0; s < segments; s++) {
            const u32 first = r * (segments + 1) + s;
            const u32 second = first + segments + 1;
            md.indices.insert(md.indices.end(),
                { first, first + 1, second,  second, first + 1, second + 1 });
        }
    }
    md.submeshes.push_back({ 0, static_cast<u32>(md.indices.size()) });
    return md;
}

MeshData MakeCube(f32 half) {
    MeshData md;
    struct Face { Vec3 n, a, b, c, d; };
    const Face faces[6] = {
        { {0,0, 1}, {-half,-half, half}, { half,-half, half}, { half, half, half}, {-half, half, half} },
        { {0,0,-1}, { half,-half,-half}, {-half,-half,-half}, {-half, half,-half}, { half, half,-half} },
        { {0, 1,0}, {-half, half, half}, { half, half, half}, { half, half,-half}, {-half, half,-half} },
        { {0,-1,0}, {-half,-half,-half}, { half,-half,-half}, { half,-half, half}, {-half,-half, half} },
        { { 1,0,0}, { half,-half, half}, { half,-half,-half}, { half, half,-half}, { half, half, half} },
        { {-1,0,0}, {-half,-half,-half}, {-half,-half, half}, {-half, half, half}, {-half, half,-half} },
    };
    for (const Face& f : faces) {
        const u32 base = static_cast<u32>(md.positions.size());
        const Vec3 v[4] = { f.a, f.b, f.c, f.d };
        const Vec2 uv[4] = { {0,0}, {1,0}, {1,1}, {0,1} };
        for (u32 i = 0; i < 4; i++) {
            md.positions.push_back(v[i]);
            md.normals.push_back(f.n);
            md.texCoords.push_back(uv[i]);
        }
        md.indices.insert(md.indices.end(), { base, base + 1, base + 2, base, base + 2, base + 3 });
    }
    md.submeshes.push_back({ 0, static_cast<u32>(md.indices.size()) });
    return md;
}

MeshData MakePlane(f32 half) {
    MeshData md;
    md.positions = { {-half,0, half}, { half,0, half}, { half,0,-half}, {-half,0,-half} };
    md.normals.assign(4, Vec3(0.0f, 1.0f, 0.0f));
    md.texCoords = { {0,0}, {1,0}, {1,1}, {0,1} };
    md.indices = { 0, 1, 2, 0, 2, 3 };
    md.submeshes.push_back({ 0, 6 });
    return md;
}

void MakeChecker(std::vector<u8>& out, u32 size, u8 r0, u8 g0, u8 b0, u8 r1, u8 g1, u8 b1) {
    out.resize(static_cast<size_t>(size) * size * 4);
    for (u32 y = 0; y < size; y++) {
        for (u32 x = 0; x < size; x++) {
            const bool alt = ((x / 16) + (y / 16)) & 1;
            const size_t i = (static_cast<size_t>(y) * size + x) * 4;
            out[i + 0] = alt ? r1 : r0;
            out[i + 1] = alt ? g1 : g0;
            out[i + 2] = alt ? b1 : b0;
            out[i + 3] = 255;
        }
    }
}

void MakeNormal(std::vector<u8>& out, u32 size) {
    out.resize(static_cast<size_t>(size) * size * 4);
    for (u32 y = 0; y < size; y++) {
        for (u32 x = 0; x < size; x++) {
            const f32 fx = static_cast<f32>(x) / size * 6.2831853f;
            const f32 fy = static_cast<f32>(y) / size * 6.2831853f;
            const f32 nx = std::sin(fx) * 0.35f;
            const f32 ny = std::cos(fy) * 0.35f;
            const f32 nz = std::sqrt(std::max(0.0f, 1.0f - nx * nx - ny * ny));
            const size_t i = (static_cast<size_t>(y) * size + x) * 4;
            out[i + 0] = static_cast<u8>((nx * 0.5f + 0.5f) * 255.0f);
            out[i + 1] = static_cast<u8>((ny * 0.5f + 0.5f) * 255.0f);
            out[i + 2] = static_cast<u8>((nz * 0.5f + 0.5f) * 255.0f);
            out[i + 3] = 255;
        }
    }
}

void MakeOrm(std::vector<u8>& out, u32 size, u8 rough, u8 metal) {
    out.resize(static_cast<size_t>(size) * size * 4);
    for (u32 y = 0; y < size; y++) {
        for (u32 x = 0; x < size; x++) {
            const u8 grain = static_cast<u8>(std::min(255, static_cast<int>(rough) + static_cast<int>((x * 7 + y * 13) % 17)));
            const size_t i = (static_cast<size_t>(y) * size + x) * 4;
            out[i + 0] = 220;
            out[i + 1] = grain;
            out[i + 2] = metal;
            out[i + 3] = 255;
        }
    }
}

double NowMs() {
    using Clock = std::chrono::steady_clock;
    return std::chrono::duration<double, std::milli>(Clock::now().time_since_epoch()).count();
}

} // namespace

int main(int argc, char** argv) {
    int objects = 2400;
    int frames = 120;
    int width = 1280, height = 720;
    int lightCount = 16;
    int spotCount = 4;
    int bloom = 1;
    int shadow = 1;
    int shadowRes = 0;   // 0 = 沿用引擎默认
    int bloomDiv = 4;
    int fullCount = 2;
    float scale = 1.0f;
    std::string outPath;
    std::string shotPath;

    for (int i = 1; i < argc; i++) {
        auto arg = [&](const char* name) { return std::strcmp(argv[i], name) == 0; };
        if (arg("--objects") && i + 1 < argc) objects = std::atoi(argv[++i]);
        else if (arg("--frames") && i + 1 < argc) frames = std::atoi(argv[++i]);
        else if (arg("--width") && i + 1 < argc) width = std::atoi(argv[++i]);
        else if (arg("--height") && i + 1 < argc) height = std::atoi(argv[++i]);
        else if (arg("--lights") && i + 1 < argc) lightCount = std::atoi(argv[++i]);
        else if (arg("--spots") && i + 1 < argc) spotCount = std::atoi(argv[++i]);
        else if (arg("--bloom") && i + 1 < argc) bloom = std::atoi(argv[++i]);
        else if (arg("--shadow") && i + 1 < argc) shadow = std::atoi(argv[++i]);
        else if (arg("--shadowres") && i + 1 < argc) shadowRes = std::atoi(argv[++i]);
        else if (arg("--bloomdiv") && i + 1 < argc) bloomDiv = std::atoi(argv[++i]);
        else if (arg("--fullcount") && i + 1 < argc) fullCount = std::atoi(argv[++i]);
        else if (arg("--scale") && i + 1 < argc) scale = static_cast<float>(std::atof(argv[++i]));
        else if (arg("--out") && i + 1 < argc) outPath = argv[++i];
        else if (arg("--shot") && i + 1 < argc) shotPath = argv[++i];
    }
    frames = std::max(1, frames);

    if (!glfwInit()) {
        std::fprintf(stderr, "glfw init failed\n");
        return 1;
    }
    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);

    GLFWwindow* window = glfwCreateWindow(width, height, "M7Next RenderBench", nullptr, nullptr);
    if (!window) {
        std::fprintf(stderr, "glfw window creation failed\n");
        glfwTerminate();
        return 1;
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(0);
    if (!gladLoadGLLoader(reinterpret_cast<GLADloadproc>(glfwGetProcAddress))) {
        std::fprintf(stderr, "glad init failed\n");
        glfwTerminate();
        return 1;
    }

    const char* rendererName = reinterpret_cast<const char*>(glGetString(GL_RENDERER));
    const char* versionName = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    std::printf("=== M7Next RenderBench ===\n");
    std::printf("GL renderer: %s\n", rendererName ? rendererName : "?");
    std::printf("GL version : %s\n", versionName ? versionName : "?");

    auto device = RHI::CreateGLDevice();
    if (!device) return 1;
    AssetManager assets(*device);

    assets.RegisterProceduralMesh("bench_cube", MakeCube(0.5f));
    assets.RegisterProceduralMesh("bench_sphere", MakeSphere(1.0f, 14));
    assets.RegisterProceduralMesh("bench_plane", MakePlane(48.0f));

    std::vector<u8> checker, checker2, normal, orm;
    MakeChecker(checker, 256, 180, 170, 150, 120, 110, 95);
    MakeChecker(checker2, 256, 90, 120, 140, 60, 85, 100);
    MakeNormal(normal, 256);
    MakeOrm(orm, 256, 160, 40);
    assets.RegisterProceduralTexture("bench_tex_a", 256, 256, checker.data(), true, true, true);
    assets.RegisterProceduralTexture("bench_tex_b", 256, 256, checker2.data(), true, true, true);
    assets.RegisterProceduralTexture("bench_nrm", 256, 256, normal.data(), true, true, false);
    assets.RegisterProceduralTexture("bench_orm", 256, 256, orm.data(), true, true, false);

    World world;
    world.Reserve(static_cast<u32>(objects + 8));

    {
        Entity floorEntity = world.CreateEntity("Floor");
        Transform& tf = world.AddComponent<Transform>(floorEntity);
        MeshRef& floor = world.AddComponent<MeshRef>(floorEntity);
        floor.path = "bench_plane";
        floor.baseColor = Vec4(0.10f, 0.105f, 0.115f, 1.0f);
        floor.roughness = 0.9f;
        floor.castShadow = false;
        floor.texturePath = "bench_tex_a";
        floor.uvScale = Vec2(12.0f, 12.0f);
        (void)tf;
    }

    const Vec4 palette[6] = {
        Vec4(0.72f, 0.68f, 0.60f, 1.0f),
        Vec4(0.38f, 0.46f, 0.52f, 1.0f),
        Vec4(0.62f, 0.34f, 0.28f, 1.0f),
        Vec4(0.30f, 0.40f, 0.30f, 1.0f),
        Vec4(0.58f, 0.54f, 0.24f, 1.0f),
        Vec4(0.48f, 0.44f, 0.50f, 1.0f),
    };

    const int side = static_cast<int>(std::ceil(std::sqrt(static_cast<double>(objects))));
    const f32 spacing = 1.6f;
    for (int i = 0; i < objects; i++) {
        const int gx = i % side;
        const int gz = i / side;
        Entity e = world.CreateEntity("BenchObject");
        Transform& t = world.AddComponent<Transform>(e);
        const f32 jitter = static_cast<f32>((i * 37) % 11) * 0.005f;
        t.position = Vec3((gx - side * 0.5f) * spacing,
                          0.5f + jitter,
                          (gz - side * 0.5f) * spacing);
        t.rotation.y = static_cast<f32>((i % 4)) * 0.05f;
        t.scale = Vec3(0.85f + 0.4f * ((i * 17) % 7) / 7.0f);

        MeshRef& m = world.AddComponent<MeshRef>(e);
        const int mat = i % 6;
        m.path = (i % 5 == 0) ? "bench_sphere" : "bench_cube";
        m.baseColor = palette[mat];
        m.metallic = (mat == 1 || mat == 5) ? 0.75f : 0.08f;
        m.roughness = 0.22f + 0.12f * static_cast<f32>(mat);
        m.texturePath = (mat & 1) ? "bench_tex_b" : "bench_tex_a";
        m.normalPath = "bench_nrm";
        m.ormPath = "bench_orm";
        m.uvScale = Vec2(1.0f, 1.0f);
        m.detailNormalStrength = (i % 7 == 0) ? 0.45f : 0.0f;
        m.detailRoughJitter = (i % 7 == 0) ? 0.35f : 0.0f;
    }

    RenderSystem renderer(*device, assets);
    RenderConfig cfg;
    cfg.exposure = 1.0f;
    cfg.vignette = 0.3f;
    cfg.shadowRadius = 26.0f;
    cfg.ambientSky = Vec3(0.16f, 0.17f, 0.20f);
    cfg.ambientGround = Vec3(0.05f, 0.05f, 0.045f);
    cfg.bloomStrength = bloom ? 0.55f : 0.0f;
    cfg.bloomDownscale = static_cast<u32>(bloomDiv);
    if (shadowRes > 0) cfg.shadowMapSize = static_cast<u32>(shadowRes);
    cfg.dynamicLightFullCount = static_cast<u32>(fullCount);
    cfg.renderScale = scale;
    renderer.SetConfig(cfg);

    if (!renderer.Init(static_cast<u32>(width), static_cast<u32>(height))) {
        std::fprintf(stderr, "RenderSystem init failed\n");
        return 1;
    }

    const f32 aspect = static_cast<f32>(width) / static_cast<f32>(height);
    const Vec3 eye(29.0f, 32.0f, 29.0f);
    const Vec3 target(0.0f, 0.0f, 0.0f);
    renderer.SetCamera(eye, target, 45.0f, aspect, 0.1f, 220.0f);

    DirectionalLight sun;
    sun.direction = Vec3(-0.35f, -1.0f, -0.25f);
    sun.color = Vec3(1.0f, 0.96f, 0.88f);
    sun.intensity = 1.1f;
    sun.castShadows = shadow != 0;

    std::printf("scene: %d objects, %d point lights, %d spots, bloom=%d/%d, shadow=%d/%u, fullPBR=%d, scale=%.2f, %dx%d\n",
                objects, lightCount, spotCount, bloom, bloomDiv, shadow,
                cfg.shadowMapSize, fullCount, scale, width, height);

    std::vector<double> cpuMs;
    std::vector<double> frameMs;
    cpuMs.reserve(static_cast<size_t>(frames));
    frameMs.reserve(static_cast<size_t>(frames));

    for (int frame = 0; frame < frames + 20; frame++) {
        glfwPollEvents();

        renderer.ClearLights();
        renderer.SetDirectionalLight(sun);
        for (int i = 0; i < lightCount; i++) {
            PointLight pl;
            const f32 a = static_cast<f32>(i) * 2.3999632f;
            const f32 r = 8.0f + 14.0f * static_cast<f32>(i % 5) / 5.0f;
            pl.position = Vec3(std::cos(a) * r, 2.2f + 0.5f * (i % 3), std::sin(a) * r);
            pl.color = Vec3(0.7f + 0.3f * std::sin(a),
                            0.5f + 0.5f * std::sin(a + 2.1f),
                            0.4f + 0.6f * std::sin(a + 4.2f));
            pl.intensity = 9.0f;
            pl.range = 11.0f;
            renderer.AddPointLight(pl);
        }
        for (int i = 0; i < spotCount; i++) {
            SpotLight sl;
            const f32 a = static_cast<f32>(i) * 1.5707963f;
            sl.position = Vec3(std::cos(a) * 12.0f, 9.0f, std::sin(a) * 12.0f);
            sl.direction = Vec3(-std::cos(a), -1.0f, -std::sin(a));
            sl.color = Vec3(0.7f, 0.85f, 1.0f);
            sl.intensity = 45.0f;
            sl.range = 26.0f;
            sl.innerCos = 0.90f;
            sl.outerCos = 0.62f;
            renderer.AddSpotLight(sl);
        }

        glFinish();
        const double t0 = NowMs();
        renderer.RenderFrame(world, Vec3(0.0f, 0.5f, 0.0f));
        const double t1 = NowMs();
        glFinish();
        const double t2 = NowMs();
        if (!shotPath.empty() && frame == frames + 19) {
            const bool ok = DemoUtil::SaveFramebufferBmp(shotPath.c_str(), width, height);
            std::printf("screenshot %s: %s\n", shotPath.c_str(), ok ? "saved" : "failed");
        }
        glfwSwapBuffers(window);

        if (frame >= 20) {
            cpuMs.push_back(t1 - t0);
            frameMs.push_back(t2 - t0);
        }
    }

    auto avg = [](const std::vector<double>& v) {
        double s = 0.0;
        for (double x : v) s += x;
        return v.empty() ? 0.0 : s / static_cast<double>(v.size());
    };
    auto percentile = [](std::vector<double> v, double p) {
        if (v.empty()) return 0.0;
        std::sort(v.begin(), v.end());
        const size_t idx = static_cast<size_t>(p * static_cast<double>(v.size() - 1));
        return v[idx];
    };

    const double cpuAvg = avg(cpuMs);
    const double frameAvg = avg(frameMs);
    const RenderStats& st = renderer.GetStats();
    std::printf("\n--- results (%d frames) ---\n", frames);
    std::printf("CPU submit avg : %8.3f ms  (p50 %.3f, p95 %.3f)\n",
                cpuAvg, percentile(cpuMs, 0.50), percentile(cpuMs, 0.95));
    std::printf("GPU frame  avg : %8.3f ms  (p50 %.3f, p95 %.3f)\n",
                frameAvg, percentile(frameMs, 0.50), percentile(frameMs, 0.95));
    std::printf("FPS            : %8.1f\n", frameAvg > 0.0 ? 1000.0 / frameAvg : 0.0);
    std::printf("draws          : scene %u, shadow %u, prepass %u, meshes %u, culled %u\n",
                st.sceneDraws, st.shadowDraws, st.prepassDraws, st.meshes, st.culled);
    std::printf("batching       : materials %u, lights %u, grid overflow %u\n",
                st.batches, st.lights, st.lightOverflows);
    std::printf("cpu breakdown  : transform %.2f, collect %.2f, sort %.2f, batch %.2f, record %.2f, submit %.2f ms\n",
                st.cpuTransformMs, st.cpuCollectMs, st.cpuSortMs, st.cpuBatchMs,
                st.cpuRecordMs, st.cpuSubmitMs);

    if (!outPath.empty()) {
        FILE* f = std::fopen(outPath.c_str(), "w");
        if (f) {
            std::fprintf(f, "renderer=%s\nversion=%s\nobjects=%d\nframes=%d\n"
                            "width=%d\nheight=%d\nlights=%d\nspots=%d\nbloom=%d\nshadow=%d\nscale=%.3f\n"
                            "cpu_avg_ms=%.4f\ncpu_p50_ms=%.4f\ncpu_p95_ms=%.4f\n"
                            "gpu_avg_ms=%.4f\ngpu_p50_ms=%.4f\ngpu_p95_ms=%.4f\n"
                            "fps=%.2f\nscene_draws=%u\nshadow_draws=%u\nprepass_draws=%u\n"
                            "meshes=%u\nculled=%u\nbatches=%u\nlight_overflows=%u\n",
                         rendererName ? rendererName : "?", versionName ? versionName : "?",
                         objects, frames, width, height, lightCount, spotCount, bloom, shadow, scale,
                         cpuAvg, percentile(cpuMs, 0.50), percentile(cpuMs, 0.95),
                         frameAvg, percentile(frameMs, 0.50), percentile(frameMs, 0.95),
                         frameAvg > 0.0 ? 1000.0 / frameAvg : 0.0,
                         st.sceneDraws, st.shadowDraws, st.prepassDraws,
                         st.meshes, st.culled, st.batches, st.lightOverflows);
            std::fclose(f);
        }
    }

    renderer.Shutdown();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
