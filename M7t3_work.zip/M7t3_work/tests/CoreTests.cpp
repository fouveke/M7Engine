/**
 * @file CoreTests.cpp
 * @brief Core 层测试：计时/固定步长、作业系统、事件总线、输入、日志。
 */
#include "TestCommon.hpp"

#include "M7N/Core/EventBus.hpp"
#include "M7N/Core/Input.hpp"
#include "M7N/Core/JobSystem.hpp"
#include "M7N/Core/Log.hpp"
#include "M7N/Core/Time.hpp"

#include <atomic>
#include <string>
#include <vector>

using namespace M7N;

namespace {

struct EventA { int value = 0; };
struct EventB { int value = 0; };

void TestTime() {
    std::printf("[Test] time / fixed step\n");
    FrameTimer timer;
    CHECK(timer.FrameCount() == 0);
    timer.Tick();
    timer.Tick();
    CHECK(timer.FrameCount() == 2);
    CHECK(timer.TotalSeconds() >= 0.0);

    FixedStepAccumulator fixed(1.0f / 60.0f, 5);
    int steps = 0;
    for (int i = 0; i < 10; ++i) {
        fixed.Advance(1.0f / 60.0f, [&](f32) { ++steps; });
    }
    CHECK(steps == 10);
    CHECK(fixed.TotalSteps() == 10);

    // 死亡螺旋保护：一次巨大 dt 最多补 maxSteps 步
    FixedStepAccumulator clamped(1.0f / 60.0f, 5);
    int burst = 0;
    clamped.Advance(1.0f, [&](f32) { ++burst; });
    CHECK(burst == 5);
}

void TestJobs() {
    std::printf("[Test] job system\n");
    JobSystem jobs(4);
    CHECK(jobs.WorkerCount() == 4);

    constexpr u32 kCount = 10000;
    std::atomic<u64> sum{ 0 };
    std::vector<u32> hits(kCount, 0);

    jobs.ParallelFor(kCount, 37, [&](u32 i) {
        sum.fetch_add(i, std::memory_order_relaxed);
        hits[i]++;   // 每个索引只由一个区间写
    });

    const u64 expected = static_cast<u64>(kCount) * (kCount - 1) / 2;
    CHECK(sum.load() == expected);
    bool allExactlyOnce = true;
    for (u32 h : hits) {
        if (h != 1) { allExactlyOnce = false; break; }
    }
    CHECK(allExactlyOnce);

    // 工作线程内嵌套 ParallelFor 退化为串行（不会死锁）
    std::atomic<u32> nestedSum{ 0 };
    jobs.ParallelFor(8, 1, [&](u32) {
        jobs.ParallelFor(10, 1, [&](u32 j) {
            nestedSum.fetch_add(j + 1, std::memory_order_relaxed);
        });
    });
    CHECK(nestedSum.load() == 8 * 55);

    // 空任务/零数量安全
    jobs.ParallelFor(0, 4, [](u32) { CHECK(false); });
    jobs.ParallelFor(1, 1, [](u32 i) { CHECK(i == 0); });
}

void TestEvents() {
    std::printf("[Test] event bus\n");
    EventBus bus;
    int totalA = 0;
    int totalB = 0;

    EventBus::SubscriptionId first = bus.Subscribe<EventA>([&](const EventA& e) {
        totalA += e.value;
    });
    bus.Subscribe<EventA>([&](const EventA& e) {
        totalA += e.value * 10;
    });
    bus.Subscribe<EventB>([&](const EventB& e) {
        totalB += e.value;
    });

    CHECK(bus.SubscriberCount<EventA>() == 2);
    bus.Publish(EventA{ 3 });
    CHECK(totalA == 33);

    CHECK(bus.Unsubscribe(first));
    bus.Publish(EventA{ 2 });
    CHECK(totalA == 33 + 20);
    CHECK(!bus.Unsubscribe(first));

    bus.Publish(EventB{ 7 });
    CHECK(totalB == 7);

    // 回调内退订自身（发布快照语义）
    EventBus::SubscriptionId self = 0;
    int selfCalls = 0;
    self = bus.Subscribe<EventB>([&](const EventB&) {
        selfCalls++;
        bus.Unsubscribe(self);
    });
    bus.Publish(EventB{ 1 });
    bus.Publish(EventB{ 1 });
    CHECK(selfCalls == 1);
}

void TestInput() {
    std::printf("[Test] input\n");
    Input input;
    input.NewFrame();
    CHECK(!input.IsKeyDown(Key::W));
    CHECK(!input.IsKeyPressed(Key::W));

    input.OnKey(static_cast<i32>(Key::W), true);
    CHECK(input.IsKeyDown(Key::W));
    CHECK(input.IsKeyPressed(Key::W));
    CHECK(!input.IsKeyPressed(Key::A));

    input.NewFrame();
    CHECK(input.IsKeyDown(Key::W));
    CHECK(!input.IsKeyPressed(Key::W));

    input.OnKey(static_cast<i32>(Key::W), false);
    CHECK(!input.IsKeyDown(Key::W));
    CHECK(input.IsKeyReleased(Key::W));

    input.MapAction("Jump", Key::Space);
    input.MapAction("Jump", MouseButton::Left);
    input.MapAxis("MoveX", Key::A, Key::D);
    input.NewFrame();
    input.OnKey(static_cast<i32>(Key::Space), true);
    CHECK(input.IsActionDown("Jump"));
    CHECK(input.IsActionPressed("Jump"));

    input.OnKey(static_cast<i32>(Key::D), true);
    CHECK_NEAR(input.GetAxis("MoveX"), 1.0f, 1e-6f);
    input.OnKey(static_cast<i32>(Key::A), true);
    CHECK_NEAR(input.GetAxis("MoveX"), 0.0f, 1e-6f);
    input.OnKey(static_cast<i32>(Key::D), false);
    CHECK_NEAR(input.GetAxis("MoveX"), -1.0f, 1e-6f);

    input.OnMouseMove(10.0f, 10.0f);
    input.OnMouseMove(15.0f, 12.0f);
    CHECK_NEAR(input.MouseDelta().x, 5.0f, 1e-6f);
    CHECK_NEAR(input.MouseDelta().y, 2.0f, 1e-6f);

    // 失焦释放全部按住键
    input.OnFocusLost();
    CHECK(!input.IsKeyDown(Key::A));
    CHECK(!input.IsKeyDown(Key::Space));
    CHECK(input.IsKeyReleased(Key::A));
}

int g_logLines = 0;
std::string g_lastLog;

void TestLogSink(LogLevel, const char* line, void*) {
    g_logLines++;
    g_lastLog = line ? line : "";
}

void TestLog() {
    std::printf("[Test] log\n");
    Log::SetLevel(LogLevel::Info);
    Log::SetSink(&TestLogSink, nullptr);
    M7N_LOG_DEBUG("Test", "hidden %d", 1);
    M7N_LOG_INFO("Test", "visible %d", 42);
    CHECK(g_logLines == 1);
    CHECK(g_lastLog.find("visible 42") != std::string::npos);
    Log::SetSink(nullptr, nullptr);
    Log::SetLevel(LogLevel::Info);
}

} // namespace

int main() {
    std::printf("=== M7Next Core Tests ===\n");
    TestTime();
    TestJobs();
    TestEvents();
    TestInput();
    TestLog();
    return TestSummary("Core");
}
