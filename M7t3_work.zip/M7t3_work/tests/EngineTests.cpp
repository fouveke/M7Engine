/**
 * @file EngineTests.cpp
 * @brief 2D / 反射序列化 / 变换缓存 / 相机 测试。
 */
#include "TestCommon.hpp"

#include "M7N/2D/Math2D.hpp"
#include "M7N/2D/Components.hpp"
#include "M7N/2D/Animation2D.hpp"
#include "M7N/2D/Renderer2D.hpp"
#include "M7N/Core/JobSystem.hpp"
#include "M7N/ECS/World.hpp"
#include "M7N/Math/Frustum.hpp"
#include "M7N/Physics/PhysicsComponents.hpp"
#include "M7N/Physics/PhysicsWorld.hpp"
#include "M7N/Scene/Camera.hpp"
#include "M7N/Scene/Components.hpp"
#include "M7N/Scene/SceneSerializer.hpp"
#include "M7N/Scene/TransformSystem.hpp"

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

using namespace M7N;
using namespace M7N::ECS;
using namespace M7N::Scene;

namespace {

Vec3 TranslationOf(const Mat4& m) {
    return Vec3(m.m[12], m.m[13], m.m[14]);
}

void TestRectMath() {
    std::printf("[Test] 2D rect / circle math\n");
    using namespace Dim2;
    Rect2D rect{ Vec2(0.0f, 0.0f), Vec2(10.0f, 10.0f) };
    CHECK(rect.Contains(Vec2(5.0f, 5.0f)));
    CHECK(!rect.Contains(Vec2(-1.0f, 5.0f)));
    CHECK(rect.Intersects(Rect2D{ Vec2(9.0f, 9.0f), Vec2(20.0f, 20.0f) }));
    CHECK(!rect.Intersects(Rect2D{ Vec2(11.0f, 0.0f), Vec2(20.0f, 10.0f) }));

    CHECK(CircleIntersectsRect(Vec2(0.0f, 0.0f), 1.0f, rect));
    CHECK(!CircleIntersectsRect(Vec2(-2.0f, 5.0f), 1.0f, rect));
    CHECK(CircleIntersectsCircle(Vec2(0.0f, 0.0f), 2.0f, Vec2(3.0f, 0.0f), 1.5f));
    CHECK(!CircleIntersectsCircle(Vec2(0.0f, 0.0f), 1.0f, Vec2(3.0f, 0.0f), 1.0f));

    const Rect2D expanded = rect.Expanded(2.0f);
    CHECK_NEAR(expanded.min.x, -2.0f, 1e-6);
    CHECK_NEAR(expanded.max.y, 12.0f, 1e-6);

    // 变换矩形：平移 + 缩放
    Mat4 m = glm::translate(Mat4(1.0f), Vec3(10.0f, 5.0f, 0.0f));
    m = glm::scale(m, Vec3(2.0f, 3.0f, 1.0f));
    const Rect2D world = TransformRectToAABB(m, Rect2D{ Vec2(0.0f, 0.0f), Vec2(1.0f, 1.0f) });
    CHECK_NEAR(world.min.x, 10.0f, 1e-5);
    CHECK_NEAR(world.min.y, 5.0f, 1e-5);
    CHECK_NEAR(world.max.x, 12.0f, 1e-5);
    CHECK_NEAR(world.max.y, 8.0f, 1e-5);
}

void TestFrameUV() {
    std::printf("[Test] atlas frame UV\n");
    using namespace Dim2;
    Vec4 uv = FrameUV(0, 2, 2);
    CHECK_NEAR(uv.x, 0.0f, 1e-6);
    CHECK_NEAR(uv.y, 0.5f, 1e-6);
    CHECK_NEAR(uv.z, 0.5f, 1e-6);
    CHECK_NEAR(uv.w, 1.0f, 1e-6);

    uv = FrameUV(1, 2, 2);
    CHECK_NEAR(uv.x, 0.5f, 1e-6);
    CHECK_NEAR(uv.y, 0.5f, 1e-6);

    uv = FrameUV(2, 2, 2);   // 第二行（图像上往下）
    CHECK_NEAR(uv.x, 0.0f, 1e-6);
    CHECK_NEAR(uv.y, 0.0f, 1e-6);
    CHECK_NEAR(uv.z, 0.5f, 1e-6);
    CHECK_NEAR(uv.w, 0.5f, 1e-6);

    // 越界帧取模
    uv = FrameUV(4, 2, 2);
    CHECK_NEAR(uv.y, 0.5f, 1e-6);
}

void TestTransformSystem() {
    std::printf("[Test] transform system\n");
    World world;
    Entity parent = world.CreateEntity("parent");
    Entity child = world.CreateEntity("child");
    Entity grand = world.CreateEntity("grand");
    world.SetParent(child, parent);
    world.SetParent(grand, child);

    world.AddComponent<Transform>(parent).position = Vec3(4.0f, 1.0f, 0.0f);
    {
        Transform& t = world.AddComponent<Transform>(child);
        t.position = Vec3(2.0f, 0.0f, 0.0f);
        t.rotation = Vec3(0.0f, 1.5707963f, 0.0f);
        t.scale = Vec3(2.0f, 2.0f, 2.0f);
    }
    world.AddComponent<Transform>(grand).position = Vec3(1.0f, 0.0f, 0.0f);

    // 未更新缓存时回退实时计算
    const Vec3 fallback = TranslationOf(TransformSystem::GetWorldMatrix(world, grand));
    const Vec3 reference = TranslationOf(ComputeWorldMatrix(world, grand));
    CHECK_NEAR(fallback.x, reference.x, 1e-5);
    CHECK_NEAR(fallback.y, reference.y, 1e-5);

    TransformSystem transforms;
    transforms.OnUpdate(world);
    CHECK(transforms.LastRootCount() == 1);
    CHECK(world.HasComponent<WorldTransform>(parent));

    for (Entity e : { parent, child, grand }) {
        const Vec3 cached = TranslationOf(TransformSystem::GetWorldMatrix(world, e));
        const Vec3 live = TranslationOf(ComputeWorldMatrix(world, e));
        CHECK_NEAR(cached.x, live.x, 1e-5);
        CHECK_NEAR(cached.y, live.y, 1e-5);
        CHECK_NEAR(cached.z, live.z, 1e-5);
    }

    // 移除 Transform -> 缓存组件应被清理
    world.RemoveComponent<Transform>(grand);
    transforms.OnUpdate(world);
    CHECK(!world.HasComponent<WorldTransform>(grand));

    // 多根并行路径
    World wide;
    std::vector<Entity> roots;
    for (int i = 0; i < 200; ++i) {
        Entity r = wide.CreateEntity("root");
        Transform& t = wide.AddComponent<Transform>(r);
        t.position = Vec3(static_cast<f32>(i), 0.0f, 0.0f);
        roots.push_back(r);
        Entity c = wide.CreateEntity("child");
        wide.SetParent(c, r);
        wide.AddComponent<Transform>(c).position = Vec3(0.0f, 1.0f, 0.0f);
    }
    JobSystem jobs(4);
    TransformSystem parallel;
    parallel.OnUpdate(wide, &jobs);
    CHECK(parallel.LastRootCount() == 200);
    const Vec3 last = TranslationOf(TransformSystem::GetWorldMatrix(wide, roots.back()));
    CHECK_NEAR(last.x, 199.0f, 1e-4);
    CHECK_NEAR(last.y, 0.0f, 1e-4);
}

void TestCamera2D() {
    std::printf("[Test] camera 2D\n");
    using namespace Dim2;
    Camera2D camera;
    camera.position = Vec2(5.0f, -3.0f);
    camera.orthoHeight = 10.0f;
    camera.aspect = 2.0f;

    const Vec4 center = camera.ViewProjection() * Vec4(5.0f, -3.0f, 0.0f, 1.0f);
    CHECK_NEAR(center.x, 0.0f, 1e-5);
    CHECK_NEAR(center.y, 0.0f, 1e-5);

    const Vec2 viewport(1280.0f, 720.0f);
    const Vec2 centerScreen = camera.WorldToScreen(Vec2(5.0f, -3.0f), viewport);
    CHECK_NEAR(centerScreen.x, 640.0f, 1e-3);
    CHECK_NEAR(centerScreen.y, 360.0f, 1e-3);
    const Vec2 centerWorld = camera.ScreenToWorld(Vec2(640.0f, 360.0f), viewport);
    CHECK_NEAR(centerWorld.x, 5.0f, 1e-4);
    CHECK_NEAR(centerWorld.y, -3.0f, 1e-4);

    camera.rotation = 0.7f;
    const Vec2 probe(7.0f, 1.5f);
    const Vec2 probeScreen = camera.WorldToScreen(probe, viewport);
    const Vec2 probeWorld = camera.ScreenToWorld(probeScreen, viewport);
    CHECK_NEAR(probeWorld.x, probe.x, 1e-3);
    CHECK_NEAR(probeWorld.y, probe.y, 1e-3);
    camera.rotation = 0.0f;

    Rect2D bounds = camera.WorldBounds();
    CHECK_NEAR(bounds.Size().x, 20.0f, 1e-4);
    CHECK_NEAR(bounds.Size().y, 10.0f, 1e-4);

    camera.rotation = 1.5707963f;   // 90°
    bounds = camera.WorldBounds();
    CHECK_NEAR(bounds.Size().x, 10.0f, 1e-4);
    CHECK_NEAR(bounds.Size().y, 20.0f, 1e-4);

    World world;
    Entity camEntity = world.CreateEntity("camera");
    Transform& t = world.AddComponent<Transform>(camEntity);
    t.position = Vec3(2.0f, 4.0f, 0.0f);
    t.scale = Vec3(2.0f, 2.0f, 1.0f);
    Camera2DComp& comp = world.AddComponent<Camera2DComp>(camEntity);
    comp.orthoHeight = 12.0f;
    comp.primary = true;

    const Camera2D built = MakeCamera2D(world, camEntity, 16.0f / 9.0f);
    CHECK_NEAR(built.position.x, 2.0f, 1e-5);
    CHECK_NEAR(built.position.y, 4.0f, 1e-5);
    CHECK_NEAR(built.orthoHeight, 6.0f, 1e-5);   // 12 / scaleY 2
    CHECK(FindPrimaryCamera2D(world) == camEntity);
}

void TestSpriteAnimation() {
    std::printf("[Test] sprite animation\n");
    using namespace Dim2;
    World world;
    Entity e = world.CreateEntity("sprite");
    world.AddComponent<Transform>(e);
    SpriteComp& sprite = world.AddComponent<SpriteComp>(e);
    sprite.size = Vec2(1.0f, 1.0f);
    SpriteAnimatorComp& anim = world.AddComponent<SpriteAnimatorComp>(e);
    anim.frameCount = 4;
    anim.columns = 2;
    anim.rows = 2;
    anim.fps = 10.0f;
    anim.loop = true;

    SpriteAnimatorSystem::OnUpdate(world, 0.11f);
    CHECK(anim.currentFrame == 1);
    CHECK_NEAR(sprite.uv.x, 0.5f, 1e-5);
    CHECK_NEAR(sprite.uv.y, 0.5f, 1e-5);

    SpriteAnimatorSystem::OnUpdate(world, 0.11f);
    CHECK(anim.currentFrame == 2);
    CHECK_NEAR(sprite.uv.x, 0.0f, 1e-5);
    CHECK_NEAR(sprite.uv.y, 0.0f, 1e-5);

    // 循环：累计到 > 4 帧后回到 0
    SpriteAnimatorSystem::OnUpdate(world, 0.21f);
    CHECK(anim.currentFrame >= 0 && anim.currentFrame < 4);

    // ping-pong
    anim.pingPong = true;
    anim.direction = 1;
    anim.currentFrame = 0;
    anim.time = 0.0f;
    anim.playing = true;
    anim.fps = 10.0f;
    for (int i = 0; i < 8; ++i) SpriteAnimatorSystem::OnUpdate(world, 0.11f);
    CHECK(anim.currentFrame >= 0 && anim.currentFrame <= 3);

    // 不循环：停在末帧
    anim.pingPong = false;
    anim.loop = false;
    anim.currentFrame = 0;
    anim.time = 0.0f;
    anim.playing = true;
    for (int i = 0; i < 10; ++i) SpriteAnimatorSystem::OnUpdate(world, 0.11f);
    CHECK(anim.currentFrame == 3);
    CHECK(!anim.playing);
}

void TestFrustumAndCamera() {
    std::printf("[Test] frustum culling / camera view\n");
    const Mat4 proj = glm::perspective(glm::radians(60.0f), 1.0f, 0.1f, 100.0f);
    const Mat4 look = glm::lookAt(Vec3(0.0f, 0.0f, 0.0f),
                                  Vec3(0.0f, 0.0f, -1.0f),
                                  Vec3(0.0f, 1.0f, 0.0f));
    Math::Frustum frustum;
    frustum.FromViewProjection(proj * look);

    CHECK(frustum.ContainsPoint(Vec3(0.0f, 0.0f, -5.0f)));
    CHECK(!frustum.ContainsPoint(Vec3(0.0f, 0.0f, 5.0f)));
    CHECK(frustum.IntersectsAABB(Vec3(-1.0f, -1.0f, -5.0f), Vec3(1.0f, 1.0f, -4.0f)));
    CHECK(!frustum.IntersectsAABB(Vec3(-1.0f, -1.0f, 1.0f), Vec3(1.0f, 1.0f, 2.0f)));
    CHECK(!frustum.IntersectsAABB(Vec3(100.0f, -1.0f, -5.0f),
                                  Vec3(101.0f, 1.0f, -4.0f)));
    // 跨越近平面的大盒子仍可见
    CHECK(frustum.IntersectsAABB(Vec3(-10.0f, -10.0f, -10.0f),
                                 Vec3(10.0f, 10.0f, -0.05f)));

    Vec3 worldMin, worldMax;
    Math::TransformAABB(glm::translate(Mat4(1.0f), Vec3(3.0f, 4.0f, 0.0f)),
                        Vec3(-1.0f, -2.0f, -3.0f), Vec3(1.0f, 2.0f, 3.0f),
                        worldMin, worldMax);
    CHECK_NEAR(worldMin.x, 2.0f, 1e-5);
    CHECK_NEAR(worldMax.y, 6.0f, 1e-5);

    World world;
    Entity cameraEntity = world.CreateEntity("camera");
    Transform& t = world.AddComponent<Transform>(cameraEntity);
    t.position = Vec3(0.0f, 0.0f, 5.0f);
    CameraComp& camera = world.AddComponent<CameraComp>(cameraEntity);
    camera.primary = true;
    camera.fovYDeg = 60.0f;

    const CameraView view = BuildCameraView(world, cameraEntity, 1.0f);
    CHECK_NEAR(view.position.z, 5.0f, 1e-5);
    CHECK_NEAR(view.forward.z, -1.0f, 1e-5);
    const Vec4 clip = view.viewProj * Vec4(0.0f, 0.0f, 0.0f, 1.0f);
    CHECK(clip.w > 0.0f);
    CHECK_NEAR(clip.x / clip.w, 0.0f, 1e-4);
    CHECK_NEAR(clip.y / clip.w, 0.0f, 1e-4);

    Entity second = world.CreateEntity("camera2");
    world.AddComponent<Transform>(second).position = Vec3(10.0f, 0.0f, 0.0f);
    world.AddComponent<CameraComp>(second).primary = false;
    CHECK(FindPrimaryCamera(world) == cameraEntity);
}

void TestPhysicsQueries() {
    std::printf("[Test] physics overlap queries\n");
    Physics::PhysicsWorld physicsWorld;
    physicsWorld.Init(Vec3(0.0f));
    const Entity sphereEntity{ 1, 1 };
    const Entity boxEntity{ 2, 1 };

    const u32 sphereId = physicsWorld.AddRigidBody(sphereEntity,
                                                   Physics::CollisionShape::Sphere, 1.0f);
    const u32 boxId = physicsWorld.AddRigidBody(boxEntity,
                                                Physics::CollisionShape::Box, 1.0f);
    Physics::RigidBody* sphere = physicsWorld.GetBody(sphereId);
    Physics::RigidBody* box = physicsWorld.GetBody(boxId);
    CHECK(sphere && box);
    if (sphere) { sphere->position = Vec3(0.0f); sphere->radius = 1.0f; }
    if (box) { box->position = Vec3(6.0f, 0.0f, 0.0f); box->halfExtents = Vec3(1.0f); }

    std::vector<Entity> hits;
    physicsWorld.OverlapSphere(Vec3(0.2f, 0.0f, 0.0f), 1.2f, hits);
    bool foundSphere = false;
    for (Entity e : hits) if (e == sphereEntity) foundSphere = true;
    CHECK(foundSphere);
    CHECK(hits.size() == 1);

    physicsWorld.OverlapBox(Physics::AABB{ Vec3(-0.5f), Vec3(0.5f) }, hits);
    CHECK(hits.size() == 1 && hits[0] == sphereEntity);

    physicsWorld.OverlapSphere(Vec3(6.0f, 0.0f, 0.0f), 0.5f, hits);
    CHECK(hits.size() == 1 && hits[0] == boxEntity);
}

void TestSerialization() {
    std::printf("[Test] extended serialization round-trip\n");
    const char* path = "m7n_engine_test_scene.json";
    {
        World w;
        Entity e = w.CreateEntity("SpriteEntity");
        Transform& t = w.AddComponent<Transform>(e);
        t.position = Vec3(1.5f, 2.5f, 0.0f);

        Dim2::SpriteComp& sprite = w.AddComponent<Dim2::SpriteComp>(e);
        sprite.texture = "atlas";
        sprite.color = Vec4(0.2f, 0.4f, 0.6f, 0.8f);
        sprite.size = Vec2(3.0f, 4.0f);
        sprite.uv = Vec4(0.1f, 0.2f, 0.3f, 0.4f);
        sprite.pivot = Vec2(0.25f, 0.75f);
        sprite.layer = 3;
        sprite.order = 7;
        sprite.flipX = true;
        sprite.blendMode = 1;

        Dim2::Camera2DComp& cam = w.AddComponent<Dim2::Camera2DComp>(e);
        cam.orthoHeight = 12.5f;
        cam.clearColor = Vec4(0.1f, 0.2f, 0.3f, 1.0f);
        cam.primary = false;

        Dim2::SpriteAnimatorComp& anim = w.AddComponent<Dim2::SpriteAnimatorComp>(e);
        anim.startFrame = 2;
        anim.frameCount = 8;
        anim.columns = 4;
        anim.rows = 2;
        anim.fps = 12.0f;
        anim.pingPong = true;

        Dim2::TilemapComp& tilemap = w.AddComponent<Dim2::TilemapComp>(e);
        tilemap.texture = "tiles";
        tilemap.Resize(3, 2);
        tilemap.atlasColumns = 8;
        tilemap.atlasRows = 8;
        tilemap.tileWorldSize = 2.0f;
        tilemap.origin = Vec2(-3.0f, -2.0f);
        tilemap.tint = Vec4(1.0f, 0.9f, 0.8f, 1.0f);
        tilemap.SetTile(0, 0, 1);
        tilemap.SetTile(1, 0, 2);
        tilemap.SetTile(2, 1, 3);

        Physics::RigidBodyComp& rb = w.AddComponent<Physics::RigidBodyComp>(e);
        rb.orientation = Quat(0.1f, 0.2f, 0.3f, 0.9f);
        rb.velocity = Vec3(1.0f, 2.0f, 3.0f);

        CHECK((SceneSerializer::Save<Transform, Dim2::SpriteComp, Dim2::Camera2DComp,
                                     Dim2::SpriteAnimatorComp, Dim2::TilemapComp,
                                     Physics::RigidBodyComp>(w, path)));
    }
    {
        World w;
        CHECK((SceneSerializer::Load<Transform, Dim2::SpriteComp, Dim2::Camera2DComp,
                                      Dim2::SpriteAnimatorComp, Dim2::TilemapComp,
                                      Physics::RigidBodyComp>(w, path)));
        Entity found = kNullEntity;
        w.ForEachEntity([&](Entity e) {
            if (w.GetName(e) == "SpriteEntity") found = e;
        });
        CHECK(found.IsValid());
        if (found.IsValid()) {
            const Dim2::SpriteComp* sprite = w.GetComponent<Dim2::SpriteComp>(found);
            CHECK(sprite != nullptr);
            if (sprite) {
                CHECK(sprite->texture == "atlas");
                CHECK_NEAR(sprite->color.w, 0.8f, 1e-5);
                CHECK_NEAR(sprite->size.x, 3.0f, 1e-5);
                CHECK_NEAR(sprite->pivot.y, 0.75f, 1e-5);
                CHECK(sprite->layer == 3);
                CHECK(sprite->order == 7);
                CHECK(sprite->flipX);
                CHECK(sprite->blendMode == 1);
            }
            const Dim2::Camera2DComp* cam = w.GetComponent<Dim2::Camera2DComp>(found);
            CHECK(cam && std::fabs(cam->orthoHeight - 12.5f) < 1e-5f);
            const Dim2::SpriteAnimatorComp* anim =
                w.GetComponent<Dim2::SpriteAnimatorComp>(found);
            CHECK(anim && anim->frameCount == 8 && anim->columns == 4 &&
                  anim->pingPong);
            const Dim2::TilemapComp* tilemap = w.GetComponent<Dim2::TilemapComp>(found);
            CHECK(tilemap != nullptr);
            if (tilemap) {
                CHECK(tilemap->columns == 3 && tilemap->rows == 2);
                CHECK(tilemap->tiles.size() == 6);
                CHECK(tilemap->GetTile(0, 0) == 1);
                CHECK(tilemap->GetTile(1, 0) == 2);
                CHECK(tilemap->GetTile(2, 1) == 3);
                CHECK(tilemap->GetTile(0, 1) == -1);
                CHECK_NEAR(tilemap->origin.x, -3.0f, 1e-5);
            }
            const Physics::RigidBodyComp* rb =
                w.GetComponent<Physics::RigidBodyComp>(found);
            CHECK(rb != nullptr);
            if (rb) {
                CHECK_NEAR(rb->orientation.x, 0.1f, 1e-6);
                CHECK_NEAR(rb->orientation.w, 0.9f, 1e-6);
                CHECK_NEAR(rb->velocity.z, 3.0f, 1e-6);
            }
        }
    }
    std::remove(path);
}

void TestTilemapComponent() {
    std::printf("[Test] tilemap data\n");
    Dim2::TilemapComp map;
    map.Resize(4, 3);
    CHECK(map.tiles.size() == 12);
    CHECK(map.GetTile(0, 0) == -1);
    map.SetTile(2, 1, 5);
    CHECK(map.GetTile(2, 1) == 5);
    CHECK(map.GetTile(-1, 0) == -1);
    CHECK(map.GetTile(4, 0) == -1);
    map.SetTile(4, 0, 9);   // 越界忽略
    CHECK(map.GetTile(3, 2) == -1);
}

} // namespace

int main() {
    std::printf("=== M7Next Engine Tests ===\n");
    TestRectMath();
    TestFrameUV();
    TestTransformSystem();
    TestCamera2D();
    TestSpriteAnimation();
    TestTilemapComponent();
    TestFrustumAndCamera();
    TestPhysicsQueries();
    TestSerialization();
    return TestSummary("Engine");
}
