/**
 * @file TestCommon.hpp
 * @brief 轻量测试宏（无第三方框架，单可执行文件一个 main）。
 */
#pragma once

#include <cmath>
#include <cstdio>

inline int g_failed = 0;
inline int g_total = 0;

#define CHECK(cond)                                                         \
    do {                                                                    \
        ++g_total;                                                          \
        if (!(cond)) {                                                      \
            ++g_failed;                                                     \
            std::printf("  FAIL L%d: %s\n", __LINE__, #cond);               \
        }                                                                   \
    } while (0)

#define CHECK_NEAR(a, b, eps)                                               \
    do {                                                                    \
        ++g_total;                                                          \
        const double _va = static_cast<double>(a);                          \
        const double _vb = static_cast<double>(b);                          \
        if (std::fabs(_va - _vb) > static_cast<double>(eps)) {              \
            ++g_failed;                                                     \
            std::printf("  FAIL L%d: %s ~= %s (%.6f vs %.6f)\n",            \
                        __LINE__, #a, #b, _va, _vb);                        \
        }                                                                   \
    } while (0)

inline int TestSummary(const char* name) {
    std::printf("\n[%s] %d checks, %d failed\n", name, g_total, g_failed);
    return g_failed == 0 ? 0 : 1;
}
