/**
 * @file NetTests.cpp
 * @brief 网络测试：字节流、模拟丢包下的可靠/分片、复制与插值、断开。
 */
#include "TestCommon.hpp"

#include "M7N/Core/Log.hpp"
#include "M7N/Net/ByteStream.hpp"
#include "M7N/Net/NetClient.hpp"
#include "M7N/Net/NetServer.hpp"
#include "M7N/Net/Replication.hpp"
#include "M7N/Net/Transport.hpp"
#include "M7N/Scene/Components.hpp"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace M7N;
using namespace M7N::Net;

namespace {

void TestAddressAndBytes() {
    std::printf("[Test] address / byte stream\n");
    const Address address = Address::Parse("192.168.1.2:9000");
    CHECK(address.host == 0xC0A80102u);
    CHECK(address.port == 9000);
    CHECK(address.ToString() == "192.168.1.2:9000");

    const Address noPort = Address::Parse("10.0.0.5");
    CHECK(noPort.host == 0x0A000005u);
    CHECK(noPort.port == 0);
    CHECK(!noPort.IsValid());

    CHECK(Address::Parse("999.1.1.1:80").host == 0);   // 非法段
    CHECK(Address::Parse("1.2.3:80").host == 0);

    std::vector<u8> bytes;
    ByteWriter writer(bytes);
    writer.U8(0x12);
    writer.U16(0x3456);
    writer.U32(0x789ABCDE);
    writer.I16(-1234);
    writer.F32(3.5f);
    const u8 payload[3] = { 1, 2, 3 };
    writer.Bytes(payload, 3);

    ByteReader reader(bytes.data(), static_cast<u32>(bytes.size()));
    CHECK(reader.U8() == 0x12);
    CHECK(reader.U16() == 0x3456);
    CHECK(reader.U32() == 0x789ABCDEu);
    CHECK(reader.I16() == -1234);
    CHECK_NEAR(reader.F32(), 3.5f, 1e-6f);
    u8 out[3] = {};
    CHECK(reader.Bytes(out, 3));
    CHECK(out[0] == 1 && out[1] == 2 && out[2] == 3);
    CHECK(reader.Ok());
    CHECK(reader.Remaining() == 0);

    // 越界读：ok 变 false，不崩溃
    reader.U32();
    CHECK(!reader.Ok());
}

/// 推演模拟网络：虚拟时间前进 -> 服务端轮询 -> 客户端轮询。
void Pump(SimulatedNetwork& hub, NetServer& server, NetClient& client,
          int iterations, f32 step = 0.02f) {
    for (int i = 0; i < iterations; ++i) {
        hub.Advance(step);
        server.Poll();
        client.Poll();
    }
}

void TestReliability() {
    std::printf("[Test] reliable stream under packet loss\n");
    SimulatedNetwork hub(0x1234);
    hub.SetLatency(15, 35);
    hub.SetJitter(8);
    hub.SetPacketLoss(0.25f);
    hub.SetDuplicate(0.03f);

    NetServer server;
    NetConfig config;
    config.port = 7777;
    config.maxClients = 4;
    config.timeoutSeconds = 6.0f;
    CHECK(server.Start(config, hub.CreateTransport()));

    NetClient client;
    std::vector<int> serverValues;
    std::vector<u8> bigMessage;
    int unreliableLast = -1;
    int unreliableCount = 0;
    bool unreliableOrdered = true;
    bool serverSawConnect = false;

    server.SetCallbacks(
        [&](ClientId) { serverSawConnect = true; },
        [&](ClientId, DisconnectReason) {},
        [&](ClientId, Channel channel, const u8* data, u32 size) {
            if (channel == Channel::Unreliable) {
                if (size >= 4) {
                    u32 value = 0;
                    std::memcpy(&value, data, 4);
                    const int intValue = static_cast<int>(value);
                    if (intValue <= unreliableLast) unreliableOrdered = false;
                    unreliableLast = intValue;
                    unreliableCount++;
                }
                return;
            }
            if (size >= 4000) {
                bigMessage.assign(data, data + size);
                return;
            }
            if (size >= 4) {
                u32 value = 0;
                std::memcpy(&value, data, 4);
                serverValues.push_back(static_cast<int>(value));
            }
        });

    std::vector<u32> clientValues;
    bool clientConnected = false;
    bool clientDisconnected = false;
    DisconnectReason clientReason = DisconnectReason::None;
    client.SetCallbacks(
        [&]() { clientConnected = true; },
        [&](DisconnectReason reason) {
            clientDisconnected = true;
            clientReason = reason;
        },
        [&](Channel, const u8* data, u32 size) {
            if (size >= 4) {
                u32 value = 0;
                std::memcpy(&value, data, 4);
                clientValues.push_back(value);
            }
        });

    NetConfig clientConfig;
    clientConfig.port = 0;
    CHECK(client.ConnectWithTransport(Address::Parse("127.0.0.1:7777"),
                                      clientConfig, hub.CreateTransport()));

    Pump(hub, server, client, 80);
    CHECK(clientConnected);
    CHECK(client.IsConnected());
    CHECK(serverSawConnect);
    CHECK(server.ClientCount() == 1);
    CHECK(client.GetClientId() != kInvalidClient);

    // 可靠有序：40 条小消息 + 1 条 5KB 分片消息
    for (u32 i = 0; i < 40; ++i) {
        client.Send(Channel::Reliable, &i, sizeof(i));
    }
    std::vector<u8> big(5000);
    for (size_t i = 0; i < big.size(); ++i) big[i] = static_cast<u8>((i * 37) & 0xFF);
    CHECK(client.Send(Channel::Reliable, big.data(), static_cast<u32>(big.size())));

    for (int i = 0; i < 600 && (serverValues.size() < 40 || bigMessage.empty()); ++i) {
        hub.Advance(0.02);
        server.Poll();
        client.Poll();
        if (i % 20 == 0) {
            // 定期注入不可靠消息；最新优先，接收端应保持递增
            const u32 v = static_cast<u32>(i);
            client.Send(Channel::Unreliable, &v, sizeof(v));
        }
    }

    CHECK(serverValues.size() == 40);
    bool ordered = true;
    for (size_t i = 0; i < serverValues.size(); ++i) {
        if (serverValues[i] != static_cast<int>(i)) ordered = false;
    }
    CHECK(ordered);
    CHECK(bigMessage.size() == big.size());
    if (bigMessage.size() == big.size()) {
        CHECK(std::memcmp(bigMessage.data(), big.data(), big.size()) == 0);
    }

    Pump(hub, server, client, 30);
    CHECK(unreliableCount > 0);
    CHECK(unreliableOrdered);

    // 服务端 -> 客户端可靠广播
    const u32 reply = 0xDEADBEEFu;
    server.Broadcast(Channel::Reliable, &reply, sizeof(reply));
    Pump(hub, server, client, 120);
    CHECK(!clientValues.empty());
    if (!clientValues.empty()) CHECK(clientValues.back() == reply);

    const NetStats stats = client.GetStats();
    CHECK(stats.packetsSent > 0);
    CHECK(stats.packetsReceived > 0);
    CHECK(stats.rttMs > 0.0f);
    CHECK(stats.retransmits > 0 || stats.packetLoss >= 0.0f);

    // 服务端主动断开
    const ClientId id = client.GetClientId();
    server.DisconnectClient(id, DisconnectReason::ServerShutdown);
    Pump(hub, server, client, 60);
    CHECK(clientDisconnected);
    CHECK(clientReason == DisconnectReason::ServerShutdown);
    CHECK(!client.IsConnected());
    CHECK(server.ClientCount() == 0);
}

void TestReplication() {
    std::printf("[Test] ECS replication + interpolation\n");
    SimulatedNetwork hub(0xBEEF);
    hub.SetLatency(10, 25);
    hub.SetPacketLoss(0.1f);

    NetServer server;
    NetConfig config;
    config.port = 7788;
    config.maxClients = 2;
    CHECK(server.Start(config, hub.CreateTransport()));

    ECS::World serverWorld;
    ECS::Entity serverEntity = serverWorld.CreateEntity("ReplicatedCube");
    Scene::Transform& transform = serverWorld.AddComponent<Scene::Transform>(serverEntity);
    transform.position = Vec3(0.0f, 1.0f, 0.0f);
    NetworkIdentity identity;
    serverWorld.AddComponent<NetworkIdentity>(serverEntity, identity);

    ReplicationServer replication(server);
    replication.SetTickRate(30);

    NetClient client;
    ECS::World clientWorld;
    ReplicationClient replicationClient(clientWorld);
    ReplicationClientConfig replicationConfig;
    replicationConfig.interpolationSeconds = 0.05f;
    replicationClient.Configure(replicationConfig);

    int spawnCount = 0;
    int destroyCount = 0;
    ECS::Entity spawnedEntity = ECS::kNullEntity;
    replicationClient.SetSpawnCallback([&](ECS::Entity e, u32) {
        spawnCount++;
        spawnedEntity = e;
    });
    replicationClient.SetDestroyCallback([&](ECS::Entity, u32) { destroyCount++; });

    bool connected = false;
    client.SetCallbacks(
        [&]() { connected = true; },
        [&](DisconnectReason) {},
        [&](Channel channel, const u8* data, u32 size) {
            replicationClient.OnPacket(channel, data, size);
        });

    NetConfig clientConfig;
    clientConfig.port = 0;
    CHECK(client.ConnectWithTransport(Address::Parse("127.0.0.1:7788"),
                                      clientConfig, hub.CreateTransport()));

    // 连接 + 初始生成
    for (int i = 0; i < 100; ++i) {
        hub.Advance(0.02f);
        server.Poll();
        client.Poll();
        replication.OnUpdate(serverWorld, 0.02f);
        replicationClient.OnUpdate(0.02f);
        if (connected && replicationClient.EntityCount() > 0) break;
    }
    CHECK(connected);
    CHECK(replication.TrackedEntityCount() == 1);
    CHECK(replicationClient.EntityCount() == 1);
    CHECK(spawnCount == 1);
    CHECK(spawnedEntity.IsValid());

    // 移动服务器实体；客户端应持续收到快照
    for (int i = 0; i < 120; ++i) {
        Scene::Transform* t = serverWorld.GetComponent<Scene::Transform>(serverEntity);
        if (t) t->position.x += 0.08f;
        hub.Advance(0.02f);
        server.Poll();
        client.Poll();
        replication.OnUpdate(serverWorld, 0.02f);
        replicationClient.OnUpdate(0.02f);
    }
    const ECS::Entity clientEntity = replicationClient.GetEntity(1);
    CHECK(clientEntity.IsValid());
    const Scene::Transform* clientTransform =
        clientWorld.GetComponent<Scene::Transform>(clientEntity);
    CHECK(clientTransform != nullptr);
    if (clientTransform) {
        CHECK(clientTransform->position.x > 1.0f);
    }

    // 停止移动并等待插值收敛到固定目标
    Scene::Transform* serverTransform =
        serverWorld.GetComponent<Scene::Transform>(serverEntity);
    if (serverTransform) serverTransform->position = Vec3(10.0f, 2.0f, 0.0f);
    for (int i = 0; i < 120; ++i) {
        hub.Advance(0.02f);
        server.Poll();
        client.Poll();
        replication.OnUpdate(serverWorld, 0.02f);
        replicationClient.OnUpdate(0.02f);
    }
    clientTransform = clientWorld.GetComponent<Scene::Transform>(clientEntity);
    CHECK(clientTransform != nullptr);
    if (clientTransform) {
        CHECK_NEAR(clientTransform->position.x, 10.0f, 0.2f);
        CHECK_NEAR(clientTransform->position.y, 2.0f, 0.2f);
    }

    // 服务端销毁 -> 客户端同步销毁
    serverWorld.DestroyEntity(serverEntity);
    bool removed = false;
    for (int i = 0; i < 120; ++i) {
        hub.Advance(0.02f);
        server.Poll();
        client.Poll();
        replication.OnUpdate(serverWorld, 0.02f);
        replicationClient.OnUpdate(0.02f);
        if (replicationClient.EntityCount() == 0) { removed = true; break; }
    }
    CHECK(removed);
    CHECK(destroyCount >= 1);
    CHECK(!clientWorld.IsAlive(clientEntity));
    CHECK(replication.TrackedEntityCount() == 0);

    // 墓碑：迟到的快照不得复活已销毁实体
    std::vector<u8> stale;
    {
        ByteWriter writer(stale);
        writer.U8(kMsgSnapshot);
        writer.U32(replicationClient.GetLastTick() + 1);
        writer.U16(0);
        writer.U16(1);
        writer.U16(1);
        writer.U32(1);       // netId 1（已销毁）
        writer.I16(0); writer.I16(0); writer.I16(0);
        writer.I16(0); writer.I16(0); writer.I16(0);
    }
    replicationClient.OnPacket(Channel::Unreliable, stale.data(),
                               static_cast<u32>(stale.size()));
    replicationClient.OnUpdate(0.02f);
    CHECK(replicationClient.EntityCount() == 0);
    CHECK(!clientWorld.IsAlive(clientEntity));
}

void TestServerFull() {
    std::printf("[Test] server full reject\n");
    SimulatedNetwork hub(7);
    hub.SetLatency(5, 10);
    NetServer server;
    NetConfig config;
    config.port = 7799;
    config.maxClients = 1;
    CHECK(server.Start(config, hub.CreateTransport()));

    NetClient first;
    NetClient second;
    bool firstDisconnected = false;
    bool secondDisconnected = false;
    DisconnectReason secondReason = DisconnectReason::None;

    first.SetCallbacks([&]() {}, [&](DisconnectReason) { firstDisconnected = true; },
                       [](Channel, const u8*, u32) {});
    second.SetCallbacks([&]() {}, [&](DisconnectReason r) {
        secondDisconnected = true;
        secondReason = r;
    }, [](Channel, const u8*, u32) {});

    NetConfig cfg;
    CHECK(first.ConnectWithTransport(Address::Parse("127.0.0.1:7799"), cfg,
                                     hub.CreateTransport()));
    Pump(hub, server, first, 30);
    CHECK(first.IsConnected());
    CHECK(server.ClientCount() == 1);

    CHECK(second.ConnectWithTransport(Address::Parse("127.0.0.1:7799"), cfg,
                                      hub.CreateTransport()));
    Pump(hub, server, second, 60);
    CHECK(secondDisconnected);
    CHECK(secondReason == DisconnectReason::ServerFull);
    CHECK(!second.IsConnected());
    CHECK(first.IsConnected());
    (void)firstDisconnected;
}

} // namespace

int main() {
    std::printf("=== M7Next Net Tests ===\n");
    Log::SetLevel(LogLevel::Warn);   // 测试输出保持干净
    TestAddressAndBytes();
    TestReliability();
    TestReplication();
    TestServerFull();
    return TestSummary("Net");
}
