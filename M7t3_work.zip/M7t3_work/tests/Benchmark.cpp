/**
 * @file Benchmark.cpp
 * @brief M7N 数据层 vs M7T1 式基线的性能基准。
 *
 * 基线完全复刻 M7T1 的存储方式：
 *   std::vector<std::unique_ptr<Entity>>
 *   + 每实体 unordered_map<type_index, std::any> 组件表
 *   + GetComponent 走哈希查找 + any_cast
 *
 * 三项基准（Release 与 Debug 各有意义，输出注明当前配置）：
 *   B1 双组件系统遍历（Transform + Velocity 积分，典型移动系统）
 *   B2 随机实体组件访问（1M 次 GetComponent）
 *   B3 实体创建 + 组件挂载（100k 实体）
 */
#include "M7N/ECS/World.hpp"

#include <any>
#include <chrono>
#include <cstdio>
#include <memory>
#include <random>
#include <typeindex>
#include <unordered_map>
#include <vector>

using namespace M7N;
using namespace M7N::ECS;

// =====================================================================
// 基准共用的组件
// =====================================================================

struct BmTransform {
    Vec3 position{ 0.0f };
    Vec3 scale{ 1.0f };
};
struct BmVelocity {
    Vec3 v{ 1.0f, 0.5f, 0.25f };
};

// =====================================================================
// M7T1 式基线实体（存储结构 1:1 复刻）
// =====================================================================

struct LegacyEntity {
    std::unordered_map<std::type_index, std::any> components;

    template <typename T>
    void Add() { components[std::type_index(typeid(T))] = T{}; }

    template <typename T>
    T* Get() {
        auto it = components.find(std::type_index(typeid(T)));
        return it == components.end() ? nullptr
                                      : std::any_cast<T>(&it->second);
    }
};

// =====================================================================
// 计时工具
// =====================================================================

template <typename Fn>
static double MsOf(Fn&& fn) {
    auto t0 = std::chrono::steady_clock::now();
    fn();
    auto t1 = std::chrono::steady_clock::now();
    return std::chrono::duration<double, std::milli>(t1 - t0).count();
}

static void PrintRow(const char* name, double legacyMs, double m7nMs) {
    double ratio = legacyMs / m7nMs;
    std::printf("  %-28s 基线 %10.3f ms | M7N %10.3f ms | M7N 快 %6.2fx\n",
                name, legacyMs, m7nMs, ratio);
}

// =====================================================================
// B1：双组件系统遍历（移动积分）
// =====================================================================

static void BenchSystemIteration(u32 entityCount, u32 frames) {
    std::printf("[B1] 双组件移动系统（%u 实体 × %u 帧）\n", entityCount, frames);

    // --- 基线构建 ---
    std::vector<std::unique_ptr<LegacyEntity>> legacy(entityCount);
    for (auto& e : legacy) {
        e = std::make_unique<LegacyEntity>();
        e->Add<BmTransform>();
        e->Add<BmVelocity>();
    }

    // --- M7N 构建 ---
    World world;
    world.Reserve(entityCount);
    world.GetStorage<BmTransform>().Reserve(entityCount);
    for (u32 i = 0; i < entityCount; i++) {
        Entity e = world.CreateEntity();
        world.AddComponent<BmTransform>(e);
        world.AddComponent<BmVelocity>(e);
    }

    const f32 dt = 1.0f / 60.0f;

    // 基线：哈希查找 ×2 + any_cast ×2，每实体一次
    double legacyMs = MsOf([&] {
        for (u32 f = 0; f < frames; f++) {
            for (auto& e : legacy) {
                BmTransform* t = e->Get<BmTransform>();
                BmVelocity* v = e->Get<BmVelocity>();
                if (t && v) t->position += v->v * dt;
            }
        }
    });

    // M7N：dense 数组线性扫描，零哈希
    double m7nMs = MsOf([&] {
        for (u32 f = 0; f < frames; f++) {
            world.ForEach<BmTransform, BmVelocity>(
                [&](Entity, BmTransform& t, const BmVelocity& v) {
                    t.position += v.v * dt;
                });
        }
    });

    PrintRow("系统遍历", legacyMs, m7nMs);
}

// =====================================================================
// B2：随机实体 GetComponent 访问
// =====================================================================

static void BenchRandomAccess(u32 entityCount, u32 accessCount) {
    std::printf("[B2] 随机组件访问（%u 实体，%u 次查询）\n", entityCount, accessCount);

    // 预生成随机索引（两边共用同一序列）
    std::mt19937 rng(42);
    std::vector<u32> order(accessCount);
    for (u32 i = 0; i < accessCount; i++) {
        order[i] = rng() % entityCount;
    }

    // --- 基线 ---
    std::vector<std::unique_ptr<LegacyEntity>> legacy(entityCount);
    for (auto& e : legacy) {
        e = std::make_unique<LegacyEntity>();
        e->Add<BmTransform>();
    }
    volatile f32 sinkLegacy = 0;
    double legacyMs = MsOf([&] {
        f32 acc = 0;
        for (u32 idx : order) {
            BmTransform* t = legacy[idx]->Get<BmTransform>();
            if (t) acc += t->position.x;
        }
        sinkLegacy = acc;
    });

    // --- M7N ---
    World world;
    world.Reserve(entityCount);
    std::vector<Entity> handles(entityCount);
    for (u32 i = 0; i < entityCount; i++) {
        handles[i] = world.CreateEntity();
        world.AddComponent<BmTransform>(handles[i]);
    }
    volatile f32 sinkM7N = 0;
    double m7nMs = MsOf([&] {
        f32 acc = 0;
        for (u32 idx : order) {
            BmTransform* t = world.GetComponent<BmTransform>(handles[idx]);
            if (t) acc += t->position.x;
        }
        sinkM7N = acc;
    });

    PrintRow("随机访问", legacyMs, m7nMs);
}

// =====================================================================
// B3：实体创建 + 组件挂载
// =====================================================================

static void BenchCreation(u32 entityCount) {
    std::printf("[B3] 实体创建 + 双组件挂载（%u 实体）\n", entityCount);

    double legacyMs = MsOf([&] {
        std::vector<std::unique_ptr<LegacyEntity>> legacy;
        legacy.reserve(entityCount);
        for (u32 i = 0; i < entityCount; i++) {
            auto e = std::make_unique<LegacyEntity>();
            e->Add<BmTransform>();
            e->Add<BmVelocity>();
            legacy.push_back(std::move(e));
        }
    });

    double m7nMs = MsOf([&] {
        World world;
        world.Reserve(entityCount);
        world.GetStorage<BmTransform>().Reserve(entityCount);
        for (u32 i = 0; i < entityCount; i++) {
            Entity e = world.CreateEntity();
            world.AddComponent<BmTransform>(e);
            world.AddComponent<BmVelocity>(e);
        }
    });

    PrintRow("创建+挂载", legacyMs, m7nMs);
}

int main() {
#ifdef NDEBUG
    std::printf("=== M7Next Benchmark（Release 构建）===\n\n");
#else
    std::printf("=== M7Next Benchmark（Debug 构建，绝对值偏保守）===\n\n");
#endif

    BenchSystemIteration(100'000, 300);
    std::printf("\n");
    BenchRandomAccess(100'000, 1'000'000);
    std::printf("\n");
    BenchCreation(100'000);

    std::printf("\n基线 = M7T1 存储（unique_ptr + unordered_map<type_index, any>）\n");
    std::printf("M7N  = SparseSet dense 数组 + generation 句柄\n");
    return 0;
}
