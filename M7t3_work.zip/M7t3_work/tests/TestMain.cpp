/**
 * @file TestMain.cpp
 * @brief M7N 数据层单元测试。
 *
 * 覆盖：句柄代数、SparseSet 存取/swap-remove、多组件遍历、
 *       层级防环与级联销毁、序列化往返、世界矩阵传播、多 World 数据隔离。
 *
 * 注意：SparseSet 的组件引用在后续 AddComponent 触发扩容后会失效
 * （与 EnTT 语义一致）；同一实体重复 AddComponent 会重置组件。
 */
#include "M7N/ECS/World.hpp"
#include "M7N/Scene/Components.hpp"
#include "M7N/Scene/SceneSerializer.hpp"

#include <cstdio>
#include <cstring>

using namespace M7N;
using namespace M7N::ECS;
using namespace M7N::Scene;

static int g_failed = 0;
static int g_total  = 0;

#define CHECK(cond)                                                     \
    do {                                                                \
        ++g_total;                                                      \
        if (!(cond)) {                                                  \
            ++g_failed;                                                 \
            std::printf("  FAIL L%d: %s\n", __LINE__, #cond);           \
        }                                                               \
    } while (0)

/// mat4 平移分量快捷提取（精简 glm 无 vec3(vec4) 构造）。
static Vec3 TranslationOf(const Mat4& m) {
    Vec4 t = m * Vec4(0.0f, 0.0f, 0.0f, 1.0f);
    return Vec3(t.x, t.y, t.z);
}

// =====================================================================
// 1. 实体句柄：创建 / 销毁 / 代数失效 / 槽位复用
// =====================================================================
static void TestEntityLifecycle() {
    std::printf("[Test] Entity lifecycle\n");
    World w;

    Entity a = w.CreateEntity("A");
    Entity b = w.CreateEntity("B");
    CHECK(a.IsValid() && b.IsValid());
    CHECK(w.AliveCount() == 2);
    CHECK(a != b);

    // 销毁 a 后旧句柄失效
    w.DestroyEntity(a);
    CHECK(!w.IsAlive(a));
    CHECK(w.IsAlive(b));
    CHECK(w.AliveCount() == 1);

    // 新实体复用槽位，generation 不同 -> 旧句柄依然失效
    Entity c = w.CreateEntity("C");
    CHECK(c.index == a.index);
    CHECK(c.generation == a.generation + 1);
    CHECK(!w.IsAlive(a));   // 旧句柄不能借尸还魂
    CHECK(w.IsAlive(c));
    CHECK(w.GetName(c) == "C");
}

// =====================================================================
// 2. SparseSet：存取 / 悬空拒绝 / swap-remove 一致性
// =====================================================================
static void TestComponentStorage() {
    std::printf("[Test] Component storage\n");
    World w;

    Entity a = w.CreateEntity("A");
    Entity b = w.CreateEntity("B");
    Entity c = w.CreateEntity("C");

    w.AddComponent<Transform>(a).position = Vec3(1.0f, 2.0f, 3.0f);
    w.AddComponent<Transform>(b).position = Vec3(9.0f, 9.0f, 9.0f);
    w.AddComponent<Transform>(c).position = Vec3(7.0f, 7.0f, 7.0f);

    CHECK(w.HasComponent<Transform>(a));
    CHECK(w.GetComponent<Transform>(a)->position.y == 2.0f);

    // 中间删除触发 swap-remove：c 的数据补到 b 的槽
    CHECK(w.RemoveComponent<Transform>(b));
    CHECK(!w.HasComponent<Transform>(b));
    CHECK(w.HasComponent<Transform>(a));
    CHECK(w.HasComponent<Transform>(c));
    CHECK(w.GetComponent<Transform>(c)->position.x == 7.0f);   // 数据未损

    // 死句柄组件访问被拒
    w.DestroyEntity(a);
    CHECK(w.GetComponent<Transform>(a) == nullptr);
    CHECK(!w.HasComponent<Transform>(a));

    // 存储自动清理
    auto& storage = w.GetStorage<Transform>();
    CHECK(storage.Size() == 1);   // 只剩 c

    // 重复 Emplace 覆盖（重置语义）
    Entity d = w.CreateEntity("D");
    w.AddComponent<MeshRef>(d).path = "old.glb";
    w.AddComponent<MeshRef>(d).path = "new.glb";
    CHECK(w.GetStorage<MeshRef>().Size() == 1);
    CHECK(w.GetComponent<MeshRef>(d)->path == "new.glb");
}

// =====================================================================
// 3. 多组件遍历：交集过滤 + 遍历中删除
// =====================================================================
static void TestForEach() {
    std::printf("[Test] ForEach multi-component\n");
    World w;

    // 3 个有 Transform，其中 2 个同时有 MeshRef，1 个有 Camera
    Entity e1 = w.CreateEntity("e1");
    Entity e2 = w.CreateEntity("e2");
    Entity e3 = w.CreateEntity("e3");
    w.AddComponent<Transform>(e1);
    w.AddComponent<Transform>(e2);
    w.AddComponent<Transform>(e3);
    w.AddComponent<MeshRef>(e1);
    w.AddComponent<MeshRef>(e2);
    w.AddComponent<CameraComp>(e3);

    int transformCount = 0, bothCount = 0, tcCount = 0;
    w.ForEach<Transform>([&](Entity, Transform&) { transformCount++; });
    w.ForEach<Transform, MeshRef>([&](Entity, Transform&, MeshRef&) { bothCount++; });
    w.ForEach<Transform, CameraComp>([&](Entity, Transform&, CameraComp&) { tcCount++; });

    CHECK(transformCount == 3);
    CHECK(bothCount == 2);
    CHECK(tcCount == 1);

    // 遍历中删除：倒序扫描保证不越界
    w.ForEach<Transform, MeshRef>([&](Entity e, Transform&, MeshRef&) {
        w.RemoveComponent<MeshRef>(e);
    });
    int after = 0;
    w.ForEach<Transform, MeshRef>([&](Entity, Transform&, MeshRef&) { after++; });
    CHECK(after == 0);
    CHECK(w.HasComponent<Transform>(e1));   // Transform 未被误删
}

// =====================================================================
// 4. 层级：挂父子 / 防环 / 级联销毁 / 换父
// =====================================================================
static void TestHierarchy() {
    std::printf("[Test] Hierarchy\n");
    World w;

    Entity root  = w.CreateEntity("root");
    Entity child = w.CreateEntity("child");
    Entity grand = w.CreateEntity("grand");

    CHECK(w.SetParent(child, root));
    CHECK(w.SetParent(grand, child));
    CHECK(w.GetParent(child) == root);
    CHECK(w.GetParent(grand) == child);
    CHECK(w.GetChildren(root).size() == 1);
    CHECK(w.IsAncestorOf(root, grand));

    // 环：grand 是 root 的祖先链成员，root 挂到 grand 必须被拒
    CHECK(!w.SetParent(root, grand));
    CHECK(!w.SetParent(root, root));   // 自引用
    CHECK(w.GetParent(root) == kNullEntity);   // 原层级未破坏

    // 换父：child 从 root 摘到独立根
    CHECK(w.SetParent(child, kNullEntity));
    CHECK(w.GetChildren(root).empty());

    // 重新挂回，测试级联销毁
    w.SetParent(child, root);
    w.DestroyEntity(root);
    CHECK(!w.IsAlive(child));    // 子树整体销毁
    CHECK(!w.IsAlive(grand));
    CHECK(w.AliveCount() == 0);
}

// =====================================================================
// 5. 序列化往返：保存 -> 清空 -> 加载 -> 逐项比对
// =====================================================================
static void TestSerializationRoundTrip() {
    std::printf("[Test] Serialization round-trip\n");
    const char* kPath = "m7n_test_scene.json";

    {
        World w;
        Entity root = w.CreateEntity("Root");
        Entity ball = w.CreateEntity("Ball");
        Entity cam  = w.CreateEntity("MainCam");

        w.SetParent(ball, root);
        w.SetParent(cam, root);

        // 每组件只 Add 一次，引用失效前完成全部赋值
        {
            Transform& t = w.AddComponent<Transform>(root);
            t.position = Vec3(0.0f, 10.0f, 0.0f);
            t.scale = Vec3(2.0f, 2.0f, 2.0f);
        }
        {
            Transform& t = w.AddComponent<Transform>(ball);
            t.position = Vec3(1.0f, 0.0f, 0.0f);
            t.rotation = Vec3(0.0f, 1.5707963f, 0.0f);
        }
        w.AddComponent<MeshRef>(ball).path = "models/ball.glb";
        {
            CameraComp& c = w.AddComponent<CameraComp>(cam);
            c.fovYDeg = 60.0f;
            c.farZ = 500.0f;
            c.primary = true;
        }

        bool ok = SceneSerializer::Save<Transform, MeshRef, CameraComp>(w, kPath);
        CHECK(ok);
    }

    {
        World w2;
        bool ok = SceneSerializer::Load<Transform, MeshRef, CameraComp>(w2, kPath);
        CHECK(ok);
        CHECK(w2.AliveCount() == 3);

        Entity root, ball, cam;
        bool hasRoot = false, hasBall = false, hasCam = false;
        w2.ForEachEntity([&](Entity e) {
            const String& n = w2.GetName(e);
            if (n == "Root") { root = e; hasRoot = true; }
            else if (n == "Ball") { ball = e; hasBall = true; }
            else if (n == "MainCam") { cam = e; hasCam = true; }
        });
        CHECK(hasRoot && hasBall && hasCam);

        // 层级恢复
        CHECK(w2.GetParent(ball) == root);
        CHECK(w2.GetParent(cam) == root);
        CHECK(w2.GetChildren(root).size() == 2);

        // 数值恢复
        Transform* tRoot = w2.GetComponent<Transform>(root);
        Transform* tBall = w2.GetComponent<Transform>(ball);
        CHECK(tRoot && tRoot->position.y == 10.0f);
        CHECK(tRoot && tRoot->scale.x == 2.0f);
        CHECK(tBall && tBall->position.x == 1.0f);
        CHECK(tBall && std::abs(tBall->rotation.y - 1.5707963f) < 1e-5f);

        MeshRef* mesh = w2.GetComponent<MeshRef>(ball);
        CHECK(mesh && mesh->path == "models/ball.glb");

        CameraComp* cc = w2.GetComponent<CameraComp>(cam);
        CHECK(cc && cc->fovYDeg == 60.0f);
        CHECK(cc && cc->farZ == 500.0f);
        CHECK(cc && cc->primary == true);

        // 未序列化的组件不应存在
        CHECK(!w2.HasComponent<MeshRef>(root));
    }

    std::remove(kPath);
}

// =====================================================================
// 6. 世界矩阵：父级 TRS 传播到子级
// =====================================================================
static void TestWorldMatrix() {
    std::printf("[Test] World matrix propagation\n");
    World w;

    Entity parent = w.CreateEntity("parent");
    Entity child  = w.CreateEntity("child");
    w.SetParent(child, parent);

    // 全部 Add 完成后再取引用（避免扩容失效）
    w.AddComponent<Transform>(parent);
    w.AddComponent<Transform>(child);
    Transform& tp = *w.GetComponent<Transform>(parent);
    Transform& tc = *w.GetComponent<Transform>(child);
    tp.position = Vec3(0.0f, 10.0f, 0.0f);
    tc.position = Vec3(1.0f, 0.0f, 0.0f);

    Vec3 worldPos = TranslationOf(ComputeWorldMatrix(w, child));
    CHECK(std::abs(worldPos.x - 1.0f) < 1e-5f);
    CHECK(std::abs(worldPos.y - 10.0f) < 1e-5f);
    CHECK(std::abs(worldPos.z - 0.0f) < 1e-5f);

    // 父级缩放传播
    tp.scale = Vec3(2.0f);
    worldPos = TranslationOf(ComputeWorldMatrix(w, child));
    CHECK(std::abs(worldPos.x - 2.0f) < 1e-5f);
    CHECK(std::abs(worldPos.y - 10.0f) < 1e-5f);

    // 三级链路：parent(T(0,10,0) S2) * child(T(1,0,0)) * leaf(T(0,1,0))
    // 原点 = (2*(1+0), 10+2*(0+1), 0) = (2, 12, 0)
    Entity leaf = w.CreateEntity("leaf");
    w.SetParent(leaf, child);
    w.AddComponent<Transform>(leaf).position = Vec3(0.0f, 1.0f, 0.0f);
    Vec3 leafPos = TranslationOf(ComputeWorldMatrix(w, leaf));
    CHECK(std::abs(leafPos.x - 2.0f) < 1e-4f);
    CHECK(std::abs(leafPos.y - 12.0f) < 1e-4f);
}

// =====================================================================
// 7. 多 World 数据隔离（M7T1 static 单例做不到的事）
// =====================================================================
static void TestMultipleWorlds() {
    std::printf("[Test] Multiple isolated worlds\n");
    World editor, runtime;

    Entity ea = editor.CreateEntity("EditorOnly");
    editor.AddComponent<Transform>(ea);

    Entity ra = runtime.CreateEntity("PlayOnly");

    CHECK(editor.AliveCount() == 1);
    CHECK(runtime.AliveCount() == 1);

    // 句柄不含 World 归属字段（与 EnTT 语义一致），隔离体现在
    // 各 World 的组件存储完全独立：
    CHECK(editor.GetComponent<Transform>(ea) != nullptr);
    CHECK(runtime.GetComponent<Transform>(ra) == nullptr);
    CHECK(editor.GetStorage<Transform>().Size() == 1);
}

int main() {
    std::printf("=== M7Next M7N-1 Unit Tests ===\n");
    TestEntityLifecycle();
    TestComponentStorage();
    TestForEach();
    TestHierarchy();
    TestSerializationRoundTrip();
    TestWorldMatrix();
    TestMultipleWorlds();

    std::printf("\n%d checks, %d failed\n", g_total, g_failed);
    return g_failed == 0 ? 0 : 1;
}
