/**
 * glm.hpp - Minimal GLM-compatible math library
 *
 * Provides essential vector, matrix, and quaternion types with the
 * operations needed by the Mutant7 engine. Designed as a drop-in
 * replacement for GLM when GLM is not available.
 */
#pragma once

#include <cmath>
#include <cstring>
#include <algorithm>

namespace glm {

// --- Constants ---
constexpr float PI = 3.14159265358979323846f;
constexpr float EPSILON = 1e-6f;
constexpr float RADIANS_PER_DEGREE = PI / 180.0f;
constexpr float DEGREES_PER_RADIAN = 180.0f / PI;

// --- Forward declarations ---
struct vec2;
struct vec3;
struct vec4;
struct mat4;
struct quat;

// --- Utility Functions ---
inline float radians(float degrees) { return degrees * RADIANS_PER_DEGREE; }
inline float degrees(float radians) { return radians * DEGREES_PER_RADIAN; }
inline float clamp(float v, float lo, float hi) { return std::max(lo, std::min(hi, v)); }
inline float mix(float a, float b, float t) { return a + (b - a) * t; }
inline float max(float a, float b) { return std::max(a, b); }
inline float min(float a, float b) { return std::min(a, b); }
inline float abs(float v) { return std::fabs(v); }
inline float sqrt(float v) { return std::sqrt(v); }
inline float pow(float b, float e) { return std::pow(b, e); }

// --- vec2 ---
struct vec2 {
    float x, y;
    vec2() : x(0), y(0) {}
    vec2(float v) : x(v), y(v) {}
    vec2(float x, float y) : x(x), y(y) {}
    float& operator[](int i) { return (&x)[i]; }
    const float& operator[](int i) const { return (&x)[i]; }
    vec2 operator+(const vec2& o) const { return {x+o.x, y+o.y}; }
    vec2 operator-(const vec2& o) const { return {x-o.x, y-o.y}; }
    vec2 operator*(float s) const { return {x*s, y*s}; }
    vec2 operator*(const vec2& o) const { return {x*o.x, y*o.y}; }
    vec2 operator/(float s) const { return {x/s, y/s}; }
    vec2& operator+=(const vec2& o) { x+=o.x; y+=o.y; return *this; }
    vec2& operator-=(const vec2& o) { x-=o.x; y-=o.y; return *this; }
};

inline float dot(const vec2& a, const vec2& b) { return a.x*b.x + a.y*b.y; }
inline float length(const vec2& v) { return std::sqrt(dot(v, v)); }
inline vec2 normalize(const vec2& v) { float l = length(v); return l > 0 ? v / l : v; }

// --- vec3 ---
struct vec3 {
    float x, y, z;
    vec3() : x(0), y(0), z(0) {}
    vec3(float v) : x(v), y(v), z(v) {}
    vec3(float x, float y, float z) : x(x), y(y), z(z) {}
    float& operator[](int i) { return (&x)[i]; }
    const float& operator[](int i) const { return (&x)[i]; }
    vec3 operator+(const vec3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    vec3 operator-(const vec3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    vec3 operator-() const { return {-x, -y, -z}; }
    vec3 operator*(float s) const { return {x*s, y*s, z*s}; }
    vec3 operator*(const vec3& o) const { return {x*o.x, y*o.y, z*o.z}; }
    vec3 operator/(float s) const { return {x/s, y/s, z/s}; }
    vec3& operator+=(const vec3& o) { x+=o.x; y+=o.y; z+=o.z; return *this; }
    vec3& operator-=(const vec3& o) { x-=o.x; y-=o.y; z-=o.z; return *this; }
    vec3& operator*=(float s) { x*=s; y*=s; z*=s; return *this; }
};

inline float dot(const vec3& a, const vec3& b) { return a.x*b.x + a.y*b.y + a.z*b.z; }
inline vec3 cross(const vec3& a, const vec3& b) {
    return {a.y*b.z - a.z*b.y, a.z*b.x - a.x*b.z, a.x*b.y - a.y*b.x};
}
inline float length(const vec3& v) { return std::sqrt(dot(v, v)); }
inline vec3 normalize(const vec3& v) { float l = length(v); return l > 0 ? v / l : v; }
inline vec3 mix(const vec3& a, const vec3& b, float t) { return a + (b - a) * t; }
inline vec3 abs(const vec3& v) { return {std::fabs(v.x), std::fabs(v.y), std::fabs(v.z)}; }

// --- vec4 ---
struct vec4 {
    float x, y, z, w;
    vec4() : x(0), y(0), z(0), w(0) {}
    vec4(float v) : x(v), y(v), z(v), w(v) {}
    vec4(float x, float y, float z, float w) : x(x), y(y), z(z), w(w) {}
    vec4(const vec3& v, float w) : x(v.x), y(v.y), z(v.z), w(w) {}
    float& operator[](int i) { return (&x)[i]; }
    const float& operator[](int i) const { return (&x)[i]; }
    vec4 operator+(const vec4& o) const { return {x+o.x, y+o.y, z+o.z, w+o.w}; }
    vec4 operator-(const vec4& o) const { return {x-o.x, y-o.y, z-o.z, w-o.w}; }
    vec4 operator*(float s) const { return {x*s, y*s, z*s, w*s}; }
};

inline float dot(const vec4& a, const vec4& b) { return a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w; }

// --- mat3 (column-major, like GLSL) ---
struct mat3 {
    float m[9]; // column-major: m[col*3 + row]

    mat3() { std::memset(m, 0, sizeof(m)); }

    static mat3 identity() {
        mat3 r;
        r.m[0] = 1; r.m[4] = 1; r.m[8] = 1;
        return r;
    }

    float& operator[](int i) { return m[i]; }
    const float& operator[](int i) const { return m[i]; }

    float& at(int col, int row) { return m[col * 3 + row]; }
    const float& at(int col, int row) const { return m[col * 3 + row]; }

    mat3 operator*(const mat3& o) const {
        mat3 r;
        for (int c = 0; c < 3; c++)
            for (int row = 0; row < 3; row++) {
                float sum = 0;
                for (int k = 0; k < 3; k++)
                    sum += at(k, row) * o.at(c, k);
                r.at(c, row) = sum;
            }
        return r;
    }

    const float* value_ptr() const { return m; }
};

inline const float* value_ptr(const mat3& m) { return m.value_ptr(); }

// --- mat4 (column-major, like GLSL) ---
struct mat4 {
    float m[16]; // column-major: m[col*4 + row]

    mat4() { std::memset(m, 0, sizeof(m)); }

    // Create diagonal matrix (scalar * identity)
    explicit mat4(float s) {
        std::memset(m, 0, sizeof(m));
        m[0] = s; m[5] = s; m[10] = s; m[15] = s;
    }

    static mat4 identity() {
        mat4 r;
        r.m[0] = 1; r.m[5] = 1; r.m[10] = 1; r.m[15] = 1;
        return r;
    }

    float& operator[](int i) { return m[i]; }
    const float& operator[](int i) const { return m[i]; }

    float& at(int col, int row) { return m[col * 4 + row]; }
    const float& at(int col, int row) const { return m[col * 4 + row]; }

    mat4 operator*(const mat4& o) const {
        mat4 r;
        for (int c = 0; c < 4; c++)
            for (int row = 0; row < 4; row++) {
                float sum = 0;
                for (int k = 0; k < 4; k++)
                    sum += at(k, row) * o.at(c, k);
                r.at(c, row) = sum;
            }
        return r;
    }

    vec4 operator*(const vec4& v) const {
        return {
            m[0]*v.x + m[4]*v.y + m[8]*v.z  + m[12]*v.w,
            m[1]*v.x + m[5]*v.y + m[9]*v.z  + m[13]*v.w,
            m[2]*v.x + m[6]*v.y + m[10]*v.z + m[14]*v.w,
            m[3]*v.x + m[7]*v.y + m[11]*v.z + m[15]*v.w
        };
    }

    vec3 operator*(const vec3& v) const {
        vec4 r = (*this) * vec4(v, 1.0f);
        return {r.x, r.y, r.z};
    }

    const float* value_ptr() const { return m; }
};

inline const float* value_ptr(const mat4& m) { return m.value_ptr(); }

// --- Matrix transformation functions ---
inline mat4 translate(const mat4& m, const vec3& v) {
    mat4 r = m;
    r.m[12] += v.x;
    r.m[13] += v.y;
    r.m[14] += v.z;
    return r;
}

inline mat4 scale(const mat4& m, const vec3& v) {
    mat4 r = m;
    r.m[0]  *= v.x;  r.m[1]  *= v.x;  r.m[2]  *= v.x;  r.m[3]  *= v.x;
    r.m[4]  *= v.y;  r.m[5]  *= v.y;  r.m[6]  *= v.y;  r.m[7]  *= v.y;
    r.m[8]  *= v.z;  r.m[9]  *= v.z;  r.m[10] *= v.z;  r.m[11] *= v.z;
    return r;
}

inline mat4 rotate(const mat4& m, float angle, const vec3& axis) {
    float c = std::cos(angle);
    float s = std::sin(angle);
    vec3 a = normalize(axis);
    float x = a.x, y = a.y, z = a.z;

    mat4 rot = mat4::identity();
    rot.m[0]  = x*x*(1-c)+c;
    rot.m[1]  = y*x*(1-c)+z*s;
    rot.m[2]  = z*x*(1-c)-y*s;

    rot.m[4]  = x*y*(1-c)-z*s;
    rot.m[5]  = y*y*(1-c)+c;
    rot.m[6]  = z*y*(1-c)+x*s;

    rot.m[8]  = x*z*(1-c)+y*s;
    rot.m[9]  = y*z*(1-c)-x*s;
    rot.m[10] = z*z*(1-c)+c;

    return m * rot;
}

// Note: parameters are named zNear/zFar (not near/far) because Windows
// headers define near/far as empty macros from the 16-bit era, which would
// break this header in any TU that includes winsock2.h/windows.h first.
inline mat4 perspective(float fovy, float aspect, float zNear, float zFar) {
    float f = 1.0f / std::tan(fovy / 2.0f);
    mat4 r;
    r.m[0]  = f / aspect;
    r.m[5]  = f;
    r.m[10] = (zFar + zNear) / (zNear - zFar);
    r.m[11] = -1.0f;
    r.m[14] = (2.0f * zFar * zNear) / (zNear - zFar);
    return r;
}

inline mat4 ortho(float left, float right, float bottom, float top, float zNear, float zFar) {
    mat4 r = mat4::identity();
    r.m[0]  = 2.0f / (right - left);
    r.m[5]  = 2.0f / (top - bottom);
    r.m[10] = -2.0f / (zFar - zNear);
    r.m[12] = -(right + left) / (right - left);
    r.m[13] = -(top + bottom) / (top - bottom);
    r.m[14] = -(zFar + zNear) / (zFar - zNear);
    return r;
}

inline mat4 lookAt(const vec3& eye, const vec3& center, const vec3& up) {
    vec3 f = normalize(center - eye);
    vec3 s = normalize(cross(f, normalize(up)));
    vec3 u = cross(s, f);

    mat4 r = mat4::identity();
    r.m[0]  = s.x;  r.m[1]  = u.x;  r.m[2]  = -f.x;
    r.m[4]  = s.y;  r.m[5]  = u.y;  r.m[6]  = -f.y;
    r.m[8]  = s.z;  r.m[9]  = u.z;  r.m[10] = -f.z;
    r.m[12] = -dot(s, eye);
    r.m[13] = -dot(u, eye);
    r.m[14] =  dot(f, eye);
    return r;
}

// --- Quaternion ---
struct quat {
    float x, y, z, w;
    quat() : x(0), y(0), z(0), w(1) {}
    quat(float x, float y, float z, float w) : x(x), y(y), z(z), w(w) {}

    /// Construct from Euler angles (pitch=X, yaw=Y, roll=Z) in radians.
    explicit quat(const vec3& euler) {
        float cx = std::cos(euler.x * 0.5f);
        float sx = std::sin(euler.x * 0.5f);
        float cy = std::cos(euler.y * 0.5f);
        float sy = std::sin(euler.y * 0.5f);
        float cz = std::cos(euler.z * 0.5f);
        float sz = std::sin(euler.z * 0.5f);
        x = sx * cy * cz - cx * sy * sz;
        y = cx * sy * cz + sx * cy * sz;
        z = cx * cy * sz - sx * sy * cz;
        w = cx * cy * cz + sx * sy * sz;
    }

    quat operator*(const quat& b) const {
        return quat(
            w * b.x + x * b.w + y * b.z - z * b.y,  // x
            w * b.y - x * b.z + y * b.w + z * b.x,  // y
            w * b.z + x * b.y - y * b.x + z * b.w,  // z
            w * b.w - x * b.x - y * b.y - z * b.z   // w
        );
    }

    /// Rotate a 3D vector by this quaternion.
    vec3 operator*(const vec3& v) const {
        vec3 qv(x, y, z);
        vec3 t = cross(qv, v) * 2.0f;
        return v + t * w + cross(qv, t);
    }

    quat operator+(const quat& b) const { return quat(x+b.x, y+b.y, z+b.z, w+b.w); }
    quat operator-(const quat& b) const { return quat(x-b.x, y-b.y, z-b.z, w-b.w); }
    quat operator-() const { return quat(-x, -y, -z, -w); }
    quat operator*(float s) const { return quat(x*s, y*s, z*s, w*s); }
};

inline quat operator*(float s, const quat& q) { return quat(s*q.x, s*q.y, s*q.z, s*q.w); }
inline float dot(const quat& a, const quat& b) {
    return a.x*b.x + a.y*b.y + a.z*b.z + a.w*b.w;
}

inline quat angleAxis(float angle, const vec3& axis) {
    vec3 a = normalize(axis);
    float s = std::sin(angle * 0.5f);
    return quat(a.x * s, a.y * s, a.z * s, std::cos(angle * 0.5f));
}

inline quat normalize(const quat& q) {
    float len = std::sqrt(q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w);
    if (len < EPSILON) return quat(0, 0, 0, 1);
    float inv = 1.0f / len;
    return quat(q.x * inv, q.y * inv, q.z * inv, q.w * inv);
}

/// Convert quaternion to Euler angles (pitch=X, yaw=Y, roll=Z) in radians.
inline vec3 eulerAngles(const quat& q) {
    // Roll (X-axis rotation)
    float sinr_cosp = 2.0f * (q.w * q.x + q.y * q.z);
    float cosr_cosp = 1.0f - 2.0f * (q.x * q.x + q.y * q.y);
    float roll = std::atan2(sinr_cosp, cosr_cosp);

    // Pitch (Y-axis rotation)
    float sinp = 2.0f * (q.w * q.y - q.z * q.x);
    float pitch;
    if (std::abs(sinp) >= 1.0f)
        pitch = std::copysign(PI / 2.0f, sinp);
    else
        pitch = std::asin(sinp);

    // Yaw (Z-axis rotation)
    float siny_cosp = 2.0f * (q.w * q.z + q.x * q.y);
    float cosy_cosp = 1.0f - 2.0f * (q.y * q.y + q.z * q.z);
    float yaw = std::atan2(siny_cosp, cosy_cosp);

    return vec3(roll, pitch, yaw);
}

inline mat4 mat4_cast(const quat& q) {
    float xx = q.x*q.x, yy = q.y*q.y, zz = q.z*q.z;
    float xy = q.x*q.y, xz = q.x*q.z, yz = q.y*q.z;
    float wx = q.w*q.x, wy = q.w*q.y, wz = q.w*q.z;

    mat4 r = mat4::identity();
    r.m[0]  = 1-2*(yy+zz);  r.m[1]  = 2*(xy+wz);   r.m[2]  = 2*(xz-wy);
    r.m[4]  = 2*(xy-wz);    r.m[5]  = 1-2*(xx+zz);  r.m[6]  = 2*(yz+wx);
    r.m[8]  = 2*(xz+wy);    r.m[9]  = 2*(yz-wx);    r.m[10] = 1-2*(xx+yy);
    return r;
}

} // namespace glm
