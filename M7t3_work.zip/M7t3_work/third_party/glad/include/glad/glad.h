/**
 * glad.h - Minimal OpenGL 3.3 Core Profile loader
 *
 * Self-contained replacement for the glad generator output.
 * Declares all OpenGL 3.3 core constants and function pointers,
 * and provides an initialization function that loads them via
 * the platform's native extension mechanism (WGL on Windows).
 *
 * Usage:
 *   1. Create OpenGL context (via GLFW)
 *   2. Call gladLoadGLLoader(glfwGetProcAddress)
 *   3. Use OpenGL functions normally
 */
#ifndef GLAD_GL_H_
#define GLAD_GL_H_

/* ---- Prevent Windows GL/gl.h from being included ---- */
/* These guards must come BEFORE any type definitions so that
   if another translation unit or header tries to #include <GL/gl.h>,
   the Windows SDK header will see these macros and skip its contents. */
#define __gl_h_
#define __GL_H__
#define __gltypes_h_
#define __glext_h_
#define __GLEXT_H_
#define __gl3_h_
#define __GL3_H__

/* ---- GLAPIENTRY calling convention ---- */
#ifndef GLAPIENTRY
  #ifdef _WIN32
    #define GLAPIENTRY __stdcall
  #else
    #define GLAPIENTRY
  #endif
#endif

#ifndef GLAPI
  #ifdef _WIN32
    #ifdef GLAD_GL_IMPLEMENTATION
      #define GLAPI __declspec(dllexport)
    #else
      #define GLAPI __declspec(dllimport)
    #endif
  #else
    #define GLAPI
  #endif
#endif

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---- GL Types ---- */
typedef void            GLvoid;
typedef unsigned int    GLenum;
typedef unsigned int    GLbitfield;
typedef float           GLfloat;
typedef double          GLdouble;
typedef int             GLint;
typedef int             GLsizei;
typedef unsigned int    GLuint;
typedef unsigned char   GLboolean;
typedef unsigned char   GLubyte;
typedef char            GLchar;
typedef int8_t          GLbyte;
typedef int16_t         GLshort;
typedef unsigned short  GLushort;
typedef ptrdiff_t       GLintptr;
typedef ptrdiff_t       GLsizeiptr;
typedef intptr_t        GLsync;

/* ---- GL Constants ---- */
#define GL_DEPTH_BUFFER_BIT               0x00000100
#define GL_STENCIL_BUFFER_BIT             0x00000400
#define GL_COLOR_BUFFER_BIT               0x00004000

#define GL_FALSE                          0
#define GL_TRUE                           1

#define GL_POINTS                         0x0000
#define GL_LINES                          0x0001
#define GL_LINE_LOOP                      0x0002
#define GL_LINE_STRIP                     0x0003
#define GL_TRIANGLES                      0x0004
#define GL_TRIANGLE_STRIP                 0x0005
#define GL_TRIANGLE_FAN                   0x0006

#define GL_NEVER                          0x0200
#define GL_LESS                           0x0201
#define GL_EQUAL                          0x0202
#define GL_LEQUAL                         0x0203
#define GL_GREATER                        0x0204
#define GL_NOTEQUAL                       0x0205
#define GL_GEQUAL                         0x0206
#define GL_ALWAYS                         0x0207

#define GL_ZERO                           0
#define GL_ONE                            1
#define GL_SRC_COLOR                      0x0300
#define GL_ONE_MINUS_SRC_COLOR            0x0301
#define GL_SRC_ALPHA                      0x0302
#define GL_ONE_MINUS_SRC_ALPHA            0x0303
#define GL_DST_ALPHA                      0x0304
#define GL_ONE_MINUS_DST_ALPHA            0x0305
#define GL_DST_COLOR                      0x0306
#define GL_ONE_MINUS_DST_COLOR            0x0307
#define GL_SRC_ALPHA_SATURATE             0x0308

#define GL_NONE                           0
#define GL_FRONT                          0x0404
#define GL_BACK                           0x0405
#define GL_FRONT_AND_BACK                 0x0408

#define GL_INVALID_ENUM                   0x0500
#define GL_INVALID_VALUE                  0x0501
#define GL_INVALID_OPERATION              0x0502

#define GL_PACK_ALIGNMENT                 0x0D05
#define GL_OUT_OF_MEMORY                  0x0505

#define GL_CW                             0x0900
#define GL_CCW                            0x0901

#define GL_LINE_WIDTH                     0x0B21
#define GL_CULL_FACE                      0x0B44
#define GL_CULL_FACE_MODE                 0x0B45
#define GL_FRONT_FACE                     0x0B46
#define GL_DEPTH_RANGE                    0x0B70
#define GL_DEPTH_TEST                     0x0B71
#define GL_DEPTH_WRITEMASK                0x0B72
#define GL_DEPTH_CLEAR_VALUE              0x0B73
#define GL_DEPTH_FUNC                     0x0B74

#define GL_STENCIL_TEST                   0x0B90
#define GL_DITHER                         0x0BD0

#define GL_BLEND                          0x0BE2
#define GL_SCISSOR_TEST                   0x0C11
#define GL_VIEWPORT                       0x0BA2
#define GL_SCISSOR_BOX                    0x0C10

#define GL_BLEND_SRC                      0x0BE1
#define GL_BLEND_DST                      0x0BE0
#define GL_BLEND_EQUATION                 0x8009

#define GL_BLEND_EQUATION_RGB             GL_BLEND_EQUATION
#define GL_BLEND_EQUATION_ALPHA           0x883D
#define GL_BLEND_SRC_RGB                  0x80C9
#define GL_BLEND_SRC_ALPHA                0x80CB
#define GL_BLEND_DST_RGB                  0x80C8
#define GL_BLEND_DST_ALPHA                0x80CA

#define GL_FUNC_ADD                       0x8006
#define GL_FUNC_SUBTRACT                  0x800A
#define GL_FUNC_REVERSE_SUBTRACT          0x800B

#define GL_TEXTURE_2D                     0x0DE1
#define GL_TEXTURE_BINDING_2D             0x8069

#define GL_TEXTURE0                       0x84C0
#define GL_TEXTURE1                       0x84C1
#define GL_TEXTURE2                       0x84C2
#define GL_TEXTURE3                       0x84C3
#define GL_ACTIVE_TEXTURE                 0x84E0

#define GL_NEAREST                        0x2600
#define GL_LINEAR                         0x2601
#define GL_NEAREST_MIPMAP_NEAREST         0x2700
#define GL_LINEAR_MIPMAP_NEAREST          0x2701
#define GL_NEAREST_MIPMAP_LINEAR          0x2702
#define GL_LINEAR_MIPMAP_LINEAR           0x2703

#define GL_TEXTURE_MIN_FILTER             0x2801
#define GL_TEXTURE_MAG_FILTER             0x2800
#define GL_TEXTURE_WRAP_S                 0x2802
#define GL_TEXTURE_WRAP_T                 0x2803
#define GL_TEXTURE_WRAP_R                 0x8072

#define GL_CLAMP_TO_EDGE                  0x812F
#define GL_REPEAT                         0x2901
#define GL_MIRRORED_REPEAT                0x8370

#define GL_MAX_TEXTURE_SIZE               0x0D33
#define GL_MAX_VERTEX_ATTRIBS             0x8869
#define GL_MAX_FRAGMENT_UNIFORM_COMPONENTS 0x8B18

#define GL_VENDOR                         0x1F00
#define GL_RENDERER                       0x1F01
#define GL_VERSION                        0x1F02
#define GL_SHADING_LANGUAGE_VERSION       0x8B8C
#define GL_EXTENSIONS                     0x1F03

#define GL_NO_ERROR                       0

#define GL_CURRENT_PROGRAM                0x8B8D

#define GL_FRAMEBUFFER                    0x8D40
#define GL_RENDERBUFFER                   0x8D41
#define GL_COLOR_ATTACHMENT0              0x8CE0
#define GL_DEPTH_ATTACHMENT               0x8D00
#define GL_FRAMEBUFFER_COMPLETE           0x8CD5
#define GL_FRAMEBUFFER_BINDING            0x8CA6
#define GL_RENDERBUFFER_BINDING           0x8CA7

#define GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS 0x8B4D

#define GL_VERTEX_SHADER                  0x8B31
#define GL_FRAGMENT_SHADER                0x8B30
#define GL_GEOMETRY_SHADER                0x8DD9

#define GL_COMPILE_STATUS                 0x8B81
#define GL_LINK_STATUS                    0x8B82
#define GL_VALIDATE_STATUS                0x8B83
#define GL_INFO_LOG_LENGTH                0x8B84

#define GL_ARRAY_BUFFER                   0x8892
#define GL_ELEMENT_ARRAY_BUFFER           0x8893
#define GL_UNIFORM_BUFFER                 0x8A11
#define GL_STATIC_DRAW                    0x88E4
#define GL_DYNAMIC_DRAW                   0x88E8
#define GL_STREAM_DRAW                    0x88E0

#define GL_VERTEX_ARRAY_BINDING           0x85B5
#define GL_BUFFER_SIZE                    0x8764
#define GL_BUFFER_USAGE                   0x8765

#define GL_FLOAT                          0x1406
#define GL_INT                            0x1404
#define GL_UNSIGNED_INT                   0x1405
#define GL_UNSIGNED_BYTE                  0x1401
#define GL_BYTE                           0x1400
#define GL_SHORT                          0x1402
#define GL_UNSIGNED_SHORT                 0x1403

#define GL_RED                            0x1903
#define GL_RGB                            0x1907
#define GL_RGBA                           0x1908
#define GL_R8                             0x8229
#define GL_RG8                            0x822B
#define GL_RGB8                           0x8051
#define GL_RGBA8                          0x8058
#define GL_SRGB8                          0x8F41
#define GL_SRGB8_ALPHA8                   0x8C43
#define GL_RED_INTEGER                    0x8D94
#define GL_DEPTH_COMPONENT                0x1902
#define GL_DEPTH_COMPONENT16              0x81A5
#define GL_DEPTH_COMPONENT24              0x81A6
#define GL_DEPTH_COMPONENT32F             0x8CAC
#define GL_STENCIL_INDEX                  0x1901
#define GL_DEPTH_STENCIL                  0x84F9

#define GL_FRAGMENT_SHADER_DERIVATIVE_HINT 0x8B8B

#define GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS  0x8B4C
#define GL_MAX_DRAW_BUFFERS               0x8824

#define GL_DRAW_FRAMEBUFFER               0x8CA9
#define GL_READ_FRAMEBUFFER               0x8CA8

#define GL_POLYGON_MODE                   0x0B40
#define GL_LINE                           0x1B01
#define GL_FILL                           0x1B02
#define GL_POINT                          0x1B00

/* ---- Instancing / HDR / Cubemap / Shadow constants (GL 3.3 core) ---- */
#define GL_TEXTURE_CUBE_MAP               0x8513
#define GL_TEXTURE_CUBE_MAP_POSITIVE_X     0x8515
#define GL_TEXTURE_CUBE_MAP_NEGATIVE_X     0x8516
#define GL_TEXTURE_CUBE_MAP_POSITIVE_Y     0x8517
#define GL_TEXTURE_CUBE_MAP_NEGATIVE_Y     0x8518
#define GL_TEXTURE_CUBE_MAP_POSITIVE_Z     0x8519
#define GL_TEXTURE_CUBE_MAP_NEGATIVE_Z     0x851A
#define GL_RGBA16F                        0x881A
#define GL_RGB16F                         0x881B
#define GL_HALF_FLOAT                     0x140B
#define GL_FLOAT_VEC3                     0x8B51
#define GL_POLYGON_OFFSET_FILL            0x8037
#define GL_POLYGON_OFFSET_UNITS           0x2A00
#define GL_POLYGON_OFFSET_FACTOR          0x8038
#define GL_CLAMP_TO_BORDER                0x812D
#define GL_TEXTURE_BORDER_COLOR           0x1004
#define GL_TEXTURE_COMPARE_MODE           0x884C
#define GL_TEXTURE_COMPARE_FUNC           0x884D
#define GL_COMPARE_REF_TO_TEXTURE         0x884E
#define GL_TEXTURE_LOD_BIAS               0x8501
#define GL_TEXTURE_MAX_LEVEL              0x813D

/* ---- GL Function Pointer Typedefs ---- */
/* These use GLAPIENTRY (__stdcall on Windows) for correct calling convention */
typedef void   (GLAPIENTRY *glGenBuffers_t)(GLsizei, GLuint*);
typedef void   (GLAPIENTRY *glDeleteBuffers_t)(GLsizei, const GLuint*);
typedef void   (GLAPIENTRY *glBindBuffer_t)(GLenum, GLuint);
typedef void   (GLAPIENTRY *glBufferData_t)(GLenum, GLsizeiptr, const void*, GLenum);
typedef void   (GLAPIENTRY *glBufferSubData_t)(GLenum, GLintptr, GLsizeiptr, const void*);
typedef void   (GLAPIENTRY *glGenVertexArrays_t)(GLsizei, GLuint*);
typedef void   (GLAPIENTRY *glDeleteVertexArrays_t)(GLsizei, const GLuint*);
typedef void   (GLAPIENTRY *glBindVertexArray_t)(GLuint);
typedef void   (GLAPIENTRY *glEnableVertexAttribArray_t)(GLuint);
typedef void   (GLAPIENTRY *glDisableVertexAttribArray_t)(GLuint);
typedef void   (GLAPIENTRY *glVertexAttribPointer_t)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*);
typedef void   (GLAPIENTRY *glVertexAttribIPointer_t)(GLuint, GLint, GLenum, GLsizei, const void*);
typedef GLuint (GLAPIENTRY *glCreateShader_t)(GLenum);
typedef void   (GLAPIENTRY *glShaderSource_t)(GLuint, GLsizei, const GLchar* const*, const GLint*);
typedef void   (GLAPIENTRY *glCompileShader_t)(GLuint);
typedef void   (GLAPIENTRY *glDeleteShader_t)(GLuint);
typedef void   (GLAPIENTRY *glGetShaderiv_t)(GLuint, GLenum, GLint*);
typedef void   (GLAPIENTRY *glGetShaderInfoLog_t)(GLuint, GLsizei, GLsizei*, GLchar*);
typedef GLuint (GLAPIENTRY *glCreateProgram_t)(void);
typedef void   (GLAPIENTRY *glAttachShader_t)(GLuint, GLuint);
typedef void   (GLAPIENTRY *glLinkProgram_t)(GLuint);
typedef void   (GLAPIENTRY *glUseProgram_t)(GLuint);
typedef void   (GLAPIENTRY *glDeleteProgram_t)(GLuint);
typedef void   (GLAPIENTRY *glGetProgramiv_t)(GLuint, GLenum, GLint*);
typedef void   (GLAPIENTRY *glGetProgramInfoLog_t)(GLuint, GLsizei, GLsizei*, GLchar*);
typedef GLint  (GLAPIENTRY *glGetAttribLocation_t)(GLuint, const GLchar*);
typedef GLint  (GLAPIENTRY *glGetUniformLocation_t)(GLuint, const GLchar*);
typedef void   (GLAPIENTRY *glUniform1f_t)(GLint, GLfloat);
typedef void   (GLAPIENTRY *glUniform2f_t)(GLint, GLfloat, GLfloat);
typedef void   (GLAPIENTRY *glUniform3f_t)(GLint, GLfloat, GLfloat, GLfloat);
typedef void   (GLAPIENTRY *glUniform4f_t)(GLint, GLfloat, GLfloat, GLfloat, GLfloat);
typedef void   (GLAPIENTRY *glUniform1i_t)(GLint, GLint);
typedef void   (GLAPIENTRY *glUniform2i_t)(GLint, GLint, GLint);
typedef void   (GLAPIENTRY *glUniform3i_t)(GLint, GLint, GLint, GLint);
typedef void   (GLAPIENTRY *glUniform4i_t)(GLint, GLint, GLint, GLint, GLint);
typedef void   (GLAPIENTRY *glUniformMatrix4fv_t)(GLint, GLsizei, GLboolean, const GLfloat*);
typedef void   (GLAPIENTRY *glUniformMatrix3fv_t)(GLint, GLsizei, GLboolean, const GLfloat*);
typedef void   (GLAPIENTRY *glGenTextures_t)(GLsizei, GLuint*);
typedef void   (GLAPIENTRY *glDeleteTextures_t)(GLsizei, const GLuint*);
typedef void   (GLAPIENTRY *glBindTexture_t)(GLenum, GLuint);
typedef void   (GLAPIENTRY *glTexImage2D_t)(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*);
typedef void   (GLAPIENTRY *glTexParameteri_t)(GLenum, GLenum, GLint);
typedef void   (GLAPIENTRY *glTexParameterf_t)(GLenum, GLenum, GLfloat);
typedef void   (GLAPIENTRY *glTexParameterfv_t)(GLenum, GLenum, const GLfloat*);
typedef void   (GLAPIENTRY *glGenerateMipmap_t)(GLenum);
typedef void   (GLAPIENTRY *glActiveTexture_t)(GLenum);
typedef void   (GLAPIENTRY *glBindBufferBase_t)(GLenum, GLuint, GLuint);
typedef void   (GLAPIENTRY *glDrawArrays_t)(GLenum, GLint, GLsizei);
typedef void   (GLAPIENTRY *glDrawElements_t)(GLenum, GLsizei, GLenum, const void*);
typedef void   (GLAPIENTRY *glViewport_t)(GLint, GLint, GLsizei, GLsizei);
typedef void   (GLAPIENTRY *glScissor_t)(GLint, GLint, GLsizei, GLsizei);
typedef void   (GLAPIENTRY *glClearColor_t)(GLfloat, GLfloat, GLfloat, GLfloat);
typedef void   (GLAPIENTRY *glClear_t)(GLbitfield);
typedef void   (GLAPIENTRY *glClearDepthf_t)(GLfloat);
typedef void   (GLAPIENTRY *glEnable_t)(GLenum);
typedef void   (GLAPIENTRY *glDisable_t)(GLenum);
typedef void   (GLAPIENTRY *glBlendFunc_t)(GLenum, GLenum);
typedef void   (GLAPIENTRY *glBlendFunci_t)(GLenum, GLenum, GLenum, GLenum);
typedef void   (GLAPIENTRY *glBlendEquation_t)(GLenum);
typedef void   (GLAPIENTRY *glDepthFunc_t)(GLenum);
typedef void   (GLAPIENTRY *glDepthMask_t)(GLboolean);
typedef void   (GLAPIENTRY *glColorMask_t)(GLboolean, GLboolean, GLboolean, GLboolean);
typedef void   (GLAPIENTRY *glTexSubImage2D_t)(GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, const void*);
typedef void   (GLAPIENTRY *glCullFace_t)(GLenum);
typedef void   (GLAPIENTRY *glFrontFace_t)(GLenum);
typedef void   (GLAPIENTRY *glPolygonMode_t)(GLenum, GLenum);
typedef void   (GLAPIENTRY *glPixelStorei_t)(GLenum, GLint);
typedef GLenum (GLAPIENTRY *glGetError_t)(void);
typedef void   (GLAPIENTRY *glGetBufferParameteriv_t)(GLenum, GLenum, GLint*);
typedef void   (GLAPIENTRY *glReadPixels_t)(GLenum, GLenum, GLsizei, GLsizei, GLenum, GLenum, void*);
typedef void   (GLAPIENTRY *glGetVertexAttribiv_t)(GLuint, GLenum, GLint*);
typedef const GLubyte* (GLAPIENTRY *glGetString_t)(GLenum);
typedef void   (GLAPIENTRY *glGetIntegerv_t)(GLenum, GLint*);
typedef void   (GLAPIENTRY *glGetFloatv_t)(GLenum, GLfloat*);
typedef void   (GLAPIENTRY *glFlush_t)(void);
typedef void   (GLAPIENTRY *glFinish_t)(void);
typedef GLboolean (GLAPIENTRY *glIsEnabled_t)(GLenum);
typedef void   (GLAPIENTRY *glDrawElementsInstanced_t)(GLenum, GLsizei, GLenum, const void*, GLsizei);
typedef void   (GLAPIENTRY *glDrawArraysInstanced_t)(GLenum, GLint, GLsizei, GLsizei);
typedef void   (GLAPIENTRY *glVertexAttribDivisor_t)(GLuint, GLuint);
typedef void   (GLAPIENTRY *glUniform1fv_t)(GLint, GLsizei, const GLfloat*);
typedef void   (GLAPIENTRY *glUniform3fv_t)(GLint, GLsizei, const GLfloat*);
typedef void   (GLAPIENTRY *glUniform4fv_t)(GLint, GLsizei, const GLfloat*);
typedef void   (GLAPIENTRY *glUniform1iv_t)(GLint, GLsizei, const GLint*);
typedef void   (GLAPIENTRY *glPolygonOffset_t)(GLfloat, GLfloat);
typedef void   (GLAPIENTRY *glDrawBuffer_t)(GLenum);
typedef void   (GLAPIENTRY *glDrawBuffers_t)(GLsizei, const GLenum*);
typedef void   (GLAPIENTRY *glFramebufferTextureLayer_t)(GLenum, GLenum, GLuint, GLint, GLint);
typedef void   (GLAPIENTRY *glGenFramebuffers_t)(GLsizei, GLuint*);
typedef void   (GLAPIENTRY *glBindFramebuffer_t)(GLenum, GLuint);
typedef void   (GLAPIENTRY *glDeleteFramebuffers_t)(GLsizei, const GLuint*);
typedef GLenum (GLAPIENTRY *glCheckFramebufferStatus_t)(GLenum);
typedef void   (GLAPIENTRY *glFramebufferTexture2D_t)(GLenum, GLenum, GLenum, GLuint, GLint);

/* ---- GL Function Pointer Declarations ---- */
#define GLAD_GL_PFN(name) extern name##_t name

GLAD_GL_PFN(glGenBuffers);
GLAD_GL_PFN(glDeleteBuffers);
GLAD_GL_PFN(glBindBuffer);
GLAD_GL_PFN(glBufferData);
GLAD_GL_PFN(glBufferSubData);
GLAD_GL_PFN(glGenVertexArrays);
GLAD_GL_PFN(glDeleteVertexArrays);
GLAD_GL_PFN(glBindVertexArray);
GLAD_GL_PFN(glEnableVertexAttribArray);
GLAD_GL_PFN(glDisableVertexAttribArray);
GLAD_GL_PFN(glVertexAttribPointer);
GLAD_GL_PFN(glVertexAttribIPointer);
GLAD_GL_PFN(glCreateShader);
GLAD_GL_PFN(glShaderSource);
GLAD_GL_PFN(glCompileShader);
GLAD_GL_PFN(glDeleteShader);
GLAD_GL_PFN(glGetShaderiv);
GLAD_GL_PFN(glGetShaderInfoLog);
GLAD_GL_PFN(glCreateProgram);
GLAD_GL_PFN(glAttachShader);
GLAD_GL_PFN(glLinkProgram);
GLAD_GL_PFN(glUseProgram);
GLAD_GL_PFN(glDeleteProgram);
GLAD_GL_PFN(glGetProgramiv);
GLAD_GL_PFN(glGetProgramInfoLog);
GLAD_GL_PFN(glGetAttribLocation);
GLAD_GL_PFN(glGetUniformLocation);
GLAD_GL_PFN(glUniform1f);
GLAD_GL_PFN(glUniform2f);
GLAD_GL_PFN(glUniform3f);
GLAD_GL_PFN(glUniform4f);
GLAD_GL_PFN(glUniform1i);
GLAD_GL_PFN(glUniform2i);
GLAD_GL_PFN(glUniform3i);
GLAD_GL_PFN(glUniform4i);
GLAD_GL_PFN(glUniformMatrix4fv);
GLAD_GL_PFN(glUniformMatrix3fv);
GLAD_GL_PFN(glGenTextures);
GLAD_GL_PFN(glDeleteTextures);
GLAD_GL_PFN(glBindTexture);
GLAD_GL_PFN(glTexImage2D);
GLAD_GL_PFN(glTexParameteri);
GLAD_GL_PFN(glTexParameterf);
GLAD_GL_PFN(glTexParameterfv);
GLAD_GL_PFN(glGenerateMipmap);
GLAD_GL_PFN(glActiveTexture);
GLAD_GL_PFN(glBindBufferBase);
GLAD_GL_PFN(glDrawArrays);
GLAD_GL_PFN(glDrawElements);
GLAD_GL_PFN(glViewport);
GLAD_GL_PFN(glScissor);
GLAD_GL_PFN(glClearColor);
GLAD_GL_PFN(glClear);
GLAD_GL_PFN(glClearDepthf);
GLAD_GL_PFN(glEnable);
GLAD_GL_PFN(glDisable);
GLAD_GL_PFN(glBlendFunc);
GLAD_GL_PFN(glBlendFunci);
GLAD_GL_PFN(glBlendEquation);
GLAD_GL_PFN(glDepthFunc);
GLAD_GL_PFN(glDepthMask);
GLAD_GL_PFN(glColorMask);
GLAD_GL_PFN(glTexSubImage2D);
GLAD_GL_PFN(glCullFace);
GLAD_GL_PFN(glFrontFace);
GLAD_GL_PFN(glPolygonMode);
GLAD_GL_PFN(glPixelStorei);
GLAD_GL_PFN(glGetError);
GLAD_GL_PFN(glGetBufferParameteriv);
GLAD_GL_PFN(glReadPixels);
GLAD_GL_PFN(glGetVertexAttribiv);
GLAD_GL_PFN(glGetString);
GLAD_GL_PFN(glGetIntegerv);
GLAD_GL_PFN(glGetFloatv);
GLAD_GL_PFN(glFlush);
GLAD_GL_PFN(glFinish);
GLAD_GL_PFN(glIsEnabled);
GLAD_GL_PFN(glDrawElementsInstanced);
GLAD_GL_PFN(glDrawArraysInstanced);
GLAD_GL_PFN(glVertexAttribDivisor);
GLAD_GL_PFN(glUniform1fv);
GLAD_GL_PFN(glUniform3fv);
GLAD_GL_PFN(glUniform4fv);
GLAD_GL_PFN(glUniform1iv);
GLAD_GL_PFN(glPolygonOffset);
GLAD_GL_PFN(glDrawBuffer);
GLAD_GL_PFN(glDrawBuffers);
GLAD_GL_PFN(glFramebufferTextureLayer);
GLAD_GL_PFN(glGenFramebuffers);
GLAD_GL_PFN(glBindFramebuffer);
GLAD_GL_PFN(glDeleteFramebuffers);
GLAD_GL_PFN(glCheckFramebufferStatus);
GLAD_GL_PFN(glFramebufferTexture2D);

#undef GLAD_GL_PFN

/* ---- Loader Function Type ---- */
typedef void* (*GLADloadproc)(const char* name);

/// Load OpenGL functions using the given loader (e.g. glfwGetProcAddress).
/// Returns 1 on success, 0 on failure.
int gladLoadGLLoader(GLADloadproc load);

/// Returns the OpenGL major version loaded.
int gladGetGLVersion(void);

#ifdef __cplusplus
}
#endif

#endif /* GLAD_GL_H_ */
