/**
 * glad.c - Minimal OpenGL 3.3 Core Profile loader implementation
 *
 * Loads OpenGL function pointers via a user-provided loader function
 * (typically glfwGetProcAddress).
 */
#define GLAD_GL_IMPLEMENTATION
#include "glad/glad.h"

/* Define function pointer instances */
#define GLAD_GL_IMPL(name) name##_t name = NULL

GLAD_GL_IMPL(glGenBuffers);
GLAD_GL_IMPL(glDeleteBuffers);
GLAD_GL_IMPL(glBindBuffer);
GLAD_GL_IMPL(glBufferData);
GLAD_GL_IMPL(glBufferSubData);
GLAD_GL_IMPL(glGenVertexArrays);
GLAD_GL_IMPL(glDeleteVertexArrays);
GLAD_GL_IMPL(glBindVertexArray);
GLAD_GL_IMPL(glEnableVertexAttribArray);
GLAD_GL_IMPL(glDisableVertexAttribArray);
GLAD_GL_IMPL(glVertexAttribPointer);
GLAD_GL_IMPL(glVertexAttribIPointer);
GLAD_GL_IMPL(glCreateShader);
GLAD_GL_IMPL(glShaderSource);
GLAD_GL_IMPL(glCompileShader);
GLAD_GL_IMPL(glDeleteShader);
GLAD_GL_IMPL(glGetShaderiv);
GLAD_GL_IMPL(glGetShaderInfoLog);
GLAD_GL_IMPL(glCreateProgram);
GLAD_GL_IMPL(glAttachShader);
GLAD_GL_IMPL(glLinkProgram);
GLAD_GL_IMPL(glUseProgram);
GLAD_GL_IMPL(glDeleteProgram);
GLAD_GL_IMPL(glGetProgramiv);
GLAD_GL_IMPL(glGetProgramInfoLog);
GLAD_GL_IMPL(glGetAttribLocation);
GLAD_GL_IMPL(glGetUniformLocation);
GLAD_GL_IMPL(glUniform1f);
GLAD_GL_IMPL(glUniform2f);
GLAD_GL_IMPL(glUniform3f);
GLAD_GL_IMPL(glUniform4f);
GLAD_GL_IMPL(glUniform1i);
GLAD_GL_IMPL(glUniform2i);
GLAD_GL_IMPL(glUniform3i);
GLAD_GL_IMPL(glUniform4i);
GLAD_GL_IMPL(glUniformMatrix4fv);
GLAD_GL_IMPL(glUniformMatrix3fv);
GLAD_GL_IMPL(glGenTextures);
GLAD_GL_IMPL(glDeleteTextures);
GLAD_GL_IMPL(glBindTexture);
GLAD_GL_IMPL(glTexImage2D);
GLAD_GL_IMPL(glTexParameteri);
GLAD_GL_IMPL(glTexParameterf);
GLAD_GL_IMPL(glTexParameterfv);
GLAD_GL_IMPL(glGenerateMipmap);
GLAD_GL_IMPL(glActiveTexture);
GLAD_GL_IMPL(glBindBufferBase);
GLAD_GL_IMPL(glDrawArrays);
GLAD_GL_IMPL(glDrawElements);
GLAD_GL_IMPL(glViewport);
GLAD_GL_IMPL(glScissor);
GLAD_GL_IMPL(glClearColor);
GLAD_GL_IMPL(glClear);
GLAD_GL_IMPL(glClearDepthf);
GLAD_GL_IMPL(glEnable);
GLAD_GL_IMPL(glDisable);
GLAD_GL_IMPL(glBlendFunc);
GLAD_GL_IMPL(glBlendFunci);
GLAD_GL_IMPL(glBlendEquation);
GLAD_GL_IMPL(glDepthFunc);
GLAD_GL_IMPL(glDepthMask);
GLAD_GL_IMPL(glColorMask);
GLAD_GL_IMPL(glTexSubImage2D);
GLAD_GL_IMPL(glCullFace);
GLAD_GL_IMPL(glFrontFace);
GLAD_GL_IMPL(glPolygonMode);
GLAD_GL_IMPL(glPixelStorei);
GLAD_GL_IMPL(glGetError);
GLAD_GL_IMPL(glGetBufferParameteriv);
GLAD_GL_IMPL(glReadPixels);
GLAD_GL_IMPL(glGetVertexAttribiv);
GLAD_GL_IMPL(glGetString);
GLAD_GL_IMPL(glGetIntegerv);
GLAD_GL_IMPL(glGetFloatv);
GLAD_GL_IMPL(glFlush);
GLAD_GL_IMPL(glFinish);
GLAD_GL_IMPL(glIsEnabled);
GLAD_GL_IMPL(glDrawElementsInstanced);
GLAD_GL_IMPL(glDrawArraysInstanced);
GLAD_GL_IMPL(glVertexAttribDivisor);
GLAD_GL_IMPL(glUniform1fv);
GLAD_GL_IMPL(glUniform3fv);
GLAD_GL_IMPL(glUniform4fv);
GLAD_GL_IMPL(glUniform1iv);
GLAD_GL_IMPL(glPolygonOffset);
GLAD_GL_IMPL(glDrawBuffer);
GLAD_GL_IMPL(glDrawBuffers);
GLAD_GL_IMPL(glFramebufferTextureLayer);
GLAD_GL_IMPL(glGenFramebuffers);
GLAD_GL_IMPL(glBindFramebuffer);
GLAD_GL_IMPL(glDeleteFramebuffers);
GLAD_GL_IMPL(glCheckFramebufferStatus);
GLAD_GL_IMPL(glFramebufferTexture2D);

#undef GLAD_GL_IMPL

static int gl_version_loaded = 0;

int gladGetGLVersion(void) {
    return gl_version_loaded;
}

int gladLoadGLLoader(GLADloadproc load) {
    if (!load) return 0;

    /* Load all 3.3 core functions */
    #define LOAD(name) name = (name##_t)load(#name)

    LOAD(glGenBuffers);
    LOAD(glDeleteBuffers);
    LOAD(glBindBuffer);
    LOAD(glBufferData);
    LOAD(glBufferSubData);
    LOAD(glGenVertexArrays);
    LOAD(glDeleteVertexArrays);
    LOAD(glBindVertexArray);
    LOAD(glEnableVertexAttribArray);
    LOAD(glDisableVertexAttribArray);
    LOAD(glVertexAttribPointer);
    LOAD(glVertexAttribIPointer);
    LOAD(glCreateShader);
    LOAD(glShaderSource);
    LOAD(glCompileShader);
    LOAD(glDeleteShader);
    LOAD(glGetShaderiv);
    LOAD(glGetShaderInfoLog);
    LOAD(glCreateProgram);
    LOAD(glAttachShader);
    LOAD(glLinkProgram);
    LOAD(glUseProgram);
    LOAD(glDeleteProgram);
    LOAD(glGetProgramiv);
    LOAD(glGetProgramInfoLog);
    LOAD(glGetAttribLocation);
    LOAD(glGetUniformLocation);
    LOAD(glUniform1f);
    LOAD(glUniform2f);
    LOAD(glUniform3f);
    LOAD(glUniform4f);
    LOAD(glUniform1i);
    LOAD(glUniform2i);
    LOAD(glUniform3i);
    LOAD(glUniform4i);
    LOAD(glUniformMatrix4fv);
    LOAD(glUniformMatrix3fv);
    LOAD(glGenTextures);
    LOAD(glDeleteTextures);
    LOAD(glBindTexture);
    LOAD(glTexImage2D);
    LOAD(glTexParameteri);
    LOAD(glTexParameterf);
    LOAD(glTexParameterfv);
    LOAD(glGenerateMipmap);
    LOAD(glActiveTexture);
    LOAD(glBindBufferBase);
    LOAD(glDrawArrays);
    LOAD(glDrawElements);
    LOAD(glViewport);
    LOAD(glScissor);
    LOAD(glClearColor);
    LOAD(glClear);
    LOAD(glClearDepthf);
    LOAD(glEnable);
    LOAD(glDisable);
    LOAD(glBlendFunc);
    LOAD(glBlendFunci);
    LOAD(glBlendEquation);
    LOAD(glDepthFunc);
    LOAD(glDepthMask);
    LOAD(glColorMask);
    LOAD(glTexSubImage2D);
    LOAD(glCullFace);
    LOAD(glFrontFace);
    LOAD(glPolygonMode);
    LOAD(glPixelStorei);
    LOAD(glGetError);
    LOAD(glGetBufferParameteriv);
    LOAD(glReadPixels);
    LOAD(glGetVertexAttribiv);
    LOAD(glGetString);
    LOAD(glGetIntegerv);
    LOAD(glGetFloatv);
    LOAD(glFlush);
    LOAD(glFinish);
    LOAD(glIsEnabled);
    LOAD(glDrawElementsInstanced);
    LOAD(glDrawArraysInstanced);
    LOAD(glVertexAttribDivisor);
    LOAD(glUniform1fv);
    LOAD(glUniform3fv);
    LOAD(glUniform4fv);
    LOAD(glUniform1iv);
    LOAD(glPolygonOffset);
    LOAD(glDrawBuffer);
    LOAD(glDrawBuffers);
    LOAD(glFramebufferTextureLayer);
    LOAD(glGenFramebuffers);
    LOAD(glBindFramebuffer);
    LOAD(glDeleteFramebuffers);
    LOAD(glCheckFramebufferStatus);
    LOAD(glFramebufferTexture2D);

    #undef LOAD

    /* Verify critical functions loaded */
    if (!glGenBuffers || !glBindBuffer || !glBufferData ||
        !glGenVertexArrays || !glBindVertexArray ||
        !glCreateShader || !glCreateProgram || !glUseProgram ||
        !glDrawArrays || !glDrawElements) {
        return 0;
    }

    gl_version_loaded = 33; /* OpenGL 3.3 */
    return 1;
}
